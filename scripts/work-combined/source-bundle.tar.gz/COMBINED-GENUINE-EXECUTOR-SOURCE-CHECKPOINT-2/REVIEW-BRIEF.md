# Bounded actual review request

Actual source1 Opus review used 13 turns and returned CHANGES B1. It did not read source1 README, TESTPLAN, ACTIVE-VARIANT-DIFF, HISTORY-ROOT-LIMIT, role profile or the variant files. No runtime proof was supplied. The complete receipt is preserved under premise/.

Review correction2 combined_executor.py, CORRECTION.patch, the nine new tests and before-after counterexample evidence. Confirm tag persistence before startup/wait, unique monitor identity, complete pg_stat_activity visibility, database/login and cluster scope, finite overall/per-call budgets, no terminating connections, and refusal to classify a live/unknown backend. Trace late COMMIT while the client has died but the server still retains its transaction and locks. Verify the original primary failure and every cleanup failure remain separately recorded.

Also read the previously unread source1 README.md, TESTPLAN.json, ACTIVE-VARIANT-DIFF.patch and HISTORY-ROOT-LIMIT.json, along with this README and HANDOFF. Inspect role-parity and variant construction evidence to the degree needed to close the earlier read-scope limit. The unchanged candidate and reader source retain their prior held-source approvals; do not infer any runtime result from them.

Package contract: source1 and correction2 are immutable sibling directories. Source1's fixed manifest and all 188 file hashes must match before contact. Correction2 main/test/profile require external root pins. No mutable links, absolute workspace authority or overlay that alters source1 is supported.

Return a bounded source verdict. No SQL, DB, provider, workflow enrollment, repository mutation or actual fixture execution is authorized by this review request. All existing owner/provider/full20/42/65 and inactive-root historical recovery holds remain open.
