# Correction 2: wait for the server before classifying an uncertain install

This is an output-only source correction for actual Opus finding B1. The old source killed the local psql process on timeout and could then read the old catalog while the PostgreSQL backend still held an uncommitted installation. That backend could later commit. A local process ending was therefore insufficient evidence of rollback.

Every new executor Runner call now receives a unique startup `PGAPPNAME` of `forge-combined-` plus a 32-character random hex identifier. The exact tag, database, login, purpose, SQL hash and process budget are saved before the subprocess wait. Inherited PG environment values are removed. The unchanged pinned predecessor scripts retain their own original behavior; their internal connections are not rewritten by this correction.

Before classifying an uncertain combined install, cleanup locates exactly one recorded installation call. A fresh administrator connection checks `pg_stat_activity` for the complete tag. It does not terminate or cancel anything. Each monitor has a separate unique tag, queries the intended database, verifies actual session/current role is supabase_admin with superuser visibility, and confirms the original system identifier and postmaster start. Any matching backend must have the exact intended database/login. Unknown or malformed evidence fails closed.

The monitor allows at most 15 seconds overall. Each child process gets at most 5 seconds and no more than the remaining overall budget. Monitor statements/locks use at most 2 seconds, capped further by the remaining process budget; inherited authenticated 8-second limits and the existing normal 20/12-second inspection limits remain unchanged. Samples use separate fresh connections and are retained before the next pause. No monitor connection shares the installing transaction or its catalog snapshot. Monitor time is separate evidence and is not subtracted from measured operation time.

A surviving backend means `ambiguous_backend_alive`. A failed, timed-out, hidden, wrong-cluster or malformed monitor means `ambiguous_backend_monitor_unknown`. Either is a fatal cleanup failure, with no rollback or installed classification. Primary installation failure and later cleanup failures remain separate. Only an observed absence within the deadline permits a new exact canonical-byte comparison against the old or authored variant catalog. Unknown catalog state still refuses repair.

The no-contact counterexample runs the actual frozen source1 control flow against a simulated still-live server transaction. It demonstrates the invalid rollback field. The corrected flow refuses to read the catalog while that backend survives. A separate late-commit case keeps the old catalog hidden until the backend exits, then classifies the authored new catalog. These are Python orchestration checks, not PostgreSQL or network-disconnect proof. Genuine PG17 must still validate backend visibility, startup tag propagation, timeout behavior and the complete fixture.

## Portable package

This checkpoint contains only changed source, an unchanged profile copy, the peer finding, reference hashes, tests and evidence. The 151 MB source1 bundle is not duplicated or symlinked. Both directories must remain siblings with these exact names:

```
BUNDLE_ROOT/
  COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-1/
  COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-2/
```

Use an ordinary read-only source copy for source1 and this correction directory for source2. Do not overlay the changed files into source1: its manifest includes its original main/test bytes, and the corrected validator deliberately refuses altered source1. No absolute workstation path is an authority.

After root pins the correction manifest externally, a proposed packaging check from BUNDLE_ROOT is:

```sh
python3 - <<'VERIFY'
from pathlib import Path
import hashlib, json, os
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
expected = {
  'COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-1': '57c3e7b498cd5134bd17f99a7cba337fe8d83c6a3c047d0c825df2e66b1b8686',
  'COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-2': os.environ['EXPECTED_CORRECTION_MANIFEST'],
}
for name, digest in expected.items():
    root = Path(name)
    assert sha(root / 'MANIFEST.json') == digest
    for row in json.loads((root / 'MANIFEST.json').read_text())['files']:
        path = root / row['path']
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256']
VERIFY
python3 COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-2/test_combined_executor.py
python3 COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-2/combined_executor.py --check-plan
```

These commands make no database contact. The executor also revalidates source1's manifest and all 188 entries before any explicit execution. The correction's own main/test/profile hashes must be pinned externally by root's reviewed packaging/workflow; no circular self-pin is invented. No workflow is authored or enrolled here.

The future explicit entry point is correction2/combined_executor.py with `--execute-fixture --output` and the existing exact fixture URL environment contract, only after actual source review and separately authorized disposable infrastructure. No such command was run for this checkpoint. All original runtime, owner, provider, historical portability and restoration holds remain unchanged.
