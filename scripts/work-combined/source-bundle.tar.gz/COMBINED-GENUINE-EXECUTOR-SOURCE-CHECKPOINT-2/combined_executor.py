#!/usr/bin/env python3
"""Proposed disposable PG17 executor. Default/check-plan never contacts a database.
Execution is separate, explicit, and requires a fresh reviewed CI service. No
provider identity, installed-K6 upgrade or paid-wait conclusion is supplied.
"""
import argparse,hashlib,importlib.util,json,os,re,subprocess,sys,time,uuid
from pathlib import Path
from urllib.parse import urlparse,urlunparse
sys.dont_write_bytecode=True
SOURCE=Path(__file__).resolve().parent
HERE=SOURCE.parent/'COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-1'
SOURCE1_MANIFEST='57c3e7b498cd5134bd17f99a7cba337fe8d83c6a3c047d0c825df2e66b1b8686'
BASE='forge_work_activity_role_test'
BRANCHES={'inactive':'forge_combined_inactive_test','active':'forge_combined_active_test','negative':'forge_combined_negative_test'}
DATABASES={BASE,'postgres',*BRANCHES.values()}
ACTOR='00000000-0000-4000-8000-000000720003'
PROFILE=SOURCE/'executor-profile.json'

def require(ok,message):
 if not ok:raise RuntimeError(message)
def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def sha(f):return sha_bytes(Path(f).read_bytes())
def q(v):return 'null' if v is None else "'"+str(v).replace("'","''")+"'"
def qi(v):require(bool(re.fullmatch('[a-zA-Z_][a-zA-Z_0-9]*',v)),'Invalid identifier');return '"'+v+'"'
def encoded(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def module(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def validate_target(value):
 try:t=urlparse(value);port=t.port
 except ValueError as e:raise RuntimeError('Malformed disposable target') from e
 require(t.scheme in ('postgres','postgresql') and t.hostname in ('localhost','127.0.0.1') and port==5432 and t.path=='/'+BASE and t.username=='supabase_admin' and t.password=='fixture-only' and not t.params and not t.query and not t.fragment,'Exact fresh localhost:5432 fixture target required')
 return t

def validate_source():
 require(sha(HERE/'MANIFEST.json')==SOURCE1_MANIFEST,'Frozen source1 manifest drift')
 for entry in json.loads((HERE/'MANIFEST.json').read_text())['files']:
  require(sha(HERE/entry['path'])==entry['sha256'] and (HERE/entry['path']).stat().st_size==entry['bytes'],'Frozen source1 file drift: '+entry['path'])
 profile=json.loads(PROFILE.read_text())
 for name,h in profile['pins'].items():require(sha(HERE/name)==h,'Source drift: '+name)
 approved=HERE/'approved-source3';manifest=json.loads((approved/'MANIFEST.json').read_text())
 require(sha(approved/'MANIFEST.json')=='9d4c2116bf3337d82e4ec282e8e58fceaec28ece75468e8b8fcacc7563d901df','Wrong approved source checkpoint')
 for e in manifest['files']:require(sha(approved/e['path'])==e['sha256'],'Approved file drift: '+e['path'])
 require(profile['targets']==BRANCHES and profile['predecessorDatabase']==BASE,'Unexpected database targets')
 a=module(HERE/'author_variants.py','variant_builder');authored=a.variants()
 for name,v in authored.items():
  require((HERE/'variants'/f'{name}.sql').read_text()==v['sql'],'Variant SQL differs')
  require(json.loads((HERE/'variants'/f'{name}.catalog.json').read_text())==v['catalog'],'Variant catalog differs')
  require((HERE/'variants'/f'{name}.canonical.json').read_text()==a.load_assembler().canonical(v['catalog']),'Variant canonical bytes differ')
 return profile,authored

def committed_fixture_sql(source):
 require(bool(re.search(r'(?im)^begin;\s*$',source)) and len(re.findall(r'(?im)^rollback;\s*$',source))==1 and source.rstrip().endswith('rollback;'),'Exact fresh source transaction boundary required')
 require(not re.search(r'(?i)disable\s+trigger|drop\s+trigger',source),'Proof-trigger bypass forbidden')
 return re.sub(r'rollback;\s*$','commit;\n',source,flags=re.I)

def db_acl_sql(name,role_profile):
 require(name in BRANCHES.values(),'Only new allowlisted branch ACL construction')
 statements=['REVOKE ALL ON DATABASE '+qi(name)+' FROM PUBLIC;']
 require(role_profile['database']['owner']=='postgres','Authored database owner differs')
 for entry in role_profile['database']['acl']:
  m=re.fullmatch(r'([^=]*)=([CTc]+)/postgres',entry);require(m is not None,'Unauthored database ACL')
  who,rights=m.groups();privileges=','.join({'C':'CREATE','T':'TEMPORARY','c':'CONNECT'}[x] for x in rights)
  statements.append('GRANT '+privileges+' ON DATABASE '+qi(name)+' TO '+(qi(who) if who else 'PUBLIC')+';')
 return ''.join(statements)

def validate_role_rows(actual,expected):
 mapping={'inherit':'rolinherit','canLogin':'rolcanlogin','bypassRls':'rolbypassrls','superuser':'rolsuper','createRole':'rolcreaterole','replication':'rolreplication','createDatabase':'rolcreatedb','connectionLimit':'rolconnlimit'}
 by_name={r['rolname']:r for r in actual}
 require(len(by_name)==len(actual),'Duplicate global role')
 for role in expected['roles']:
  require(role['name'] in by_name,'Missing authored role '+role['name'])
  # The cluster bootstrap identity is infrastructure; it was created by the
  # PG17 service, not normalized to provider account attributes.
  if role['name']=='supabase_admin':continue
  require(all(by_name[role['name']][field]==role[key] for key,field in mapping.items()),'Authored role attributes differ: '+role['name'])
 extra_system={'pg_database_owner','pg_write_all_data','pg_read_server_files','pg_write_server_files','pg_execute_server_program','pg_checkpoint','pg_use_reserved_connections','pg_maintain'}
 allowed={r['name'] for r in expected['roles']}|{'supabase_etl_admin','supabase_storage_admin','dashboard_user'}|extra_system
 require(set(by_name)==allowed,'Unexpected extra role outside exact fixture inventory')
 for name in sorted({'supabase_etl_admin','supabase_storage_admin','dashboard_user'}|extra_system):
  if name not in {r['name'] for r in expected['roles']}:
   require(not any(by_name[name][field] for field in ('rolsuper','rolcanlogin','rolcreaterole','rolcreatedb','rolreplication','rolbypassrls')),'ACL-only fixture role escalated')
 return True

def validate_initial_settings(global_rows,role_profile):
 names={r['oid']:r['rolname'] for r in global_rows['roles']};actual={}
 for row in global_rows['settings']:
  require(row['setdatabase']==0 and row['setrole'] in names,'Unexpected database/all-role setting')
  name=names[row['setrole']];require(name not in actual,'Duplicate role setting row')
  values={}
  for entry in row['setconfig'] or []:
   require('=' in entry,'Malformed role setting');key,value=entry.split('=',1);require(key not in values,'Duplicate GUC');values[key]=value
  actual[name]=values
 expected={}
 for row in role_profile['settings']:
  if row['safeValues']:
   require(row['scope']=='all_databases' and row['role'] is not None,'Unexpected authored database-scoped configuration')
   expected[row['role']]=dict(entry.split('=',1) for entry in row['safeValues'])
 require(actual==expected,'Initial global configuration differs from exact pinned safe settings; no normalization allowed')
 return True

class Report:
 def __init__(self,path):
  self.path=Path(path);require(self.path.is_absolute() and self.path.name=='combined-executor.json' and not self.path.parent.exists(),'New absolute output directory required')
  require(all(root!=self.path.parent and root not in self.path.parents for root in (HERE,SOURCE)),'Runtime output must be outside source checkpoint')
  self.path.parent.mkdir(parents=True,exist_ok=False)
  self.value={'status':'running','stage':'initial_before_source_target_or_contact','checks':0,'labels':[],'calls':[],'sessions':[],'cases':[],'branches':{},'databaseContacted':False,'providerIdentityVerified':False,'productionActivation':False,'full20Complete':False,'full42Complete':False,'full65Complete':False,'paidWaitBudgetProved':False,'activeInactiveCatalogRestored':False,'scriptSha256':sha(__file__)};self.persist()
 def persist(self,stage=None):
  if stage:self.value['stage']=stage
  tmp=self.path.with_suffix('.tmp');tmp.write_text(json.dumps(self.value,indent=2)+'\n');tmp.replace(self.path)
 def check(self,ok,label):require(ok,label);self.value['checks']+=1;self.value['labels'].append(label);self.persist()

class Runner:
 def __init__(self,target,report,database=BASE,execute=subprocess.run):
  require(database in DATABASES,'Unapproved database');self.target=target;self.report=report;self.database=database;self.execute=execute
  self.env={k:v for k,v in os.environ.items() if not k.startswith('PG')};self.env['PGCONNECT_TIMEOUT']='3'
 def at(self,database):return Runner(self.target,self.report,database,self.execute)
 def run(self,sql,user='postgres',zone='UTC',digits=1,error=None,message=None,purpose=None,monitor_budget=None):
  require(user in ('postgres','supabase_admin','authenticator') and zone in ('UTC','America/Denver') and digits in (1,0,-15),'Unapproved connection context')
  t=self.target;uri=urlunparse((t.scheme,f'{user}:fixture-only@{t.hostname}:5432','/'+self.database,'','',''))
  require(monitor_budget is None or (user=='supabase_admin' and 0<monitor_budget<=5),'Invalid monitor budget')
  timeout=35 if monitor_budget is None else monitor_budget
  tag='forge-combined-'+uuid.uuid4().hex
  env=dict(self.env,PGAPPNAME=tag,PGOPTIONS='-c timezone='+zone+' -c extra_float_digits='+str(digits))
  prelude='\\set VERBOSITY verbose\n'
  if monitor_budget is not None:
   milliseconds=max(1,min(2000,int(monitor_budget*1000)))
   prelude+=f"set statement_timeout='{milliseconds}ms';set lock_timeout='{milliseconds}ms';set search_path=public,pg_temp;\n"
  elif user!='authenticator':prelude+="set statement_timeout='20s';set lock_timeout='12s';set search_path=public,pg_temp;\n"
  n=len(self.report.value['calls']);stem=self.report.path.parent/f'call-{n:05d}';wire=prelude+sql
  stem.with_suffix('.sql').write_text(wire)
  call={'database':self.database,'login':user,'zone':zone,'floatDigits':digits,'sqlSha256':sha_bytes(wire.encode()),'file':stem.name,'status':'waiting','processTimeoutSeconds':timeout,'expectedError':error,'applicationName':tag,'purpose':purpose};self.report.value['calls'].append(call);self.report.value['databaseContacted']=True;self.report.persist('before_psql_wait')
  start=time.monotonic()
  try:
   result=self.execute(['psql',uri,'-X','-q','-t','-A','-v','ON_ERROR_STOP=1'],input=wire,text=True,capture_output=True,timeout=timeout,env=env)
   stem.with_suffix('.stdout').write_text(result.stdout);stem.with_suffix('.stderr').write_text(result.stderr);call.update(status='returned',returnCode=result.returncode,stdoutSha256=sha_bytes(result.stdout.encode()),stderrSha256=sha_bytes(result.stderr.encode()))
   if error:require(result.returncode!=0 and re.search(r'\b'+re.escape(error)+r'\b',result.stderr) and (message is None or message in result.stderr),'Expected exact refusal missing: '+result.stderr[-1200:])
   else:require(result.returncode==0,'SQL failed: '+result.stderr[-1200:])
   return result.stdout.strip()
  except subprocess.TimeoutExpired as e:
   call['status']='process_timeout';stem.with_suffix('.stdout').write_bytes(e.stdout.encode() if isinstance(e.stdout,str) else e.stdout or b'');stem.with_suffix('.stderr').write_bytes(e.stderr.encode() if isinstance(e.stderr,str) else e.stderr or b'');raise
  finally:call['wallMillisecondsIncludingPsql']=round((time.monotonic()-start)*1000,3);self.report.persist()
 def wait_backend_gone(self,call,budget=15,clock=time.monotonic,sleep=time.sleep):
  # Process death is not backend death. Every sample is a fresh administrator
  # connection with a different startup application_name and bounded wait.
  require(call['database']==self.database and call['login'] in ('postgres','supabase_admin','authenticator') and re.fullmatch(r'forge-combined-[0-9a-f]{32}',call['applicationName']) is not None,'Unproven backend monitoring identity')
  require(0<budget<=15,'Invalid backend settlement budget')
  evidence={'targetApplicationName':call['applicationName'],'database':self.database,'login':call['login'],'budgetSeconds':budget,'status':'waiting','samples':[]}
  self.report.value.setdefault('backendSettlement',[]).append(evidence);self.report.persist('before_backend_settlement')
  deadline=clock()+budget
  try:
   while True:
    remaining=deadline-clock()
    if remaining<=0:
     evidence['status']='alive_at_deadline';raise RuntimeError('ambiguous_backend_alive')
    self.report.persist('before_backend_monitor_wait')
    sql="select jsonb_build_object('systemIdentifier',(select system_identifier::text from pg_control_system()),'postmasterStart',extract(epoch from pg_postmaster_start_time())::text,'monitorDatabase',current_database(),'monitorLogin',session_user,'monitorCurrentRole',current_user,'canSeeAllBackends',(select rolsuper from pg_roles where rolname=current_user),'backends',(select coalesce(jsonb_agg(jsonb_build_object('pid',pid,'database',datname,'login',usename,'applicationName',application_name,'backendStart',backend_start::text,'transactionStart',xact_start::text,'state',state,'waitEventType',wait_event_type,'waitEvent',wait_event) order by pid),'[]'::jsonb) from pg_stat_activity where application_name="+q(call['applicationName'])+"))"
    sample=self.json(sql,user='supabase_admin',purpose='backend_monitor:'+call['applicationName'],monitor_budget=min(5,remaining))
    baseline=self.report.value['clusterBaseline']
    require(isinstance(sample,dict) and sample.get('monitorDatabase')==self.database and sample.get('monitorLogin')=='supabase_admin' and sample.get('monitorCurrentRole')=='supabase_admin' and sample.get('canSeeAllBackends') is True and all(sample.get(k)==baseline[k] for k in ('systemIdentifier','postmasterStart')),'Backend monitor cluster/login scope unknown')
    rows=sample.get('backends');require(isinstance(rows,list),'Backend monitor result unknown')
    require(all(isinstance(row,dict) and row.get('applicationName')==call['applicationName'] and row.get('database')==call['database'] and row.get('login')==call['login'] and type(row.get('pid')) is int for row in rows),'Backend monitor target ownership unknown')
    evidence['samples'].append(sample);self.report.persist('backend_monitor_sample')
    require(clock()<=deadline,'Backend monitor completed outside finite budget')
    if not rows:
     evidence['status']='gone';self.report.persist('backend_exit_observed');return
    remaining=deadline-clock()
    if remaining<=0:
     evidence['status']='alive_at_deadline';raise RuntimeError('ambiguous_backend_alive')
    self.report.persist('before_backend_monitor_pause');sleep(min(0.25,remaining))
  except BaseException as error:
   if evidence['status']!='alive_at_deadline':evidence['status']='unknown'
   evidence['failure']={'type':type(error).__name__,'message':str(error)};self.report.persist('backend_settlement_failed')
   if evidence['status']=='alive_at_deadline':raise
   raise RuntimeError('ambiguous_backend_monitor_unknown') from error
 def json(self,sql,**kwargs):
  # SQL-side scalar serialization stays explicit; the decoder never coerces t/f or UUID text.
  statement=sql.strip().removesuffix(';');require(statement.lower().startswith('select '),'JSON query must be one SELECT')
  value=self.run('select to_jsonb(__combined_result.value) from ('+statement+') as __combined_result(value);',**kwargs)
  require(len(value.splitlines())==1,'Exactly one JSON result required');return json.loads(value)

INSTANCE="select jsonb_build_object('systemIdentifier',(select system_identifier::text from pg_control_system()),'postmasterStart',extract(epoch from pg_postmaster_start_time())::text,'databaseOid',(select oid::text from pg_database where datname=current_database()),'database',current_database(),'serverVersionNum',current_setting('server_version_num'),'timezone',current_setting('TimeZone'),'floatDigits',current_setting('extra_float_digits'),'transactionIsolation',current_setting('transaction_isolation'))"
GLOBAL="select jsonb_build_object('roles',(select jsonb_agg(to_jsonb(r) order by rolname) from pg_roles r),'memberships',(select jsonb_agg(to_jsonb(m) order by roleid,member,grantor) from pg_auth_members m),'settings',(select coalesce(jsonb_agg(to_jsonb(s) order by setdatabase,setrole),'[]'::jsonb) from pg_db_role_setting s))"

def same_cluster(a,b):
 require(all(a[k]==b[k] for k in ('systemIdentifier','postmasterStart','serverVersionNum','timezone')),'Cluster/server context changed')
 require(int(a['serverVersionNum'])//10000==17 and a['timezone']=='UTC','Expected PG17 UTC inspection')
def same_database(a,b):same_cluster(a,b);require(a['database']==b['database'] and a['databaseOid']==b['databaseOid'],'Database identity changed')

def predecessor_process(script,args,env,log,report,popen=subprocess.Popen):
 require(not log.exists(),'Predecessor evidence cannot be overwritten');deadline=time.monotonic()+1200;primary=None
 with log.open('x') as output:
  report.persist('before_predecessor_spawn');proc=popen([sys.executable,str(script),*args],cwd=script.parent.parent,env=env,stdout=output,stderr=subprocess.STDOUT,text=True)
  try:
   while True:
    report.value['predecessorWaitRemainingSeconds']=max(0,round(deadline-time.monotonic(),2));report.persist('before_predecessor_wait')
    try:code=proc.wait(timeout=min(5,max(0.01,deadline-time.monotonic())));require(code==0,'Pinned predecessor failed');return
    except subprocess.TimeoutExpired:require(time.monotonic()<deadline,'Predecessor finite budget expired')
  except BaseException as error:
   primary=error;report.value.setdefault('predecessorFailures',[]).append({'script':script.name,'type':type(error).__name__,'message':str(error)});report.persist('predecessor_primary_failure')
  finally:
   try:
    if proc.poll() is None:proc.kill();report.persist('before_predecessor_process_cleanup');proc.wait(timeout=5)
   except BaseException as error:
    report.value.setdefault('predecessorCleanupFailures',[]).append({'script':script.name,'type':type(error).__name__,'message':str(error)});report.persist('predecessor_cleanup_failed')
    if primary is None:raise
  if primary is not None:raise primary.with_traceback(primary.__traceback__)

class Executor:
 def __init__(self,target,report,profile,variants):
  self.report=report;self.profile=profile;self.variants=variants;self.r=Runner(target,report);self.admin=self.r.at('postgres');self.target=target
  self.legacy=module(HERE/'pinned-repository/scripts/verify-work-cross-job-v2-postgres.py','pinned_v2_fixture')
  self.legacy.ROOT=HERE/'pinned-repository'
  self.canonical=module(HERE/'author_variants.py','runtime_variant_author').load_assembler().canonical
  self.public_query=(self.legacy.ROOT/'scripts/work-cross-job-catalog.sql').read_text().strip().removesuffix(';')
  self.combined_query=(HERE/'approved-source3/combined-catalog-query.sql').read_text().strip().removesuffix(';')
  self.initial_global=None;self.predecessor_state=None;self.installed=set();self.attempted=set();self.contexts={};self.fixture=None
 def check(self,ok,label):self.report.check(ok,label)
 def identity(self,r):return r.json(INSTANCE,user='supabase_admin')
 def catalog(self,r,expected,combined=False):
  query=self.combined_query if combined else self.public_query
  authored_text=self.canonical(expected);observed_text=r.run('select ('+query+')::text;')
  self.report.value.setdefault('catalogComparisons',[]).append({'database':r.database,'combined':combined,'authoredCanonicalSha256':sha_bytes(authored_text.encode()),'observedCanonicalSha256':sha_bytes(observed_text.encode()),'exactCanonicalBytes':observed_text==authored_text});self.report.persist()
  self.check(observed_text==authored_text,'Exact authored canonical catalog bytes '+r.database)
  return json.loads(observed_text)
 def authority_set(self,r,enabled):
  r.run('begin;select public._work_activity_gate();update public.work_activity_authority_generation set capture_enabled='+str(enabled).lower()+',revision=revision+1 where singleton;commit;')
 def context(self,r):
  return r.json("select jsonb_build_object('profile',(select to_jsonb(p) from profiles p where id="+q(ACTOR)+"::uuid),'state',(select to_jsonb(s) from personal_activity_state s where profile_id="+q(ACTOR)+"::uuid),'safety',(select coalesce(jsonb_agg(to_jsonb(s) order by id),'[]') from work_activity_safety_events s where profile_id="+q(ACTOR)+"::uuid),'authority',(select to_jsonb(a)-'updated_at' from work_activity_authority_generation a where singleton))")
 def fingerprint(self,r):
  tables=r.json("select coalesce(jsonb_agg(jsonb_build_object('schema',n.nspname,'name',c.relname,'kind',c.relkind) order by n.nspname,c.relname),'[]') from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname in('public','auth') and c.relkind in('r','p','S')")
  result=[]
  for t in tables:
   name=qi(t['schema'])+'.'+qi(t['name'])
   data=r.json("select jsonb_build_object('count',count(*),'sha256',encode(sha256(convert_to(coalesce(jsonb_agg(to_jsonb(x) order by to_jsonb(x)::text),'[]'::jsonb)::text,'UTF8')),'hex')) from "+name+' x')
   result.append({**t,**data})
  return result
 def make_fixture(self,r):
  f=self.legacy.Fixture(r,self.report,self.profile,json.loads((HERE/'pinned-repository/scripts/work-cross-job-v2-authored-inert-catalog.json').read_text()),{})
  return f
 def verify_infrastructure(self):
  identity=self.identity(self.r);same_cluster(identity,identity);require(identity['floatDigits']=='1' and identity['transactionIsolation']=='read committed','Inspection serialization/isolation mismatch');self.report.value['clusterBaseline']=identity
  rows=self.admin.json("select jsonb_agg(jsonb_build_object('name',datname,'owner',pg_get_userbyid(datdba),'template',datistemplate,'allow',datallowconn) order by datname) from pg_database")
  require({x['name'] for x in rows}=={'postgres','template0','template1',BASE},'Fresh cluster contains unexpected or preexisting target databases')
  require(next(x for x in rows if x['name']==BASE)['owner']=='postgres','Unexpected template owner')
  require(self.admin.json("select session_user='supabase_admin' and (select rolsuper and rolcreatedb from pg_roles where rolname=session_user)") is True,'Exact fixture administrator CREATEDB/SUPERUSER prerequisite missing')
  require(self.r.json("select session_user='postgres' and not (select rolsuper from pg_roles where rolname=session_user)") is True,'Source owner must remain nonsuperuser')
  require(self.admin.json("select not exists(select 1 from pg_event_trigger where evtenabled<>'D')",user='supabase_admin') is True,'Enabled event trigger outside plain fixture contract')
  initial=self.admin.json(GLOBAL,user='supabase_admin');require(not any(x['setdatabase']!=0 for x in initial['settings']),'Unexpected database-specific settings; refuse clone normalization')
  role_profile=json.loads((HERE/'pinned-repository/scripts/fixtures/work-activity-engine-role-parity.json').read_text());validate_role_rows(initial['roles'],role_profile);validate_initial_settings(initial,role_profile)
  # Reconstruct role names from current OIDs, then compare exact authored grants.
  names={x['oid']:x['rolname'] for x in initial['roles']}
  grants=[{'role':names[x['roleid']],'member':names[x['member']],'grantor':names[x['grantor']],'setOption':x['set_option'],'adminOption':x['admin_option'],'inheritOption':x['inherit_option']} for x in initial['memberships']]
  require(sorted(grants,key=encoded)==sorted(role_profile['memberships'],key=encoded),'Authored role membership/options differ')
  self.initial_global=initial;self.report.value['globalBefore']=initial;self.report.persist()
  old=json.loads((HERE/'pinned-repository/scripts/work-cross-job-old-catalog.json').read_text())['metadata'];self.catalog(self.r,old)
  require(self.r.json("select to_regclass('public.work_cross_job_contract') is null and to_regclass('public._work_unit_metadata_contract') is null") is True,'Fresh common0846 required')
  return identity,old
 def clone_branches(self):
  identity,old=self.verify_infrastructure()
  # Supported publication/unit constructors and explicit synthetic fixture rows,
  # all before cloning. No retained paid receipt or clock-request row is inserted.
  self.fixture=self.make_fixture(self.r);self.fixture.seed();self.catalog(self.r,old)
  baseline=self.fingerprint(self.r);self.report.value['baselineState']=baseline;self.report.value['syntheticSeedTimes']=self.fixture.times;self.report.persist('before_database_clones')
  role_profile=json.loads((HERE/'pinned-repository/scripts/fixtures/work-activity-engine-role-parity.json').read_text())
  for kind,name in BRANCHES.items():
   # Every query used for the baseline has completed and closed its connection.
   require(self.admin.json('select not exists(select 1 from pg_stat_activity where datname='+q(BASE)+')',user='supabase_admin') is True,'Template has another connection; never terminate it')
   self.report.value.setdefault('cloneAttempts',[]).append({'name':name,'stage':'before_create'});self.report.persist('before_database_create')
   self.admin.run('create database '+qi(name)+' with template '+qi(BASE)+' owner postgres;',user='supabase_admin')
   self.admin.run(db_acl_sql(name,role_profile),user='postgres')
   r=self.r.at(name);clone=self.identity(r);same_cluster(identity,clone);require(clone['databaseOid']!=identity['databaseOid'],'Clone must have distinct OID')
   actual=r.json("select jsonb_build_object('owner',pg_get_userbyid(datdba),'acl',to_jsonb(datacl::text[])) from pg_database where datname=current_database()")
   require(actual['owner']=='postgres' and sorted(actual['acl'])==sorted(role_profile['database']['acl']),'New database ACL differs from authored construction')
   self.catalog(r,old);state=self.fingerprint(r);require(state==baseline,'Clone starting state differs')
   self.report.value['branches'][kind]={'identity':clone,'startingStateSha256':sha_bytes(encoded(state).encode()),'startingCatalogSha256':self.profile['oldCatalogDigest'],'installed':False,'inactiveCatalogRestored':kind!='active'};self.report.persist()
  self.check(self.admin.json(GLOBAL,user='supabase_admin')==self.initial_global,'New branch construction leaves all global roles/settings exact')
 def predecessors(self):
  root=HERE/'pinned-repository';out=self.report.path.parent/'predecessors';out.mkdir()
  env=dict(self.r.env,WORK_ACTIVITY_ROLE_TEST_DB_URL=urlunparse(self.target),WORK_CROSS_JOB_POSTGRES_OUT=str(out/'work-cross-job-postgres.json'),WORK_CROSS_JOB_FRESH_SESSIONS_OUT=str(out/'work-cross-job-fresh-sessions.json'))
  vprofile=json.loads((root/'scripts/work-cross-job-v2-profile.json').read_text());baseline=self.identity(self.r)
  for kind,name,args in [('inert','verify-work-cross-job-postgres.py',[]),('fresh','verify-work-cross-job-fresh-sessions.py',['--execute-fixture'])]:
   before=self.identity(self.r);predecessor_process(root/'scripts'/name,args,env,out/(kind+'.log'),self.report);after=self.identity(self.r);same_database(before,after);same_database(baseline,after)
   path=out/('work-cross-job-postgres.json' if kind=='inert' else 'work-cross-job-fresh-sessions.json');receipt=json.loads(path.read_text());self.legacy.validate_predecessor(kind,receipt,vprofile)
   self.check(self.admin.json(GLOBAL,user='supabase_admin')==self.initial_global,'Pinned '+kind+' restores exact global roles, memberships and settings; no extras allowed')
   self.catalog(self.r,json.loads((root/'scripts/work-cross-job-new-catalog.json').read_text())['metadata'])
   self.report.value.setdefault('predecessors',[]).append({'kind':kind,'checks':receipt['checks'],'receiptSha256':sha(path),'instanceBefore':before,'instanceAfter':after});self.report.persist()
  self.predecessor_state=self.fingerprint(self.r);self.report.value['predecessorFinalState']=self.predecessor_state;self.report.persist('predecessors_complete_before_combined')
 def install(self,kind):
  r=self.r.at(BRANCHES[kind]);expected=self.variants[kind]
  self.catalog(r,json.loads((HERE/'pinned-repository/scripts/work-cross-job-old-catalog.json').read_text())['metadata'])
  self.report.value['branches'][kind]['installationAttempted']=True;self.report.value['branches'][kind]['authoredFixtureVariant']={'root':expected['root'],'privateGate':expected['privateGate'],'delta':expected['delta']};self.report.persist('before_fresh_'+kind+'_install')
  self.attempted.add(kind);r.run(committed_fixture_sql(expected['sql']),purpose='install:'+kind);self.installed.add(kind);self.report.value['branches'][kind]['installed']=True
  self.catalog(r,expected['catalog'],True)
  # PostgreSQL canonicalizes AUTHORED JSON. Never seed or learn a live root.
  authored=r.json("select to_jsonb(encode(sha256(convert_to("+q(encoded(expected['catalog']))+"::jsonb::text,'UTF8')),'hex'))")
  require(authored==expected['root'],'Authored canonical root differs on PG17')
  self.report.value['branches'][kind]['authoredRootVerifiedByPg']=authored;self.report.persist()
  f=self.make_fixture(r);seed=self.fixture
  for name in ('times','definitions','menu','selections'):setattr(f,name,getattr(seed,name))
  # Command IDs may repeat across isolated databases, never within one branch.
  f.next_id=seed.next_id
  return f
 def capability_pair(self,f,negative=False):
  for mode,enabled in [('active',True),('closing_only',False)]:
   self.authority_set(f.r,enabled);context=self.context(f.r)
   # Guard-written updated_at differs across sequential databases and is not
   # read by capability. Preserve it separately; compare all consumed authority
   # fields, actor/state/safety values exactly, without editing either row.
   raw_authority=f.r.json('select to_jsonb(a) from work_activity_authority_generation a where singleton')
   self.report.value['cases'].append({'case':'capability_context','database':f.r.database,'mode':mode,'negative':negative,'consumedContext':context,'rawAuthority':raw_authority});self.report.persist()
   if negative:
    require(context==self.contexts[mode],'Negative lacks same-identity/state base positive')
    f.auth(ACTOR,(HERE/'approved-source3/fixtures/v1-capability-omitted-negative.sql').read_text())
   else:
    f.auth(ACTOR,(HERE/f'approved-source3/fixtures/v1-capability-{mode}.sql').read_text());self.contexts[mode]=context
   self.check(True,('Negative refusal after exact same-context positive: ' if negative else 'Base V1 positive: ')+mode)
 def base_cases(self,f):
  self.capability_pair(f)
  f.auth(ACTOR,(HERE/'approved-source3/fixtures/float0-paid-reader-still-refuses.sql').read_text())
  f.r.run((HERE/'approved-source3/fixtures/float0-private-coverage.sql').read_text())
  settings="set fixture.visible_project_id="+q(f.job_b)+";set fixture.visible_unit_id="+q(self.legacy.uid(30))+";set fixture.missing_unit_id="+q(self.legacy.uid(31))+';'
  f.auth(ACTOR,'begin;'+settings+(HERE/'approved-source3/fixtures/float0-existing-public-readers.sql').read_text()+'commit;')
  self.check(True,'Actual approved float contracts under fresh authenticated contexts')
  # Real V1 clock-in and paid safety on physical A under closing-only capture.
  actor=self.legacy.uid(1);key=f.new_id();first=f.rpc(actor,f.clock_sql(key,1,f.times['clock']));shift=first['id']
  for action,expression in [('start_break','to_jsonb(public.start_break('+q(shift)+"::uuid,'rest',"+q(f.new_id())+'::uuid,'+q(f.times['break'])+'::timestamptz,'+q(f.times['checked'])+'::timestamptz,0))'),('end_break','to_jsonb(public.end_break('+q(shift)+'::uuid,'+q(f.new_id())+'::uuid,'+q(f.times['return'])+'::timestamptz,'+q(f.times['checked'])+'::timestamptz,0))'),('clock_out','to_jsonb(public.clock_out('+q(shift)+'::uuid,null::text,false,true,null::integer,null::double precision,null::double precision,null::text,'+q(f.new_id())+'::uuid,'+q(f.times['out'])+'::timestamptz,'+q(f.times['checked'])+'::timestamptz,0))')]:
   reply=f.rpc(actor,expression);self.legacy.validate_paid_response(action,reply,first,f.times);self.check(True,'Base V1 real '+action+' retains physical paid identity')
  self.report.value['branches']['inactive']['census']=f.census();self.report.persist()
 def paid_lookup(self,f,actor,key,registered):
  original=f.clock_sql(key,2,f.times['clock']);request=original[len('to_jsonb(public.clock_in('):-2]
  expression='public.work_activity_clock_receipt_v2('+request+')'
  retained=f.retained(key);proof=f.request_proof(key);require(proof=={'version':2,'registered':registered,'fingerprintMatches':True},'Wrong original2 retained stamp')
  fingerprint=f.r.run('select _work_cross_job_clock_receipt_fingerprint(r) from work_activity_clock_receipts r where client_id='+q(key)+'::uuid')
  wire_map=[('clientId','client_id'),('profileId','profile_id'),('shiftId','shift_id'),('action','action'),('outcome','outcome'),('tappedAt','tapped_at'),('arrivedAt','arrived_at'),('clockCheckedAt','clock_checked_at'),('clockSkewMs','clock_skew_ms'),('usedTapTime','used_tap_time'),('reviewReason','review_reason'),('sourceCreatedAt','source_created_at'),('receiptProtocol','receipt_protocol'),('setupPayloadDigest','setup_payload_digest'),('recordedAt','recorded_at')]
  times={'tapped_at','arrived_at','clock_checked_at','source_created_at','recorded_at'}
  columns=','.join(q(k)+','+('public._work_activity_iso(r.'+v+')' if v in times else 'r.'+v) for k,v in wire_map)
  expected=f.r.json('select jsonb_build_object('+columns+') from work_activity_clock_receipts r where client_id='+q(key)+'::uuid')
  digest=f.r.json('select to_jsonb(public._work_activity_clock_setup_digest('+request.rsplit(',',1)[0]+'))')
  require(digest==retained['setup_payload_digest'],'Full eleven-argument writer digest differs')
  before=f.rows();first=f.rpc(actor,expression);require(first.get('availability')=='available' and first.get('protocolVersion')==2 and first.get('contract')=='paid_setup_v2_recovery_v1','Full-request paid lookup unavailable')
  require(set(first)=={'protocolVersion','contract','availability','receipt','proof','current'} and len(first['receipt'])==15,'Wrong paid reader envelope')
  require(first['receipt']==expected,'Reader fifteen-field original receipt differs')
  require(first['proof']=={'originalSetupVersion':2,'match':'full_original_setup_digest','fingerprintVersion':1,'receiptSha256':fingerprint},'Wrong paid recovery proof')
  require(set(first['current'])=={'asOf','sourcePresent','captureRegistered'} and isinstance(first['current']['asOf'],str) and first['current']['sourcePresent'] is True,'Current source presence/shape differs from retained physical rows')
  require(first['current']['captureRegistered'] is registered,'Registration/fallback conflated')
  for zone in ('America/Denver','UTC'):
   replay=f.rpc(actor,expression,zone=zone);require(replay['receipt']==first['receipt'] and replay['proof']==first['proof'] and f.retained(key)==retained and f.rows()==before,'Historical lookup/replay changed evidence')
  unavailable=f.rpc(self.legacy.uid(2),expression);require(unavailable=={'protocolVersion':2,'contract':'paid_setup_v2_recovery_v1','availability':'unavailable','receipt':None,'proof':None,'current':None},'Other owner received historical data')
  # Same 12 original arguments, one bounded coordinate mutation: typed historical
  # mismatch must not return another owner's or another intent's paid receipt.
  changed=expression.replace('37.123456789::double precision','37.123456780::double precision')
  require(f.rpc(actor,changed)==unavailable and f.rows()==before,'Changed full original request leaked or rewrote history')
  micro=f.r.run("select _work_cross_job_clock_receipt_fingerprint(jsonb_populate_record(r,jsonb_build_object('arrived_at',r.arrived_at+interval '1 microsecond'))) from work_activity_clock_receipts r where client_id="+q(key)+'::uuid')
  require(micro!=fingerprint and f.rows()==before,'Microsecond fingerprint counterexample did not distinguish original')
  self.report.value['cases'].append({'case':'paid_full_original_lookup','database':f.r.database,'actor':actor,'clientId':key,'registered':registered,'authorityCaptureEnabled':f.r.json('select to_jsonb(capture_enabled) from work_activity_authority_generation where singleton'),'originalCall':original,'lookup':first,'retained15':retained,'fingerprint':fingerprint});self.report.persist()
 def active_cases(self,f):
  # Private literaltrue is authored before immutable proof triggers, authority
  # false first supplies actual requested2 fallback under supported writer.
  self.authority_set(f.r,False);actor=self.legacy.uid(4);key=f.new_id();first=f.rpc(actor,f.clock_sql(key,2,f.times['clock']));self.paid_lookup(f,actor,key,False);fallback_key=key
  self.authority_set(f.r,True);before=f.rows();retry=f.rpc(actor,f.clock_sql(key,2,f.times['clock']),zone='America/Denver');require(f.compare_paid_wire(first,retry) and f.rows()==before and not f.request_proof(key)['registered'],'Fallback retry acquired registration')
  actor=self.legacy.uid(1);key=f.new_id();first=f.rpc(actor,f.clock_sql(key,2,f.times['clock']));shift=first['id'];self.paid_lookup(f,actor,key,True)
  before=f.rows();retained=f.retained(key)
  for zone in ('America/Denver','UTC'):
   replay=f.rpc(actor,f.clock_sql(key,2,f.times['clock']),zone=zone)
   require(f.compare_paid_wire(first,replay) and f.retained(key)==retained and f.rows()==before,'Registered2 original clock replay changed paid/receipt history')
  f.auth(actor,'select '+f.clock_sql(key,2,f.times['clock'])+';',digits=-15,error='23514',message='Clock command identity conflicts.')
  require(f.rows()==before and f.retained(key)==retained,'Changed float writer retry mutated history')

  # Exact general A→B allocation lineage; additional families remain held.
  device=f.new_id();generation=f.new_id();head=None
  for sequence,intent,tap in [(0,{'kind':'establish_stream','previousGeneration':None,'previousHeadCommandId':None},f.times['finish']),(1,{'kind':'finish_setup','projectId':f.job_a,'costCodeId':f.cost},f.times['finish']),(2,f.switch_intent(f.job_b,'general'),f.times['b'])]:head,_,_=f.activity(actor,shift,device,generation,head,sequence,intent,tap)
  for action,expression in [('start_break','to_jsonb(public.start_break('+q(shift)+"::uuid,'rest',"+q(f.new_id())+'::uuid,'+q(f.times['break'])+'::timestamptz,'+q(f.times['checked'])+'::timestamptz,0))'),('end_break','to_jsonb(public.end_break('+q(shift)+'::uuid,'+q(f.new_id())+'::uuid,'+q(f.times['return'])+'::timestamptz,'+q(f.times['checked'])+'::timestamptz,0))'),('clock_out','to_jsonb(public.clock_out('+q(shift)+'::uuid,null::text,false,true,null::integer,null::double precision,null::double precision,null::text,'+q(f.new_id())+'::uuid,'+q(f.times['out'])+'::timestamptz,'+q(f.times['checked'])+'::timestamptz,0))')]:
   reply=f.rpc(actor,expression);self.legacy.validate_paid_response(action,reply,first,f.times);self.check(True,'Registered2 actual '+action+' preserves physical A')
   if action=='end_break':
    resumed=f.r.json("select jsonb_build_object('project',s.project_id,'physical',h.project_id,'resumed',b.resumed_from_history_id is not null) from personal_activity_state p join custom_work_sessions s on s.id=p.active_source_id join time_shifts h on h.id=p.shift_id join work_cross_job_bindings b on b.source_id=s.id where p.profile_id="+q(actor)+'::uuid')
    require(resumed=={'project':f.job_b,'physical':f.job_a,'resumed':True},'Paid return did not resume B on physical A')
  self.authority_set(f.r,False)
  self.paid_lookup(f,actor,key,True)
  self.paid_lookup(f,self.legacy.uid(4),fallback_key,False)

  guards=f.r.json("select jsonb_build_object('cross',_work_cross_job_coverage(),'metadata',_work_unit_metadata_coverage(),'review',_work_unit_review_coverage(),'totals',_work_totals_coverage(),'contributors',_work_unit_contributors_coverage())")
  require(guards=={'cross':True,'metadata':True,'review':False,'totals':False,'contributors':False},'Registered2 report fence changed')
  for expression,key_name in [('public.work_activity_totals_read('+q(f.job_b)+'::uuid,'+q(self.legacy.uid(30))+'::uuid)','totals'),('public.work_unit_contributors_read('+q(f.job_b)+'::uuid,'+q(self.legacy.uid(30))+'::uuid,1)','contributors'),('public.work_unit_metadata_read('+q(self.legacy.uid(30))+'::uuid,1)','metadata')]:
   require(f.rpc(ACTOR,expression)=={'protocolVersion':1,'availability':'unavailable',key_name:None},'Registered2 held public reader changed false-guard contract')
  review=f.rpc(ACTOR,'public.work_unit_review_read('+q(self.legacy.uid(30))+'::uuid)')
  require(review['availability']=='available' and review['review']['qc']['lifecycle']=='unproven' and review['review']['qc']['qcAccepted'] is False,'Registered2 visible review must retain available/unproven contract')
  # Source-owner negative only, not a service transport/census success proof.
  f.r.run('select public._work_unit_metadata_person_counts('+q(ACTOR)+'::uuid,null::uuid);',error='55000',message='Person history source is unavailable.')
  self.check(True,'Registered2 report and private census refusals remain functional holds')
  self.report.value['branches']['active']['registered2ReportCensusFunctionalHold']=True;self.report.value['branches']['active']['census']=f.census();self.report.persist()
 def finalize_branch(self,kind):
  r=self.r.at(BRANCHES[kind]);f=self.make_fixture(r);before=f.rows();before_census=f.census();self.authority_set(r,False)
  require(f.rows()==before,'Authority shutdown changed measured paid/source/receipt/history rows')
  after_census=f.census();require({k:v for k,v in before_census.items() if k!='paidUpdateStatsInformational'}=={k:v for k,v in after_census.items() if k!='paidUpdateStatsInformational'},'Authority shutdown changed measured business counts')
  self.catalog(r,self.variants[kind]['catalog'],True)
  flags=r.json("select jsonb_build_object('captureEnabled',(select capture_enabled from work_activity_authority_generation where singleton),'privateGate',_work_cross_job_enabled(),'settings',jsonb_build_object('float',current_setting('extra_float_digits'),'zone',current_setting('TimeZone')))")
  require(flags=={'captureEnabled':False,'privateGate':kind=='active','settings':{'float':'1','zone':'UTC'}},'Final branch flags/settings differ')
  same_database(self.report.value['branches'][kind]['identity'],self.identity(r))
  require(r.json("select not exists(select 1 from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname like 'pg_temp_%' or n.nspname like 'pg_toast_temp_%')") is True,'Temporary relations remain')
  self.report.value['branches'][kind].update(finalFlags=flags,finalCensus=after_census,finalState=self.fingerprint(r),cleanupVerified=True,inactiveCatalogRestored=kind!='active',historyRetained=True);self.report.persist('branch_finalized_'+kind)
 def run(self):
  primary=None
  try:
   self.clone_branches();self.predecessors()
   base=self.install('inactive');self.base_cases(base)
   negative=self.install('negative');self.capability_pair(negative,True)
   active=self.install('active');self.active_cases(active)
  except BaseException as e:primary=e;self.report.value['primaryFailure']={'type':type(e).__name__,'message':str(e)};self.report.persist('primary_failure_before_cleanup')
  finally:
   failures=[]
   for kind in sorted(self.attempted):
    try:
     if kind not in self.installed:
      r=self.r.at(BRANCHES[kind])
      calls=[call for call in self.report.value['calls'] if call.get('purpose')=='install:'+kind]
      require(len(calls)==1,'Ambiguous install has no unique recorded backend identity')
      r.wait_backend_gone(calls[0])
      # Only after the tagged backend is absent may a catalog snapshot classify
      # the install. A timed-out client could otherwise still commit later.
      live=r.run('select ('+self.public_query+')::text;')
      old=json.loads((HERE/'pinned-repository/scripts/work-cross-job-old-catalog.json').read_text())['metadata']
      if live==self.canonical(old):
       self.report.value['branches'][kind]['installationRolledBackVerified']=True;self.report.persist('installation_rollback_verified_after_backend_exit');continue
      require(live==self.canonical(self.variants[kind]['catalog']['publicCatalog']),'Ambiguous install left unauthored catalog; refuse repair')
      self.installed.add(kind)
     self.finalize_branch(kind)
    except BaseException as e:
     failures.append({'branch':kind,'type':type(e).__name__,'message':str(e)});self.report.value['cleanupFailures']=list(failures);self.report.persist('cleanup_failure')
   if self.initial_global is not None:
    try:require(self.admin.json(GLOBAL,user='supabase_admin')==self.initial_global,'Final global roles/settings differ')
    except BaseException as e:failures.append({'scope':'global','message':str(e)})
   if self.predecessor_state is not None:
    try:
     same_database(self.report.value['clusterBaseline'],self.identity(self.r))
     self.catalog(self.r,json.loads((HERE/'pinned-repository/scripts/work-cross-job-new-catalog.json').read_text())['metadata'])
     require(self.fingerprint(self.r)==self.predecessor_state,'Combined work altered predecessor database state')
     self.report.value['predecessorStatePreservedAfterCombined']=True
    except BaseException as e:failures.append({'scope':'predecessor_database','message':str(e)})
   if self.initial_global is not None:
    try:
     inventory=self.admin.json("select jsonb_agg(datname order by datname) from pg_database",user='supabase_admin')
     require(set(inventory)<=({'postgres','template0','template1',BASE}|set(BRANCHES.values())),'Unexpected final database outside disposable inventory')
     if len(self.report.value['branches'])==3:require(set(inventory)==({'postgres','template0','template1',BASE}|set(BRANCHES.values())),'Expected clone disappeared')
     self.report.value['finalDatabaseInventory']=inventory
    except BaseException as e:failures.append({'scope':'database_inventory','message':str(e)})
   self.report.value['cleanupFailures']=failures;self.report.persist()
   if failures and primary is None:primary=RuntimeError('Cleanup verification failed')
  if primary is not None:raise primary
  self.report.value.update(status='passed_finite_fixture',activeInactiveCatalogRestored=False,disposalIsNotRestoration=True);self.report.persist('complete_with_explicit_holds')

def main(argv=None):
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--check-plan',action='store_true');parser.add_argument('--execute-fixture',action='store_true');parser.add_argument('--output');args=parser.parse_args(argv)
 require(not(args.check_plan and args.execute_fixture),'Mutually exclusive modes')
 if not args.execute_fixture:
  require(args.output is None,'Plan mode creates no runtime receipt');profile,_=validate_source();print(encoded({'status':'SOURCE_PLAN_VALIDATED','databaseContacted':False,'targets':profile['targets'],'holds':profile['holds']}));return 0
 require(args.output,'Explicit fresh output path required');report=Report(args.output)
 try:
  profile,variants=validate_source();report.value['profileSha256']=sha(PROFILE);report.persist('source_validated_before_target')
  target=validate_target(os.environ.get('WORK_ACTIVITY_ROLE_TEST_DB_URL',''));Executor(target,report,profile,variants).run();return 0
 except BaseException as e:report.value.update(status='failed',failure={'type':type(e).__name__,'message':str(e)});report.persist('failed');raise
if __name__=='__main__':raise SystemExit(main())
