# Correction 2 handoff

B1 is corrected at source level: cleanup now waits for the exact tagged PostgreSQL backend to disappear before deciding whether an uncertain install committed or rolled back. Killing psql alone no longer permits either claim. A surviving or unobservable backend causes fatal cleanup failure without a catalog classification.

The new monitor has its own unique startup tag and finite 15-second total budget, with each subprocess capped at 5 seconds and the remaining budget. It confirms database/login, administrator visibility and original cluster identity. It never terminates a connection. Original errors, monitor evidence and all cleanup errors remain separate. Existing normal and authenticated timeout limits are unchanged.

The actual source1 counterexample records rollback while its simulated backend is alive. Correction2 rejects that state; a late-commit case reads the new catalog only after the backend exits. These are no-contact orchestration tests. No PostgreSQL, SQL, provider or network-disconnect case ran here.

Final checks are 60 passing tests: all 51 original test methods are unchanged, plus nine new methods covering unique persisted identity, alive/gone/late-commit states, monitor timeout, wrong owner/cluster/visibility, malformed evidence, finite monitor limits, the actual old-source counterexample and error preservation. Default/check-plan remain no-contact, and the two changed Python files compile. Exact source hashes and logs are in evidence/source-validation.json and SOURCE-AUDIT.json.

Source1's manifest `57c3e7b498cd5134bd17f99a7cba337fe8d83c6a3c047d0c825df2e66b1b8686` and all 188 files remain unchanged. Candidate `2a323f3d59e622b80cf235c68d7d39533ae1b98717b1a9769a5e5923046f69cd`, inactive root `d7d520dd7c227fedb6594117d017cde3307981156162aedf2c37dfbfd06467b2`, active SQL `efcc993da1be44fe89235e7b1408b1210ab5b8a81f65dc685bd0129965d6e0cd` and active root `df8a3fcecdec0c58073ce2f83be49b8f00d0808afcdce58aa7313d3f2422921d` are unchanged. No repository or workflow was edited.

Package the two directories as siblings; run the correction2 main/test files. The exact layout and verification commands are in README. Do not overlay source1: that would invalidate the deliberately immutable original manifest. Correction2 references source1 by relative path and verifies every file before contact; root must externally pin this correction's manifest/main/test/profile. No mutable symlink is frozen here.

Actual source1 review was limited and omitted README, TESTPLAN and variant diff. The next bounded actual review must cover those files plus the B1 correction and monitor assumptions, as specified in REVIEW-BRIEF. No executor source approval or operational execution is claimed yet.

All previous holds remain: actual PG17 behavior/catalog/seed/ACL checks, provider and float transport, registered history under the inactive base root, registered-2 report/census support, complete client/kernel/metadata acceptance, paid-wait budget, devices, owner policies and installed-K6 upgrade. Active catalog restoration remains false; authority false is a separate requirement. Ownership returns to root for verification and actual review before any CI enrollment.
