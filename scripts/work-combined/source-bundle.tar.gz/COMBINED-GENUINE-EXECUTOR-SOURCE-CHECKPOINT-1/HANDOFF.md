# Handoff: combined genuine executor source proposal

The difficult construction problem is resolved as a reviewable source proposal. The old 47-control fixture commits 0847, so the combined candidate cannot follow it in the same database. This proposal instead makes three untouched copies of the same seeded 0846 database before running the unchanged 47 and 66 fixtures on the original database. All four databases share one disposable PostgreSQL 17 cluster, with separate names, OIDs, catalogs, paid history and counts.

No SQL, provider request, workflow or CI run was executed for this checkpoint. The next action is root verification and actual independent source review of this new executor and its clone/privilege contract. Prior Opus approval covered the held candidate, not this executor. No repository files were edited.

## What is concrete

`combined_executor.py` provides an explicit fixture-only executor with a no-contact default/check-plan path, exact source pins, allowlisted disposable targets, partial receipts before waits, complete subprocess output, strict JSON scalars, raw canonical catalog byte comparison, real-writer runtime case definitions and fatal cleanup reporting. `author_variants.py` derives expectations only from the approved source. `executor-profile.json`, `TESTPLAN.json`, README and REVIEW-BRIEF define the exact infrastructure and acceptance boundaries.

The existing 47 and 66 scripts remain unchanged and run together in their original database. The candidate branches retain both original preflights before DDL. Proof data is inserted before immutable triggers. No installed proof is disabled, dropped, replaced or repaired. New database ACLs are explicit fixture construction from the pinned role profile; global roles, grants and settings are checked rather than normalized.

The base and closing-only SQL are exactly approved candidate `2a323f3d59e622b80cf235c68d7d39533ae1b98717b1a9769a5e5923046f69cd`, with catalog root `d7d520dd7c227fedb6594117d017cde3307981156162aedf2c37dfbfd06467b2`. The active SQL is `efcc993da1be44fe89235e7b1408b1210ab5b8a81f65dc685bd0129965d6e0cd`, root `df8a3fcecdec0c58073ce2f83be49b8f00d0808afcdce58aa7313d3f2422921d`. Exactly one of 76 function definitions changes: the private fixture gate becomes literal true. The paid reader and the other 75 definitions remain byte-identical. The two proof data roots and final gate assertion are authored for that variant. The negative variant is the exact approved stale-capability fixture.

## Checks completed

- 51 final no-contact tests passed against the exact final Python source. These cover target/source rejection, no-contact paths, authored variant reproduction, strict scalars and canonical bytes, output/error/timeout handling, fixture prerequisites, restoration boundaries and failure preservation.
- Default and `--check-plan` returned `SOURCE_PLAN_VALIDATED` with `databaseContacted: false`; three Python modules compiled.
- All 103 prior manifest-listed files and their copies matched. Seven preparation inputs, 20 transitive repository files, 14 protected source inputs and three metadata trial files matched their prior hashes. Four frozen premise files matched.
- Initial test-selector and local authoring/audit mistakes are retained in `evidence/authoring-notes.json`. They were harness/inventory mistakes, not product failures or SQL results. The final source binding is `evidence/validation-source-hashes.json`.

`COMMANDS.json` records exact final checks. `SOURCE-AUDIT.json` contains each expected and actual hash. `NEW-SOURCE.patch` contains the new authored Python, profile and documentation; `ACTIVE-VARIANT-DIFF.patch` shows the SQL delta. The manifest lists every checkpoint file with relative path, byte count and SHA-256, excluding itself.

## Critical limits for review and eventual execution

Actual PostgreSQL must still establish baseline seed feasibility, clone privileges/ACLs, exact PG17 catalog types/RI/attributes and role/config assumptions. The proposed real LOGIN plus SET ROLE authenticated and synthetic JWT GUC is fixture identity, not provider authentication. Authenticator limits remain installed 8 seconds; inspection sessions use 20-second statements and 12-second locks. Timings include process/connection work and do not establish an owner paid-wait budget.

Capability-negative prerequisites compare exactly the context consumed by capability. The authority guard stamps `updated_at` during each sequential update, while capability reads capture_enabled/revision. That unread timestamp is excluded from equality, and complete raw authority rows are retained. Generic 55000 alone cannot establish the negative.

Registered protocol-2 historical lookup is characterized only under the identical reader body in the reviewed active variant catalog, including capture authority false. The unchanged source3 historical fixture requires the inactive base root and is not counted as executed. Inactive-root registered historical portability remains a REQUIRED open paid-recovery/integration gate. No ledger is copied between branches and no direct receipt INSERT substitutes for a real writer.

The active branch retains its literal-true fixture catalog and real history. Authority capture must end false, with exact active catalog and paid/history invariants retained. **Inactive catalog restoration is false.** Later database/service disposal is external cleanup, not restoration evidence. Cleanup errors remain fatal. The original predecessor database retains its own inert catalog and post-66 history, and its state is checked unchanged during combined work.

The registered-2 report/census refusals remain functional holds. Full 20 client, 42 kernel and 65 metadata completion, provider/float transport, inactive-root historical portability, other source families, race/volume/paid-wait testing, devices, old-client cooperation, safety resolution, owner policy and installed-K6 upgrade remain open. All production activation and completion flags remain false.

## Ownership returned

This checkpoint is frozen for root verification and bounded actual peer review. Root owns any later packaging, infrastructure/workflow changes, operational execution or repository enrollment. No further source work is authorized by this handoff alone.
