create function public._work_unit_review_view(actor uuid,s jsonb) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare c public.work_unit_review_current;verification public.work_unit_dimension_verifications;submission public.work_unit_review_events;
 q public.work_unit_review_events;b jsonb;defects jsonb;observation jsonb;inc bigint;uid uuid;ready boolean;proof boolean;matches boolean;qcstate text;acceptance text;dvstate text;
 verify_allowed boolean;reviewer boolean;factusable boolean;
begin
 if s is null then return null;end if;uid:=(s#>>'{unit,id}')::uuid;inc:=(s#>>'{unit,incarnationEpoch}')::bigint;
 select * into c from public.work_unit_review_current where unit_id=uid and incarnation=inc;
 if c.unit_id is null and exists(select 1 from public.work_unit_review_events where unit_id=uid and incarnation=inc) then return null;end if;
 if c.unit_id is not null and not exists(select 1 from public.work_unit_review_events e where e.id=c.latest_event_id and e.unit_id=uid and e.incarnation=inc and e.review_revision=c.review_revision and e.generation=c.generation) then return null;end if;
 select * into verification from public.work_unit_dimension_verifications where id=c.dimension_verification_id;
 if verification.id is not null and (verification.unit_id<>uid or verification.incarnation<>inc) then return null;end if;
 select * into submission from public.work_unit_review_events where id=c.current_submission_id;
 select * into q from public.work_unit_review_events where id=c.latest_qc_event_id;
 defects:=public._work_unit_review_defect_projection(uid,inc);
 if jsonb_array_length(defects)>200 or jsonb_array_length(defects)<>(select count(*) from public.work_unit_review_defects where unit_id=uid and incarnation=inc) then return null;end if;
 observation:=s->'observation';
 factusable:=s#>>'{unit,fact,id}' is not null and observation<>'null'::jsonb
 and s#>>'{unit,fact,eventKind}' not in ('incomplete','cleared')
 and (s#>>'{dimension,fact,unit_binding_epoch}')::bigint=(s#>>'{unit,bindingEpoch}')::bigint;
 factusable:=coalesce(factusable,false);
 proof:=(s->>'proven')::boolean and public._work_unit_review_coverage();
 ready:=(s->>'active')::integer=0 and (s->>'pending')::integer=0;
 matches:=submission.id is not null and submission.scope_manifest=s->'manifest' and submission.scope_token=s->>'scopeToken';
 qcstate:=coalesce(c.qc_state,'not_submitted');
 acceptance:='not_accepted';
 if qcstate in ('passed','awaiting_review') and not coalesce(matches,false) then qcstate:='not_submitted';acceptance:='noncurrent';end if;
 if c.qc_state='passed' and coalesce(matches,false) then
 if q.action<>'pass' or q.unit_id is distinct from uid or q.incarnation is distinct from inc or q.generation is distinct from c.generation or q.submission_id is distinct from c.current_submission_id then return null;end if;
 acceptance:=case when not proof then 'recorded_only' when ready and not exists(select 1 from jsonb_array_elements(defects) x where x->>'state'<>'verified_resolved') then 'accepted' else 'noncurrent' end;
 end if;
 dvstate:=case when verification.id is null then 'unverified' when verification.dimension_manifest=s->'dimension' and (s->>'dimensionProven')::boolean then 'verified' else 'noncurrent' end;
 reviewer:=public._work_unit_review_authority(actor,s->'jobs','final_qc');
 verify_allowed:=factusable and (s->>'dimensionProven')::boolean and observation->>'observerId' is not null and observation->>'observerId'<>actor::text and public._work_unit_review_authority(actor,s->'jobs','dimensions_edit');
 b:=case when s#>>'{unit,fact,id}' is null then null else jsonb_build_object('unitId',uid,'unitRevision',s#>'{unit,operationalRevision}',
 'factId',s#>'{unit,fact,id}','factRevision',s#>'{unit,fact,revision}','scopeToken',s->'scopeToken',
 'reviewRevision',coalesce(c.review_revision,0),'submissionId',c.current_submission_id,'generation',coalesce(c.generation,0)) end;
 return jsonb_build_object('basis',b,'basisStatus',case when b is null then 'unavailable' else 'current' end,
 'capabilities',jsonb_build_object('verifyDimensions',coalesce(verify_allowed,false),'submit',factusable and ready,
 'pass',factusable and reviewer and ready and coalesce(matches,false) and qcstate='awaiting_review' and not exists(select 1 from jsonb_array_elements(defects) x where x->>'state'='open'),
 'fail',factusable and reviewer and c.current_submission_id is not null,
 'claimResolved',factusable and exists(select 1 from jsonb_array_elements(defects) x where x->>'state'='open'),
 'reopen',factusable and reviewer),
 'observation',observation,'dimensionVerification',jsonb_build_object('state',dvstate,'verificationId',verification.id),
 'qc',jsonb_build_object('state',qcstate,'acceptance',acceptance,'lifecycle',case when proof then 'proven' else 'unproven' end,'qcAccepted',acceptance='accepted'),
 'work',jsonb_build_object('availability','available','activeCount',s->'active','pendingCount',s->'pending'),'defects',defects);
end; $$;
