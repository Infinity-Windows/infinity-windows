create function public.work_unit_metadata_read(p_unit_id uuid,p_protocol_version integer default 1) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare a uuid;s jsonb;r jsonb;m jsonb;catalog jsonb;begin
 if p_protocol_version is distinct from 1 or p_unit_id is null then raise exception using errcode='23514',message='Invalid metadata request.';end if;
 -- METADATA_BOUNDARY_a_BEGIN
 perform public._work_activity_read_committed();perform public._work_activity_gate();a:=public._work_activity_actor();perform pg_advisory_xact_lock(7710,0);a:=public._work_activity_actor();
 if not coalesce((select encode(sha256(convert_to(pin.value::text,'UTF8')),'hex')='63eb01e50016563968e2056c8997bc2a7b87d7221b20b5d253d7a1e751bc16b8' from (select jsonb_build_object('body',p.prosrc,'owner',pg_get_userbyid(p.proowner),'acl',p.proacl::text,'definer',p.prosecdef,'config',p.proconfig,'volatility',p.provolatile,'strict',p.proisstrict,'leakproof',p.proleakproof,'parallel',p.proparallel,'kind',p.prokind,'set',p.proretset,'result',pg_get_function_result(p.oid),'args',pg_get_function_identity_arguments(p.oid),'defaults',pg_get_expr(p.proargdefaults,0),'cost',p.procost,'rows',p.prorows,'support',p.prosupport::regprocedure::text,'language',(select lanname from pg_language where oid=p.prolang)) value from pg_proc p where p.oid=to_regprocedure('public._work_unit_metadata_coverage()'))pin),false) then a:=null;
 elsif not public._work_unit_metadata_coverage() or not public._work_unit_review_coverage() or not public._work_totals_coverage() or not public._work_unit_contributors_coverage() then a:=null;end if;
 -- METADATA_BOUNDARY_a_END
if a is not null then s:=public._work_unit_review_scope(a,p_unit_id);r:=public._work_unit_review_view(a,s);m:=public._work_unit_metadata_state(a,s,r);end if;
 if m is null then return jsonb_build_object('protocolVersion',1,'availability','unavailable','metadata',null);end if;
 select coalesce(jsonb_agg(jsonb_build_object('definitionId',d.id,'versionId',v.id,'version',v.version,'kind',d.kind,'projectId',d.project_id,'code',d.code,'state',v.state,'definition',v.value) order by d.kind,d.id,v.version),'[]') into catalog
 from public._work_unit_metadata_definitions d join public._work_unit_metadata_versions v on v.definition_id=d.id
 where d.project_id is null or d.project_id=(s#>>'{unit,projectId}')::uuid;
 if jsonb_array_length(catalog)>500 or octet_length(catalog::text)>1000000 then return jsonb_build_object('protocolVersion',1,'availability','unavailable','metadata',null);end if;
 return jsonb_build_object('protocolVersion',1,'availability','available','metadata',m||jsonb_build_object('asOf',public._work_activity_iso(clock_timestamp()),'catalog',catalog,
 'capabilities',jsonb_build_object('assign',public._is_lead(a) or exists(select 1 from public.custom_work_units where id=p_unit_id and created_by=a),'allocate',public._work_unit_review_authority(a,s->'jobs','dimensions_edit'),'publish',public._work_config_is_owner(a),'propose',public._work_config_is_supervisor(a))));
end$$;
