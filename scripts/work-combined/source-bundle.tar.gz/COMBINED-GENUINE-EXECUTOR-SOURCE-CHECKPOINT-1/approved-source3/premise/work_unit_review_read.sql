create function public.work_unit_review_read(p_unit_id uuid) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare actor uuid;s jsonb;v jsonb;t timestamptz;
begin
 perform public._work_activity_read_committed();perform public._work_activity_gate();actor:=public._work_activity_actor();
 perform pg_advisory_xact_lock(7710,0);actor:=public._work_activity_actor();t:=clock_timestamp();
 s:=public._work_unit_review_scope(actor,p_unit_id);v:=public._work_unit_review_view(actor,s);
 if octet_length(v::text)>102400 then v:=null;end if;
 return jsonb_build_object('protocolVersion',1,'asOf',public._work_activity_iso(t),'availability',case when v is null then 'unavailable' else 'available' end,'review',v);
end; $$;
