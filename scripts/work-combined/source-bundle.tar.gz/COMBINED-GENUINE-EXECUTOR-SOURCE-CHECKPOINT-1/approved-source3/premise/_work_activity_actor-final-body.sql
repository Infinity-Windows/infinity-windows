
declare v_actor uuid;
begin
  perform public._work_activity_gate();
  v_actor:=auth.uid();
  if not public._work_config_internal(v_actor) then
    raise exception using errcode='42501',message='An eligible Forge account is required.';
  end if;
  return v_actor;
end; 