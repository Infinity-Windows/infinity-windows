create function public.work_activity_totals_read(p_project_id uuid,p_unit_id uuid default null) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare actor uuid;stamp timestamptz;ids uuid[];sid uuid;ledger jsonb;ledgers jsonb:='[]';rows jsonb;unit_scope jsonb;review jsonb;unitrow public.custom_work_units;
 available constant jsonb:='{"protocolVersion":1,"availability":"unavailable","totals":null}';complete boolean:=true;personal_complete boolean:=true;trusted boolean:=false;
 orphan record;orphan_proof jsonb;scope_unproven boolean:=false;own_scope_unproven boolean:=false;reconciliation_authorized boolean:=false;reconciliation_ledgers jsonb;orphan_count integer:=0;cohort jsonb;reason text[]:='{}';area numeric;factor_num numeric;factor_den numeric;labor numeric;own_labor numeric;actual numeric;cohort_scope boolean;
begin
 perform public._work_activity_read_committed();perform public._work_activity_gate();actor:=public._work_activity_actor();
 perform pg_advisory_xact_lock(7710,0);actor:=public._work_activity_actor();stamp:=clock_timestamp();
 if p_project_id is null or not public._ai_job_visible(p_project_id,actor) or not public._work_unit_review_coverage() or not public._work_totals_coverage() then return available;end if;
 reconciliation_authorized:=public._work_unit_review_authority(actor,jsonb_build_array(p_project_id),'final_qc');
 if p_unit_id is not null then
 select * into unitrow from public.custom_work_units where id=p_unit_id;
 if unitrow.id is null or unitrow.project_id<>p_project_id then return available;end if;
 unit_scope:=public._work_unit_review_scope(actor,p_unit_id);if unit_scope is null then return available;end if;
 review:=public._work_unit_review_view(actor,unit_scope);if review is null then return available;end if;
 reconciliation_authorized:=reconciliation_authorized and public._work_unit_review_authority(actor,unit_scope->'jobs','final_qc');
 own_scope_unproven:=exists(select 1 from jsonb_array_elements(unit_scope#>'{manifest,history}') h where h->>'source_kind' in ('custom_work_sessions','unit_sessions','task_sessions','service_time_sessions') and (h#>>'{before_value,profile_id}'=actor::text or h#>>'{after_value,profile_id}'=actor::text) and not exists(select 1 from jsonb_array_elements(unit_scope#>'{manifest,transitions}') t where t#>>'{source,source_id}'=h->>'source_id' and t#>>'{source,source_shift_id}' is not null));
 scope_unproven:=not coalesce((unit_scope->>'proven')::boolean,false) or exists(
 select 1 from jsonb_array_elements(unit_scope#>'{manifest,history}') h where h->>'source_kind' in ('custom_work_sessions','unit_sessions','task_sessions','service_time_sessions')
 and not exists(select 1 from jsonb_array_elements(unit_scope#>'{manifest,transitions}') t where t#>>'{source,source_id}'=h->>'source_id' and t#>>'{source,source_shift_id}' is not null));
 end if;
 -- A legacy source without a retained payroll/transition binding cannot
 -- silently disappear into a zero. Check its original grants before the flag.
 for orphan in
 select distinct h.source_kind,h.source_id from public.work_activity_source_history h
 where h.source_kind in ('custom_work_sessions','service_time_sessions','task_sessions')
 and p_unit_id is null and (h.before_value->>'project_id'=p_project_id::text or h.after_value->>'project_id'=p_project_id::text)
 and not exists(select 1 from public.personal_activity_transition_sources e where e.source_id=h.source_id::uuid and e.source_shift_id is not null
 and e.source_kind=case h.source_kind when 'custom_work_sessions' then 'custom' when 'service_time_sessions' then 'service' else 'task' end)
 loop
 orphan_count:=orphan_count+1;if orphan_count>500 then return available;end if;
 orphan_proof:=public._work_totals_source(orphan.source_kind,orphan.source_id);
 if not public._work_totals_visible(actor,orphan.source_kind,orphan_proof) then return available;end if;
 scope_unproven:=true;
 reconciliation_authorized:=reconciliation_authorized and public._work_totals_visible(actor,orphan.source_kind,orphan_proof,0,true);
 own_scope_unproven:=own_scope_unproven or orphan_proof#>>'{current,profile_id}'=actor::text or exists(select 1 from jsonb_array_elements(orphan_proof->'history') h where h#>>'{before_value,profile_id}'=actor::text or h#>>'{after_value,profile_id}'=actor::text);
 end loop;
 complete:=not scope_unproven;personal_complete:=not scope_unproven;
 -- Include current payroll allocations and original captured project bindings.
 -- A missing retained shift is unavailable; it never becomes synthetic zero.
 select array_agg(distinct id) into ids from (
 select id from public.time_shifts where p_unit_id is null and project_id=p_project_id
 union select s.shift_id from public.custom_work_sessions s where (p_unit_id is null and s.project_id=p_project_id) or (p_unit_id is not null and s.unit_id=p_unit_id)
 union select s.shift_id from public.custom_work_sessions s join public.work_session_capture_metadata m on m.session_id=s.id where (p_unit_id is null and m.project_id=p_project_id) or (p_unit_id is not null and m.unit_id=p_unit_id)
 union select (case when source_kind='time_shifts' then source_id else before_value->>'shift_id' end)::uuid from public.work_activity_source_history where source_kind in ('custom_work_sessions','service_time_sessions','time_shifts','task_sessions','project_openings') and p_unit_id is null and before_value->>'project_id'=p_project_id::text
 union select (case when source_kind='time_shifts' then source_id else after_value->>'shift_id' end)::uuid from public.work_activity_source_history where source_kind in ('custom_work_sessions','service_time_sessions','time_shifts','task_sessions','project_openings') and p_unit_id is null and after_value->>'project_id'=p_project_id::text
 union select (case when source_kind='time_shifts' then source_id else before_value->>'shift_id' end)::uuid from public.work_activity_source_history where source_kind='custom_work_sessions' and p_unit_id is not null and before_value->>'unit_id'=p_unit_id::text
 union select (case when source_kind='time_shifts' then source_id else after_value->>'shift_id' end)::uuid from public.work_activity_source_history where source_kind='custom_work_sessions' and p_unit_id is not null and after_value->>'unit_id'=p_unit_id::text
 union select (n#>>'{source,source_shift_id}')::uuid from jsonb_array_elements(unit_scope#>'{manifest,transitions}') n
 union select e.source_shift_id from public.personal_activity_transition_sources e where p_unit_id is null and (e.before_evidence->>'project_id'=p_project_id::text or e.after_evidence->>'project_id'=p_project_id::text)
 union select e.source_shift_id from public.personal_activity_transition_sources e join public.project_openings o on o.id::text=coalesce(e.after_evidence->>'opening_id',e.before_evidence->>'opening_id') where p_unit_id is null and o.project_id=p_project_id
 union select e.source_shift_id from public.personal_activity_transition_sources e join public.work_activity_source_history h on h.source_kind='project_openings' and h.source_id=coalesce(e.after_evidence->>'opening_id',e.before_evidence->>'opening_id') where p_unit_id is null and (h.before_value->>'project_id'=p_project_id::text or h.after_value->>'project_id'=p_project_id::text)
 ) q where id is not null;
 if coalesce(array_length(ids,1),0)>500 then return available;end if;
 foreach sid in array coalesce(ids,'{}') loop
 ledger:=public._work_totals_shift(actor,sid,stamp);
 if ledger->>'availability'<>'available' then return available;end if;
 ledgers:=ledgers||jsonb_build_array(ledger);
 reconciliation_authorized:=reconciliation_authorized and coalesce((ledger->>'reconciliationAuthorized')::boolean,false);
 complete:=complete and (ledger->>'complete')::boolean;
 if ledger->>'profileId'=actor::text then personal_complete:=personal_complete and (ledger->>'complete')::boolean;end if;
 end loop;
 if octet_length(ledgers::text)>5000000 then return available;end if;
 -- Detailed payroll/review evidence has a stricter boundary than activity totals.
 select coalesce(jsonb_agg(l),'[]') into reconciliation_ledgers from jsonb_array_elements(ledgers) l where reconciliation_authorized or l->>'profileId'=actor::text;
 own_scope_unproven:=coalesce(own_scope_unproven,false) or exists(select 1 from jsonb_array_elements(reconciliation_ledgers) l where l->>'profileId'=actor::text and not (l->>'complete')::boolean);
 with claims as(select c.* from jsonb_array_elements(ledgers) l cross join lateral jsonb_to_recordset(l->'claims') as c("profileId" uuid,"projectId" uuid,"unitId" uuid,"definitionId" uuid,"definitionVersionId" uuid,"definitionVersion" integer,scope text,"labelEn" text,"labelEs" text,"machineKind" text,microseconds text,live boolean)
 where ((p_unit_id is null and c."projectId"=p_project_id and c.scope='general') or (p_unit_id is not null and c.scope='specific' and c."unitId"=p_unit_id))),
 grouped as(select "definitionId","definitionVersionId","definitionVersion",scope,"labelEn","labelEs",sum(microseconds::numeric) us,
 coalesce(sum(microseconds::numeric) filter(where "profileId"=actor),0) own,bool_or(live and "profileId"=actor) live from claims group by 1,2,3,4,5,6)
 select coalesce(jsonb_agg(jsonb_build_object('definitionId',g."definitionId",'definitionVersionId',g."definitionVersionId",'definitionVersion',g."definitionVersion",'scope',g.scope,
 'labelEn',g."labelEn",'labelEs',g."labelEs",'retired',d.retired_at is not null,
 'personal',jsonb_build_object('state',case when personal_complete then 'known' else 'partial' end,'microseconds',case when personal_complete then g.own::text end,'knownMicros',g.own::text,'includesLive',g.live),
 'scopeTotal',jsonb_build_object('state',case when complete then 'known' else 'partial' end,'microseconds',case when complete then g.us::text end,'knownMicros',g.us::text),
 'machineSubsets',(select coalesce(jsonb_agg(jsonb_build_object('machineKind',m.kind,'microseconds',m.us::text) order by m.kind),'[]') from(
 select "machineKind" kind,sum(microseconds::numeric) us from claims c where c."definitionVersionId"=g."definitionVersionId" and "machineKind" is not null group by 1)m)
 ) order by g."definitionId",g."definitionVersion"),'[]') into rows from grouped g join public.work_activity_definitions d on d.id=g."definitionId";
 select coalesce(sum((c->>'microseconds')::numeric),0),coalesce(sum((c->>'microseconds')::numeric)filter(where c->>'profileId'=actor::text),0) into labor,own_labor
 from jsonb_array_elements(ledgers) l cross join lateral jsonb_array_elements(l->'claims')c
 where ((p_unit_id is null and c->>'projectId'=p_project_id::text and c->>'scope'='general') or (p_unit_id is not null and c->>'scope'='specific' and c->>'unitId'=p_unit_id::text));
 cohort_scope:=p_unit_id is not null and reconciliation_authorized and public._work_unit_review_authority(actor,unit_scope->'jobs','final_qc');
 if not cohort_scope then cohort:=jsonb_build_object('availability','unavailable','reason',case when p_unit_id is null then 'unit_selection_required' else 'role_restricted' end);
 else
 if not complete then reason:=array_append(reason,'coverage_incomplete');end if;
 if exists(select 1 from jsonb_array_elements(ledgers)l where (l->>'unclassifiedMicros')::numeric>0) then reason:=array_append(reason,'unclassified_coverage');end if;
 if exists(select 1 from jsonb_array_elements(ledgers)l where not (l->>'approved')::boolean or (l->>'policyAdjustmentMicros')::numeric<>0) then reason:=array_append(reason,'payroll_not_trusted');end if;
 if review#>>'{dimensionVerification,state}'<>'verified' then reason:=array_append(reason,'dimensions_unverified');end if;
 if review#>>'{qc,qcAccepted}' is distinct from 'true' then reason:=array_append(reason,'qc_not_current_accepted');end if;
 if (unit_scope->>'active')::integer<>0 or (unit_scope->>'pending')::integer<>0 then reason:=array_append(reason,'active_or_rework');end if;
 if labor<=0 then reason:=array_append(reason,'no_attributed_labor');end if;
 factor_num:=case unit_scope#>>'{observation,unit}' when 'in' then 1 when 'ft' then 12 when 'mm' then 5 when 'cm' then 50 end;
 factor_den:=case unit_scope#>>'{observation,unit}' when 'mm' then 127 when 'cm' then 127 else 1 end;
 -- Exact rational area, no floating-point transport or rounded comparisons.
 if factor_num is null or unit_scope#>>'{observation,widthDecimal}' is null then reason:=array_append(reason,'area_unknown');
 else area:=(unit_scope#>>'{observation,widthDecimal}')::numeric*(unit_scope#>>'{observation,heightDecimal}')::numeric*factor_num*factor_num;end if;
 trusted:=cardinality(reason)=0;
 cohort:=jsonb_build_object('availability','available','unitId',p_unit_id,'eligible',trusted,'exclusions',to_jsonb(reason),
 'actualLaborMicros',labor::text,'excludedLaborMicros',case when trusted then '0' else labor::text end,
 'eligibleUnitIds',case when trusted then jsonb_build_array(p_unit_id) else '[]'::jsonb end,
 'laborNumeratorMicros',case when trusted then labor::text else '0' end,
 'areaSquareFeetNumerator',case when trusted then trim_scale(area)::text else '0' end,
 'areaSquareFeetDenominator',trim_scale(factor_den*factor_den*144)::text,
 'dimensionSource',unit_scope#>'{observation,source}','dimensionVerification',review#>'{dimensionVerification,state}',
 'floor',jsonb_build_object('state','unallocated','label',nullif(unitrow.facts->>'story',''),'areaCountedOnce',true),'generalOverheadIncluded',false);
 end if;
 return jsonb_build_object('protocolVersion',1,'availability','available','totals',jsonb_build_object('asOf',public._work_activity_iso(stamp),'actorId',actor,'projectId',p_project_id,'unitId',p_unit_id,
 'window',jsonb_build_object('kind','all_retained_selected_scope','from',null,'until',public._work_activity_iso(stamp),'personalScope','actual_actor_selected_scope'),
 'complete',complete,'personalComplete',personal_complete,'activities',rows,'scopeKnownMicros',labor::text,'personalKnownMicros',own_labor::text,
 'reconciliation',(select jsonb_build_object('scope',case when reconciliation_authorized then 'authorized_scope' else 'personal' end,'unresolvedScope',case when reconciliation_authorized then scope_unproven else own_scope_unproven end,'ledgerCount',count(*),'grossMicros',case when count(*)filter(where l->>'grossMicros' is null)=0 then sum((l->>'grossMicros')::numeric)::text end,
 'payrollMicros',case when count(*)filter(where l->>'payrollMicros' is null)=0 then sum((l->>'payrollMicros')::numeric)::text end,
 'classifiedMicros',coalesce(sum((l->>'classifiedMicros')::numeric),0)::text,'setupMicros',coalesce(sum((l->>'setupMicros')::numeric),0)::text,
 'unclassifiedMicros',coalesce(sum((l->>'unclassifiedMicros')::numeric),0)::text,'breakElapsedMicros',coalesce(sum((l->>'breakElapsedMicros')::numeric),0)::text,
 'breakDeductionMicros',coalesce(sum((l->>'breakDeductionMicros')::numeric),0)::text,'policyAdjustmentMicros',coalesce(sum((l->>'policyAdjustmentMicros')::numeric),0)::text,
 'issues',(select coalesce(jsonb_agg(distinct i),'[]') from jsonb_array_elements(reconciliation_ledgers)z cross join lateral jsonb_array_elements(z->'issues')i)) from jsonb_array_elements(reconciliation_ledgers)l),
 'cohort',cohort));
end$$;
