
begin
  if current_setting('transaction_isolation') <> 'read committed' then
    raise exception using errcode='25000',message='Activity coordination requires READ COMMITTED.';
  end if;
  perform pg_advisory_xact_lock(7712,0);
end; 