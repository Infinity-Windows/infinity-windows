
  select p_uid is not null and exists (
    select 1 from public.profiles
     where id = p_uid and retired_at is null and access_revoked_at is null
       and not coalesce(is_partner, false)
       and role in ('installer', 'foreman', 'supervisor', 'owner'))
