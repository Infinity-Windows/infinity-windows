
declare u public.custom_work_units; f public.work_unit_fact_revisions; eligible boolean; reason text; dimensions jsonb;
begin
  if p_actor is distinct from auth.uid() or not public._work_config_internal(p_actor) then return null; end if;
  select * into u from public.custom_work_units where id=p_unit_id;
  if u.id is null or not public._work_unit_fact_context_visible(p_actor,
      case when u.project_id is null then 'unassigned' else 'job' end,u.project_id,u.opening_id,u.created_by,public.is_test_profile(u.created_by),false) then return null; end if;
  select r.* into f from public.work_unit_fact_revisions r join public.work_unit_fact_current c on c.current_revision_id=r.id where c.unit_id=u.id;
  if f.id is not null and (f.unit_incarnation_epoch is distinct from public._work_unit_fact_peek_epoch('unit_incarnation',u.id)
    or not public._work_unit_fact_context_visible(p_actor,f.origin_kind,f.origin_project_id,f.origin_opening_id,f.origin_author_id,f.origin_is_test,true)) then return null; end if;
  eligible:=u.project_id is not null and f.id is not null and f.raw_observation is not null
    and f.width_in>0 and f.width_in<=100000 and f.height_in>0 and f.height_in<=100000 and f.measurement_source in ('measured','plans','estimated');
  eligible:=coalesce(eligible,false);
  reason:=case when u.project_id is null then 'unassigned' when f.event_kind in ('incomplete','cleared') then 'incomplete_dimensions' when f.id is null or f.raw_observation is null then 'missing_observation'
    when not eligible then 'incomplete_dimensions' else null end;
  dimensions:=case when f.width_in is not null and f.height_in is not null and f.measurement_source is not null then
    jsonb_build_object('widthIn',f.width_in,'heightIn',f.height_in,'source',f.measurement_source,
      'original',case when f.raw_observation is not null then jsonb_build_object('width',f.raw_observation->'width','height',f.raw_observation->'height',
        'unit',f.measurement_unit,'source',f.measurement_source,'sourceReference',f.source_reference) else 'null'::jsonb end)
    else 'null'::jsonb end;
  return jsonb_build_object('id',u.id,'projectId',u.project_id,'openingId',u.opening_id,'operationalRevision',u.revision,
    'incarnationEpoch',public._work_unit_fact_peek_epoch('unit_incarnation',u.id),'bindingEpoch',public._work_unit_fact_peek_epoch('unit_binding',u.id),
    'projectEpoch',case when u.project_id is not null then public._work_unit_fact_peek_epoch('project',u.project_id) end,
    'openingEpoch',case when u.opening_id is not null then public._work_unit_fact_peek_epoch('opening',u.opening_id) end,
    'fact',case when f.id is not null then jsonb_build_object('id',f.id,'revision',f.revision,'eventKind',f.event_kind,
      'originProjectEpoch',case when f.origin_project_id is not null then public._work_unit_fact_peek_epoch('project',f.origin_project_id) end,
      'originOpeningEpoch',case when f.origin_opening_id is not null then public._work_unit_fact_peek_epoch('opening',f.origin_opening_id) end,
      'dimensions',dimensions,'estimated',f.estimated) else 'null'::jsonb end,
    'eligibleForCapture',eligible,'ineligibleReason',reason);
end; 