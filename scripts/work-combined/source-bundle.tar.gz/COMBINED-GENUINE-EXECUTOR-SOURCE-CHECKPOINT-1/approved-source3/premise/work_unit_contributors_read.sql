create function public.work_unit_contributors_read(p_project_id uuid,p_unit_id uuid,p_protocol_version integer default 1) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare actor uuid;stamp timestamptz;u public.custom_work_units;s jsonb;review jsonb;ids uuid[];sid uuid;ledger jsonb;proof_cache jsonb:='{}';ledgers jsonb:='[]';claims jsonb;v jsonb;w jsonb;r jsonb;n jsonb;
 reasons text[]:='{}';row_reasons text[];subject uuid;subjects uuid[];person jsonb;people jsonb:='[]';zero_only jsonb:='[]';named jsonb:='[]';untimed jsonb:='[]';entries jsonb;
 micros numeric;positive boolean;uncertain boolean;named_person boolean;live boolean;proof_bytes bigint:=0;
 unavailable constant jsonb:='{"protocolVersion":1,"availability":"unavailable","contributors":null}';
begin
 perform public._work_activity_read_committed();perform public._work_activity_gate();actor:=public._work_activity_actor();
 if not public._work_config_is_supervisor(actor) then raise exception using errcode='42501',message='A current supervisor or owner is required.';end if;
 perform pg_advisory_xact_lock(7710,0);actor:=public._work_activity_actor();
 if not public._work_config_is_supervisor(actor) then raise exception using errcode='42501',message='A current supervisor or owner is required.';end if;
 stamp:=clock_timestamp();
 if p_protocol_version is distinct from 1 or p_project_id is null or p_unit_id is null then raise exception using errcode='23514',message='A valid unit contributors request is required.';end if;
 if not public._ai_job_visible(p_project_id,actor) or not public._work_unit_review_coverage() or not public._work_totals_coverage() or not public._work_unit_contributors_coverage() then return unavailable;end if;
 select * into u from public.custom_work_units where id=p_unit_id;
 if u.id is null or u.project_id is distinct from p_project_id then return unavailable;end if;
 s:=public._work_unit_review_scope(actor,p_unit_id);if s is null then return unavailable;end if;
 review:=public._work_unit_review_view(actor,s);if review is null then return unavailable;end if;
 if not coalesce((s->>'proven')::boolean,false) then reasons:=array_append(reasons,'source_unproven');end if;
 if exists(select 1 from jsonb_array_elements(s#>'{manifest,history}')h where h->>'source_kind' in ('custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','summon_helpers')
 and not exists(select 1 from jsonb_array_elements(s#>'{manifest,transitions}')t where t#>>'{source,source_id}'=h->>'source_id' and t#>>'{source,source_shift_id}' is not null)) then reasons:=array_append(reasons,'legacy_unmapped');end if;
 -- One distinct-shift assembly. No public v1 call, person fanout or new clock.
 select array_agg(id order by id) into ids from (
 select distinct id from (
 select c.shift_id id from public.custom_work_sessions c where c.unit_id=p_unit_id
 union select c.shift_id from public.custom_work_sessions c join public.work_session_capture_metadata m on m.session_id=c.id where m.unit_id=p_unit_id
 union select (h.before_value->>'shift_id')::uuid from public.work_activity_source_history h where h.source_kind='custom_work_sessions' and h.before_value->>'unit_id'=p_unit_id::text
 union select (h.after_value->>'shift_id')::uuid from public.work_activity_source_history h where h.source_kind='custom_work_sessions' and h.after_value->>'unit_id'=p_unit_id::text
 union select (t#>>'{source,source_shift_id}')::uuid from jsonb_array_elements(s#>'{manifest,transitions}')t
 )all_ids where id is not null limit 501)bounded;
 if coalesce(cardinality(ids),0)>500 then return unavailable;end if;
 if (select count(*) from(select 1 from public.personal_activity_transitions where source_shift_id=any(ids) limit 10001)x)>10000
 or (select count(*) from(select 1 from public.personal_activity_transition_sources where source_shift_id=any(ids) limit 10001)x)>10000 then return unavailable;end if;
 foreach sid in array coalesce(ids,'{}') loop
 ledger:=public._work_unit_contributors_shift(actor,sid,stamp,proof_cache);
 if ledger->>'availability'<>'available' then return unavailable;end if;
 proof_cache:=ledger->'proofCache';ledger:=ledger-'proofCache';
 if octet_length(proof_cache::text)>5000000 then return unavailable;end if;
 proof_bytes:=proof_bytes+octet_length(ledger::text);if proof_bytes>5000000 then return unavailable;end if;
 ledgers:=ledgers||jsonb_build_array(ledger);
 if not coalesce((ledger->>'complete')::boolean,false) then reasons:=array_append(reasons,'source_unproven');end if;
 if ledger->'issues' ?| array['open_not_extrapolated','own_live_provisional'] then reasons:=array_append(reasons,'open_shift');end if;
 if ledger->'issues' ? 'legacy_activity_unmapped' then reasons:=array_append(reasons,'legacy_unmapped');end if;
 if ledger->'issues' ? 'negative_interval' then reasons:=array_append(reasons,'negative_interval');end if;
 end loop;
 -- Match v1 positive scope exactly; zero is additional validated audit evidence.
 select coalesce(jsonb_agg(c order by c->>'profileId',c->>'shiftId',c->>'intervalId'),'[]') into claims
 from jsonb_array_elements(ledgers)l cross join lateral jsonb_array_elements(l->'claims')c
 where c->>'scope'='specific' and c->>'unitId'=p_unit_id::text;
 if exists(select 1 from jsonb_array_elements(claims)c group by c->>'shiftId',c->>'intervalId' having count(*)<>1)
 or exists(select 1 from jsonb_array_elements(claims)c where c->>'microseconds' !~ '^(0|[1-9][0-9]{0,39})$'
 or c->>'unitIncarnation' is distinct from s#>>'{manifest,incarnation}') then return unavailable;end if;
 -- Named work is never assigned time. Current effective links control display;
 -- retained originals already participate in the complete permission closure.
 for v in select value from jsonb_array_elements(s#>'{manifest,current}') loop
 w:=v->'value';subject:=null;n:=null;
 if v->>'kind'='crew_work_record_people' and w->>'voided_at' is null then
 select x->'value' into r from jsonb_array_elements(s#>'{manifest,current}')x where x->>'kind'='crew_work_records' and x->>'id'=w->>'record_id';
 if r->>'unit_id'=p_unit_id::text and r->>'outcome' in ('partial','finished') then subject:=(w->>'profile_id')::uuid;n:=jsonb_build_object('sourceKind','crew_work_record_people','sourceId',v->>'id','workDate',r->>'work_date','recordedAt',null,'activityLabel',r->>'stage','evidenceState','named');end if;
 elsif v->>'kind'='opening_phases' and w->>'started_by' is not null and w->>'started_at' is not null then
 if w->>'opening_id' is distinct from u.opening_id::text then reasons:=array_append(reasons,'source_unproven');continue;end if;
 -- An exact accepted transition child is corroboration, not extra named work.
 if not exists(select 1 from jsonb_array_elements(s#>'{manifest,transitions}')t join jsonb_array_elements(claims)c on c->>'intervalId'=t#>>'{source,transition_id}' and c->>'profileId'=w->>'started_by'
 where t#>>'{source,source_kind}'='phase' and t#>>'{source,source_id}'=v->>'id') then
 subject:=(w->>'started_by')::uuid;n:=jsonb_build_object('sourceKind','opening_phases','sourceId',v->>'id','workDate',((w->>'started_at')::timestamptz at time zone 'America/Denver')::date::text,'recordedAt',public._work_activity_iso((w->>'started_at')::timestamptz),'activityLabel',w->>'kind','evidenceState','named');end if;
 elsif v->>'kind'='install_events' and w->>'installer_id' is not null and w->>'voided_at' is null then
 if w->>'project_opening_id' is distinct from u.opening_id::text then reasons:=array_append(reasons,'source_unproven');continue;end if;
 subject:=(w->>'installer_id')::uuid;n:=jsonb_build_object('sourceKind','install_events','sourceId',v->>'id','workDate',case when w->>'started_at' is not null then ((w->>'started_at')::timestamptz at time zone 'America/Denver')::date::text end,'recordedAt',public._work_activity_iso((w->>'started_at')::timestamptz),'activityLabel','Install (legacy)','evidenceState','named');
 elsif v->>'kind'='qc_checks' and w->>'checked_by' is not null and w->>'checked_at' is not null then
 if w->>'project_opening_id' is distinct from u.opening_id::text then reasons:=array_append(reasons,'source_unproven');continue;end if;
 subject:=(w->>'checked_by')::uuid;n:=jsonb_build_object('sourceKind','qc_checks','sourceId',v->>'id','workDate',((w->>'checked_at')::timestamptz at time zone 'America/Denver')::date::text,'recordedAt',public._work_activity_iso((w->>'checked_at')::timestamptz),'activityLabel','Quality review','evidenceState','named');
 end if;
 if subject is not null then
 if (n->>'recordedAt')::timestamptz>stamp or (n->>'workDate')::date>(stamp at time zone 'America/Denver')::date then
 reasons:=array_append(reasons,'source_unproven');
 else named:=named||jsonb_build_array(jsonb_build_object('profileId',subject,'evidence',n));end if;
 end if;
 if jsonb_array_length(named)>4000 then return unavailable;end if;
 end loop;
 for r in select to_jsonb(e) from public.work_unit_review_events e where e.unit_id=p_unit_id and e.incarnation=(s#>>'{manifest,incarnation}')::bigint and e.action in ('pass','fail') loop
 named:=named||jsonb_build_array(jsonb_build_object('profileId',r->>'actor_id','evidence',jsonb_build_object('sourceKind','work_unit_review_events','sourceId',r->>'id','workDate',((r->>'recorded_at')::timestamptz at time zone 'America/Denver')::date::text,'recordedAt',public._work_activity_iso((r->>'recorded_at')::timestamptz),'activityLabel','Quality review','evidenceState','named')));
 if jsonb_array_length(named)>4000 then return unavailable;end if;
 end loop;
 if named<>'[]' then reasons:=array_append(reasons,'named_unlinked');end if;
 -- Include uncertainty subjects without inventing their measured amounts.
 select array_agg(profile order by profile) into subjects from (
 select distinct profile from (
 select (c->>'profileId')::uuid profile from jsonb_array_elements(claims)c
 union select (n.value->>'profileId')::uuid from jsonb_array_elements(named)n
 union select (h.value->>'profile_id')::uuid from jsonb_array_elements(s#>'{manifest,history}')x cross join lateral(values(x->'before_value'),(x->'after_value'))h(value)
 where x->>'source_kind' in ('custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','summon_helpers')
 )p where profile is not null limit 201)bounded;
 if coalesce(cardinality(subjects),0)>200 then return unavailable;end if;
 if exists(select 1 from unnest(subjects)p where not exists(select 1 from public.profiles where id=p)) then reasons:=array_append(reasons,'identity_unproven');end if;
 select coalesce(array_agg(distinct rr.code order by rr.code),'{}') into reasons from unnest(reasons)rr(code);
 select coalesce(sum((c->>'microseconds')::numeric),0),coalesce(bool_or((c->>'live')::boolean and (c->>'microseconds')::numeric>0),false) into micros,live from jsonb_array_elements(claims)c;
 foreach subject in array coalesce(subjects,'{}') loop
 named_person:=exists(select 1 from jsonb_array_elements(named)n where n.value->>'profileId'=subject::text);
 positive:=exists(select 1 from jsonb_array_elements(claims)c where c->>'profileId'=subject::text and (c->>'microseconds')::numeric>0);
 uncertain:=not exists(select 1 from jsonb_array_elements(claims)c where c->>'profileId'=subject::text)
 and exists(select 1 from jsonb_array_elements(s#>'{manifest,history}')x cross join lateral(values(x->'before_value'),(x->'after_value'))h(value)
 where x->>'source_kind' in ('custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','summon_helpers') and h.value->>'profile_id'=subject::text);
 row_reasons:=reasons;
 person:=public._work_unit_contributors_person(subject,claims,row_reasons,micros,reasons);if person is null then return unavailable;end if;
 if positive or uncertain then people:=people||jsonb_build_array(person);
 elsif exists(select 1 from jsonb_array_elements(claims)c where c->>'profileId'=subject::text) then
 -- Only an actual validated timer claim enters this branch. Pure named work
 -- without a claim or retained timer stays untimed-only, even on partial units.
 -- A zero audit requires complete, closed proof; zero elapsed time alone is
 -- insufficient. Uncertain zero claims cannot create a worked/tap count.
 if (person->>'complete')::boolean and person->>'measurementState'='recorded_zero' and not (person->>'includesLive')::boolean then
 person:=jsonb_set(person,'{share}',jsonb_build_object('state','unavailable','reasons',jsonb_build_array('zero')));
 zero_only:=zero_only||jsonb_build_array(person);
 else
 person:=person||jsonb_build_object('measurementState','unproven','activities','[]'::jsonb,'includesLive',false,'complete',false);
 people:=people||jsonb_build_array(person);
 end if;
 end if;
 if named_person then
 select jsonb_agg(n.value->'evidence' order by n.value#>>'{evidence,sourceKind}',n.value#>>'{evidence,sourceId}') into entries from jsonb_array_elements(named)n where n.value->>'profileId'=subject::text;
 untimed:=untimed||jsonb_build_array(jsonb_build_object('profileId',subject,'displayName',person->'displayName','nameState',person->'nameState','retired',person->'retired','evidence',entries));
 end if;
 end loop;
 if exists(select 1 from jsonb_array_elements(people)p where p->>'measurementState'='unproven') and cardinality(reasons)=0 then return unavailable;end if;
 select coalesce(jsonb_agg(p order by (p->>'knownMicros')::numeric desc,p->>'profileId'),'[]') into people from jsonb_array_elements(people)p;
 if (select coalesce(sum((p->>'knownMicros')::numeric),0) from jsonb_array_elements(people)p)<>micros then return unavailable;end if;
 if (select coalesce(sum(jsonb_array_length(p->'activities')),0) from jsonb_array_elements(people||zero_only)p)>2000 then return unavailable;end if;
 n:=jsonb_build_object('asOf',public._work_activity_iso(stamp),'actorId',actor,'projectId',p_project_id,'unitId',p_unit_id,'unitIncarnation',s#>>'{manifest,incarnation}',
 'window',jsonb_build_object('kind','all_retained_selected_unit','from',null,'until',public._work_activity_iso(stamp)),
 'unitKnownMicros',micros::text,'unitComplete',cardinality(reasons)=0,'completenessReasons',to_jsonb(case when micros=0 then reasons||array['zero'] else reasons end),'includesLive',live,
 'people',people,'zeroOnly',zero_only,'untimedParticipants',untimed,
 'participantCounts',jsonb_build_object('timed',(select count(*) from jsonb_array_elements(people)p where (p->>'knownMicros')::numeric>0),'timingUncertain',(select count(*) from jsonb_array_elements(people)p where p->>'measurementState'='unproven'),'untimedOnly',(select count(*) from jsonb_array_elements(untimed)n where not exists(select 1 from jsonb_array_elements(people)p where p->>'profileId'=n.value->>'profileId')),'zeroOnly',jsonb_array_length(zero_only),'total',(select count(distinct x->>'profileId') from jsonb_array_elements(people||untimed)x)),
 'unresolvedAttribution',jsonb_build_object('present',cardinality(reasons)>0,'unknownMicros',case when cardinality(reasons)=0 then '0' end,'reasons',to_jsonb(reasons)));
 if octet_length(n::text)>1000000 then return unavailable;end if;
 return jsonb_build_object('protocolVersion',1,'availability','available','contributors',n);
end$$;
