-- Authored read-only historical recovery. No provider session attestation is supplied.
create function public.work_activity_clock_receipt_v2(
 p_project_id uuid,p_cost_code_id uuid,p_photo text,p_lat double precision,p_lng double precision,
 p_note text,p_mode text,p_client_id uuid,p_tapped_at timestamptz,p_clock_checked_at timestamptz,p_clock_skew_ms integer,p_setup_version integer
) returns jsonb language plpgsql volatile security definer set search_path=public,pg_temp as $paid_reader$
declare actor uuid;r public.work_activity_clock_receipts;stamp public.work_cross_job_clock_requests;
 registration public.work_cross_job_shifts;digest text;fingerprint text;present boolean;registered boolean;as_of timestamptz;
 missing constant jsonb:='{"protocolVersion":2,"contract":"paid_setup_v2_recovery_v1","availability":"unavailable","receipt":null,"proof":null,"current":null}'::jsonb;
begin
 -- Float serialization is part of the original request digest. Never try alternate settings.
 if current_setting('extra_float_digits') is distinct from '1' then
  raise exception using errcode='55000',message='Paid recovery serialization setting is unavailable.';
 end if;
 perform public._work_activity_read_committed();
 perform public._work_activity_gate();perform pg_advisory_xact_lock(7710,0);actor:=public._work_activity_actor();
 if not (coalesce((select p.prosrc is not null and encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='4572636a9f1ad22652fe4ece317efd18f38364993c0f793a4e10d1b16680282e' and pg_get_userbyid(p.proowner)='postgres' and p.proacl::text='{postgres=X/postgres}' and p.prosecdef and p.proconfig=array['search_path=public, pg_temp']::text[] and p.provolatile='s' and not p.proisstrict and not p.proleakproof and p.proparallel='u' and p.prokind='f' and not p.proretset and p.prorettype='boolean'::regtype and p.pronargs=0 and p.pronargdefaults=0 and p.procost=100 and p.prorows=0 and p.prosupport=0 and p.prolang=(select oid from pg_language where lanname='plpgsql') from pg_proc p where p.oid=to_regprocedure('public._work_cross_job_coverage()')),false) and public._work_cross_job_coverage()) then
  raise exception using errcode='55000',message='Paid recovery source contract is unavailable.';
 end if;
 -- These are the keyed outer writer's admitted typed stamp conditions, not new authoring rules.
 if p_client_id is null or p_tapped_at is null or not isfinite(p_tapped_at)
  or (p_clock_checked_at is not null and not isfinite(p_clock_checked_at))
  or p_setup_version is distinct from 2 then
  raise exception using errcode='23514',message='The exact original protocol 2 clock request is required.';
 end if;
 select * into r from public.work_activity_clock_receipts where client_id=p_client_id and profile_id=actor;
 if not found then return missing;end if;
 select * into stamp from public.work_cross_job_clock_requests where client_id=p_client_id and profile_id=actor;
 if not found then return missing;end if;
 if r.client_id is distinct from p_client_id or r.profile_id is distinct from actor or r.shift_id is null
  or r.action is distinct from 'clock_in' or r.outcome is distinct from 'clocked_in' or r.receipt_protocol is distinct from 'setup_v1'
  or r.used_tap_time is null or r.tapped_at is null or not isfinite(r.tapped_at)
  or r.arrived_at is null or not isfinite(r.arrived_at) or r.source_created_at is null or not isfinite(r.source_created_at)
  or r.recorded_at is null or not isfinite(r.recorded_at) or (r.clock_checked_at is not null and not isfinite(r.clock_checked_at))
  or r.setup_payload_digest is null or r.setup_payload_digest !~ '^[0-9a-f]{64}$'
  or stamp.client_id is distinct from r.client_id or stamp.profile_id is distinct from r.profile_id
  or stamp.shift_id is distinct from r.shift_id or stamp.setup_version is distinct from 2 or stamp.operation_id is null
 then return missing;end if;
 digest:=public._work_activity_clock_setup_digest(p_project_id,p_cost_code_id,p_photo,p_lat,p_lng,p_note,p_mode,p_client_id,p_tapped_at,p_clock_checked_at,p_clock_skew_ms);
 fingerprint:=public._work_cross_job_clock_receipt_fingerprint(r);
 if digest is distinct from r.setup_payload_digest or r.tapped_at is distinct from p_tapped_at
  or r.clock_checked_at is distinct from p_clock_checked_at or r.clock_skew_ms is distinct from p_clock_skew_ms
  or stamp.receipt_sha256 is distinct from fingerprint then return missing;end if;
 -- Registration absence is valid for original protocol 2 fallback. Present registration must agree.
 select * into registration from public.work_cross_job_shifts where shift_id=r.shift_id;
 registered:=found;
 if exists(select 1 from public.work_cross_job_shifts where clock_request_id=r.client_id
  and (shift_id is distinct from r.shift_id or profile_id is distinct from actor or generation is distinct from 2)) then return missing;end if;
 if registered and (registration.profile_id is distinct from actor or registration.clock_request_id is distinct from r.client_id
  or registration.generation is distinct from 2) then return missing;end if;
 -- Current source presence is a separate observation; neither visibility nor source retention rewrites history.
 present:=exists(select 1 from public.time_shifts where id=r.shift_id and profile_id=actor)
  and exists(select 1 from public.time_clock_actions where client_id=r.client_id and profile_id=actor and shift_id=r.shift_id and action='clock_in');
 as_of:=clock_timestamp();
 return jsonb_build_object('protocolVersion',2,'contract','paid_setup_v2_recovery_v1','availability','available',
 'receipt',jsonb_build_object('clientId',r.client_id,'profileId',r.profile_id,'shiftId',r.shift_id,'action',r.action,'outcome',r.outcome,
 'tappedAt',public._work_activity_iso(r.tapped_at),'arrivedAt',public._work_activity_iso(r.arrived_at),
 'clockCheckedAt',public._work_activity_iso(r.clock_checked_at),'clockSkewMs',r.clock_skew_ms,'usedTapTime',r.used_tap_time,
 'reviewReason',r.review_reason,'sourceCreatedAt',public._work_activity_iso(r.source_created_at),'receiptProtocol',r.receipt_protocol,
 'setupPayloadDigest',r.setup_payload_digest,'recordedAt',public._work_activity_iso(r.recorded_at)),
 'proof',jsonb_build_object('originalSetupVersion',2,'match','full_original_setup_digest','fingerprintVersion',1,'receiptSha256',fingerprint),
 'current',jsonb_build_object('asOf',public._work_activity_iso(as_of),'sourcePresent',present,'captureRegistered',registered));
end;
$paid_reader$;
revoke all on function public.work_activity_clock_receipt_v2(uuid,uuid,text,double precision,double precision,text,text,uuid,timestamptz,timestamptz,integer,integer) from public,anon,authenticated,service_role;
grant execute on function public.work_activity_clock_receipt_v2(uuid,uuid,text,double precision,double precision,text,text,uuid,timestamptz,timestamptz,integer,integer) to authenticated;
