# Disposable combined catalog and paid recovery reader

This is concrete candidate source for independent review, followed by a separately authorized disposable PostgreSQL fixture. It has not been executed against PostgreSQL. It does not install or activate anything. The source finishes with `ROLLBACK`, and `_work_cross_job_enabled()` remains the original literal `select false`.

## What was built

`candidate.sql` assembles the exact K6 capture source and the exact metadata source on their common 0846 predecessor. Both original source-owned preflights run before any DDL. The metadata preflight cannot run after K6 because K6 changes the catalog it expects. The assembler preserves those preflight bodies and changes their placement, rather than weakening them or accepting an observed catalog.

The two private coverage functions now attest one common JSON object containing the complete K6 public catalog and the complete metadata catalog. The latter retains the six actor-retention foreign keys, 24 internal RI trigger entries, namespace, private access, columns and other metadata-specific checks. Both existing proof tables store the same independently authored root. Their proof rows are inserted before their immutable contract triggers are created. No trigger is disabled or dropped. The existing metadata contract gate stays in place. This is possible only in this fresh disposable assembly; it is not an installed-K6 upgrade procedure.

The new `work_activity_clock_receipt_v2` function takes the exact twelve typed arguments of the outer paid setup writer. It returns a six-key envelope and, when fully matched, the original fifteen retained receipt fields, a four-key proof and a three-key current observation. It calls no writer, replay path, snapshot or observation function. The unchanged V1 reader and receipt fingerprint function remain byte-identical.

The reader requires `extra_float_digits = 1` before catalog access or receipt lookup, uses READ COMMITTED, acquires G then A, checks a fresh eligible actor and the exact combined attester, then reads only that actor's retained receipt and original-version stamp. It matches the complete original eleven-field setup digest plus incoming version 2, the original keyed timestamps/skew, and the exact fifteen-field receipt fingerprint. The legacy digest's internal version-1 domain value remains unchanged; the actual incoming version is independently proved by the retained version stamp. A missing, foreign, version-1 or inconsistent record returns the same unavailable envelope. SQL input/cast, authentication and catalog errors are not hidden by a catch-all.

Raw `p_mode` goes into the original digest. An inner writer may normalize that mode for the physical row; the reader does not replace the supplied original mode with that normalized value. No new coordinate range, finite-coordinate, text-length, current-job, current-visibility, toolbox, age or admission rule is applied to historical input. Nullable photo/note/mode/coordinate values remain typed inputs. The reader validates only the outer writer's keyed client/tap/check conditions and version 2 before historical matching. It does validate that the retained successful receipt has the supported original shape and finite required receipt timestamps.

Registration absence is valid for an original2 fallback. A present registration must match self, shift, request and generation 2; a registration using the same request for another shift is refused. Current source presence is a separate observation and never overwrites the historical receipt. The source does not claim that this lookup proves an allocation command's full intent.

## Source and catalog dependency closure

The assembler operates only on copied, pinned input bytes. It reproduces all three existing canonical catalog digests byte-for-byte: the common 0846 public catalog, K6's authored catalog and metadata's frozen source-matched catalog. PostgreSQL JSONB object ordering is length-then-byte ordering; ordinary alphabetical JSON is not used for these roots.

The final root has 753 public functions. Seventeen final functions are changed or added: the two coverage functions; eight direct K6 coverage-hash callers; five metadata coverage-attribute callers; the V1 capability function; and the new paid reader. The eight callers include all three report guards. Their existing `not exists(work_cross_job_shifts)` condition remains in place. Those report guards, and therefore the metadata public entries and service-only person census that depend on them, remain intentionally unavailable after a registered2 shift. The exact person-census chain and candidate source locations are recorded in `INTEGRATION-HOLDS.json`. There is no blanket claim of V2 report parity.

The capability's structured manifest is rebuilt after the changed paid writer and setup-claim body hashes are known. All 27 manifest entries are resolved to actual authored bodies and checked against their catalog attributes. The two previously unresolved toolbox bodies come from the pinned `20261031000000_new_front_door.sql` definitions and match the exact common-baseline catalog. They are not reinstalled or assigned new owners or grants.

Every hash literal in a changed or added final body is classified as a final function-body hash, the metadata coverage raw-body-plus-attributes digest, or the unchanged V1 marker data. The changed-function dependency graph is topologically ordered; unknown targets or cycles stop assembly. The current graph has neither. The metadata coverage stub and its later replacement are both deliberately replaced with the same final combined body. Expected catalog roots remain proof-table data, not embedded helper-body literals, so they do not introduce a recursive hash cycle.

Existing K6 public catalog rows remain exact. The metadata subset is projected onto K6's final functions, triggers and two protocol-version CHECK definitions. Nine metadata private tables and their authored types, columns, constraints, indexes and triggers are added to the full public catalog. These transforms use frozen source-matched expectations. PostgreSQL's actual deparser, generated type names, raw ACLs and `connoinherit` values still require genuine validation. The source checks do not turn those authored expectations into runtime evidence.

## Authored compatibility fixtures

`fixtures/v1-capability-active.sql` and `fixtures/v1-capability-closing_only.sql` assert the exact existing V1 capability shape under an otherwise valid, fresh eligible self with capture enabled or disabled respectively. They do not toggle authority or create identities. The later reviewed executor must construct those states through supported source paths.

`fixtures/omit-capability.negative.sql` is an intentionally invalid assembly: it restores only the old capability definition, recalculates the full catalog root independently, and enrolls that root before immutable triggers. Thus its catalog can agree while its capability's two embedded writer hashes are stale. `v1-capability-omitted-negative.sql` requires a 55000 refusal. No immutable trigger bypass is used in this negative variant. Neither the positive assertions nor this SQL negative has been run.

`fixtures/paid-history-positive.sql` requires an actual previous authenticated `clock_in(..., 2)` call and its original request, retained fifteen-field receipt and fingerprint from the same disposable instance. Direct synthetic receipt/stamp insertion is expressly not accepted as runtime proof. The unchanged inactive private gate refuses a newly authored version-2 writer call, so a separately reviewed, source-authored disposable gate variant and real seed execution are prerequisites. If that admitted writer is called while capture is disabled, the source may retain an unregistered original2 fallback; that possibility is distinct from registered2 proof and must be tested, not assumed. Root owns those variants and execution. The fixture settings merely transport captured fixture evidence; they do not attest provider identity.

The copied design-4 matrix retains its 102 proposed cases. Source tests and authored SQL cases are labeled separately from those unexecuted acceptance cases. This checkpoint does not claim full reader compatibility, all 20 client cases, all 42 backend cases or all 65 metadata cases.

## Unresolved boundaries

- No provider-session attestation is implemented. Provider claim/table infrastructure has not been verified. Page-local sign-in counters are not durable authentication epochs. Same-session reload, changed-session authorization and remote revocation atomicity remain separate gates.
- The original writer did not retain its float serialization setting. The reader cannot recover every historical request, try alternative settings or silently substitute a digest. A genuine authenticated same-provider float-1 transport proof is still required. Unreadable history needs a visible resolution slot with owner policy still held.
- Unknown attempted paid or allocation requests must never be resent. Lookup-only allocation recovery still cannot prove a complete saved allocation intent. This paid twelve-argument reader resolves only the paid-root matching design.
- A cross-version, all-generation safety census and one owner dispatch lock are not implemented here. Allocation stop is not paid clock-out. Cached V1 clients do not cooperate with a future cross-store lock; rollover/old-client cooperation remains an activation gate.
- Unknown allocation plus revoked job visibility can block the safety census. That must be visible as `resolution_required`; no discard, new clock punch or owner bypass is authorized. Owner resolution policy remains open.
- Both complete catalog projections run under the retained locks. Their cost is unmeasured; no prior isolated-source timing proves this combined candidate meets a paid-wait budget.
- Different-session policy, live/unverified boundary policy, paid-wait budget, physical devices, browser durability, delivery, V2 report readers and full combined payroll safety remain held. No owner policy is chosen by this source.
- An installed-K6 upgrade remains a separate design requiring a new proof table, successor coverage and complete recursive caller reauthoring. This artifact does not provide an upgrade path and never disables immutable enrollment triggers.

## Reproduction without contact

From this directory:

```
python3 assemble.py
python3 build_fixtures.py
python3 test_assembly.py
python3 -m py_compile assemble.py build_fixtures.py test_assembly.py
```

These commands use only Python's standard library and local files. No database executable, provider client, network call or installation is involved. The resulting source and tests require actual independent review, followed by a separately authorized genuine disposable PostgreSQL run. A source-only pass cannot establish SQL compilation, actor-role execution, whole-row no-write behavior, statement timing or historical receipt equality.
