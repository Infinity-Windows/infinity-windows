# Combined catalog and paid reader source checkpoint 1

The reviewable source is complete for this bounded task. It is a fresh disposable common-0846 candidate, not an installed-K6 upgrade. No repository source, workflow or existing checkpoint was changed. No database, provider, installation, commit, push or peer dispatch occurred.

In plain English: the two features previously checked different definitions of the database. This candidate gives them one complete shared catalog check and adds a way for a signed-in worker to ask whether an exact original paid clock-in request succeeded. It keeps the original receipt separate from whether the source row still exists today. It does not turn either feature on.

## Main files

- `candidate.sql`: full assembled source; literal inactive gate; terminal `ROLLBACK`.
- `paid-reader.sql`: resolved twelve-argument reader, fifteen historical fields and six envelope keys.
- `assemble.py`: pinned, deterministic, no-contact assembly and dependency audit.
- `expected-catalog.json`, `expected-catalog.canonical.json`, `combined-catalog-query.sql`: independent authored expectation and the exact runtime projection.
- `DEPENDENCY-CLOSURE.json`: 17 changed/added final functions, 16 changed-body edges, all 27 capability entries resolved to authored bodies, classified hash literals and dependency order.
- `fixtures/`: two authored V1 positives, a stale-capability negative with its own catalog root, and a historical positive requiring a genuine original writer seed. None was executed.
- `test_assembly.py`, `COMMANDS.json`, `evidence/`: 46 passing no-contact source checks and Python compilation evidence.
- `FULL-SOURCE-DIFF.patch`, `INPUT-PINS.json`, `SOURCE-SCOPE-AUDIT.json`: complete source diff, copied input provenance and 14 current protected-source matches.
- `DESIGN-AND-LIMITS.md`, `INTEGRATION-HOLDS.json`: exact behavior, remaining gates and source-located functional refusal chain.

## Exact identities

| Identity | SHA-256 or value |
|---|---|
| K6 input SQL file | `c0eaccc11ca212853a3950bb64d47805990a2b4af824755a04d92b3fdf170c07` |
| Metadata input SQL file | `d083b38b07bb51f9f34d7b6c114fcdfcaf4c16b91a1541b7c51f2f11d5459c44` |
| Candidate SQL file | `afcb6870893874edd152a6077c2697021a0af32c0e150365e814b3847b253c33` |
| Combined canonical catalog root | `22bb3f21faff9531e16b969e92e6cbb7b82ad1d2e14ce33feeb4f35e37917877` |
| Intentional omitted-capability catalog root | `7d89146d3f8153dd38cba7da565c55bf339a4834282334e0b2bbf424cc2b5289` |
| Unchanged V1 marker data | `2ac3aad6d095d5bf9584bb656ce7123392884b946b0df46e2c6d84beeba3d32a` |

A file hash, a function body hash, the V1 marker and a full catalog root serve different purposes. None is substituted for another. `MANIFEST.json` records all final file hashes.

## Validation and limits

Final result: **46/46 no-contact source tests passed**, Python compilation passed, deterministic regeneration matched, and all 14 checked protected source files still matched their copies. Earlier 42- and 45-test passes are retained. These counts are unrelated to the 42 backend acceptance cases.

The canonical serializer reproduces the common-0846 public digest, K6 public digest and metadata digest exactly. The two missing toolbox helper bodies were resolved from exact legacy source and matched the common-baseline catalog. Each of the 12 public catalog domains and 15 metadata domains has an omission negative. The dependency audit refuses cycles, unknown targets and stale changed-function body hashes. The capability negative intentionally preserves stale writer hashes while independently enrolling its own complete catalog expectation, so it isolates the omitted capability update.

**Zero SQL or PostgreSQL cases were executed.** The candidate's SQL compilation, actual catalog/deparser/ACL/type/constraint equality, fresh authenticated behavior, no-write row equality and latency remain unproved. The authored SQL fixtures must be exercised by a later reviewed disposable executor. The historical positive must come from an actual original `clock_in(..., 2)` writer call on that same instance, not direct receipt/stamp insertion. Root owns the separately authored disposable gate variant and seed. An admitted original2 capture-disabled fallback, if the inherited gates allow it, is not registered2 proof.

## Functional hold that must remain visible

`candidate.sql:2677` defines `_work_unit_metadata_person_counts(uuid,uuid)`. Its existing chain requires the exact metadata attester, `_work_unit_metadata_coverage()` and all three report guards. The report guards at lines 1520, 1524 and 1528 each require the common catalog plus `not exists(select 1 from public.work_cross_job_shifts)`. Therefore a retained registered2 shift keeps the service-only metadata census unavailable with 55000. The four metadata public entries keep the same guard policy. Catalog compatibility does not establish metadata retirement or report support after registration.

`INTEGRATION-HOLDS.json` records this chain and proposed before-registration success, after-registration refusal, four-entry refusal, unchanged retention and future report-parity cases. None was executed. No guard dependency was relaxed. Both catalog projections run under the retained locks; their cost and paid-wait impact are unmeasured.

## Next action and stopping point

Root should obtain actual independent hard source review of the assembly, reader, catalog transforms and dependency closure. Only after that review should root author the genuine combined executor, source-authored gate variants and real historical seed. The first runtime check should compare the complete observed catalog with the frozen authored expectation and refuse every discrepancy; it must never learn the expected root from the database or normalize owners/grants. Run V1 active/closing-only and the isolated omitted-capability negative before claiming source compatibility. Keep installed-K6 upgrade and functional report/retirement successors separate.

All full 20 client, 42 kernel and 65 metadata gates remain held. Provider-session infrastructure, authenticated float-1 transport, different-session policy, live/unverified boundary, paid-wait budget, safety resolution, cached old-client cooperation, lost allocation intent, devices and delivery remain open. No owner policy was chosen or re-asked. The approved design-4 receipt is copied as design evidence only; this concrete source has not yet received independent approval.
