-- UNEXECUTED: genuine authenticated caller with EXECUTE privilege. This
-- checks the paid reader's own first guard, before invalid-key/history checks.
-- It does not prove a valid historical request or provider-session identity.
do $float_paid$ begin
 if current_setting('extra_float_digits') is distinct from '1' then raise exception 'Fixture requires initial float1';end if;
 perform set_config('extra_float_digits','0',true);
 begin
  perform public.work_activity_clock_receipt_v2(null::uuid,null::uuid,null::text,null::double precision,null::double precision,null::text,null::text,null::uuid,null::timestamptz,null::timestamptz,null::integer,2);
 exception when sqlstate '55000' then
  perform set_config('extra_float_digits','1',true);return;
 end;
 raise exception 'Paid reader setting mismatch was not refused';
end $float_paid$;
