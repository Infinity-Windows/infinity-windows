#!/usr/bin/env python3
"""Author fixtures only. This module has no database or subprocess interface."""
import copy,json
from float_contract_fixtures import write_float_contract_fixtures
from pathlib import Path
from assemble import HERE,INPUT,K,assemble,functions,key,replace_function,sha,canonical

def write_fixtures():
    out=HERE/'fixtures';out.mkdir(exist_ok=True)
    base=assemble();old=next(m for m in functions((INPUT/K).read_text()) if m[1]=='work_activity_clock_capability')
    # Deliberately wrong assembly with an independently recalculated catalog
    # root: this isolates stale capability body dependencies, not generic drift.
    sql=replace_function(base['sql'],('work_activity_clock_capability',''),lambda _:old[0])
    catalog=copy.deepcopy(base['catalog']);row=next(r for r in catalog['publicCatalog']['functions'] if r['name']=='work_activity_clock_capability');row['body']=sha(old[5])
    # Metadata selector does not include capability in its function census.
    assert not any(r['name']=='work_activity_clock_capability' for r in catalog['metadataCatalog']['functions'])
    root=sha(canonical(catalog));before=base['audit']['combinedCatalogSha256'];assert sql.count(before)==2
    sql=sql.replace(before,root)
    (out/'omit-capability.negative.sql').write_text('-- INTENTIONALLY INVALID COMPATIBILITY VARIANT. NEVER DEPLOY.\n'+sql)
    (out/'omit-capability.expected-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
    (out/'omit-capability.manifest.json').write_text(json.dumps(dict(status='AUTHORED_NEGATIVE_NOT_EXECUTED',expectedCatalogSha256=root,expectedFailure='work_activity_clock_capability() raises 55000 because its two writer-body expectations were intentionally left stale',sourceDelta='Only original capability definition restored; final proof DATA independently recomputed. No trigger bypass.'),indent=2)+'\n')
    for mode,author,reason in [('active','true','null'),('closing_only','false',"'starts_disabled'::text")]:
        (out/f'v1-capability-{mode}.sql').write_text("""-- Execute at the candidate fixture seam in a genuine fresh authenticated context.
-- Prerequisite supplied by the later reviewed executor: eligible self, clean V1
-- state, no safety events or open registered2 shift, authority capture flag """+str(mode=='active').lower()+""".
-- This assertion neither changes authority nor grants access.
do $fixture$ declare r jsonb;begin
 r:=public.work_activity_clock_capability();
 if (select array_agg(k order by k) from jsonb_object_keys(r) k) is distinct from
 array['asOf','canAuthorSetup','canDispatchExistingSetup','canDispatchPayrollSafety','canReadOwnReceipts','clockProtocol','mode','protocolVersion','receiptProtocol','setupReason']::text[]
 or r->>'protocolVersion' is distinct from '1' or r->>'clockProtocol' is distinct from 'setup_v1'
 or r->>'receiptProtocol' is distinct from 'retained_v1' or r->>'mode' is distinct from '"""+mode+"""'
 or (r->>'canAuthorSetup')::boolean is distinct from """+author+"""
 or r->>'setupReason' is distinct from """+reason+"""
 or r->'canDispatchExistingSetup' is distinct from 'true'::jsonb
 or r->'canReadOwnReceipts' is distinct from 'true'::jsonb
 or r->'canDispatchPayrollSafety' is distinct from 'true'::jsonb
 then raise exception 'V1 capability compatibility failed';end if;
end $fixture$;
""")
    (out/'v1-capability-omitted-negative.sql').write_text("""-- Use ONLY with omit-capability.negative.sql and the same otherwise valid V1
-- context as an active/closing_only positive. Catalog equality should pass first.
do $fixture$ begin
 begin
  perform public.work_activity_clock_capability();
 exception when sqlstate '55000' then return;
 end;
 raise exception 'Stale capability body hashes were not refused';
end $fixture$;
""")
    (out/'paid-history-positive.sql').write_text("""-- UNEXECUTED. Requires a genuine prior authenticated original clock_in(...,2)
-- seed from a separately reviewed, authored disposable gate variant. Direct
-- INSERT of receipts/stamps is forbidden as proof. Root executor must preserve
-- the original request, actual writer trace, retained fifteen fields and stamp.
-- It must also prove this reader call uses the same disposable instance.
-- Settings below carry fixture evidence only; they are NOT provider attestation.
-- Run as the original eligible self after returning to inactive final source.
-- original request keys are the exact twelve SQL parameter names.
do $history$ declare request jsonb;expected jsonb;r jsonb;begin
 request:=current_setting('fixture.original_clock_request')::jsonb;
 expected:=current_setting('fixture.original_clock_receipt')::jsonb;
 if jsonb_typeof(request)<>'object' or (select count(*) from jsonb_object_keys(request))<>12
 or not request ?& array['p_project_id','p_cost_code_id','p_photo','p_lat','p_lng','p_note','p_mode','p_client_id','p_tapped_at','p_clock_checked_at','p_clock_skew_ms','p_setup_version']
 or request->>'p_setup_version' is distinct from '2'
 or jsonb_typeof(expected)<>'object' or (select count(*) from jsonb_object_keys(expected))<>15
 then raise exception 'Genuine original request/receipt seed is required';end if;
 r:=public.work_activity_clock_receipt_v2((request->>'p_project_id')::uuid,(request->>'p_cost_code_id')::uuid,
 request->>'p_photo',(request->>'p_lat')::double precision,(request->>'p_lng')::double precision,
 request->>'p_note',request->>'p_mode',(request->>'p_client_id')::uuid,(request->>'p_tapped_at')::timestamptz,
 (request->>'p_clock_checked_at')::timestamptz,(request->>'p_clock_skew_ms')::integer,(request->>'p_setup_version')::integer);
 if (select array_agg(k order by k) from jsonb_object_keys(r) k) is distinct from array['availability','contract','current','proof','protocolVersion','receipt']::text[]
 or r->>'protocolVersion' is distinct from '2' or r->>'contract' is distinct from 'paid_setup_v2_recovery_v1'
 or r->>'availability' is distinct from 'available' or r->'receipt' is distinct from expected
 or r->'proof' is distinct from jsonb_build_object('originalSetupVersion',2,'match','full_original_setup_digest','fingerprintVersion',1,'receiptSha256',current_setting('fixture.original_receipt_sha256'))
 or jsonb_typeof(r->'current') is distinct from 'object'
 or (select array_agg(k order by k) from jsonb_object_keys(r->'current') k) is distinct from array['asOf','captureRegistered','sourcePresent']::text[]
 or (r#>>'{current,captureRegistered}')::boolean is distinct from current_setting('fixture.expected_capture_registered')::boolean
 or (r#>>'{current,sourcePresent}')::boolean is distinct from current_setting('fixture.expected_source_present')::boolean
 then raise exception 'Historical original2 recovery differs';end if;
end $history$;
""")
    write_float_contract_fixtures(out)
    print(json.dumps(dict(status='fixtures_authored_not_executed',files=sorted(p.name for p in out.iterdir()),negativeCatalogSha256=root),indent=2))
if __name__=='__main__':write_fixtures()
