-- Use ONLY with omit-capability.negative.sql and the same otherwise valid V1
-- context as an active/closing_only positive. Catalog equality should pass first.
do $fixture$ begin
 begin
  perform public.work_activity_clock_capability();
 exception when sqlstate '55000' then return;
 end;
 raise exception 'Stale capability body hashes were not refused';
end $fixture$;
