#!/usr/bin/env python3
"""No-contact, pinned-input fresh-0846 assembly. Never reads an installed catalog.
Outputs are authored expectations, NOT evidence that PostgreSQL accepted the SQL.
"""
from pathlib import Path
import copy, hashlib, json, re
HERE=Path(__file__).resolve().parent
INPUT=HERE/'inputs'
K='20261108470000_work_cross_job_capture.sql'
M='20261108480000_work_unit_metadata_cohorts.sql'
FN=re.compile(r'^create(?: or replace)? function public\.(\w+)\((.*?)\)\s+returns\b(.*?)\bas\s+(\$[a-zA-Z0-9_]*\$)(.*?)\4\s*;',re.S|re.M|re.I)
ROLES=['anon','authenticated','service_role']
PUBLIC_DOMAINS={'types','sequences','foreignTables','functions','relations','columns','constraints','notNullConstraints','indexes','triggers','policies','views'}
METADATA_DOMAINS={'view','tables','columns','policies','triggers','functions','namespace','constraints','columnAccess','privateAccess','functionAccess','metadataIndexes','namespaceRelations','metadataNamespaceTypes','metadataActorRetentionTriggers'}
ENTRY=re.compile(r"\('([^']+)'::text,\$(activity_body_\d+)\$(.*?)\$\2\$::text,(true|false),'([0-9a-f]{64})'::text,'([0-9a-f]{64})'::text,'([^']+)'::text,'([^']*)'::text\)",re.S)
def sha(x): return hashlib.sha256(x if isinstance(x,bytes) else x.encode()).hexdigest()
def canonical(v):
    if isinstance(v,dict):return '{'+', '.join(json.dumps(k,ensure_ascii=False)+': '+canonical(v[k]) for k in sorted(v,key=lambda k:(len(k.encode()),k.encode())))+'}'
    if isinstance(v,list):return '['+', '.join(map(canonical,v))+']'
    return json.dumps(v,ensure_ascii=False,allow_nan=False)
def load(name):return json.loads((INPUT/name).read_text())
def args(a):
    out=[]
    for x in a.split(',') if a.strip() else []:
        x=re.split(r'\s+default\s+',re.sub(r'\s+',' ',x.strip()),flags=re.I)[0]
        out.append(re.sub(r'\btimestamptz\b','timestamp with time zone',x).replace('public.',''))
    return ', '.join(out)
def key(name,a):return (name,args(a))
def signature(k):return 'public.'+k[0]+'('+','.join(a.split(' ',1)[1] for a in k[1].split(', ') if a)+')'
def functions(text):
    ms=list(FN.finditer(text));assert len(ms)==len(re.findall(r'^create(?: or replace)? function public\.',text,re.M|re.I))
    return ms

def replace_function(text,k,transform,expected=1):
    hits=[m for m in functions(text) if key(m[1],m[2])==k];assert len(hits)==expected,(k,len(hits))
    for m in reversed(hits):text=text[:m.start()]+transform(m)+text[m.end():]
    return text

def meta_attester(body,language='sql'):
    return sha(canonical(dict(body=body,owner='postgres',acl='{postgres=X/postgres}',definer=True,config=['search_path=public, pg_temp'],volatility='s',strict=False,leakproof=False,parallel='u',kind='f',set=False,result='boolean',args='',defaults=None,cost=100,rows=0,support='-',language=language)))

def closure_order(nodes,edges):
    pending=set(nodes);order=[]
    for edge in edges:
        if edge['dependency'] not in pending or edge['dependent'] not in pending:
            raise ValueError('Unknown embedded-hash dependency target: '+repr(edge))
    while pending:
        ready=sorted(x for x in pending if not any(e['dependent']==x and e['dependency'] in pending for e in edges))
        if not ready:raise ValueError('Embedded-hash dependency cycle: '+repr(sorted(pending)))
        order.extend(ready);pending.difference_update(ready)
    return order

def verify_inputs():
    for row in json.loads((HERE/'INPUT-PINS.json').read_text()):
        assert sha((INPUT/row['copy']).read_bytes())==row['sha256'],row['copy']
    for name in ['work-cross-job-new-catalog.json','work-cross-job-old-catalog.json','metadata-catalog.json']:
        j=load(name);t=canonical(j['metadata'])
        assert sha(t)==j.get('catalogSha256',j.get('catalogDigest')),name
        if 'canonicalCatalogText' in j:assert t==j['canonicalCatalogText']
    old=load('work-cross-job-old-catalog.json')['metadata']['functions']
    toolbox=[]
    for m in functions((INPUT/'20261031000000_new_front_door.sql').read_text()):
        if m[1] in ('_toolbox_signed_today','_toolbox_gate_open'):
            row=next(r for r in old if key(r['name'],r['arguments'])==key(m[1],m[2]))
            assert row['body']==sha(m[5]);assert row['language']=='sql' and row['volatility']=='s' and not row['definer']
            assert row['config']==['search_path=public, pg_temp']
            toolbox.append(dict(signature=signature(key(m[1],m[2])),source='20261031000000_new_front_door.sql',bodySha256=sha(m[5]),baselineCatalogEntry=row))
    assert len(toolbox)==2
    return toolbox

def merge_catalog(kcat,mcat,final):
    """Explicit source-derived map. No observed candidate values or permissive union.
    Existing K6 public rows win; only nine authored metadata tables and functions
    are added. Metadata-selected K6 dependencies are projected from K6's exact rows.
    """
    assert set(kcat)==PUBLIC_DOMAINS and set(mcat)==METADATA_DOMAINS
    p=copy.deepcopy(kcat);m=copy.deepcopy(mcat)
    tables={r['table'] for r in m['tables'] if r['table'].startswith('_work_unit_metadata_')}
    assert len(tables)==9
    col_access=[dict(role=r,privilege=v,allowed=False) for r in ROLES for v in ['INSERT','REFERENCES','SELECT','UPDATE']]
    rel_access=[dict(role=r,privilege=v,table=False,column=False if v in ['INSERT','REFERENCES','SELECT','UPDATE'] else None) for r in ROLES for v in ['DELETE','INSERT','REFERENCES','SELECT','TRIGGER','TRUNCATE','UPDATE']]
    for r in m['tables']:
        if r['table'] in tables:
            assert r['rawAcl']=='{postgres=arwdDxtm/postgres}' and r['persistence']=='p'
            p['relations'].append(dict(name=r['table'],kind=r['kind'],owner=r['owner'],rls=r['rls'],forcedRls=r['forcedRls'],acl=r['rawAcl'],access=copy.deepcopy(rel_access)))
    for r in m['columns']:
        if r['table'] in tables:
            assert r['rawAcl'] is None
            p['columns'].append(dict(table=r['table'],name=r['column'],type=r['type'],notNull=not r['nullable'],generated=r['generated'],identity=r['identity'],acl=r['rawAcl'],default=r['default'],access=copy.deepcopy(col_access)))
            p['notNullConstraints'].append(dict(table=r['table'],column=r['column'],validated=r['notNullValidated'],enforced=r['notNullEnforced'],noInherit=r['notNullNoInherit']))
    for r in m['constraints']:
        if r['table'] in tables:
            # PG17 connoinherit is true for PK/UNIQUE/FK and false for inherited CHECK.
            kind=r['definition'].split(' (',1)[0]
            assert kind in ['CHECK','PRIMARY KEY','FOREIGN KEY','UNIQUE'],kind
            p['constraints'].append({**{k:r[k] for k in ['table','name','definition','validated','enforced']},'noInherit':kind!='CHECK'})
    for r in m['metadataIndexes']:
        table=re.search(r' ON public\.(\w+) ',r['definition'])[1];assert table in tables
        p['indexes'].append(dict(table=table,**{k:r[k] for k in ['name','definition','valid','ready']}))
    p['triggers'] += [copy.deepcopy(r) for r in m['triggers'] if r['table'] in tables]
    assert not any(r['table'] in tables for r in m['policies'])
    for table in sorted(tables):
        for name,element,template in [(table,None,'work_cross_job_contract'),('_'+table,table,'_work_cross_job_contract')]:
            r=copy.deepcopy(next(x for x in kcat['types'] if x['name']==template));r.update(name=name,element=element);p['types'].append(r)
    pf={key(r['name'],r['arguments']):r for r in p['functions']}
    mf={key(r['name'],r['args']):r for r in m['functions']}
    for k,r in mf.items():
        if k in pf:continue
        assert k[0].startswith(('_work_unit_metadata_','work_unit_metadata_')) or k[0]=='work_unit_cohorts_read',k
        access={x['role']:x['execute'] for x in m['functionAccess'] if key(x['name'],x['args'])==k};assert set(access)==set(ROLES)
        row={n:r[n] for n in ['name','body','result','owner','language','kind','definer','config','volatility','strict','leakproof','cost','rows','support','parallel','defaults']}
        row.update(arguments=r['args'],acl=r['rawAcl'],access=access);p['functions'].append(row);pf[k]=row
    rk=next(k for k in final if k[0]=='work_activity_clock_receipt_v2')
    row=copy.deepcopy(next(r for r in p['functions'] if r['name']=='work_activity_clock_receipt'))
    row.update(name=rk[0],arguments=rk[1],body=sha(final[rk][5]),defaults=None)
    # Explicit grant order determines the raw ACL; matches revoke-all then authenticated grant.
    row.update(acl='{postgres=X/postgres,authenticated=X/postgres}',access=dict(anon=False,authenticated=True,service_role=False))
    p['functions'].append(row);pf[rk]=row
    for k,fn in final.items():
        assert k in pf,('unresolved final function',k)
        pf[k]['body']=sha(fn[5])
        if k[0] in ['_work_cross_job_coverage','_work_unit_metadata_coverage']:pf[k]['language']='plpgsql'
    # Metadata catalog selects a subset by explicit names. Reproject every selected
    # exact overload to the combined K6/metadata final body/attributes/privileges.
    for k,r in mf.items():
        s=pf[k]
        for n in ['body','result','owner','language','kind','definer','config','volatility','strict','leakproof','cost','rows','support','parallel','defaults']:r[n]=s[n]
        r['rawAcl']=s['acl']
    for r in m['functionAccess']:r['execute']=pf[key(r['name'],r['args'])]['access'][r['role']]
    # K6 widens two protocol-version CHECKs and rewires old-table triggers.
    # Their final definitions must also be reflected in the metadata subset.
    pc={(r['table'],r['name']):r for r in p['constraints']}
    for r in m['constraints']:
        actual=pc[(r['table'],r['name'])]
        for field in ['definition','validated','enforced']:r[field]=actual[field]
    # K6 rewires triggers on old selected tables; project their final public definitions.
    selected={r['table'] for r in m['tables']}
    m['triggers']=[copy.deepcopy(r) for r in p['triggers'] if r['table'] in selected]
    sortkeys={'types':lambda r:r['name'],'views':lambda r:r['name'],'relations':lambda r:r['name'],'functions':lambda r:(r['name'],r['arguments']),'indexes':lambda r:(r['table'],r['name']),'constraints':lambda r:(r['table'],r['name']),'triggers':lambda r:(r['table'],r['name']),'columns':lambda r:r['table'],'notNullConstraints':lambda r:r['table']}
    for domain,sort in sortkeys.items():p[domain].sort(key=sort)
    m['triggers'].sort(key=lambda r:(r['table'],r['name']))
    assert len(m['metadataActorRetentionTriggers'])==24
    return dict(publicCatalog=p,metadataCatalog=m)

def assemble():
    toolbox=verify_inputs();k=(INPUT/K).read_text();m=(INPUT/M).read_text()
    original_k={key(x[1],x[2]):x for x in functions(k)};original_m={key(x[1],x[2]):x for x in functions(m)}
    kc=load('work-cross-job-new-catalog.json')['metadata'];mc=load('metadata-catalog.json')['metadata']
    public_query=(INPUT/'work-cross-job-catalog.sql').read_text().strip().rstrip(';')
    assert public_query.endswith(') value')
    metadata_query=load('metadata-catalog.json')['catalogQuery'].strip().rstrip(';')
    assert metadata_query.endswith(') value')
    combined_query="select jsonb_build_object('publicCatalog',(select value from ("+public_query+") public_catalog),'metadataCatalog',(select value from ("+metadata_query+") metadata_catalog)) value"
    coverage_body="\ndeclare actual text;\nbegin\n if current_setting('extra_float_digits') is distinct from '1' then\n  return false;\n end if;\n select encode(sha256(convert_to(c.value::text,'UTF8')),'hex') into actual from (\n"+combined_query+"\n)c;\n return (select count(*)=1 and bool_and(proof_key='cross_job_kernel_2' and expected_catalog_sha256=actual) from public.work_cross_job_contract)\n  and (select count(*)=1 and bool_and(proof_key='metadata_v1' and expected_catalog_sha256=actual) from public._work_unit_metadata_contract);\nend;\n"
    old_hash=sha(original_k[('_work_cross_job_coverage','')][5]);new_hash=sha(coverage_body)
    def coverage_definition(match):
        prefix='create or replace' if 'or replace' in match[0].split('function',1)[0] else 'create'
        return prefix+' function public.'+match[1]+'() returns boolean\nlanguage plpgsql stable security definer set search_path=public,pg_temp as $combined_coverage$'+coverage_body+'$combined_coverage$;'
    k=replace_function(k,('_work_cross_job_coverage',''),coverage_definition)
    m=replace_function(m,('_work_unit_metadata_coverage',''),coverage_definition,2)
    edges=[];changes=[]
    # Exact attestation expression is matched by target signature, not global substitution.
    old_pin=re.search(r"coalesce\(\(select p.prosrc is not null.*?to_regprocedure\('public\._work_cross_job_coverage\(\)'\)\),false\)",original_k[('clock_in',next(k[1] for k in original_k if k[0]=='clock_in'))][5])[0]
    assert old_hash in old_pin and "lanname='sql'" in old_pin
    new_pin=old_pin.replace(old_hash,new_hash).replace("lanname='sql'","lanname='plpgsql'")
    expected_callers={'clock_in','_work_activity_claim_clock_setup','work_activity_command','work_cross_job_snapshot','work_cross_job_receipt','_work_unit_review_coverage','_work_totals_coverage','_work_unit_contributors_coverage'}
    seen=set()
    for sig,fn in original_k.items():
        if old_pin in fn[5]:
            assert sig[0] in expected_callers and fn[5].count(old_pin)==1
            k=replace_function(k,sig,lambda x:x[0].replace(old_pin,new_pin));seen.add(sig[0])
            edges.append(dict(dependency=signature(('_work_cross_job_coverage','')),dependent=signature(sig),kind='body_and_full_attributes',oldExpected=old_hash,newExpected=new_hash))
    assert seen==expected_callers
    old_meta_hash=meta_attester(original_m[('_work_unit_metadata_coverage','')][5]);assert old_meta_hash=='63eb01e50016563968e2056c8997bc2a7b87d7221b20b5d253d7a1e751bc16b8'
    new_meta_hash=meta_attester(coverage_body,'plpgsql');meta_callers=[]
    for sig,fn in original_m.items():
        if old_meta_hash in fn[5]:
            assert fn[5].count(old_meta_hash)==1
            # These expressions hash live pg_proc attributes, so language is data,
            # and only the exact expected full-attribute digest is reauthored.
            assert "'body',p.prosrc" in fn[5] and "to_regprocedure('public._work_unit_metadata_coverage()')" in fn[5]
            m=replace_function(m,sig,lambda x:x[0].replace("'"+old_meta_hash+"'","'"+new_meta_hash+"'"));meta_callers.append(signature(sig))
            edges.append(dict(dependency=signature(('_work_unit_metadata_coverage','')),dependent=signature(sig),kind='raw_body_and_full_attributes_digest',oldExpected=old_meta_hash,newExpected=new_meta_hash))
    assert len(meta_callers)==5
    # Rebuild the capability's structured protocol manifest in dependency order.
    interim={key(x[1],x[2]):x for x in functions(k)}
    cap=interim[('work_activity_clock_capability','')];protocol_match=re.search(r'\$protocol\$(.*?)\$protocol\$',cap[5],re.S)
    protocol=json.loads(protocol_match[1]);updated=[]
    for row in protocol:
        sig=key(row['name'],row['args']);old=original_k.get(sig);new=interim.get(sig)
        if old is not None and new is not None and sha(old[5])!=sha(new[5]):
            assert row['value']['body']==sha(old[5]);row['value']['body']=sha(new[5]);updated.append(signature(sig))
            edges.append(dict(dependency=signature(sig),dependent='public.work_activity_clock_capability()',kind='structured_protocol_full_attributes',oldExpected=sha(old[5]),newExpected=sha(new[5])))
    assert len(updated)==2
    replacement=json.dumps(protocol,separators=(',',':'))
    k=replace_function(k,('work_activity_clock_capability',''),lambda x:x[0].replace(protocol_match[1],replacement))
    reader=(HERE/'paid-reader.sql.in').read_text().replace('@COVERAGE_ATTESTATION@',new_pin)
    assert '@COVERAGE' not in reader
    edges.append(dict(dependency='public._work_cross_job_coverage()',dependent=signature(key(functions(reader)[0][1],functions(reader)[0][2])),kind='new_reader_body_and_full_attributes',oldExpected=None,newExpected=new_hash))
    # Preserve preflight bytes, but run both against the common 0846 baseline.
    kpre=k[k.index('-- CROSS_JOB_PREFLIGHT_BEGIN'):k.index('-- CROSS_JOB_DDL_BEGIN')]
    mpre=m[m.index('do $namespace$'):m.index('create table public._work_unit_metadata_definitions')]
    kddl=k[k.index('-- CROSS_JOB_DDL_BEGIN'):k.rindex('rollback;')]
    mddl=m[m.index('create table public._work_unit_metadata_definitions'):m.rindex('rollback;')]
    delayed=[]
    for source,name in [('k','work_cross_job_contract_immutable'),('k','work_cross_job_contract_no_truncate'),('m','metadata_immutable')]:
        text=kddl if source=='k' else mddl
        table='work_cross_job_contract' if source=='k' else '_work_unit_metadata_contract'
        pat=r'^create trigger '+name+r' .*? on public\.'+table+r' .*?;\n'
        matches=list(re.finditer(pat,text,re.M));assert len(matches)==1,(name,len(matches))
        delayed.append(matches[0][0]);text=text[:matches[0].start()]+text[matches[0].end():]
        if source=='k':kddl=text
        else:mddl=text
    for source,pat in [('k',r"^insert into public\.work_cross_job_contract values\('cross_job_kernel_2','[0-9a-f]{64}'\);\n"),('m',r"^insert into public\._work_unit_metadata_contract\(proof_key,expected_catalog_sha256\) values\('metadata_v1','[0-9a-f]{64}'\);\n")]:
        text=kddl if source=='k' else mddl;text,count=re.subn(pat,'',text,flags=re.M);assert count==1
        if source=='k':kddl=text
        else:mddl=text
    float_guard="do $float_contract$ begin\n if current_setting('extra_float_digits') is distinct from '1' then raise exception using errcode='55000',message='Combined assembly requires extra_float_digits=1.';end if;\nend $float_contract$;\n"
    start='-- DISPOSABLE COMMON-0846 CANDIDATE. NEVER an installed-K6 upgrade or activation.\n-- Source-authored catalog; no observed-catalog learning. Terminal rollback is mandatory.\nbegin;\nset local search_path=public,pg_temp;\n'+float_guard+kpre+mpre
    preproof=start+kddl+'\n-- METADATA DDL AFTER BOTH ORIGINAL PREFLIGHTS\n'+mddl+'\n'+reader
    final={key(x[1],x[2]):x for x in functions(preproof)}
    # Every changed body must have an authored catalog entry and complete literal
    # dependency closure, including metadata raw-body attribute hashes above.
    originals={**original_k,**original_m}
    for sig,fn in final.items():
        old=originals.get(sig)
        if old is None or old[5]!=fn[5]:changes.append(dict(signature=signature(sig),oldBodySha256=sha(old[5]) if old else None,newBodySha256=sha(fn[5])))
    for row in changes:
        if row['oldBodySha256']:
            for sig,fn in final.items():
                assert row['oldBodySha256'] not in fn[5],('stale embedded body hash',row['signature'],signature(sig))
    order=closure_order([x['signature'] for x in changes],edges)
    combined=merge_catalog(kc,mc,final);root=sha(canonical(combined))
    # Resolve every capability body against authored source (including the two
    # legacy toolbox routines), not merely against a catalog hash declaration.
    source_bodies={}
    for path in sorted(INPUT.glob('*.sql')):
        if not re.match(r'\d{14}_',path.name):continue
        text=path.read_text();records=[(x.start(),key(x[1],x[2]),x[5]) for x in functions(text)]
        for x in ENTRY.finditer(text):
            assert sha(x[3])==x[6];records.append((x.start(),key(x[7],x[8]),x[3]))
        for _,sig,body in sorted(records):source_bodies[sig]=dict(body=body,source=path.name)
    for sig,fn in final.items():source_bodies[sig]=dict(body=fn[5],source='candidate.sql')
    final_cap=final[('work_activity_clock_capability','')]
    final_protocol=json.loads(re.search(r'\$protocol\$(.*?)\$protocol\$',final_cap[5],re.S)[1]);resolved_protocol=[]
    pf={key(r['name'],r['arguments']):r for r in combined['publicCatalog']['functions']}
    for entry in final_protocol:
        sig=key(entry['name'],entry['args']);body=source_bodies[sig];row=pf[sig]
        assert entry['value']['body']==sha(body['body'])==row['body'],sig
        projected={name:row[name] for name in ['body','kind','owner','config','definer','language','volatility']}
        projected.update(returns=row['result'],anon=row['access']['anon'],authenticated=row['access']['authenticated'],public=bool(re.search(r'(?:\{|,)=',row['acl'] or '{=X}')))
        assert projected==entry['value'],sig
        resolved_protocol.append(dict(signature=signature(sig),source=body['source'],bodySha256=row['body'],attributesMatch=True))
    assert len(resolved_protocol)==27
    # Classify all embedded SHA literals in changed/added bodies. Digest proof
    # DATA and the unchanged V1 marker are distinct from function-body hashes.
    known_hashes={r['body'] for r in combined['publicCatalog']['functions']}
    marker='2ac3aad6d095d5bf9584bb656ce7123392884b946b0df46e2c6d84beeba3d32a'
    classified=[]
    changed_signatures={r['signature'] for r in changes}
    for sig,fn in final.items():
        if signature(sig) not in changed_signatures:continue
        for literal in sorted(set(re.findall(r'[0-9a-f]{64}',fn[5]))):
            assert literal in known_hashes or literal in [new_meta_hash,marker],('unknown embedded expected hash',sig,literal)
            kind='function_body_sha256' if literal in known_hashes else 'coverage_raw_body_and_attributes' if literal==new_meta_hash else 'unchanged_v1_contract_marker_data'
            classified.append(dict(caller=signature(sig),literal=literal,kind=kind))

    seed="\n-- Proof DATA is authored after final bodies, before immutable contract triggers.\ninsert into public.work_cross_job_contract values('cross_job_kernel_2','"+root+"');\ninsert into public._work_unit_metadata_contract(proof_key,expected_catalog_sha256) values('metadata_v1','"+root+"');\n"+''.join(delayed)
    assertion="\ndo $final_contract$ begin\n if not public._work_cross_job_coverage() or not public._work_unit_metadata_coverage()\n or not public._work_unit_review_coverage() or not public._work_totals_coverage() or not public._work_unit_contributors_coverage() then\n raise exception using errcode='55000',message='Combined authored catalog or pre-registration report guards differ.';end if;\n if public._work_cross_job_enabled() then raise exception using errcode='55000',message='Candidate must remain inactive.';end if;\nend $final_contract$;\n-- AUTHORIZED DISPOSABLE FIXTURE SEAM: no fixture executes by default.\nrollback;\n"
    sql=preproof+seed+assertion
    assert root not in coverage_body
    audit=dict(status='AUTHORED_SOURCE_NOT_POSTGRES_VALIDATED',capabilityProtocolSourceResolution=resolved_protocol,classifiedEmbeddedLiterals=classified,combinedCatalogSha256=root,functionChanges=changes,embeddedHashEdges=edges,dependencyFirstOrder=order,unresolvedCycles=[],unknownTargets=[],toolboxBaselineDefinitions=toolbox,publicDomains={n:len(v) if isinstance(v,list) else None for n,v in combined['publicCatalog'].items()},metadataDomains={n:len(v) if isinstance(v,list) else 'scalar' for n,v in combined['metadataCatalog'].items()},notes=['Common 0846 disposable baseline only. Both original preflight bodies execute before DDL.','The temporary metadata stub and final coverage definition are both replaced with the exact same combined attester.','Coverage helpers have no embedded expected root. Both immutable proof rows carry the independent final root as data.','Catalog transforms are authored expectations based on pinned predecessor snapshots; actual PG17 deparser/ACL/type/constraint equality remains unexecuted.','No provider session attestation, changed auth epoch or live activation is implemented.'])
    return dict(sql=sql,catalog=combined,audit=audit,combinedQuery=combined_query,reader=reader)

def write():
    result=assemble()
    for name,value in [('candidate.sql',result['sql']),('paid-reader.sql',result['reader']),('combined-catalog-query.sql',result['combinedQuery']+';\n'),('expected-catalog.canonical.json',canonical(result['catalog']))]: (HERE/name).write_text(value)
    for name,value in [('expected-catalog.json',result['catalog']),('DEPENDENCY-CLOSURE.json',result['audit'])]: (HERE/name).write_text(json.dumps(value,indent=2)+'\n')
    print(json.dumps(dict(status='authored',candidateSha256=sha(result['sql']),combinedCatalogSha256=result['audit']['combinedCatalogSha256'],changedFunctions=len(result['audit']['functionChanges'])),indent=2))
if __name__=='__main__':write()
