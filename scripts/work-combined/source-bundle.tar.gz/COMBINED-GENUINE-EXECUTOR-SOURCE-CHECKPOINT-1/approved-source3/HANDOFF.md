# Combined paid reader fixture correction 3

The fixture now distinguishes the paid reader's upfront serialization guard from its later catalog refusal. No candidate, reader, assembly or catalog bytes changed. Both errors use SQLSTATE 55000, so checking only that code could pass after deleting the guard.

The authored SQL first invokes the exact same twelve-argument null-key request at float setting 1. It must reach 23514 after the genuine eligible actor and catalog checks. At float setting 0, it catches 55000 with GET STACKED DIAGNOSTICS and requires the exact message `Paid recovery serialization setting is unavailable.` A source-contract error is rethrown. Unexpected success or another error fails the fixture. No historical row, provider identity or SQL execution is claimed.

The omitted-capability negative now explicitly requires the executor to first pass the appropriate V1 positive on the base candidate with the same identity and state, then verify the exact negative catalog. Its generic 55000 cannot identify the cause alone. This prerequisite is documented in both generated SQL headers and their generator; no security design or error contract changed.

## Review and source preservation

Actual Opus session `cfe4eeff-3ad2-4019-90b5-fd69a2e7461c` returned CHANGES after 30 turns on checkpoint 2, with only fixture blocker F1. The full actual receipt and diagnosis were frozen in `correction3-premise/` before editing. It read the assembler, tests and fixture generators fully; reused inherited unchanged caller reviews and the prior full paid-reader review; and judged generated catalogs through the generating code rather than reading every catalog row. Its conditional statement that closure would allow held source approval is not an actual approval of this correction.

`CORRECTION-3-SOURCE-DIFF.patch` is the complete fixture/test source delta. All 53 old test methods remain identical; four tests were added. The old-fixture regression fails before correction. New controls reject the old fixture, a wrong diagnostic message, omitted stacked diagnostics, wrong float-1 SQLSTATE, a removed message check and different request arguments. These are no-contact source checks, not SQL interpretation or PostgreSQL evidence.

The candidate SHA remains `2a323f3d59e622b80cf235c68d7d39533ae1b98717b1a9769a5e5923046f69cd`; the authored catalog root remains `d7d520dd7c227fedb6594117d017cde3307981156162aedf2c37dfbfd06467b2`. Canonical catalog bytes, reader SQL, recursive closure and all protected repository inputs remain unchanged. Prior checkpoints remain immutable. Copied prior evidence and documents retain their historical scope; current correction evidence uses `c3-` names.

## Next action and holds

Root owns narrow actual Opus closure of F1 and the negative-fixture prerequisite, then the separately reviewed disposable executor. This task runs no SQL, provider, migration, workflow, installation or activation. Read-only full-request matching and all prior security, lifecycle, namespace, scope and immutable-proof contracts remain unchanged.

Genuine catalog equality, authenticated float transport, real writer-created historical seeds, registered-2 census/report functionality, combined catalog latency, owner policies, client safety resolution, old-client cooperation, installed-K6 upgrade and all 20/42/65 completion gates remain held. The executor must preserve positive context and original historical evidence; source checks cannot establish those runtime facts.

Final checks: **57/57 PASS** (26.735 seconds); all ten generated fixture files reproduce byte-for-byte in temporary output; four Python modules compile. All 88 checkpoint-2 manifest-listed files, 14 protected repository source inputs and three metadata trial files remain unchanged.
