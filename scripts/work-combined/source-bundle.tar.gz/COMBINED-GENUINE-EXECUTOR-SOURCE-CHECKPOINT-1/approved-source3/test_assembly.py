#!/usr/bin/env python3
"""Source/assembly checks only: no PostgreSQL, provider, or connection emulation."""
import copy,json,re,unittest
from unittest.mock import patch
import assemble as a

class AssemblyTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.r=a.assemble();cls.sql=cls.r['sql'];cls.cat=cls.r['catalog'];cls.audit=cls.r['audit'];cls.fns={a.key(x[1],x[2]):x for x in a.functions(cls.sql)}
  cls.k=(a.INPUT/a.K).read_text();cls.m=(a.INPUT/a.M).read_text();cls.kcat=a.load('work-cross-job-new-catalog.json')['metadata'];cls.mcat=a.load('metadata-catalog.json')['metadata'];cls.reader=next(x for x in a.functions(cls.r['reader']) if x[1]=='work_activity_clock_receipt_v2')
 def test_all_input_pins(self):self.assertEqual(len(a.verify_inputs()),2)
 def test_canonical_frozen_public_before(self):
  j=a.load('work-cross-job-old-catalog.json');self.assertEqual(a.canonical(j['metadata']),j['canonicalCatalogText'])
 def test_canonical_frozen_public_after(self):
  j=a.load('work-cross-job-new-catalog.json');self.assertEqual(a.canonical(j['metadata']),j['canonicalCatalogText'])
 def test_canonical_frozen_metadata(self):self.assertEqual(a.sha(a.canonical(self.mcat)),a.load('metadata-catalog.json')['catalogDigest'])
 def test_deterministic_full_assembly(self):self.assertEqual(a.assemble(),self.r)
 def test_generated_outputs_match(self):
  self.assertEqual((a.HERE/'candidate.sql').read_text(),self.sql);self.assertEqual(json.loads((a.HERE/'expected-catalog.json').read_text()),self.cat)
 def test_every_public_domain_required(self):
  for domain in sorted(a.PUBLIC_DOMAINS):
   with self.subTest(domain=domain):
    bad=copy.deepcopy(self.kcat);del bad[domain]
    with self.assertRaises(AssertionError):a.merge_catalog(bad,self.mcat,self.fns)
 def test_every_metadata_domain_required(self):
  for domain in sorted(a.METADATA_DOMAINS):
   with self.subTest(domain=domain):
    bad=copy.deepcopy(self.mcat);del bad[domain]
    with self.assertRaises(AssertionError):a.merge_catalog(self.kcat,bad,self.fns)
 def test_catalog_domain_changes_change_root(self):
  root=self.audit['combinedCatalogSha256']
  for outer in self.cat:
   for domain,value in self.cat[outer].items():
    with self.subTest(outer=outer,domain=domain):
     changed=copy.deepcopy(self.cat);changed[outer][domain]=[] if value is None else None
     self.assertNotEqual(a.sha(a.canonical(changed)),root)
 def test_both_exact_preflights_before_ddl(self):
  kp=self.k[self.k.index('-- CROSS_JOB_PREFLIGHT_BEGIN'):self.k.index('-- CROSS_JOB_DDL_BEGIN')]
  mp=self.m[self.m.index('do $namespace$'):self.m.index('create table public._work_unit_metadata_definitions')]
  self.assertIn(kp,self.sql);self.assertIn(mp,self.sql)
  self.assertLess(self.sql.index(mp)+len(mp),self.sql.index('create table public.work_cross_job_shifts'))
 def test_float_guard_before_catalog(self):self.assertLess(self.sql.index("current_setting('extra_float_digits')"),self.sql.index('-- CROSS_JOB_PREFLIGHT_BEGIN'))
 def test_global_flag_and_terminal_rollback(self):
  body=self.fns[('_work_cross_job_enabled','')][5];self.assertRegex(body,r'^\s*select false\s*$');self.assertTrue(self.sql.rstrip().endswith('rollback;'))
  self.assertNotRegex(self.sql.lower(),r'\bcommit\s*;|disable\s+trigger|alter\s+function.*owner\s+to|set\s+(?:local\s+)?extra_float_digits')
 def test_proofs_inserted_before_immutable_trigger(self):
  for table,name in [('work_cross_job_contract','work_cross_job_contract_immutable'),('_work_unit_metadata_contract','metadata_immutable')]:
   seed=self.sql.index('insert into public.'+table);trigger=re.search(r'create trigger '+name+r' .*? on public\.'+table+r' ',self.sql)
   self.assertLess(seed,trigger.start());self.assertEqual(self.sql.count('insert into public.'+table),1)
 def test_expected_root_only_proof_data(self):
  root=self.audit['combinedCatalogSha256'];self.assertEqual(self.sql.count(root),2)
  for fn in self.fns.values():self.assertNotIn(root,fn[5])
 def test_two_coverage_bodies_equal_and_float_guarded(self):
  x=self.fns[('_work_cross_job_coverage','')][5];y=self.fns[('_work_unit_metadata_coverage','')][5];self.assertEqual(x,y)
  self.assertLess(x.index("current_setting('extra_float_digits')"),x.index('pg_proc'))
  mismatch=x.split('end if;',1)[0];self.assertIn('return false;',mismatch);self.assertNotIn('raise exception',mismatch)
  self.assertLess(x.index('return false;'),x.index('select encode(sha256'));self.assertNotIn('raise exception',x)
  self.assertIn('count(*)=1',x);self.assertIn("proof_key='cross_job_kernel_2'",x);self.assertIn("proof_key='metadata_v1'",x)
 def test_explicit_metadata_stub_resolution(self):
  f=[m for m in a.functions(self.sql) if m[1]=='_work_unit_metadata_coverage'];self.assertEqual(len(f),2);self.assertEqual(f[0][5],f[1][5]);self.assertNotIn('select false',f[0][5])
 def test_full_dependency_changes_and_edges(self):
  self.assertEqual(len(self.audit['functionChanges']),17);self.assertEqual(len(self.audit['embeddedHashEdges']),16)
  self.assertEqual(len(self.audit['dependencyFirstOrder']),17);self.assertEqual(self.audit['unresolvedCycles'],[])
 def test_dependency_order(self):
  order=self.audit['dependencyFirstOrder']
  for e in self.audit['embeddedHashEdges']:self.assertLess(order.index(e['dependency']),order.index(e['dependent']))
 def test_cycle_refused(self):
  with self.assertRaisesRegex(ValueError,'cycle'):a.closure_order(['a','b'],[dict(dependency='a',dependent='b'),dict(dependency='b',dependent='a')])
 def test_unknown_dependency_target_refused(self):
  with self.assertRaisesRegex(ValueError,'Unknown'):a.closure_order(['a'],[dict(dependency='missing',dependent='a')])
 def test_catalog_queries_are_original_source_owned(self):
  public=(a.INPUT/'work-cross-job-catalog.sql').read_text().strip().rstrip(';')
  metadata=a.load('metadata-catalog.json')['catalogQuery'].strip().rstrip(';')
  self.assertIn(public,self.k);self.assertIn(metadata,self.m)
 def test_unchanged_helpers_and_v1_reader_body(self):
  old={a.key(x[1],x[2]):x for x in a.functions(self.k)}
  for sig in old:
   if sig[0] in ['_work_cross_job_clock_receipt_fingerprint','work_activity_clock_receipt','_work_activity_clock_contract_marker','_work_cross_job_enabled']:
    self.assertEqual(old[sig][0],self.fns[sig][0])
 def test_stale_body_hashes_absent_from_changed_callers(self):
  allb='\n'.join(m[5] for m in self.fns.values())
  for row in self.audit['functionChanges']:
   if row['oldBodySha256']:self.assertNotIn(row['oldBodySha256'],allb)
 def test_toolbox_bodies_resolved_with_attributes(self):
  rs=self.audit['toolboxBaselineDefinitions'];self.assertEqual({x['signature'] for x in rs},{'public._toolbox_signed_today(uuid)','public._toolbox_gate_open(uuid)'})
  self.assertTrue(all(x['source']=='20261031000000_new_front_door.sql' for x in rs));self.assertTrue(all(not x['baselineCatalogEntry']['definer'] for x in rs))
 def test_all_capability_entries_resolved(self):self.assertEqual(len(self.audit['capabilityProtocolSourceResolution']),27);self.assertTrue(all(x['attributesMatch'] for x in self.audit['capabilityProtocolSourceResolution']))
 def test_no_unknown_expected_hash_literals(self):self.assertTrue(self.audit['classifiedEmbeddedLiterals']);self.assertEqual(self.audit['unknownTargets'],[])
 def test_unchanged_public_domains_retained(self):
  for domain in ['views','sequences','policies','foreignTables']:self.assertEqual(self.cat['publicCatalog'][domain],self.kcat[domain])
 def test_old_public_nonfunction_rows_preserved(self):
  for domain in ['types','columns','constraints','notNullConstraints','indexes','triggers','relations']:
   new=self.cat['publicCatalog'][domain]
   for row in self.kcat[domain]:self.assertIn(row,new,(domain,row))
 def test_six_metadata_retention_fks_and_24_ri_rows(self):
  self.assertEqual(self.cat['metadataCatalog']['metadataActorRetentionTriggers'],self.mcat['metadataActorRetentionTriggers'])
  rows=[r for r in self.cat['publicCatalog']['constraints'] if r['name']=='metadata_actor_retention'];self.assertEqual(len(rows),6)
  self.assertTrue(all('ON DELETE RESTRICT' in r['definition'] for r in rows))
 def test_old_protocol_checks_projected_to_metadata(self):
  for table in ['personal_activity_commands','personal_activity_transitions']:
   r=next(r for r in self.cat['metadataCatalog']['constraints'] if r['table']==table and r['name'].endswith('protocol_version_check'))
   k=next(r for r in self.kcat['constraints'] if r['table']==table and r['name'].endswith('protocol_version_check'));self.assertEqual(r['definition'],k['definition']);self.assertIn('2',r['definition'])
 def test_metadata_namespace_and_private_access_preserved(self):
  for domain in ['namespace','namespaceRelations','metadataNamespaceTypes','privateAccess','columnAccess','metadataIndexes']:self.assertEqual(self.cat['metadataCatalog'][domain],self.mcat[domain])
 def test_all_final_bodies_present_in_authored_catalog(self):
  rows={a.key(x['name'],x['arguments']):x for x in self.cat['publicCatalog']['functions']}
  for key,fn in self.fns.items():self.assertEqual(rows[key]['body'],a.sha(fn[5]))
 def test_report_guards_still_fence_registered2(self):
  for name in ['_work_unit_review_coverage','_work_totals_coverage','_work_unit_contributors_coverage']:self.assertIn('not exists(select 1 from public.work_cross_job_shifts)',self.fns[(name,'')][5])
 def test_reader_matches_approved_design_wire(self):
  contract=a.load('design4-CONTRACT.json');expected=', '.join(x['name']+' '+x['type'] for x in contract['arguments'])
  self.assertEqual(a.args(self.reader[2]),a.args(expected))
  wire=json.loads(re.search(r"missing constant jsonb:='(.*?)'::jsonb",self.reader[5])[1]);self.assertEqual(wire,contract['unavailable'])
  self.assertEqual(set(wire),set(contract['envelopeKeys']))
 def test_reader_exact_12_arguments_no_defaults(self):self.assertEqual(len(self.reader[2].split(',')),12);self.assertNotIn('default',self.reader[2].lower())
 def test_reader_exact_15_historical_keys(self):
  body=self.reader[5];section=body.split("'receipt',jsonb_build_object(",1)[1].split("'proof',jsonb_build_object(",1)[0]
  self.assertEqual(re.findall(r"'([A-Za-z]+)'\s*,",section),['clientId','profileId','shiftId','action','outcome','tappedAt','arrivedAt','clockCheckedAt','clockSkewMs','usedTapTime','reviewReason','sourceCreatedAt','receiptProtocol','setupPayloadDigest','recordedAt'])
 def test_reader_exact_unavailable_six_key_envelope(self):
  wire=json.loads(re.search(r"missing constant jsonb:='(.*?)'::jsonb",self.reader[5])[1]);self.assertEqual(set(wire),{'protocolVersion','contract','availability','receipt','proof','current'});self.assertEqual(wire['protocolVersion'],2);self.assertIsNone(wire['receipt']);self.assertIsNone(wire['proof']);self.assertIsNone(wire['current'])
 def test_reader_float_g_a_fresh_actor_then_catalog_then_read(self):
  b=self.reader[5];marks=["current_setting('extra_float_digits')",'public._work_activity_read_committed()','public._work_activity_gate()','pg_advisory_xact_lock(7710,0)','public._work_activity_actor()','to_regprocedure','select * into r']
  self.assertEqual([b.index(x) for x in marks],sorted(b.index(x) for x in marks))
 def test_reader_no_writes_or_historical_admission(self):
  b=re.sub(r'--[^\n]*','',self.reader[5]);self.assertNotRegex(b.lower(),r'\b(insert|update|delete|truncate|merge)\b')
  for denied in ['_work_cross_job_scope','_ai_job_visible','_toolbox_gate_open','_work_activity_observe','_work_activity_operation_enter','_work_activity_clock_replay_guard','interval ','length(','p_mode not in','p_lat between']:self.assertNotIn(denied,b)
 def test_reader_retained_only_full_digest_fingerprint_and_original2(self):
  b=self.reader[5];self.assertIn('public.work_activity_clock_receipts',b);self.assertIn('public.work_cross_job_clock_requests',b)
  self.assertIn('stamp.setup_version is distinct from 2',b);self.assertIn('stamp.receipt_sha256 is distinct from fingerprint',b);self.assertIn('digest is distinct from r.setup_payload_digest',b)
  self.assertIn('public._work_activity_clock_setup_digest(p_project_id,p_cost_code_id,p_photo,p_lat,p_lng,p_note,p_mode,p_client_id,p_tapped_at,p_clock_checked_at,p_clock_skew_ms)',b)
  self.assertEqual(b.count('into r from'),1);self.assertNotIn('into r from public.time_clock_actions',b)
 def test_reader_registration_and_source_are_distinct(self):
  b=self.reader[5];self.assertIn('registered:=found',b);self.assertIn('registration.clock_request_id is distinct from r.client_id',b);self.assertIn('clock_request_id=r.client_id',b);self.assertIn("'captureRegistered',registered",b);self.assertIn("'sourcePresent',present",b)
 def test_reader_acl_is_self_api_only(self):
  r=next(r for r in self.cat['publicCatalog']['functions'] if r['name']=='work_activity_clock_receipt_v2');self.assertEqual(r['access'],{'anon':False,'authenticated':True,'service_role':False});self.assertTrue(r['definer']);self.assertEqual(r['owner'],'postgres');self.assertEqual(r['config'],['search_path=public, pg_temp'])
 def test_negative_capability_catalog_self_consistent_but_entries_stale(self):
  c=json.loads((a.HERE/'fixtures/omit-capability.expected-catalog.json').read_text());manifest=json.loads((a.HERE/'fixtures/omit-capability.manifest.json').read_text());self.assertEqual(a.sha(a.canonical(c)),manifest['expectedCatalogSha256'])
  sql=(a.HERE/'fixtures/omit-capability.negative.sql').read_text();self.assertEqual(sql.count(manifest['expectedCatalogSha256']),2)
  old=next(x for x in a.functions(sql) if x[1]=='work_activity_clock_capability');protocol=json.loads(re.search(r'\$protocol\$(.*?)\$protocol\$',old[5],re.S)[1]);rows={a.key(r['name'],r['arguments']):r for r in c['publicCatalog']['functions']}
  mismatches=[x['name'] for x in protocol if x['value']['body']!=rows[a.key(x['name'],x['args'])]['body']];self.assertEqual(set(mismatches),{'clock_in','_work_activity_claim_clock_setup'})
 def test_authored_v1_positive_and_negative_assertions_present(self):
  for mode in ['active','closing_only']:self.assertIn("is distinct from '"+mode+"'",(a.HERE/f'fixtures/v1-capability-{mode}.sql').read_text())
  self.assertIn("exception when sqlstate '55000'",(a.HERE/'fixtures/v1-capability-omitted-negative.sql').read_text())
 def test_history_fixture_requires_genuine_seed_and_has_no_dml(self):
  s=(a.HERE/'fixtures/paid-history-positive.sql').read_text();self.assertIn('genuine prior authenticated original clock_in(...,2)',s);self.assertIn("current_setting('fixture.original_clock_request')",s)
  self.assertNotRegex(re.sub(r'--[^\n]*','',s).lower(),r'\b(insert|update|delete|truncate)\b')
 def test_unknown_final_function_refuses(self):
  bad=dict(self.fns);fake=self.reader;bad[('not_authored','')]=fake
  with self.assertRaises(AssertionError):a.merge_catalog(self.kcat,self.mcat,bad)


 def test_paid_and_assembly_setting_errors_are_preserved(self):
  preamble=self.sql.split('-- CROSS_JOB_PREFLIGHT_BEGIN',1)[0]
  self.assertIn("errcode='55000',message='Combined assembly requires extra_float_digits=1.'",preamble)
  paid=self.reader[5];guard=paid.split('end if;',1)[0]
  self.assertIn("errcode='55000',message='Paid recovery serialization setting is unavailable.'",guard)
  self.assertLess(paid.index("current_setting('extra_float_digits')"),paid.index('public._work_activity_actor()'))
 def test_paid_reader_changed_only_dependency_hash(self):
  old_sql=(a.HERE/'previous/candidate.sql').read_text();old=next(x for x in a.functions(old_sql) if x[1]=='_work_cross_job_coverage')
  new=self.fns[('_work_cross_job_coverage','')];before=(a.HERE/'previous/paid-reader.sql').read_text()
  self.assertEqual(before.count(a.sha(old[5])),1)
  self.assertEqual(before.replace(a.sha(old[5]),a.sha(new[5])),self.r['reader'])
 def test_inherited_reader_catalog_bodies_are_preserved(self):
  rows={a.key(r['name'],r['arguments']):r for r in self.cat['publicCatalog']['functions']}
  for row in self.kcat['functions']:
   if row['name'] in ['work_unit_review_read','_work_unit_review_view','_work_unit_review_scope','work_activity_totals_read','work_unit_contributors_read']:
    self.assertEqual(rows[a.key(row['name'],row['arguments'])],row)
  original=self.m[self.m.index('create function public.work_unit_metadata_read('):self.m.index('create function public.work_unit_metadata_receipt(')]
  current=self.fns[('work_unit_metadata_read','p_unit_id uuid, p_protocol_version integer')][0]
  oldfn=next(x for x in a.functions(original) if x[1]=='work_unit_metadata_read')
  before_pin=re.findall(r'[0-9a-f]{64}',oldfn[0]);after_pin=re.findall(r'[0-9a-f]{64}',current)
  self.assertEqual(len(before_pin),1);self.assertEqual(len(after_pin),1)
  self.assertEqual(oldfn[0].replace(before_pin[0],after_pin[0]),current)
 def test_float0_public_fixture_matches_source_false_responses(self):
  fixture=(a.HERE/'fixtures/float0-existing-public-readers.sql').read_text()
  for source,key in [('20261108450000_work_activity_totals.sql','totals'),('20261108460000_work_unit_contributors.sql','contributors')]:
   expected='{"protocolVersion":1,"availability":"unavailable","'+key+'":null}'
   self.assertIn(expected,(a.INPUT/source).read_text());self.assertIn(expected,fixture)
  self.assertIn("return jsonb_build_object('protocolVersion',1,'availability','unavailable','metadata',null)",self.m)
  self.assertIn('{"protocolVersion":1,"availability":"unavailable","metadata":null}',fixture)
  self.assertNotIn('exception when',fixture)
 def test_float0_review_fixture_keeps_available_unproven_and_missing_unavailable(self):
  source=(a.INPUT/'20261108440000_work_unit_review.sql').read_text()
  view=next(x for x in a.functions(source) if x[1]=='_work_unit_review_view')[5]
  public=next(x for x in a.functions(source) if x[1]=='work_unit_review_read')[5]
  self.assertIn("proof:=(s->>'proven')::boolean and public._work_unit_review_coverage();",view)
  self.assertIn("'lifecycle',case when proof then 'proven' else 'unproven' end",view)
  self.assertIn("'availability',case when v is null then 'unavailable' else 'available' end",public)
  fixture=(a.HERE/'fixtures/float0-existing-public-readers.sql').read_text()
  self.assertIn("baseline_review#>>'{review,qc,lifecycle}' is distinct from 'proven'",fixture)
  self.assertIn("r#>>'{review,qc,lifecycle}' is distinct from 'unproven'",fixture)
  self.assertIn("r->>'availability' is distinct from 'available'",fixture)
  self.assertIn('public.work_unit_review_read(missing_unit_id)',fixture)
  self.assertIn('{"protocolVersion":1,"availability":"unavailable","review":null}',fixture)
 def test_existing_actor_and_supervisor_checks_precede_false_handling(self):
  for file,name,guard in [('20261108450000_work_activity_totals.sql','work_activity_totals_read','if p_project_id is null'),('20261108460000_work_unit_contributors.sql','work_unit_contributors_read','if not public._ai_job_visible'),('20261108480000_work_unit_metadata_cohorts.sql','work_unit_metadata_read','if not coalesce')]:
   body=next(x for x in a.functions((a.INPUT/file).read_text()) if x[1]==name)[5]
   self.assertLess(body.index('public._work_activity_gate()'),body.index('pg_advisory_xact_lock(7710,0)'))
   self.assertLess(body.rindex('public._work_activity_actor()'),body.index(guard))
   if name=='work_unit_contributors_read':
    self.assertEqual(body.count('if not public._work_config_is_supervisor(actor)'),2)
    self.assertLess(body.rindex('if not public._work_config_is_supervisor(actor)'),body.index(guard))
  review=(a.HERE/'premise/work_unit_review_read.sql').read_text();self.assertLess(review.rindex('public._work_activity_actor()'),review.index('s:=public._work_unit_review_scope'))
 def test_float0_fixtures_have_positive_prerequisites_and_distinct_roles(self):
  public=(a.HERE/'fixtures/float0-existing-public-readers.sql').read_text();before,after=public.split("perform set_config('extra_float_digits','0',true);",1)
  for call in ['public.work_activity_totals_read(project_id,unit_id)','public.work_unit_contributors_read(project_id,unit_id,1)','public.work_unit_metadata_read(unit_id,1)','public.work_unit_review_read(unit_id)']:
   self.assertIn(call,before);self.assertIn(call,after)
  self.assertNotIn('public._work_cross_job_coverage()',public)
  private=(a.HERE/'fixtures/float0-private-coverage.sql').read_text()
  self.assertIn('is distinct from true',private);self.assertIn('is distinct from false',private)
  paid=(a.HERE/'fixtures/float0-paid-reader-still-refuses.sql').read_text();self.assertIn("exception when sqlstate '55000'",paid)
  self.assertNotRegex(re.sub(r'--[^\n]*','',public+private+paid),r'(?i)\b(?:insert|update|delete|truncate|grant|alter role)\s')


 def assert_paid_fixture_specific_guard(self,fixture):
  sql=re.sub(r'--[^\n]*','',fixture)
  before,after=sql.split("perform set_config('extra_float_digits','0',true);",1)
  calls=re.findall(r'perform public\.work_activity_clock_receipt_v2\((.*?)\);',sql,re.S)
  self.assertEqual(len(calls),2);self.assertEqual(calls[0],calls[1])
  self.assertIn("exception when sqlstate '23514' then",before)
  self.assertIn('key_refused:=true;',before)
  self.assertIn("if not key_refused then raise exception 'Float1 null-key prerequisite was not refused';end if;",before)
  handler=after.split("exception when sqlstate '55000' then",1)[1]
  self.assertIn('get stacked diagnostics error_message=message_text;',handler)
  self.assertIn("if error_message is distinct from 'Paid recovery serialization setting is unavailable.' then raise;end if;",handler)
  self.assertLess(handler.index('get stacked diagnostics'),handler.index("set_config('extra_float_digits','1',true)"))
  self.assertIn("raise exception 'Paid reader setting mismatch was not refused';",after)
 def test_paid_float_fixture_requires_specific_message_and_float1_control(self):
  self.assert_paid_fixture_specific_guard((a.HERE/'fixtures/float0-paid-reader-still-refuses.sql').read_text())
 def test_paid_float_fixture_old_counterexample_is_rejected(self):
  old=(a.HERE/'correction3-premise/float0-paid-reader-still-refuses.sql').read_text()
  self.assertIn("exception when sqlstate '55000' then",old)
  self.assertNotIn('get stacked diagnostics',old)
  with self.assertRaises((AssertionError,IndexError,ValueError)):self.assert_paid_fixture_specific_guard(old)
  body=self.reader[5]
  messages=re.findall(r"errcode='55000',message='([^']+)'",body)
  self.assertEqual(messages,['Paid recovery serialization setting is unavailable.','Paid recovery source contract is unavailable.'])
  self.assertIn('return false;',self.fns[('_work_cross_job_coverage','')][5])
 def test_paid_float_fixture_mutations_are_rejected(self):
  good=(a.HERE/'fixtures/float0-paid-reader-still-refuses.sql').read_text()
  mutations=[good.replace('Paid recovery serialization setting is unavailable.','Paid recovery source contract is unavailable.'),
   good.replace('get stacked diagnostics error_message=message_text;',''),
   good.replace("exception when sqlstate '23514' then","exception when sqlstate '55000' then"),
   good.replace("if error_message is distinct from 'Paid recovery serialization setting is unavailable.' then raise;end if;",''),
   good.replace('null::integer,2);','null::integer,1);',1)]
  for changed in mutations:
   with self.subTest(mutation=mutations.index(changed)):
    with self.assertRaises((AssertionError,IndexError,ValueError)):self.assert_paid_fixture_specific_guard(changed)
 def test_omitted_capability_requires_same_context_positive_first(self):
  sql=(a.HERE/'fixtures/v1-capability-omitted-negative.sql').read_text()
  for required in ['executor MUST first pass','same identity and state','base candidate','generic 55000 cannot identify the cause']:
   self.assertIn(required,sql)

if __name__=='__main__':unittest.main(verbosity=2)
