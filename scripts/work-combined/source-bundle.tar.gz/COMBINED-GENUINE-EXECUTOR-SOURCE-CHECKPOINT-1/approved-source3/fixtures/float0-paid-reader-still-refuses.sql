-- UNEXECUTED: genuine eligible authenticated caller with EXECUTE privilege,
-- READ COMMITTED and an exact installed base-candidate catalog are prerequisites.
-- The same float1 null-key call must first reach 23514 after actor/catalog checks.
-- Then float0 must identify the reader's own first guard by its exact message;
-- a later source-contract 55000 is a failure, not proof of the setting guard.
-- This does not prove a valid historical request or provider-session identity.
do $float_paid$ declare error_message text;key_refused boolean:=false;begin
 if current_setting('extra_float_digits') is distinct from '1' then raise exception 'Fixture requires initial float1';end if;
 begin
  perform public.work_activity_clock_receipt_v2(null::uuid,null::uuid,null::text,null::double precision,null::double precision,null::text,null::text,null::uuid,null::timestamptz,null::timestamptz,null::integer,2);
 exception when sqlstate '23514' then
  key_refused:=true;
 end;
 if not key_refused then raise exception 'Float1 null-key prerequisite was not refused';end if;
 perform set_config('extra_float_digits','0',true);
 begin
  perform public.work_activity_clock_receipt_v2(null::uuid,null::uuid,null::text,null::double precision,null::double precision,null::text,null::text,null::uuid,null::timestamptz,null::timestamptz,null::integer,2);
 exception when sqlstate '55000' then
  get stacked diagnostics error_message=message_text;
  if error_message is distinct from 'Paid recovery serialization setting is unavailable.' then raise;end if;
  perform set_config('extra_float_digits','1',true);return;
 end;
 raise exception 'Paid reader setting mismatch was not refused';
end $float_paid$;
