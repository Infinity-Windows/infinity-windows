-- UNEXECUTED: separate installed-function-owner fixture phase. No role grant
-- or privilege repair is allowed. Public-reader assertions use authenticated
-- callers in float0-existing-public-readers.sql, not this privileged phase.
do $float_private$ begin
 if current_setting('extra_float_digits') is distinct from '1' then raise exception 'Fixture requires initial float1';end if;
 if public._work_cross_job_coverage() is distinct from true or public._work_unit_metadata_coverage() is distinct from true then raise exception 'Exact combined catalog positive prerequisite failed';end if;
 perform set_config('extra_float_digits','0',true);
 if public._work_cross_job_coverage() is distinct from false or public._work_unit_metadata_coverage() is distinct from false then raise exception 'Shared coverage must return false';end if;
 perform set_config('extra_float_digits','1',true);
 if public._work_cross_job_coverage() is distinct from true or public._work_unit_metadata_coverage() is distinct from true then raise exception 'Combined catalog changed during fixture';end if;
end $float_private$;
