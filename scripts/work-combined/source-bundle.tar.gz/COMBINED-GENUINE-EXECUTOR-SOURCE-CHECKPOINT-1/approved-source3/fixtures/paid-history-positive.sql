-- UNEXECUTED. Requires a genuine prior authenticated original clock_in(...,2)
-- seed from a separately reviewed, authored disposable gate variant. Direct
-- INSERT of receipts/stamps is forbidden as proof. Root executor must preserve
-- the original request, actual writer trace, retained fifteen fields and stamp.
-- It must also prove this reader call uses the same disposable instance.
-- Settings below carry fixture evidence only; they are NOT provider attestation.
-- Run as the original eligible self after returning to inactive final source.
-- original request keys are the exact twelve SQL parameter names.
do $history$ declare request jsonb;expected jsonb;r jsonb;begin
 request:=current_setting('fixture.original_clock_request')::jsonb;
 expected:=current_setting('fixture.original_clock_receipt')::jsonb;
 if jsonb_typeof(request)<>'object' or (select count(*) from jsonb_object_keys(request))<>12
 or not request ?& array['p_project_id','p_cost_code_id','p_photo','p_lat','p_lng','p_note','p_mode','p_client_id','p_tapped_at','p_clock_checked_at','p_clock_skew_ms','p_setup_version']
 or request->>'p_setup_version' is distinct from '2'
 or jsonb_typeof(expected)<>'object' or (select count(*) from jsonb_object_keys(expected))<>15
 then raise exception 'Genuine original request/receipt seed is required';end if;
 r:=public.work_activity_clock_receipt_v2((request->>'p_project_id')::uuid,(request->>'p_cost_code_id')::uuid,
 request->>'p_photo',(request->>'p_lat')::double precision,(request->>'p_lng')::double precision,
 request->>'p_note',request->>'p_mode',(request->>'p_client_id')::uuid,(request->>'p_tapped_at')::timestamptz,
 (request->>'p_clock_checked_at')::timestamptz,(request->>'p_clock_skew_ms')::integer,(request->>'p_setup_version')::integer);
 if (select array_agg(k order by k) from jsonb_object_keys(r) k) is distinct from array['availability','contract','current','proof','protocolVersion','receipt']::text[]
 or r->>'protocolVersion' is distinct from '2' or r->>'contract' is distinct from 'paid_setup_v2_recovery_v1'
 or r->>'availability' is distinct from 'available' or r->'receipt' is distinct from expected
 or r->'proof' is distinct from jsonb_build_object('originalSetupVersion',2,'match','full_original_setup_digest','fingerprintVersion',1,'receiptSha256',current_setting('fixture.original_receipt_sha256'))
 or jsonb_typeof(r->'current') is distinct from 'object'
 or (select array_agg(k order by k) from jsonb_object_keys(r->'current') k) is distinct from array['asOf','captureRegistered','sourcePresent']::text[]
 or (r#>>'{current,captureRegistered}')::boolean is distinct from current_setting('fixture.expected_capture_registered')::boolean
 or (r#>>'{current,sourcePresent}')::boolean is distinct from current_setting('fixture.expected_source_present')::boolean
 then raise exception 'Historical original2 recovery differs';end if;
end $history$;
