-- UNEXECUTED: executor MUST first pass the appropriate V1 active/closing_only
-- positive on the base candidate with the same identity and state. Preserve
-- that evidence before constructing this negative variant on a fresh baseline.
-- Its generic 55000 cannot identify the cause; exact negative catalog equality
-- and the preceding same-context positive are mandatory executor prerequisites.
-- Use ONLY with omit-capability.negative.sql; catalog equality must pass first.
do $fixture$ begin
 begin
  perform public.work_activity_clock_capability();
 exception when sqlstate '55000' then return;
 end;
 raise exception 'Stale capability body hashes were not refused';
end $fixture$;
