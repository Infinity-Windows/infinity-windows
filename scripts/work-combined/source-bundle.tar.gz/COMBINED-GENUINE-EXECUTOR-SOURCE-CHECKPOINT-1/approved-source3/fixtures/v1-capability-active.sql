-- Execute at the candidate fixture seam in a genuine fresh authenticated context.
-- Prerequisite supplied by the later reviewed executor: eligible self, clean V1
-- state, no safety events or open registered2 shift, authority capture flag true.
-- This assertion neither changes authority nor grants access.
do $fixture$ declare r jsonb;begin
 r:=public.work_activity_clock_capability();
 if (select array_agg(k order by k) from jsonb_object_keys(r) k) is distinct from
 array['asOf','canAuthorSetup','canDispatchExistingSetup','canDispatchPayrollSafety','canReadOwnReceipts','clockProtocol','mode','protocolVersion','receiptProtocol','setupReason']::text[]
 or r->>'protocolVersion' is distinct from '1' or r->>'clockProtocol' is distinct from 'setup_v1'
 or r->>'receiptProtocol' is distinct from 'retained_v1' or r->>'mode' is distinct from 'active'
 or (r->>'canAuthorSetup')::boolean is distinct from true
 or r->>'setupReason' is distinct from null
 or r->'canDispatchExistingSetup' is distinct from 'true'::jsonb
 or r->'canReadOwnReceipts' is distinct from 'true'::jsonb
 or r->'canDispatchPayrollSafety' is distinct from 'true'::jsonb
 then raise exception 'V1 capability compatibility failed';end if;
end $fixture$;
