# Narrow correction 3 closure request

Read the actual checkpoint-2 receipt in `correction3-premise/ACTUAL-SOURCE-2-REVIEW.json`, this handoff, `CORRECTION-3-SOURCE-DIFF.patch`, the modified fixture generators and generated SQL, and the four new tests. Do not recursively review or execute anything.

Confirm F1: the float-1 call is byte-identical to the float-0 null-key call and must reach 23514 after actor/catalog checks. The float-0 handler obtains MESSAGE_TEXT with GET STACKED DIAGNOSTICS, requires exactly `Paid recovery serialization setting is unavailable.`, and rethrows any other 55000. Check failure on unexpected success and the source-backed later-catalog-error counterexample.

Confirm that both omitted-capability headers require an actual V1 positive on the base candidate first, with the same identity and state, plus exact negative catalog equality. Its generic 55000 alone cannot prove cause.

The accepted candidate/security design is unchanged. All 53 prior test methods, candidate/reader/canonical catalog bytes and roots remain identical; inspect the source audit. Prior review read the assembler in full, reused unchanged inherited callers, and assessed generated catalogs through code rather than line-by-line rows. No genuine execution is claimed. Return an explicit actual verdict on this narrow correction; any approval remains held concrete source only, before the separately owned executor and runtime gates.
