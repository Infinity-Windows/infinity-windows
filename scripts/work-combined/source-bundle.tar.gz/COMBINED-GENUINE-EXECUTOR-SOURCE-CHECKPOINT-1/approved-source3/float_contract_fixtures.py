"""Authored, unexecuted float-setting compatibility fixtures; no connection API."""
def write_float_contract_fixtures(out):
    (out/'float0-existing-public-readers.sql').write_text("""-- UNEXECUTED: run at the candidate fixture seam as a genuine eligible
-- authenticated supervisor/owner, before any registered2 shift. The later
-- executor must provide an actually visible project and coherent unit whose
-- baseline review is proven. No identities, rows or grants are manufactured here.
-- The positive float1 calls below prevent invalid context from vacuously passing
-- the float0 unavailable assertions. Any unexpected SQL error fails the fixture.
-- Custom settings hold fixture IDs only; they are not provider attestation.
do $float_public$ declare project_id uuid;unit_id uuid;missing_unit_id uuid;r jsonb;baseline_review jsonb;
begin
 if current_setting('extra_float_digits') is distinct from '1' then raise exception 'Fixture requires initial float1';end if;
 project_id:=current_setting('fixture.visible_project_id')::uuid;
 unit_id:=current_setting('fixture.visible_unit_id')::uuid;
 missing_unit_id:=current_setting('fixture.missing_unit_id')::uuid;
 if project_id is null or unit_id is null or missing_unit_id is null or missing_unit_id=unit_id then raise exception 'Distinct fixture IDs required';end if;
 r:=public.work_activity_totals_read(project_id,unit_id);
 if r->>'availability' is distinct from 'available' then raise exception 'Totals positive prerequisite failed';end if;
 r:=public.work_unit_contributors_read(project_id,unit_id,1);
 if r->>'availability' is distinct from 'available' then raise exception 'Contributors positive prerequisite failed';end if;
 r:=public.work_unit_metadata_read(unit_id,1);
 if r->>'availability' is distinct from 'available' then raise exception 'Metadata positive prerequisite failed';end if;
 baseline_review:=public.work_unit_review_read(unit_id);
 if baseline_review->>'availability' is distinct from 'available' or baseline_review#>>'{review,qc,lifecycle}' is distinct from 'proven' then raise exception 'Proven review positive prerequisite failed';end if;
 r:=public.work_unit_review_read(missing_unit_id);
 if r-'asOf' is distinct from '{"protocolVersion":1,"availability":"unavailable","review":null}'::jsonb then raise exception 'Missing-unit prerequisite failed';end if;
 perform set_config('extra_float_digits','0',true);
 r:=public.work_activity_totals_read(project_id,unit_id);
 if r is distinct from '{"protocolVersion":1,"availability":"unavailable","totals":null}'::jsonb then raise exception 'Totals false-coverage response changed';end if;
 r:=public.work_unit_contributors_read(project_id,unit_id,1);
 if r is distinct from '{"protocolVersion":1,"availability":"unavailable","contributors":null}'::jsonb then raise exception 'Contributors false-coverage response changed';end if;
 r:=public.work_unit_metadata_read(unit_id,1);
 if r is distinct from '{"protocolVersion":1,"availability":"unavailable","metadata":null}'::jsonb then raise exception 'Metadata false-coverage response changed';end if;
 -- Review has a different existing contract: a valid view stays available,
 -- but its proof is unproven and its accepted-proof bit cannot remain true.
 r:=public.work_unit_review_read(unit_id);
 if (select array_agg(k order by k) from jsonb_object_keys(r) k) is distinct from array['asOf','availability','protocolVersion','review']::text[]
 or r->'protocolVersion' is distinct from '1'::jsonb or r->>'availability' is distinct from 'available'
 or jsonb_typeof(r->'asOf') is distinct from 'string'
 or (select array_agg(k order by k) from jsonb_object_keys(r->'review') k) is distinct from array['basis','basisStatus','capabilities','defects','dimensionVerification','observation','qc','work']::text[]
 or r#>>'{review,qc,lifecycle}' is distinct from 'unproven'
 or r#>'{review,qc,qcAccepted}' is distinct from 'false'::jsonb
 or r#>>'{review,qc,acceptance}'='accepted'
 then raise exception 'Review false-coverage response changed';end if;
 r:=public.work_unit_review_read(missing_unit_id);
 if r-'asOf' is distinct from '{"protocolVersion":1,"availability":"unavailable","review":null}'::jsonb
 or jsonb_typeof(r->'asOf') is distinct from 'string' then raise exception 'Missing-unit review response changed';end if;
 perform set_config('extra_float_digits','1',true);
 -- Restoration is an explicit fixture input reset, not production normalization.
end $float_public$;
""")
    (out/'float0-private-coverage.sql').write_text("""-- UNEXECUTED: separate installed-function-owner fixture phase. No role grant
-- or privilege repair is allowed. Public-reader assertions use authenticated
-- callers in float0-existing-public-readers.sql, not this privileged phase.
do $float_private$ begin
 if current_setting('extra_float_digits') is distinct from '1' then raise exception 'Fixture requires initial float1';end if;
 if public._work_cross_job_coverage() is distinct from true or public._work_unit_metadata_coverage() is distinct from true then raise exception 'Exact combined catalog positive prerequisite failed';end if;
 perform set_config('extra_float_digits','0',true);
 if public._work_cross_job_coverage() is distinct from false or public._work_unit_metadata_coverage() is distinct from false then raise exception 'Shared coverage must return false';end if;
 perform set_config('extra_float_digits','1',true);
 if public._work_cross_job_coverage() is distinct from true or public._work_unit_metadata_coverage() is distinct from true then raise exception 'Combined catalog changed during fixture';end if;
end $float_private$;
""")
    (out/'float0-paid-reader-still-refuses.sql').write_text("""-- UNEXECUTED: genuine eligible authenticated caller with EXECUTE privilege,
-- READ COMMITTED and an exact installed base-candidate catalog are prerequisites.
-- The same float1 null-key call must first reach 23514 after actor/catalog checks.
-- Then float0 must identify the reader's own first guard by its exact message;
-- a later source-contract 55000 is a failure, not proof of the setting guard.
-- This does not prove a valid historical request or provider-session identity.
do $float_paid$ declare error_message text;key_refused boolean:=false;begin
 if current_setting('extra_float_digits') is distinct from '1' then raise exception 'Fixture requires initial float1';end if;
 begin
  perform public.work_activity_clock_receipt_v2(null::uuid,null::uuid,null::text,null::double precision,null::double precision,null::text,null::text,null::uuid,null::timestamptz,null::timestamptz,null::integer,2);
 exception when sqlstate '23514' then
  key_refused:=true;
 end;
 if not key_refused then raise exception 'Float1 null-key prerequisite was not refused';end if;
 perform set_config('extra_float_digits','0',true);
 begin
  perform public.work_activity_clock_receipt_v2(null::uuid,null::uuid,null::text,null::double precision,null::double precision,null::text,null::text,null::uuid,null::timestamptz,null::timestamptz,null::integer,2);
 exception when sqlstate '55000' then
  get stacked diagnostics error_message=message_text;
  if error_message is distinct from 'Paid recovery serialization setting is unavailable.' then raise;end if;
  perform set_config('extra_float_digits','1',true);return;
 end;
 raise exception 'Paid reader setting mismatch was not refused';
end $float_paid$;
""")
