#!/usr/bin/env python3
"""Author fresh disposable variants from approved source; never learns live values."""
import copy,hashlib,importlib.util,json,re
from pathlib import Path
HERE=Path(__file__).resolve().parent
APPROVED=HERE/'approved-source3'
def load_assembler():
 spec=importlib.util.spec_from_file_location('approved_combined_assembler',APPROVED/'assemble.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def variants():
 a=load_assembler();source=(APPROVED/'candidate.sql').read_text();catalog=json.loads((APPROVED/'expected-catalog.json').read_text());root=a.sha(a.canonical(catalog))
 assert root=='d7d520dd7c227fedb6594117d017cde3307981156162aedf2c37dfbfd06467b2'
 assert a.sha(source)=='2a323f3d59e622b80cf235c68d7d39533ae1b98717b1a9769a5e5923046f69cd'
 result={'inactive':{'sql':source,'catalog':catalog,'root':root,'privateGate':False,'delta':[]}}
 gate=next(x for x in a.functions(source) if x[1]=='_work_cross_job_enabled');assert gate[5]=='select false'
 # No dependent body may embed the old gate hash. If this changes, stop for a
 # new recursive authoring review rather than substituting arbitrary literals.
 old_hash=a.sha(gate[5]);new_hash=a.sha('select true')
 assert not any(old_hash in fn[5] for fn in a.functions(source))
 active=a.replace_function(source,('_work_cross_job_enabled',''),lambda f:f[0].replace('$$select false$$','$$select true$$'))
 expected=copy.deepcopy(catalog);delta=[]
 for domain in ('publicCatalog','metadataCatalog'):
  for row in expected[domain]['functions']:
   if row['name']=='_work_cross_job_enabled':
    assert row['body']==old_hash;row['body']=new_hash;delta.append({'domain':domain,'function':'_work_cross_job_enabled','field':'body','before':old_hash,'after':new_hash})
 assert len(delta)==1 and delta[0]['domain']=='publicCatalog'
 active_root=a.sha(a.canonical(expected));assert active.count(root)==2;active=active.replace(root,active_root)
 marker="if public._work_cross_job_enabled() then raise exception using errcode='55000',message='Candidate must remain inactive.';end if;"
 assert active.count(marker)==1
 active=active.replace(marker,"if not public._work_cross_job_enabled() then raise exception using errcode='55000',message='Authored disposable active gate is missing.';end if;")
 result['active']={'sql':active,'catalog':expected,'root':active_root,'privateGate':True,'delta':delta}
 # Closing-only is authority DATA false under the unchanged inactive catalog.
 # It is not a third mutable gate implementation or a learned catalog.
 result['closing_only']={'sql':source,'catalog':catalog,'root':root,'privateGate':False,'delta':[]}
 n=json.loads((APPROVED/'fixtures/omit-capability.expected-catalog.json').read_text());nroot=a.sha(a.canonical(n))
 result['negative']={'sql':(APPROVED/'fixtures/omit-capability.negative.sql').read_text(),'catalog':n,'root':nroot,'privateGate':False,'delta':'Exact approved omitted-capability negative; proof data independently authored before immutable triggers.'}
 for name,v in result.items():
  assert v['sql'].rstrip().endswith('rollback;');assert v['sql'].count(v['root'])==2
  assert not re.search(r'disable\s+trigger|drop\s+trigger|update\s+(?:public\.)?(?:work_cross_job_contract|_work_unit_metadata_contract)',v['sql'],re.I)
 return result

def write():
 a=load_assembler();out=HERE/'variants';out.mkdir(exist_ok=True);manifest={}
 for name,v in variants().items():
  (out/(name+'.sql')).write_text(v['sql']);(out/(name+'.catalog.json')).write_text(json.dumps(v['catalog'],indent=2)+'\n');(out/(name+'.canonical.json')).write_text(a.canonical(v['catalog']))
  manifest[name]={'sqlSha256':a.sha(v['sql']),'catalogRoot':v['root'],'privateGate':v['privateGate'],'allowedCatalogDelta':v['delta'],'terminalRollback':True}
 (out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');return manifest
if __name__=='__main__':print(json.dumps(write(),indent=2))
