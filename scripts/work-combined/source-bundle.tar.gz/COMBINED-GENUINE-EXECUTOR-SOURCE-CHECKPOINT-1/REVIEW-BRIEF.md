# New executor source review request

The prior actual source3 approval is limited to held candidate source. Review this new executor proposal independently before any CI execution. No database, provider or SQL case has run here.

Read `combined_executor.py`, `author_variants.py`, `executor-profile.json`, `test_combined_executor.py`, README and TESTPLAN in full. Inspect variant SQL/catalog diffs and exact fixture reuse. Trace inherited helper methods actually used from the pinned V2 module: Fixture.seed/auth/rpc/activity/switch_intent/rows/paid/retained/request_proof/census and validate_paid_response/validate_wire. The inherited enrollment, restoration, run and active_case methods are not called; their proof-trigger mutation path is forbidden in the new executor.

Critical questions:

1. Does the fresh cluster/allowlisted database contract fail closed without terminating connections, changing roles or repairing ownership? Are new database ACLs source-authored construction, and are default PUBLIC rights and extra PG17/ACL-only roles explicitly accounted for? Check exact global membership/options/configuration comparisons and predecessor cleanup.
2. Are all clones made from the same exact0846 source/data state before unchanged47/66 run on the original database? Check shared server identity versus distinct database OIDs and avoid any same-database or cross-instance performance inference.
3. Are both candidate preflights preserved, roots derived only from authored JSON, proof inserts before immutable triggers, and the active variant limited to its declared gate body plus proof data and final assertion? Actual PG17 catalog equality remains a future gate.
4. Does the capability negative require a successful base positive with identical consumed context? Inspect authority updated_at's source-backed exclusion and complete raw-row evidence. A generic 55000 alone must not pass without these prerequisites.
5. Do the real original2 writer calls, twelve original arguments, full eleven-argument digest, incoming version2, fifteen retained fields, fingerprint/microseconds, owner refusal and retries remain exact? Check general A→B, paid physical-A invariants and actual source-B resume.
6. Check actual float fixtures, strict scalar output serialization, full/partial output evidence, timeout staging, ambiguous commit classification and fatal cleanup handling. Nothing may claim rollback/restoration after a disconnect merely because a process ended.
7. Check the required historical limitation: registered2 history is read under the identical reader body in the authored active catalog with capture authority false. The original inactive-root historical fixture is not executed and remains required/open. Active private gate remains literaltrue and its inactive catalog is not restored.

No current repository, workflow, candidate, proof row or role should be edited or executed during this review. Return exact source findings and an explicit held-source verdict. Existing owner/provider/runtime gates remain outside source approval.
