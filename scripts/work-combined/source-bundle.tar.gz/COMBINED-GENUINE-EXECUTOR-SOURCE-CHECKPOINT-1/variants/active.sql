-- DISPOSABLE COMMON-0846 CANDIDATE. NEVER an installed-K6 upgrade or activation.
-- Source-authored catalog; no observed-catalog learning. Terminal rollback is mandatory.
begin;
set local search_path=public,pg_temp;
do $float_contract$ begin
 if current_setting('extra_float_digits') is distinct from '1' then raise exception using errcode='55000',message='Combined assembly requires extra_float_digits=1.';end if;
end $float_contract$;
-- CROSS_JOB_PREFLIGHT_BEGIN: metadata only; refusal precedes every DDL statement.
do $preflight$
begin
 if exists(select 1 from pg_class where relnamespace='public'::regnamespace and (starts_with(relname,'work_cross_job_') or starts_with(relname,'_work_cross_job_')))
 or exists(select 1 from pg_proc where pronamespace='public'::regnamespace and (starts_with(proname,'work_cross_job_') or starts_with(proname,'_work_cross_job_')))
 or exists(select 1 from pg_type where typnamespace='public'::regnamespace and (starts_with(typname,'work_cross_job_') or starts_with(typname,'_work_cross_job_'))) then
  raise exception using errcode='55000',message='Cross-job namespace is not empty; installation refused.';
 end if;
 if (select encode(sha256(convert_to(c.value::text,'UTF8')),'hex') from (
-- Deliberately closed source-derived public catalog. Unknown live drift refuses;
-- this is not a request to normalize a provider to the disposable fixture.
select jsonb_build_object(
 'types',(select jsonb_agg(jsonb_build_object('name',t.typname,'kind',t.typtype,'owner',pg_get_userbyid(t.typowner),'acl',t.typacl::text,'category',t.typcategory,'preferred',t.typispreferred,'defined',t.typisdefined,'notNull',t.typnotnull,'base',format_type(nullif(t.typbasetype,0),t.typtypmod),'element',format_type(nullif(t.typelem,0),null),'collation',case when t.typcollation<>0 then t.typcollation::regcollation::text end,'default',t.typdefault,'defaultExpression',pg_get_expr(t.typdefaultbin,0),'input',t.typinput::regprocedure::text,'output',t.typoutput::regprocedure::text,'receive',t.typreceive::regprocedure::text,'send',t.typsend::regprocedure::text,'length',t.typlen,'byValue',t.typbyval,'alignment',t.typalign,'storage',t.typstorage,'delimiter',t.typdelim,'access',(select jsonb_object_agg(r.rolname,has_type_privilege(r.oid,t.oid,'USAGE')) from pg_roles r where r.rolname in('anon','authenticated','service_role')),'enum',(select jsonb_agg(jsonb_build_object('label',e.enumlabel,'sort',e.enumsortorder) order by e.enumsortorder) from pg_enum e where e.enumtypid=t.oid),'constraints',(select jsonb_agg(jsonb_build_object('name',k.conname,'definition',pg_get_constraintdef(k.oid,true),'validated',k.convalidated) order by k.conname) from pg_constraint k where k.contypid=t.oid),'range',(select jsonb_build_object('subtype',format_type(r.rngsubtype,null),'collation',r.rngcollation::regcollation::text,'opclass',(select n.nspname||'.'||o.opcname from pg_opclass o join pg_namespace n on n.oid=o.opcnamespace where o.oid=r.rngsubopc),'canonical',r.rngcanonical::regprocedure::text,'subdiff',r.rngsubdiff::regprocedure::text) from pg_range r where r.rngtypid=t.oid)) order by t.typname) from pg_type t where t.typnamespace='public'::regnamespace),
 'sequences',(select jsonb_agg(jsonb_build_object('name',c.relname,'owner',pg_get_userbyid(c.relowner),'acl',c.relacl::text,'type',format_type(s.seqtypid,null),'start',s.seqstart,'increment',s.seqincrement,'max',s.seqmax,'min',s.seqmin,'cache',s.seqcache,'cycle',s.seqcycle,'access',(select jsonb_agg(jsonb_build_object('role',r.rolname,'privilege',v.p,'allowed',has_sequence_privilege(r.oid,c.oid,v.p)) order by r.rolname,v.p) from pg_roles r cross join unnest(array['SELECT','UPDATE','USAGE'])v(p) where r.rolname in('anon','authenticated','service_role'))) order by c.relname) from pg_class c join pg_sequence s on s.seqrelid=c.oid where c.relnamespace='public'::regnamespace),
 'foreignTables',(select jsonb_agg(jsonb_build_object('table',c.relname,'options',f.ftoptions,'server',s.srvname,'serverOwner',pg_get_userbyid(s.srvowner),'serverType',s.srvtype,'serverVersion',s.srvversion,'serverOptionsDigest',encode(sha256(convert_to(coalesce(s.srvoptions::text,''),'UTF8')),'hex'),'serverAcl',s.srvacl::text,'serverAccess',(select jsonb_object_agg(r.rolname,has_server_privilege(r.oid,s.oid,'USAGE')) from pg_roles r where r.rolname in('anon','authenticated','service_role')),'wrapper',w.fdwname,'wrapperOwner',pg_get_userbyid(w.fdwowner),'wrapperAcl',w.fdwacl::text,'wrapperAccess',(select jsonb_object_agg(r.rolname,has_foreign_data_wrapper_privilege(r.oid,w.oid,'USAGE')) from pg_roles r where r.rolname in('anon','authenticated','service_role')),'handler',w.fdwhandler::regprocedure::text,'validator',w.fdwvalidator::regprocedure::text,'wrapperOptionsDigest',encode(sha256(convert_to(coalesce(w.fdwoptions::text,''),'UTF8')),'hex')) order by c.relname) from pg_foreign_table f join pg_class c on c.oid=f.ftrelid join pg_foreign_server s on s.oid=f.ftserver join pg_foreign_data_wrapper w on w.oid=s.srvfdw where c.relnamespace='public'::regnamespace),
 'functions',(select jsonb_agg(jsonb_build_object('name',p.proname,'arguments',pg_get_function_identity_arguments(p.oid),'body',encode(sha256(convert_to(p.prosrc,'UTF8')),'hex'),'result',pg_get_function_result(p.oid),'owner',pg_get_userbyid(p.proowner),'acl',p.proacl::text,'language',l.lanname,'kind',p.prokind,'definer',p.prosecdef,'config',p.proconfig,'volatility',p.provolatile,'strict',p.proisstrict,'leakproof',p.proleakproof,'cost',p.procost,'rows',p.prorows,'support',p.prosupport::regprocedure::text,'parallel',p.proparallel,'defaults',pg_get_expr(p.proargdefaults,0),'access',(select jsonb_object_agg(r.rolname,has_function_privilege(r.oid,p.oid,'EXECUTE')) from pg_roles r where r.rolname in('anon','authenticated','service_role'))) order by p.proname,pg_get_function_identity_arguments(p.oid)) from pg_proc p join pg_language l on l.oid=p.prolang where p.pronamespace='public'::regnamespace and not exists(select 1 from pg_depend d where d.classid='pg_proc'::regclass and d.objid=p.oid and d.deptype='e')),
 'relations',(select jsonb_agg(jsonb_build_object('name',c.relname,'kind',c.relkind,'owner',pg_get_userbyid(c.relowner),'rls',c.relrowsecurity,'forcedRls',c.relforcerowsecurity,'acl',c.relacl::text,'access',(select jsonb_agg(jsonb_build_object('role',r.rolname,'privilege',v.p,'table',has_table_privilege(r.oid,c.oid,v.p),'column',case when v.p in('SELECT','INSERT','UPDATE','REFERENCES') then has_any_column_privilege(r.oid,c.oid,v.p) end) order by r.rolname,v.p) from pg_roles r cross join unnest(array['SELECT','INSERT','UPDATE','DELETE','TRUNCATE','REFERENCES','TRIGGER'])v(p) where r.rolname in('anon','authenticated','service_role'))) order by c.relname) from pg_class c where c.relnamespace='public'::regnamespace and c.relkind in('r','p','v','m','f','c')),
 'columns',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',a.attname,'type',format_type(a.atttypid,a.atttypmod),'notNull',a.attnotnull,'generated',a.attgenerated,'identity',a.attidentity,'acl',a.attacl::text,'default',pg_get_expr(d.adbin,d.adrelid),'access',(select jsonb_agg(jsonb_build_object('role',r.rolname,'privilege',v.p,'allowed',has_column_privilege(r.oid,c.oid,a.attnum,v.p)) order by r.rolname,v.p) from pg_roles r cross join unnest(array['SELECT','INSERT','UPDATE','REFERENCES'])v(p) where r.rolname in('anon','authenticated','service_role'))) order by c.relname,a.attnum) from pg_class c join pg_attribute a on a.attrelid=c.oid and a.attnum>0 and not a.attisdropped left join pg_attrdef d on d.adrelid=c.oid and d.adnum=a.attnum where c.relnamespace='public'::regnamespace and c.relkind in('r','p','v','m','f','c')),
 'constraints',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',k.conname,'definition',pg_get_constraintdef(k.oid,true),'validated',k.convalidated,'noInherit',k.connoinherit,'enforced',coalesce((to_jsonb(k)->>'conenforced')::boolean,true)) order by c.relname,k.conname) from pg_constraint k join pg_class c on c.oid=k.conrelid where c.relnamespace='public'::regnamespace and k.contype<>'n'),
 'notNullConstraints',(select jsonb_agg(jsonb_build_object('table',c.relname,'column',a.attname,'validated',coalesce(n.validated,true),'enforced',coalesce(n.enforced,true),'noInherit',coalesce(n.no_inherit,false)) order by c.relname,a.attnum) from pg_class c join pg_attribute a on a.attrelid=c.oid and a.attnum>0 and not a.attisdropped left join lateral(select bool_and(k.convalidated) validated,bool_and(coalesce((to_jsonb(k)->>'conenforced')::boolean,true)) enforced,bool_or(k.connoinherit) no_inherit from pg_constraint k where k.conrelid=c.oid and k.contype='n' and a.attnum=any(k.conkey))n on true where c.relnamespace='public'::regnamespace and c.relkind in('r','p')),
 'indexes',(select jsonb_agg(jsonb_build_object('table',t.relname,'name',c.relname,'definition',pg_get_indexdef(i.indexrelid),'valid',i.indisvalid,'ready',i.indisready) order by t.relname,c.relname) from pg_index i join pg_class c on c.oid=i.indexrelid join pg_class t on t.oid=i.indrelid where t.relnamespace='public'::regnamespace),
 'triggers',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',t.tgname,'definition',pg_get_triggerdef(t.oid,true),'enabled',t.tgenabled) order by c.relname,t.tgname) from pg_trigger t join pg_class c on c.oid=t.tgrelid where c.relnamespace='public'::regnamespace and not t.tgisinternal),
 'policies',(select jsonb_agg(to_jsonb(p) order by p.tablename,p.policyname) from pg_policies p where schemaname='public'),
 'views',(select jsonb_agg(jsonb_build_object('name',c.relname,'definition',pg_get_viewdef(c.oid,true)) order by c.relname) from pg_class c where c.relnamespace='public'::regnamespace and c.relkind in('v','m'))
) value
 )c) is distinct from '18f1f9048e57087987020441e0aff395c5094ec8f677643078f551aa4d705950' then
  raise exception using errcode='55000',message='Cross-job old source contract differs; installation refused before DDL.';
 end if;
end $preflight$;
do $namespace$ begin
 if exists(select 1 from pg_catalog.pg_proc p join pg_catalog.pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and
  (starts_with(p.proname,'_work_unit_metadata_') or starts_with(p.proname,'work_unit_metadata_') or p.proname='work_unit_cohorts_read'))
 or exists(select 1 from pg_catalog.pg_class c join pg_catalog.pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and (starts_with(c.relname,'_work_unit_metadata_') or starts_with(c.relname,'work_unit_metadata_')))
 or exists(select 1 from pg_catalog.pg_type t join pg_catalog.pg_namespace n on n.oid=t.typnamespace where n.nspname='public' and (starts_with(t.typname,'_work_unit_metadata_') or starts_with(t.typname,'work_unit_metadata_'))) then
 raise exception using errcode='55000',message='Unit metadata source is unavailable.';end if;
end $namespace$;
-- METADATA_BASE_PREFLIGHT_BEGIN
do $metadata_source$ begin
 if not public._work_unit_review_coverage() or not public._work_totals_coverage() or not public._work_unit_contributors_coverage() or not coalesce((select encode(sha256(convert_to(c.value::text,'UTF8')),'hex')='2631d3339a577efb31ba99334c9639ad36c6d7248e3eb7eae20293ab1d2e6ee0' from (select jsonb_build_object('namespaceRelations',(select coalesce(jsonb_agg(jsonb_build_object('name',c.relname,'kind',c.relkind) order by c.relname),'[]') from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and starts_with(c.relname,'_work_unit_contributors_')),'namespace',(select coalesce(jsonb_agg(jsonb_build_object('name',p.proname,'args',pg_get_function_identity_arguments(p.oid)) order by p.proname,pg_get_function_identity_arguments(p.oid)),'[]') from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and (p.proname='work_unit_contributors_read' or starts_with(p.proname,'_work_unit_contributors_'))),
 'functions',(select jsonb_agg(jsonb_build_object('name',p.proname,'args',pg_get_function_identity_arguments(p.oid),'language',(select lanname from pg_language where oid=p.prolang),'kind',p.prokind,'result',pg_get_function_result(p.oid),'defaults',pg_get_expr(p.proargdefaults,0),'strict',p.proisstrict,'parallel',p.proparallel,'leakproof',p.proleakproof,'cost',p.procost,'rows',p.prorows,'support',p.prosupport::regprocedure::text,'setReturning',p.proretset,'rawAcl',p.proacl::text,'body',encode(sha256(convert_to(p.prosrc,'UTF8')),'hex'),'config',p.proconfig,'owner',pg_get_userbyid(p.proowner),'definer',p.prosecdef,'volatility',p.provolatile) order by p.proname,pg_get_function_identity_arguments(p.oid)) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname=any(array['_ai_job_visible','_is_lead','_is_supervisor','_work_activity_actor','_work_activity_answers','_work_activity_authority_changed','_work_activity_authority_guard','_work_activity_authority_revision','_work_activity_bookkeeping_guard','_work_activity_claim_clock_setup','_work_activity_clock_replay_guard','_work_activity_clock_review','_work_activity_clock_setup_digest','_work_activity_close_all','_work_activity_close_source','_work_activity_command_basis','_work_activity_consume','_work_activity_context_assert','_work_activity_context_close','_work_activity_context_commit_guard','_work_activity_context_for','_work_activity_context_guard','_work_activity_context_open','_work_activity_ensure_state','_work_activity_ephemeral_commit_guard','_work_activity_establish_payload','_work_activity_establish_stream','_work_activity_event','_work_activity_evidence','_work_activity_expect','_work_activity_expected_guard','_work_activity_fact_snapshot','_work_activity_finish','_work_activity_gate','_work_activity_insert_source','_work_activity_instant','_work_activity_integer','_work_activity_iso','_work_activity_keep_clock_receipt','_work_activity_live_sources','_work_activity_no_truncate','_work_activity_object','_work_activity_observe','_work_activity_operation','_work_activity_operation_enter','_work_activity_operation_exit','_work_activity_parent_gate','_work_activity_parent_source_history','_work_activity_payload','_work_activity_profile_delete_guard','_work_activity_project_view','_work_activity_read_committed','_work_activity_refresh_state','_work_activity_resume','_work_activity_retain_source','_work_activity_review_visit','_work_activity_row_allowance','_work_activity_row_before','_work_activity_row_event','_work_activity_safety_exit','_work_activity_safety_guard','_work_activity_setup_guard','_work_activity_setup_ledger_guard','_work_activity_shift_lifecycle','_work_activity_source_material','_work_activity_source_view','_work_activity_start_setup','_work_activity_statement_begin','_work_activity_statement_end','_work_activity_stream_guard','_work_activity_touch','_work_activity_transition_source_guard','_work_activity_unit_basis','_work_activity_uuid','_work_activity_validate_switch','_work_config_can_manage_menu','_work_config_internal','_work_config_is_foreman','_work_config_is_owner','_work_config_is_supervisor','_work_config_replay','_work_config_store_receipt','_work_config_validate_menu_draft_items','_work_config_validate_typed_fields','_work_totals_capture','_work_totals_coverage','_work_totals_shift','_work_totals_source','_work_totals_visible','_work_unit_contributors_coverage','_work_unit_contributors_person','_work_unit_contributors_shift','_work_unit_fact_bump_epoch','_work_unit_fact_context_visible','_work_unit_fact_peek_epoch','_work_unit_review_authority','_work_unit_review_coverage','_work_unit_review_defect_projection','_work_unit_review_scope','_work_unit_review_view','attach_sandbox_guards','clock_in','clock_out','custom_work_internal','end_break','guard_test_account_sandbox_only','is_partner_user','is_sandbox_project','is_test_profile','person_record_counts','row_project_id','sandbox_scoped_tables','service_job_access','shift_cap_hours','start_break','work_activity_command','work_activity_snapshot','work_activity_totals_read','work_capture_immutable_record','work_publish_activity_version','work_publish_menu_version','work_select_job_menu','work_unit_contributors_read'])),
 'triggers',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',t.tgname,'definition',pg_get_triggerdef(t.oid,true),'enabled',t.tgenabled) order by c.relname,t.tgname) from pg_trigger t join pg_class c on c.oid=t.tgrelid join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants']) and not t.tgisinternal),
 'columns',(select jsonb_agg(jsonb_build_object('table',c.relname,'column',a.attname,'type',format_type(a.atttypid,a.atttypmod),'nullable',not a.attnotnull,'default',(select pg_get_expr(d.adbin,d.adrelid) from pg_attrdef d where d.adrelid=a.attrelid and d.adnum=a.attnum),'collation',a.attcollation::regcollation::text,'rawAcl',a.attacl::text,'notNullValidated',coalesce(nn.validated,true),'notNullEnforced',coalesce(nn.enforced,true),'notNullNoInherit',coalesce(nn.no_inherit,false),'generated',a.attgenerated,'identity',a.attidentity) order by c.relname,a.attnum) from pg_class c join pg_namespace n on n.oid=c.relnamespace join pg_attribute a on a.attrelid=c.oid and a.attnum>0 and not a.attisdropped left join lateral (select bool_and(k.convalidated) validated,bool_and(coalesce((to_jsonb(k)->>'conenforced')::boolean,true)) enforced,bool_or(k.connoinherit) no_inherit from pg_constraint k where k.conrelid=a.attrelid and k.contype='n' and a.attnum=any(k.conkey)) nn on true where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants'])),
 'functionAccess',(select jsonb_agg(jsonb_build_object('name',p.proname,'args',pg_get_function_identity_arguments(p.oid),'role',r.rolname,'execute',has_function_privilege(r.oid,p.oid,'EXECUTE')) order by p.proname,pg_get_function_identity_arguments(p.oid),r.rolname) from pg_proc p join pg_namespace n on n.oid=p.pronamespace cross join pg_roles r where n.nspname='public' and p.proname=any(array['_ai_job_visible','_is_lead','_is_supervisor','_work_activity_actor','_work_activity_answers','_work_activity_authority_changed','_work_activity_authority_guard','_work_activity_authority_revision','_work_activity_bookkeeping_guard','_work_activity_claim_clock_setup','_work_activity_clock_replay_guard','_work_activity_clock_review','_work_activity_clock_setup_digest','_work_activity_close_all','_work_activity_close_source','_work_activity_command_basis','_work_activity_consume','_work_activity_context_assert','_work_activity_context_close','_work_activity_context_commit_guard','_work_activity_context_for','_work_activity_context_guard','_work_activity_context_open','_work_activity_ensure_state','_work_activity_ephemeral_commit_guard','_work_activity_establish_payload','_work_activity_establish_stream','_work_activity_event','_work_activity_evidence','_work_activity_expect','_work_activity_expected_guard','_work_activity_fact_snapshot','_work_activity_finish','_work_activity_gate','_work_activity_insert_source','_work_activity_instant','_work_activity_integer','_work_activity_iso','_work_activity_keep_clock_receipt','_work_activity_live_sources','_work_activity_no_truncate','_work_activity_object','_work_activity_observe','_work_activity_operation','_work_activity_operation_enter','_work_activity_operation_exit','_work_activity_parent_gate','_work_activity_parent_source_history','_work_activity_payload','_work_activity_profile_delete_guard','_work_activity_project_view','_work_activity_read_committed','_work_activity_refresh_state','_work_activity_resume','_work_activity_retain_source','_work_activity_review_visit','_work_activity_row_allowance','_work_activity_row_before','_work_activity_row_event','_work_activity_safety_exit','_work_activity_safety_guard','_work_activity_setup_guard','_work_activity_setup_ledger_guard','_work_activity_shift_lifecycle','_work_activity_source_material','_work_activity_source_view','_work_activity_start_setup','_work_activity_statement_begin','_work_activity_statement_end','_work_activity_stream_guard','_work_activity_touch','_work_activity_transition_source_guard','_work_activity_unit_basis','_work_activity_uuid','_work_activity_validate_switch','_work_config_can_manage_menu','_work_config_internal','_work_config_is_foreman','_work_config_is_owner','_work_config_is_supervisor','_work_config_replay','_work_config_store_receipt','_work_config_validate_menu_draft_items','_work_config_validate_typed_fields','_work_totals_capture','_work_totals_coverage','_work_totals_shift','_work_totals_source','_work_totals_visible','_work_unit_contributors_coverage','_work_unit_contributors_person','_work_unit_contributors_shift','_work_unit_fact_bump_epoch','_work_unit_fact_context_visible','_work_unit_fact_peek_epoch','_work_unit_review_authority','_work_unit_review_coverage','_work_unit_review_defect_projection','_work_unit_review_scope','_work_unit_review_view','attach_sandbox_guards','clock_in','clock_out','custom_work_internal','end_break','guard_test_account_sandbox_only','is_partner_user','is_sandbox_project','is_test_profile','person_record_counts','row_project_id','sandbox_scoped_tables','service_job_access','shift_cap_hours','start_break','work_activity_command','work_activity_snapshot','work_activity_totals_read','work_capture_immutable_record','work_publish_activity_version','work_publish_menu_version','work_select_job_menu','work_unit_contributors_read','_work_unit_contributors_coverage']) and r.rolname in('anon','authenticated','service_role')),
 'privateAccess',(select jsonb_agg(jsonb_build_object('table',c.relname,'role',r.rolname,'privilege',v.name,'allowed',has_table_privilege(r.oid,c.oid,v.name)) order by c.relname,r.rolname,v.name) from pg_class c join pg_namespace n on n.oid=c.relnamespace cross join pg_roles r cross join (values('SELECT'),('INSERT'),('UPDATE'),('DELETE'),('TRUNCATE'),('REFERENCES'),('TRIGGER')) v(name) where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_review_live_sources']) and r.rolname in('anon','authenticated','service_role')),
 -- Effective access includes table-derived rights, role inheritance and PUBLIC.
 'columnAccess',(select jsonb_agg(jsonb_build_object('table',c.relname,'role',r.rolname,'privilege',v.name,'allowed',has_any_column_privilege(r.oid,c.oid,v.name)) order by c.relname,r.rolname,v.name) from pg_class c join pg_namespace n on n.oid=c.relnamespace cross join pg_roles r cross join (values('SELECT'),('INSERT'),('UPDATE'),('REFERENCES')) v(name) where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_review_live_sources']) and r.rolname in('anon','authenticated','service_role')),
 'constraints',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',k.conname,'definition',pg_get_constraintdef(k.oid,true),'validated',k.convalidated,'enforced',coalesce((to_jsonb(k)->>'conenforced')::boolean,true),'deferrable',k.condeferrable,'deferred',k.condeferred) order by c.relname,k.conname) from pg_constraint k join pg_class c on c.oid=k.conrelid join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and k.contype<>'n' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants'])),
 'policies',(select jsonb_agg(jsonb_build_object('table',tablename,'name',policyname,'permissive',permissive,'roles',roles,'command',cmd,'using',qual,'check',with_check) order by tablename,policyname) from pg_policies where schemaname='public' and tablename=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants'])),
 'view',pg_get_viewdef('public._work_unit_review_live_sources'::regclass,true),
 'tables',(select jsonb_agg(jsonb_build_object('table',c.relname,'rls',c.relrowsecurity,'forcedRls',c.relforcerowsecurity,'kind',c.relkind,'persistence',c.relpersistence,'rawAcl',c.relacl::text,'owner',pg_get_userbyid(c.relowner)) order by c.relname) from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants']))
) value)c),false) then raise exception using errcode='55000',message='Unit metadata source is unavailable.';end if;
end $metadata_source$;
-- METADATA_BASE_PREFLIGHT_END

-- CROSS_JOB_DDL_BEGIN
-- All identities are retained UUIDs. Operational deletes never cascade evidence.
create table public.work_cross_job_shifts (
 shift_id uuid primary key, profile_id uuid not null, clock_in_at timestamptz not null check(isfinite(clock_in_at)),
 birth_history_id uuid not null, birth_transition_id uuid not null, clock_request_id uuid not null,
 original_project_id uuid, original_cost_code_id uuid, generation integer not null check(generation=2),
 registered_at timestamptz not null default clock_timestamp()
);
create index work_cross_job_shifts_profile on public.work_cross_job_shifts(profile_id,shift_id);
create table public.work_cross_job_allocations (
 id uuid primary key, shift_id uuid not null references public.work_cross_job_shifts(shift_id), profile_id uuid not null,
 predecessor_id uuid references public.work_cross_job_allocations(id), event_kind text not null check(event_kind in('initial','handoff','amendment')),
 project_id uuid not null, cost_code_id uuid, original_tapped_at timestamptz not null check(isfinite(original_tapped_at)),
 clock_checked_at timestamptz not null check(isfinite(clock_checked_at)), clock_skew_ms integer not null,
 admitted_at timestamptz not null check(isfinite(admitted_at)), effective_at timestamptz not null check(isfinite(effective_at)),
 boundary_mode text not null check(boundary_mode='trusted_original_tap'), command_id uuid not null unique,
 transition_id uuid not null, authority_revision bigint not null, source_generation integer not null check(source_generation=2),
 check(effective_at<=admitted_at), check((event_kind='initial')=(predecessor_id is null))
);
create unique index work_cross_job_allocations_successor on public.work_cross_job_allocations(predecessor_id) where predecessor_id is not null;
create unique index work_cross_job_allocations_initial on public.work_cross_job_allocations(shift_id) where predecessor_id is null;
create index work_cross_job_allocations_shift on public.work_cross_job_allocations(shift_id,effective_at);
create table public.work_cross_job_heads (
 shift_id uuid primary key references public.work_cross_job_shifts(shift_id), allocation_id uuid not null references public.work_cross_job_allocations(id)
);
create table public.work_cross_job_bindings (
 source_kind text not null check(source_kind in('custom','unit','task','service','phase','setup')), source_id uuid not null,
 birth_history_id uuid not null, source_effective_at timestamptz not null check(isfinite(source_effective_at)),
 profile_id uuid not null, shift_id uuid not null references public.work_cross_job_shifts(shift_id),
 allocation_id uuid references public.work_cross_job_allocations(id), project_id uuid,
 command_id uuid, transition_id uuid not null, resumed_from_history_id uuid,
 generation integer not null check(generation=2),
 primary key(source_kind,source_id,birth_history_id),
 check((source_kind='setup')=(allocation_id is null)), check((source_kind='setup')=(project_id is null))
);
create index work_cross_job_bindings_shift on public.work_cross_job_bindings(shift_id,source_kind,source_id);
-- Optional bounded resume cache: never a new deferred paid-commit requirement.
create table public.work_cross_job_resume (
 profile_id uuid primary key, shift_id uuid not null, source_kind text not null, source_id uuid not null,
 closure_history_id uuid not null, birth_history_id uuid not null, break_transition_id uuid not null,
 break_started_at timestamptz not null, effective_started_at timestamptz not null,
 allocation_id uuid, authority_revision bigint not null, source_value jsonb not null
);
-- No activation function or writable switch exists in this held candidate.
create function public._work_cross_job_enabled() returns boolean language sql stable security definer set search_path=public,pg_temp as $$select true$$;
revoke all on function public._work_cross_job_enabled() from public,anon,authenticated,service_role;
revoke all on table public.work_cross_job_shifts from public,anon,authenticated,service_role;
revoke all on table public.work_cross_job_allocations from public,anon,authenticated,service_role;
revoke all on table public.work_cross_job_heads from public,anon,authenticated,service_role;
revoke all on table public.work_cross_job_bindings from public,anon,authenticated,service_role;
revoke all on table public.work_cross_job_resume from public,anon,authenticated,service_role;
alter table public.work_cross_job_shifts enable row level security;
alter table public.work_cross_job_allocations enable row level security;
alter table public.work_cross_job_heads enable row level security;
alter table public.work_cross_job_bindings enable row level security;
alter table public.work_cross_job_resume enable row level security;
-- CROSS_JOB_RUNTIME_BEGIN
-- New private implementation. Generation2 remains unreachable while held.
alter table public.personal_activity_commands drop constraint personal_activity_commands_protocol_version_check;
alter table public.personal_activity_commands add constraint personal_activity_commands_protocol_version_check check(protocol_version in(1,2));
alter table public.personal_activity_transitions drop constraint personal_activity_transitions_protocol_version_check;
alter table public.personal_activity_transitions add constraint personal_activity_transitions_protocol_version_check check(protocol_version in(1,2));
create index work_cross_job_source_history_operation on public.work_activity_source_history(source_kind,source_id,operation_id);
create table public.work_cross_job_write_frames (
 operation_id uuid not null, source_kind text not null, source_id uuid not null, profile_id uuid not null, shift_id uuid not null,
 allocation_id uuid, effective_at timestamptz not null, primary key(operation_id,source_kind,source_id)
);
revoke all on table public.work_cross_job_write_frames from public,anon,authenticated,service_role;
alter table public.work_cross_job_write_frames enable row level security;
create trigger work_cross_job_shifts_immutable before update or delete on public.work_cross_job_shifts for each row execute function public.work_capture_immutable_record();
create trigger work_cross_job_allocations_immutable before update or delete on public.work_cross_job_allocations for each row execute function public.work_capture_immutable_record();
create trigger work_cross_job_bindings_immutable before update or delete on public.work_cross_job_bindings for each row execute function public.work_capture_immutable_record();
create trigger work_cross_job_shifts_no_truncate before truncate on public.work_cross_job_shifts for each statement execute function public.work_capture_immutable_record();
create trigger work_cross_job_allocations_no_truncate before truncate on public.work_cross_job_allocations for each statement execute function public.work_capture_immutable_record();
create trigger work_cross_job_bindings_no_truncate before truncate on public.work_cross_job_bindings for each statement execute function public.work_capture_immutable_record();

create function public._work_cross_job_table(p_kind text) returns text language sql immutable set search_path=public,pg_temp as $$
 select case p_kind when 'custom' then 'custom_work_sessions' when 'service' then 'service_time_sessions' when 'unit' then 'unit_sessions' when 'task' then 'task_sessions' when 'phase' then 'opening_phases' when 'setup' then 'work_setup_sessions' when 'shift' then 'time_shifts' end
$$;
-- Indexed current history head; no ordering by time/UUID, no full proof walk.
create function public._work_cross_job_history(p_kind text,p_id uuid) returns public.work_activity_source_history
language plpgsql stable security definer set search_path=public,pg_temp as $$
declare r public.work_activity_source_history; n integer; current_operation uuid;
begin
 current_operation:=(public._work_activity_operation()).id;
 if current_operation is null then return null;end if;
 select count(*) into n from public.work_activity_source_history h where h.source_kind=public._work_cross_job_table(p_kind) and h.source_id=p_id::text and h.operation_id=current_operation
 and not exists(select 1 from public.work_activity_source_history x where x.predecessor_id=h.id);
 if n<>1 then return null;end if;
 select h.* into r from public.work_activity_source_history h where h.source_kind=public._work_cross_job_table(p_kind) and h.source_id=p_id::text and h.operation_id=current_operation
 and not exists(select 1 from public.work_activity_source_history x where x.predecessor_id=h.id);
 if r.legacy_baseline then return null;end if;return r;
end$$;
create function public._work_cross_job_scope(p_shift uuid,p_actor uuid,p_full boolean default true) returns boolean
language plpgsql stable security definer set search_path=public,pg_temp as $$
declare s public.work_cross_job_shifts; h public.time_shifts; b public.work_activity_source_history; source_row record; view_state public.personal_activity_state;
begin
 select * into s from public.work_cross_job_shifts where shift_id=p_shift;
 select * into h from public.time_shifts where id=p_shift;
 select * into b from public.work_activity_source_history where id=s.birth_history_id;
 if s.shift_id is null or h.id is null or s.profile_id is distinct from p_actor or h.profile_id is distinct from p_actor
 or h.clock_in_at is distinct from s.clock_in_at or h.project_id is distinct from s.original_project_id or h.cost_code_id is distinct from s.original_cost_code_id
 or b.before_value<>'{}'::jsonb or b.after_value->>'id' is distinct from h.id::text or b.legacy_baseline
 or not public._work_config_internal(p_actor) then return false;end if;
 if exists(select 1 from public.work_activity_source_history x where x.source_kind='time_shifts' and x.source_id=p_shift::text and (x.after_value='{}'::jsonb or (x.before_value='{}'::jsonb and x.id<>s.birth_history_id))) then return false;end if;
 if not public._work_cross_job_head_valid(p_shift) then return false;end if;
 if s.original_project_id is not null and not public._ai_job_visible(s.original_project_id,p_actor) then return false;end if;
 -- All retained original job dependencies must be visible before any receipt.
 if p_full then
  if exists(select 1 from public.work_cross_job_allocations a where a.shift_id=p_shift and not public._ai_job_visible(a.project_id,p_actor)) then return false;end if;
  select * into view_state from public.personal_activity_state where profile_id=p_actor;
  for source_row in select source_kind,source_id,source_effective_at from public.work_cross_job_bindings where shift_id=p_shift loop
   view_state.active_source_kind:=source_row.source_kind;view_state.active_source_id:=source_row.source_id;view_state.effective_since:=source_row.source_effective_at;
   if public._work_activity_source_view(view_state)->>'visibility' is distinct from 'available' then return false;end if;
  end loop;
 end if;
 return true;
end$$;
create function public._work_cross_job_register(p_shift public.time_shifts,p_request uuid) returns void
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare o public.work_activity_operations; person public.work_activity_operation_people; birth public.work_activity_source_history;
begin
 o:=public._work_activity_operation();person:=public._work_activity_touch(p_shift.profile_id);birth:=public._work_cross_job_history('shift',p_shift.id);
 if not public._work_cross_job_enabled() or o.route<>'clock_in_setup' or o.arguments->>'setupVersion'<>'2' or o.request_id is distinct from p_request
 or o.actor_id is distinct from p_shift.profile_id or birth.operation_id is distinct from o.id or birth.before_value<>'{}'::jsonb
 or birth.after_value->>'id' is distinct from p_shift.id::text or birth.legacy_baseline then raise exception using errcode='23514',message='Unsupported cross-job physical origin.';end if;
 insert into public.work_cross_job_shifts(shift_id,profile_id,clock_in_at,birth_history_id,birth_transition_id,clock_request_id,original_project_id,original_cost_code_id,generation)
 values(p_shift.id,p_shift.profile_id,p_shift.clock_in_at,birth.id,person.transition_id,p_request,p_shift.project_id,p_shift.cost_code_id,2);
end$$;
-- No source is admitted merely because another source on this shift is v2.
create function public._work_cross_job_birth_guard(p_kind text,p_before jsonb,p_after jsonb) returns void
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare who uuid; sh uuid; o public.work_activity_operations; starts boolean; open_count integer;
begin
 if p_kind not in('custom','service','unit','task','phase','setup') then return;end if;
 who:=(p_after->>case when p_kind='phase' then 'started_by' else 'profile_id' end)::uuid;
 starts:=case when p_kind='phase' then p_after->>'status'='active' and p_after->>'paused_at' is null and (p_before is null or p_before->>'paused_at' is not null or p_before->>'status' is distinct from 'active')
 else p_after->>'ended_at' is null and (p_before is null or p_before->>'ended_at' is not null) and (p_kind<>'task' or p_after->>'state'='on_task') end;
 if starts is distinct from true then return;end if;
 if not exists(select 1 from public.work_cross_job_shifts s join public.time_shifts h on h.id=s.shift_id where s.profile_id=who and h.status='open' and h.clock_out_at is null) then return;end if;
 select count(*) into open_count from public.time_shifts h where h.profile_id=who and h.status='open' and h.clock_out_at is null;
 if open_count<>1 then raise exception using errcode='23514',message='Choose work on one unambiguous paid shift.';end if;
 select s.shift_id into sh from public.work_cross_job_shifts s join public.time_shifts h on h.id=s.shift_id where s.profile_id=who and h.status='open' and h.clock_out_at is null;
 o:=public._work_activity_operation();
 if p_kind='setup' and o.actor_id=who and o.route in('clock_in_setup','end_break') then return;end if;
 if not exists(select 1 from public.work_cross_job_write_frames f where f.operation_id=o.id and f.profile_id=who and f.shift_id=sh
 and f.source_kind=p_kind and f.source_id=(p_after->>'id')::uuid) then
 raise exception using errcode='23514',message='Choose work using the current capture version.';end if;
end$$;
create function public._work_cross_job_bind(p_kind text,p_id uuid,p_shift uuid,p_allocation uuid,p_started timestamptz,p_prior uuid default null) returns void
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare o public.work_activity_operations; person public.work_activity_operation_people; h public.work_activity_source_history; a public.work_cross_job_allocations; s public.work_cross_job_shifts;
begin
 o:=public._work_activity_operation();select * into s from public.work_cross_job_shifts where shift_id=p_shift;
 person:=public._work_activity_touch(s.profile_id);h:=public._work_cross_job_history(p_kind,p_id);
 select * into a from public.work_cross_job_allocations where id=p_allocation;
 if h.id is null or h.operation_id is distinct from o.id or h.after_value->>'id' is distinct from p_id::text
 or (p_kind<>'setup' and (a.shift_id is distinct from p_shift or a.profile_id is distinct from s.profile_id or a.effective_at>p_started)) then
 raise exception using errcode='23514',message='Source birth does not match allocation.';end if;
 insert into public.work_cross_job_bindings(source_kind,source_id,birth_history_id,source_effective_at,profile_id,shift_id,allocation_id,project_id,command_id,transition_id,resumed_from_history_id,generation)
 values(p_kind,p_id,h.id,p_started,s.profile_id,p_shift,p_allocation,a.project_id,o.command_id,person.transition_id,p_prior,2);
end$$;
create function public._work_cross_job_local_valid(p_kind text,p_row jsonb,p_shift public.time_shifts) returns boolean
language plpgsql stable security definer set search_path=public,pg_temp as $$
declare b public.work_cross_job_bindings; a public.work_cross_job_allocations; s public.work_cross_job_shifts; n integer; birth public.work_activity_source_history;
begin
 select count(*) into n from public.work_cross_job_bindings where source_kind=p_kind and source_id=(p_row->>'id')::uuid;
 if n<>1 then return false;end if;
 select * into b from public.work_cross_job_bindings where source_kind=p_kind and source_id=(p_row->>'id')::uuid;
 select * into s from public.work_cross_job_shifts where shift_id=b.shift_id;
 select * into a from public.work_cross_job_allocations where id=b.allocation_id;
 select * into birth from public.work_activity_source_history where id=b.birth_history_id;
 return coalesce(b.shift_id=p_shift.id and b.profile_id=p_shift.profile_id and p_row->>'profile_id'=b.profile_id::text
 and p_row->>'shift_id'=b.shift_id::text and p_row->>'project_id'=b.project_id::text and a.project_id=b.project_id and a.shift_id=b.shift_id
 and (p_row->>'started_at')::timestamptz=b.source_effective_at and a.effective_at<=b.source_effective_at
 and not exists(select 1 from public.work_activity_source_history x where x.source_kind=public._work_cross_job_table(p_kind) and x.source_id=b.source_id::text and (x.after_value='{}'::jsonb or (x.before_value='{}'::jsonb and x.id<>b.birth_history_id)))
 and birth.before_value='{}'::jsonb and birth.after_value->>'id'=b.source_id::text and not birth.legacy_baseline
 and s.clock_in_at=p_shift.clock_in_at and s.original_project_id is not distinct from p_shift.project_id
 and s.original_cost_code_id is not distinct from p_shift.cost_code_id and p_shift.status not in('needs_finish','rejected','voided')
 and b.source_effective_at>=p_shift.clock_in_at
 -- Callbacks run before lifecycle closure. A live source is valid only when
 -- its actual/effective start is already within the paid boundary; a closed
 -- source must also end within it. Equality is a valid zero-length interval.
 and (p_shift.clock_out_at is null or (b.source_effective_at<=p_shift.clock_out_at
  and (p_row->>'ended_at' is null or (p_row->>'ended_at')::timestamptz<=p_shift.clock_out_at))),false);
end$$;

-- General and Specific direct/resumed births share this exact writer.
create function public._work_cross_job_custom(p_profile uuid,p_shift public.time_shifts,p_allocation uuid,p_intent jsonb,p_at timestamptz,p_cause text,p_prior uuid default null) returns uuid
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare a public.work_cross_job_allocations; d public.work_activity_definition_versions; data jsonb; new_id uuid:=gen_random_uuid(); frame uuid; columns text[]; o public.work_activity_operations; basis jsonb;
begin
 o:=public._work_activity_operation();select * into a from public.work_cross_job_allocations where id=p_allocation;
 if o.actor_id is distinct from p_profile or p_shift.profile_id is distinct from p_profile or a.shift_id is distinct from p_shift.id
 or a.project_id is distinct from (p_intent->>'projectId')::uuid or not public._work_cross_job_scope(p_shift.id,p_profile,false)
 or public._work_activity_validate_switch(p_intent,p_profile) is not null or p_shift.break_started_at is not null or p_shift.clock_out_at is not null
 or p_shift.status<>'open' or p_at<a.effective_at or exists(select 1 from public._work_activity_live_sources(p_profile)) then
 raise exception using errcode='23514',message='Cross-job source is unavailable.';end if;
 if p_intent->>'scope'='specific' then perform public._unit_work_gate(p_profile);else perform public._prep_time_gate(p_profile);end if;
 select * into d from public.work_activity_definition_versions where id=(p_intent->>'definitionVersionId')::uuid;
 data:=jsonb_build_object('id',new_id,'profile_id',p_profile,'shift_id',p_shift.id,'project_id',a.project_id,'unit_id',p_intent#>'{unit,id}',
 'kind',case when p_intent->>'scope'='specific' then 'unit' else 'idle' end,'participation','install','stage',left(d.label_en,100),'description',d.label_en,'started_at',p_at,'shift_status',p_shift.status,'review_required',false);
 insert into public.work_cross_job_write_frames values(o.id,'custom',new_id,p_profile,p_shift.id,a.id,p_at);
 select array_agg(key order by key) into columns from jsonb_object_keys(data)key;frame:=public._work_activity_context_for(p_profile,p_cause,p_at);
 perform public._work_activity_expect(frame,'public.custom_work_sessions'::regclass,'INSERT',new_id,columns,null,public._work_activity_evidence('custom_work_sessions',data));
 insert into public.custom_work_sessions(id,profile_id,shift_id,project_id,unit_id,kind,participation,stage,description,started_at,shift_status,review_required)
 select r.id,r.profile_id,r.shift_id,r.project_id,r.unit_id,r.kind,r.participation,r.stage,r.description,r.started_at,r.shift_status,r.review_required from jsonb_populate_record(null::public.custom_work_sessions,data)r;
 perform public._work_activity_context_close(frame);
 if p_intent->>'scope'='specific' then basis:=public._work_activity_command_basis(public._work_activity_unit_basis((p_intent#>>'{unit,id}')::uuid,p_profile));end if;
 insert into public.work_session_capture_metadata(session_id,profile_id,project_id,definition_version_id,menu_version_id,scope,unit_id,fact_revision,unit_facts,machine_kind,selection_id,selection_revision,answers,unit_basis,continuation_unit_basis)
 values(new_id,p_profile,a.project_id,d.id,(p_intent->>'menuVersionId')::uuid,p_intent->>'scope',(p_intent#>>'{unit,id}')::uuid,(p_intent#>>'{unit,factRevision}')::bigint,
 case when p_intent->>'scope'='specific' then public._work_activity_fact_snapshot((p_intent#>>'{unit,id}')::uuid) end,p_intent->>'machineKind',(p_intent->>'selectionId')::uuid,(p_intent->>'selectionRevision')::bigint,p_intent->'values',nullif(p_intent->'unit','null'::jsonb),basis);
 perform public._work_cross_job_bind('custom',new_id,p_shift.id,p_allocation,p_at,p_prior);
 delete from public.work_cross_job_write_frames where operation_id=o.id and source_kind='custom' and source_id=new_id;
 return new_id;
end$$;

-- Exact eligibility is checked after close and again independently at resume.
create function public._work_cross_job_save(p_state public.personal_activity_state,p_shift uuid,p_break timestamptz,p_transition uuid) returns boolean
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare h public.work_activity_source_history; r jsonb; b public.work_cross_job_bindings; a uuid; n integer; o public.work_activity_operations;
begin
 delete from public.work_cross_job_resume where profile_id=p_state.profile_id;
 begin
 if p_state.active_source_id is null or p_state.effective_since is null or p_state.effective_since>p_break then return false;end if;
 o:=public._work_activity_operation();h:=public._work_cross_job_history(p_state.active_source_kind,p_state.active_source_id);r:=h.after_value;
 if h.id is null or h.operation_id is distinct from o.id or not(p_transition=any(h.transition_ids))
 or (case when p_state.active_source_kind='phase' then (r->>'paused_at')::timestamptz else (r->>'ended_at')::timestamptz end) is distinct from p_break
 or coalesce((r->>'review_required')::boolean,false) or (p_state.active_source_kind in('custom','unit','service','setup') and r->>'end_reason' is distinct from 'break') then return false;end if;
 if exists(select 1 from public.work_cross_job_shifts where shift_id=p_shift) then
   select count(*) into n from public.work_cross_job_bindings where source_kind=p_state.active_source_kind and source_id=p_state.active_source_id and source_effective_at=p_state.effective_since;
   if n<>1 then return false;end if;
   select * into b from public.work_cross_job_bindings where source_kind=p_state.active_source_kind and source_id=p_state.active_source_id and source_effective_at=p_state.effective_since;
   select allocation_id into a from public.work_cross_job_heads where shift_id=p_shift;
   if b.allocation_id is distinct from a or b.shift_id is distinct from p_shift or b.profile_id is distinct from p_state.profile_id
   or exists(select 1 from public.work_cross_job_allocations where id=a and effective_at>p_break) then return false;end if;
 end if;
 insert into public.work_cross_job_resume(profile_id,shift_id,source_kind,source_id,closure_history_id,birth_history_id,break_transition_id,break_started_at,effective_started_at,allocation_id,authority_revision,source_value)
 values(p_state.profile_id,p_shift,p_state.active_source_kind,p_state.active_source_id,h.id,coalesce(b.birth_history_id,h.id),p_transition,p_break,p_state.effective_since,a,public._work_activity_authority_revision(),r);
 return true;
exception when raise_exception or check_violation or foreign_key_violation or unique_violation or insufficient_privilege or numeric_value_out_of_range then return false;
 end;
end$$;
create function public._work_cross_job_resume_basis(p_state public.personal_activity_state,p_shift public.time_shifts,p_at timestamptz) returns boolean
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare b public.work_cross_job_resume; h public.work_activity_source_history; paid public.work_activity_source_history; o public.work_activity_operations; a uuid; t public.personal_activity_transitions; binding public.work_cross_job_bindings;
begin
 o:=public._work_activity_operation();select * into b from public.work_cross_job_resume where profile_id=p_state.profile_id;
 if b.profile_id is null or b.source_id is distinct from p_state.resume_source_id or b.source_kind is distinct from p_state.resume_source_kind
 or b.shift_id is distinct from p_shift.id or b.break_transition_id is distinct from p_state.resume_after_break_transition_id
 or b.effective_started_at>b.break_started_at or b.break_started_at>p_at or b.authority_revision is distinct from public._work_activity_authority_revision()
 or o.route<>'end_break' or o.actor_id is distinct from p_state.profile_id then return false;end if;
 select * into h from public.work_activity_source_history where id=b.closure_history_id and source_kind=public._work_cross_job_table(b.source_kind) and source_id=b.source_id::text;
 if exists(select 1 from public.work_activity_source_history where predecessor_id=h.id) then return false;end if;
 select * into paid from public.work_activity_source_history where operation_id=o.id and source_kind='time_shifts' and source_id=p_shift.id::text and before_value->>'break_started_at' is not null and after_value->>'break_started_at' is null;
 if not found then return false;end if;
 select * into t from public.personal_activity_transitions where id=b.break_transition_id;
 if t.id is null or t.profile_id is distinct from p_state.profile_id or t.source_shift_id is distinct from p_shift.id or t.cause<>'break_start'
 or t.selected_effective_at is distinct from b.break_started_at or not(b.break_transition_id=any(h.transition_ids))
 or t.before_evidence#>>'{state,active_source_kind}' is distinct from b.source_kind
 or t.before_evidence#>>'{state,active_source_id}' is distinct from b.source_id::text
 or (t.before_evidence#>>'{state,effective_since}')::timestamptz is distinct from b.effective_started_at then return false;end if;
 if exists(select 1 from public.work_cross_job_shifts where shift_id=p_shift.id) then
  select * into binding from public.work_cross_job_bindings where source_kind=b.source_kind and source_id=b.source_id and birth_history_id=b.birth_history_id;
  if binding.source_id is null or binding.source_effective_at is distinct from b.effective_started_at or binding.source_effective_at>b.break_started_at
   or binding.allocation_id is distinct from b.allocation_id or binding.shift_id is distinct from p_shift.id or binding.profile_id is distinct from p_state.profile_id
   or exists(select 1 from public.work_cross_job_allocations where id=binding.allocation_id and effective_at>b.break_started_at) then return false;end if;
 end if;
 if h.id is distinct from b.closure_history_id or h.after_value is distinct from b.source_value or h.legacy_baseline
 or paid.operation_id is distinct from o.id or (paid.before_value->>'break_started_at')::timestamptz is distinct from b.break_started_at
 or paid.after_value->>'break_started_at' is not null or (paid.after_value->>'last_punch_at')::timestamptz is distinct from p_at
 or (case when b.source_kind='phase' then (h.after_value->>'paused_at')::timestamptz else (h.after_value->>'ended_at')::timestamptz end) is distinct from b.break_started_at
 or coalesce((h.after_value->>'review_required')::boolean,false) then return false;end if;
 select allocation_id into a from public.work_cross_job_heads where shift_id=p_shift.id;
 if a is distinct from b.allocation_id or not public._work_cross_job_head_valid(p_shift.id) then return false;end if;
 if exists(select 1 from public.work_cross_job_shifts where shift_id=p_shift.id) and not public._work_cross_job_scope(p_shift.id,p_state.profile_id,false) then return false;end if;
 return true;
end$$;
create or replace function public.custom_work_follow_shift() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
begin
 -- Unregistered sources retain the exact legacy callback behavior.
 update public.custom_work_sessions s set shift_status=new.status,
 review_required=review_required or new.status in('needs_finish','rejected','voided') or project_id is distinct from new.project_id
 or started_at<new.clock_in_at or (ended_at is not null and new.clock_out_at is not null and ended_at>new.clock_out_at)
 where shift_id=new.id and not exists(select 1 from public.work_cross_job_shifts x where x.shift_id=s.shift_id);
 update public.custom_work_sessions s set shift_status=new.status,review_required=coalesce(s.review_required,false) or
 not public._work_cross_job_local_valid('custom',to_jsonb(s),new)
 or coalesce((new.break_started_at is not null and old.break_started_at is null and (s.started_at>new.break_started_at or s.ended_at>new.break_started_at)),false)
 where shift_id=new.id and exists(select 1 from public.work_cross_job_shifts x where x.shift_id=s.shift_id)
 and (s.shift_status is distinct from new.status or (not coalesce(s.review_required,false) and (
 not public._work_cross_job_local_valid('custom',to_jsonb(s),new)
 or coalesce((new.break_started_at is not null and old.break_started_at is null and (s.started_at>new.break_started_at or s.ended_at>new.break_started_at)),false))));
 return new;
end$$;
create or replace function public.service_follow_shift() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
declare visit_id uuid; r public.service_time_sessions; bad boolean; affected uuid[]:='{}'; registered boolean;
begin
 registered:=exists(select 1 from public.work_cross_job_shifts where shift_id=new.id);
 for r in select * from public.service_time_sessions where shift_id=new.id loop
  if not registered then
   bad:=r.review_required or new.status in('needs_finish','rejected','voided') or r.project_id is distinct from new.project_id
    or r.started_at<new.clock_in_at or (r.ended_at is not null and new.clock_out_at is not null and r.ended_at>new.clock_out_at)
    or (new.break_seconds is distinct from old.break_seconds and old.break_started_at is null);
   update public.service_time_sessions set review_required=bad where id=r.id;
   affected:=array_append(affected,r.visit_id);
  else
   bad:=not public._work_cross_job_local_valid('service',to_jsonb(r),new)
    or (new.break_seconds is distinct from old.break_seconds and old.break_started_at is null)
    or coalesce((new.break_started_at is not null and old.break_started_at is null and (r.started_at>new.break_started_at or r.ended_at>new.break_started_at)),false);
   if bad and not r.review_required then update public.service_time_sessions set review_required=true where id=r.id;end if;
   -- Original trigger runs BEFORE lifecycle closure. Include active intervals
   -- at the selected boundary; unrelated earlier visits retain their stamps.
   if bad or (r.ended_at is null and ((new.break_started_at is not null and old.break_started_at is null)
    or (new.clock_out_at is not null and old.clock_out_at is null) or new.status is distinct from old.status)) then affected:=array_append(affected,r.visit_id);end if;
  end if;
 end loop;
 for visit_id in select distinct unnest(affected) order by 1 loop
  perform public._work_activity_review_visit(visit_id,(public._work_activity_operation()).arrival_at,'correction');
 end loop;
 return new;
end$$;
-- Shared version2 start/resume writer for remaining timing kinds. Public legacy
-- entries remain row-fenced until they explicitly carry this validated context.
create function public._work_cross_job_source(p_profile uuid,p_shift public.time_shifts,p_allocation uuid,p_kind text,p_data jsonb,p_at timestamptz,p_cause text,p_prior uuid default null) returns uuid
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare a public.work_cross_job_allocations; o public.work_activity_operations; new_id uuid; opening public.project_openings; visit public.service_visits;
 data jsonb; frame uuid; columns text[]; oldj jsonb; paused numeric; table_name text;
begin
 o:=public._work_activity_operation();select * into a from public.work_cross_job_allocations where id=p_allocation;
 if p_kind not in('unit','task','service','phase') or o.actor_id is distinct from p_profile or p_shift.profile_id is distinct from p_profile
 or a.shift_id is distinct from p_shift.id or not public._work_cross_job_scope(p_shift.id,p_profile,false) or p_shift.status<>'open'
 or p_shift.break_started_at is not null or p_shift.clock_out_at is not null or p_at<a.effective_at
 or exists(select 1 from public._work_activity_live_sources(p_profile)) then raise exception using errcode='23514',message='Cross-job source is unavailable.';end if;
 perform public._unit_work_gate(p_profile);
 perform public._work_activity_touch(p_profile);
 if p_kind in('unit','task','phase') then
  select * into opening from public.project_openings where id=(p_data->>'opening_id')::uuid;
  if opening.id is null or opening.project_id is distinct from a.project_id or opening.removed_at is not null or opening.status='installed'
  or not public._ai_job_visible(opening.project_id,p_profile) then raise exception using errcode='23514',message='Cross-job opening is unavailable.';end if;
 end if;
 new_id:=gen_random_uuid();
 if p_kind='unit' then
  if p_data->>'role' is distinct from 'install' then raise exception using errcode='23514',message='Unsupported unit participation.';end if;
  data:=jsonb_build_object('id',new_id,'profile_id',p_profile,'opening_id',opening.id,'role','install','is_rework',public._has_open_redo(opening.id),'started_at',p_at);
 elsif p_kind='task' then
  data:=jsonb_build_object('id',new_id,'profile_id',p_profile,'opening_id',opening.id,'project_id',a.project_id,'state','on_task','started_at',p_at);
 elsif p_kind='service' then
  select * into visit from public.service_visits where id=(p_data->>'visit_id')::uuid;
  if visit.id is null or visit.project_id is distinct from a.project_id or visit.status<>'active' or not public.service_job_access(a.project_id)
  or (p_data->>'unit_id' is not null and not exists(select 1 from public.service_visit_units where id=(p_data->>'unit_id')::uuid and visit_id=visit.id and project_id=a.project_id)) then
  raise exception using errcode='23514',message='Cross-job visit is unavailable.';end if;
  data:=jsonb_build_object('id',new_id,'profile_id',p_profile,'visit_id',visit.id,'project_id',a.project_id,'unit_id',p_data->'unit_id','shift_id',p_shift.id,
  'kind',p_data->'kind','stage',p_data->'stage','description',p_data->'description','started_at',p_at);
 elsif p_kind='phase' then
  if p_prior is not null then
   select to_jsonb(x) into oldj from public.opening_phases x where id=(p_data->>'id')::uuid for update;
   if oldj is null or oldj->>'started_by' is distinct from p_profile::text or oldj->>'opening_id' is distinct from opening.id::text or oldj->>'status'<>'active' or oldj->>'paused_at' is null then
   raise exception using errcode='23514',message='Phase continuation is unavailable.';end if;
   paused:=(oldj->>'paused_seconds')::numeric+greatest(0,round(extract(epoch from p_at-(oldj->>'paused_at')::timestamptz)));
   if paused is null or paused<0 or paused>2147483647 then raise exception using errcode='23514',message='Phase continuation is unavailable.';end if;
   new_id:=(oldj->>'id')::uuid;data:=jsonb_build_object('paused_at',null,'paused_seconds',paused::integer);
  else
   data:=jsonb_build_object('id',new_id,'started_by',p_profile,'opening_id',opening.id,'kind',p_data->'kind','status','active','started_at',p_at,'paused_seconds',0);
  end if;
 end if;
 insert into public.work_cross_job_write_frames values(o.id,p_kind,new_id,p_profile,p_shift.id,a.id,p_at);
 if p_kind<>'phase' then
  perform public._work_activity_insert_source(p_profile,p_kind,data,p_at,p_cause);
 else
  frame:=public._work_activity_context_for(p_profile,p_cause,p_at);
  if oldj is null then
   select array_agg(key order by key) into columns from jsonb_object_keys(data)key;
   perform public._work_activity_expect(frame,'public.opening_phases'::regclass,'INSERT',new_id,columns,null,public._work_activity_evidence('opening_phases',data));
   insert into public.opening_phases(id,started_by,opening_id,kind,status,started_at,paused_seconds)
   select r.id,r.started_by,r.opening_id,r.kind,r.status,r.started_at,r.paused_seconds from jsonb_populate_record(null::public.opening_phases,data)r;
  else
   columns:=array['paused_at','paused_seconds'];
   perform public._work_activity_expect(frame,'public.opening_phases'::regclass,'UPDATE',new_id,columns,
   jsonb_build_object('id',new_id,'started_by',p_profile,'paused_at',oldj->'paused_at','paused_seconds',oldj->'paused_seconds'),
   jsonb_build_object('id',new_id,'started_by',p_profile)||data);
   update public.opening_phases set paused_at=null,paused_seconds=paused::integer where id=new_id;
  end if;
  perform public._work_activity_context_close(frame);
 end if;
 perform public._work_cross_job_bind(p_kind,new_id,p_shift.id,a.id,p_at,p_prior);
 delete from public.work_cross_job_write_frames where operation_id=o.id and source_kind=p_kind and source_id=new_id;
 return new_id;
end$$;
-- A mutable head can accelerate CAS but can never turn an ancestor into a head.
create function public._work_cross_job_head_valid(p_shift uuid) returns boolean language sql stable security definer set search_path=public,pg_temp as $$
 select case when not exists(select 1 from public.work_cross_job_allocations where shift_id=p_shift)
 then not exists(select 1 from public.work_cross_job_heads where shift_id=p_shift)
 else exists(select 1 from public.work_cross_job_heads h join public.work_cross_job_allocations a on a.id=h.allocation_id
 where h.shift_id=p_shift and a.shift_id=p_shift and not exists(select 1 from public.work_cross_job_allocations n where n.predecessor_id=a.id)) end
$$;
create function public._work_cross_job_allocation_guard() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
declare o public.work_activity_operations;p public.work_activity_operation_people;prior public.work_cross_job_allocations;head uuid;s public.work_cross_job_shifts;
begin
 o:=public._work_activity_operation();select * into p from public.work_activity_operation_people where operation_id=o.id and profile_id=new.profile_id;
 select * into s from public.work_cross_job_shifts where shift_id=new.shift_id;
 select allocation_id into head from public.work_cross_job_heads where shift_id=new.shift_id;
 select * into prior from public.work_cross_job_allocations where id=new.predecessor_id;
 if o.route is distinct from 'work_activity_command' or o.command_id is distinct from new.command_id or o.actor_id is distinct from new.profile_id
 or p.transition_id is distinct from new.transition_id or s.profile_id is distinct from new.profile_id or new.effective_at<s.clock_in_at
 or new.predecessor_id is distinct from head or not public._work_cross_job_head_valid(new.shift_id)
 or (new.predecessor_id is not null and (prior.shift_id is distinct from new.shift_id or prior.profile_id is distinct from new.profile_id or prior.effective_at>new.effective_at))
 or new.event_kind='amendment' then raise exception using errcode='23514',message='Allocation lacks its exact current command boundary.';end if;
 return new;
end$$;
create trigger work_cross_job_allocation_admission before insert on public.work_cross_job_allocations for each row execute function public._work_cross_job_allocation_guard();
create index work_cross_job_source_incarnations on public.work_activity_source_history(source_kind,source_id) where before_value='{}'::jsonb or after_value='{}'::jsonb;
-- Callback predicates are same-shift lookups, including historical closed visits.
create index work_cross_job_custom_shift on public.custom_work_sessions(shift_id,started_at,ended_at);
create index work_cross_job_service_shift on public.service_time_sessions(shift_id,started_at,ended_at,visit_id);

-- Original successful keyed setup request identity, including paid-only fallback.
-- Deliberately retained without profile/shift/operation FKs or cascade rewriting.
create table public.work_cross_job_clock_requests (
 client_id uuid primary key,
 profile_id uuid not null,
 shift_id uuid not null,
 operation_id uuid not null,
 setup_version integer not null check(setup_version in(1,2)),
 receipt_sha256 text not null check(receipt_sha256 ~ '^[0-9a-f]{64}$')
);
create index work_cross_job_clock_requests_profile on public.work_cross_job_clock_requests(profile_id);
revoke all on table public.work_cross_job_clock_requests from public,anon,authenticated,service_role;
alter table public.work_cross_job_clock_requests enable row level security;
-- Canonical receipt fingerprint v1. All 15 retained fields in fixed order;
-- timestamptz values are exact numeric epoch microseconds, never session text.
create function public._work_cross_job_clock_receipt_fingerprint(p_receipt public.work_activity_clock_receipts) returns text
language sql immutable strict security definer set search_path=public,pg_temp as $$
 select pg_catalog.encode(pg_catalog.sha256(pg_catalog.convert_to(pg_catalog.jsonb_build_array(
  'work_clock_receipt_fingerprint_v1'::text,
  p_receipt.client_id,p_receipt.profile_id,p_receipt.shift_id,p_receipt.action,p_receipt.outcome,
  extract(epoch from p_receipt.tapped_at)*1000000::numeric,
  extract(epoch from p_receipt.arrived_at)*1000000::numeric,
  extract(epoch from p_receipt.clock_checked_at)*1000000::numeric,
  p_receipt.clock_skew_ms,p_receipt.used_tap_time,p_receipt.review_reason,
  extract(epoch from p_receipt.source_created_at)*1000000::numeric,
  p_receipt.receipt_protocol,p_receipt.setup_payload_digest,
  extract(epoch from p_receipt.recorded_at)*1000000::numeric
 )::text,'UTF8')),'hex')
$$;
revoke all on function public._work_cross_job_clock_receipt_fingerprint(public.work_activity_clock_receipts) from public,anon,authenticated,service_role;
create function public._work_cross_job_clock_request_admit() returns trigger
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare o public.work_activity_operations;r public.work_activity_clock_receipts;
begin
 perform pg_catalog.pg_advisory_xact_lock(7712,0);
 o:=public._work_activity_operation();
 select * into r from public.work_activity_clock_receipts where client_id=new.client_id;
 if o.id is null or o.route is distinct from 'clock_in_setup' or not o.clock_entry_claimed
  or o.actor_id is null or o.actor_id is distinct from auth.uid() or o.actor_id is distinct from new.profile_id
  or o.request_id is distinct from new.client_id or o.id is distinct from new.operation_id
  or o.top_xid is distinct from pg_current_xact_id() or o.backend_pid is distinct from pg_backend_pid() or o.command_id is not null
  or o.arguments->>'setupVersion' is distinct from new.setup_version::text
  or r.client_id is null or r.profile_id is distinct from new.profile_id or r.shift_id is distinct from new.shift_id
  or r.action is distinct from 'clock_in' or r.receipt_protocol is distinct from 'setup_v1'
  or r.setup_payload_digest is distinct from o.arguments->>'clockPayloadDigest'
  or new.receipt_sha256 is distinct from public._work_cross_job_clock_receipt_fingerprint(r) then
   raise exception using errcode='42501',message='Clock receipt unavailable.';
 end if;
 return new;
end$$;
create function public._work_cross_job_clock_request_stamp() returns trigger
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare o public.work_activity_operations;
begin
 if new.action<>'clock_in' or new.receipt_protocol<>'setup_v1' then return new;end if;
 o:=public._work_activity_operation();
 if o.id is null or o.route is distinct from 'clock_in_setup'
  or o.arguments->>'setupVersion' is null or o.arguments->>'setupVersion' not in('1','2') then
  raise exception using errcode='42501',message='Clock receipt unavailable.';
 end if;
 insert into public.work_cross_job_clock_requests(client_id,profile_id,shift_id,operation_id,setup_version,receipt_sha256)
 values(new.client_id,new.profile_id,new.shift_id,o.id,(o.arguments->>'setupVersion')::integer,public._work_cross_job_clock_receipt_fingerprint(new));
 return new;
end$$;
revoke all on function public._work_cross_job_clock_request_admit() from public,anon,authenticated,service_role;
revoke all on function public._work_cross_job_clock_request_stamp() from public,anon,authenticated,service_role;
create trigger work_cross_job_clock_requests_admit before insert on public.work_cross_job_clock_requests for each row execute function public._work_cross_job_clock_request_admit();
create trigger work_cross_job_clock_requests_immutable before update or delete on public.work_cross_job_clock_requests for each row execute function public.work_capture_immutable_record();
create trigger work_cross_job_clock_requests_no_truncate before truncate on public.work_cross_job_clock_requests for each statement execute function public.work_capture_immutable_record();
create trigger work_cross_job_clock_request_stamp after insert on public.work_activity_clock_receipts for each row execute function public._work_cross_job_clock_request_stamp();

create or replace function public._work_activity_row_before() returns trigger
language plpgsql security definer set search_path=public,pg_temp as $$
declare oldj jsonb; newj jsonb; who uuid; oldwho uuid; kind text; o public.work_activity_operations;
 allowance uuid; new_live boolean; old_live boolean; boundary timestamptz;
begin
 o:=public._work_activity_operation();
 if o.id is null then raise exception using errcode='23514',message='Activity source write lacks its statement.';end if;
 oldj:=case when tg_op<>'INSERT' then to_jsonb(old) end;
 newj:=case when tg_op<>'DELETE' then to_jsonb(new) end;
 who:=(coalesce(newj,oldj)->>case when tg_table_name='opening_phases' then 'started_by' else 'profile_id' end)::uuid;
 oldwho:=(oldj->>case when tg_table_name='opening_phases' then 'started_by' else 'profile_id' end)::uuid;
 perform public._work_cross_job_birth_guard(case tg_table_name when 'custom_work_sessions' then 'custom' when 'unit_sessions' then 'unit' when 'task_sessions' then 'task' when 'service_time_sessions' then 'service' when 'opening_phases' then 'phase' when 'work_setup_sessions' then 'setup' end,oldj,newj);
 if oldwho is not null then perform public._work_activity_touch(oldwho);end if;
 if who is not null then perform public._work_activity_touch(who);end if;
 -- Setup has its stronger exact-once private guard. Do not consume its
 -- allowance twice; its row guard remains installed and authoritative.
 if tg_table_name<>'work_setup_sessions' then allowance:=public._work_activity_row_allowance(tg_relid,tg_op,oldj,newj);end if;
 if allowance is not null or tg_op='DELETE' or tg_table_name in ('time_shifts','summon_helpers','work_setup_sessions') then
   if tg_op='DELETE' then return old;else return new;end if;
 end if;
 kind:=case tg_table_name when 'custom_work_sessions' then 'custom' when 'unit_sessions' then 'unit' when 'task_sessions' then 'task' when 'service_time_sessions' then 'service' when 'opening_phases' then 'phase' end;
 new_live:=case when kind='phase' then newj->>'status'='active' and newj->'paused_at'='null'::jsonb
   when kind='task' then newj->>'state'='on_task' and newj->'ended_at'='null'::jsonb else newj->'ended_at'='null'::jsonb end;
 old_live:=coalesce(case when kind='phase' then oldj->>'status'='active' and oldj->'paused_at'='null'::jsonb
   when kind='task' then oldj->>'state'='on_task' and oldj->'ended_at'='null'::jsonb else oldj->'ended_at'='null'::jsonb end,false);
 -- Shared progress may be resumed by another authorized worker, or by a
 -- starter off the clock. It is then untimed progress, never a transfer of
 -- that starter's personal claim or a closure of their unrelated activity.
 if kind='phase' and (who is distinct from o.actor_id or (select count(*) from public.time_shifts where profile_id=who and status='open' and clock_out_at is null and break_started_at is null)<>1) then return new;end if;
 if who is not null and new_live and (not old_live or oldwho is distinct from who) then
   boundary:=case when kind='phase' and tg_op='UPDATE' then o.arrival_at else (newj->>'started_at')::timestamptz end;
   if boundary is null or not isfinite(boundary) then raise exception using errcode='23514',message='A finite activity boundary is required.';end if;
   if exists(select 1 from public.time_shifts where profile_id=who and status='open' and clock_out_at is null and break_started_at is not null) then
     raise exception using errcode='23514',message='Resume the job clock before starting work.';
   end if;
   if kind<>'service' and exists(select 1 from public.service_time_sessions where profile_id=who and (started_at>boundary or ended_at>boundary)) then
     raise exception using errcode='23514',message='Newer service time requires timeline review.';
   end if;
   perform public._work_activity_close_all(who,boundary,'legacy_transition',kind,(newj->>'id')::uuid);
 elsif kind='task' and tg_op='INSERT' and newj->>'state'='off_task' then
   perform public._work_activity_close_all(who,(newj->>'started_at')::timestamptz,'stop');
 end if;
 return new;
end; $$;

create or replace function public._work_activity_operation_exit(p_operation uuid) returns void
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare o public.work_activity_operations; person public.work_activity_operation_people; s public.personal_activity_state;
 before_s public.personal_activity_state; last_event public.work_activity_operation_events; event_row record;
 selected_time timestamptz; selected_cause text; shift_source uuid; relation_kind text; before_count bigint;
begin
 if p_operation is null then return; end if;
 o:=public._work_activity_operation();
 if o.id is distinct from p_operation then raise exception using errcode='42501',message='Activity operation is unavailable.'; end if;
 if exists(select 1 from public.work_activity_statement_frames where operation_id=o.id)
   or exists(select 1 from public.work_activity_transaction_context where top_xid=o.top_xid and backend_pid=o.backend_pid) then
   raise exception using errcode='23514',message='Activity statements and mutations must finish before their operation.';
 end if;
 for person in select * from public.work_activity_operation_people where operation_id=o.id order by profile_id loop
   before_s:=jsonb_populate_record(null::public.personal_activity_state,person.before_state);
   s:=public._work_activity_refresh_state(person.profile_id);
   select * into last_event from public.work_activity_operation_events where operation_id=o.id and profile_id=person.profile_id order by event_order desc limit 1;
   if last_event.id is null and (to_jsonb(s)-'updated_at')=(person.before_state-'updated_at') then continue; end if;
   selected_time:=coalesce(last_event.selected_at,o.arrival_at);
   selected_cause:=coalesce(last_event.cause,'legacy_transition');
   -- A payroll transition owns the root boundary even when its callback
   -- emits subsequent per-source rows at the same selected time.
   select source_id,selected_at,cause into shift_source,selected_time,selected_cause from public.work_activity_operation_events
     where operation_id=o.id and profile_id=person.profile_id and source_kind='shift' order by event_order desc limit 1;
   if not found then selected_time:=coalesce(last_event.selected_at,o.arrival_at);selected_cause:=coalesce(last_event.cause,'legacy_transition');shift_source:=coalesce(s.shift_id,before_s.shift_id); end if;
   if o.command_id is not null then selected_cause:=case o.arguments->>'kind' when 'switch' then 'switch' else 'stop' end; end if;
   if before_s.revision>=9007199254740991 or exists(select 1 from public.work_activity_safety_events where profile_id=person.profile_id) then
     perform public._work_activity_safety_exit(o.id,person.profile_id,case when before_s.revision>=9007199254740991 then 'revision_exhausted' else 'prior_safety_event' end);
     continue;
   end if;
   insert into public.personal_activity_transitions(id,profile_id,revision_before,revision_after,command_id,legacy_source_route,source_request_id,actor_id,cause,
     received_at,selected_effective_at,time_selection_reason,source_shift_id,before_evidence,after_evidence,protocol_version)
   values(person.transition_id,person.profile_id,before_s.revision,before_s.revision+1,o.command_id,case when o.command_id is null then o.route end,o.request_id,o.actor_id,
     selected_cause,o.arrival_at,selected_time,case when o.command_id is null then 'legacy_selected_boundary' else 'validated_activity_boundary' end,shift_source,
     jsonb_build_object('state',person.before_state),jsonb_build_object('state',(to_jsonb(s)-'updated_at')||jsonb_build_object('revision',before_s.revision+1,'last_transition_id',person.transition_id)),case when exists(select 1 from public.work_cross_job_shifts where shift_id=shift_source) then 2 else 1 end);
   -- Multiple writes to one source in one logical operation are one typed
   -- immutable child: exact first-before and last-after, never copied notes.
   for event_row in
     select source_kind,source_id,(array_agg(before_value order by event_order))[1] first_before,
       (array_agg(after_value order by event_order desc))[1] last_after,
       (array_agg(selected_at order by event_order desc))[1] boundary,
       (array_agg(cause order by event_order desc))[1] event_cause
     from public.work_activity_operation_events where operation_id=o.id and profile_id=person.profile_id group by source_kind,source_id
   loop
     relation_kind:=case event_row.source_kind when 'shift' then 'payroll' when 'helper' then 'attribution'
       when 'phase' then case when (before_s.active_source_kind='phase' and before_s.active_source_id=event_row.source_id)
         or (s.active_source_kind='phase' and s.active_source_id=event_row.source_id) then 'phase_participation' else 'attribution' end else 'effective' end;
     insert into public.personal_activity_transition_sources(transition_id,profile_id,source_kind,source_id,relation,source_shift_id,
       selected_effective_at,cause,before_revision,after_revision,before_evidence,after_evidence)
     values(person.transition_id,person.profile_id,event_row.source_kind,event_row.source_id,relation_kind,
       case when event_row.source_kind='shift' then event_row.source_id else coalesce((event_row.last_after->>'shift_id')::uuid,(event_row.first_before->>'shift_id')::uuid,shift_source) end,
       event_row.boundary,event_row.event_cause,(event_row.first_before->>'revision')::bigint,(event_row.last_after->>'revision')::bigint,event_row.first_before,event_row.last_after);
   end loop;
   update public.personal_activity_state set revision=before_s.revision+1,last_transition_id=person.transition_id,
     resume_after_break_transition_id=case when resume_token is not null and selected_cause='break_start' then person.transition_id else resume_after_break_transition_id end,
     updated_at=clock_timestamp() where profile_id=person.profile_id;
   -- A source's narrow integer counter may be exhausted while the personal
   -- counter remains usable. Keep the normal lifecycle transition AND exact
   -- exceptional evidence; do not wrap a source revision or block payroll.
   if exists(select 1 from public.work_activity_operation_events e where e.operation_id=o.id and e.profile_id=person.profile_id
      and ((e.source_kind='custom' and (e.before_value->>'revision')::bigint>=2147483647 and e.before_value is distinct from e.after_value)
        or e.after_value->'exhaustedVisitCounter' is not null)) then
     perform public._work_activity_safety_exit(o.id,person.profile_id,'source_revision_exhausted');
   end if;
 end loop;
 delete from public.work_activity_operation_events where operation_id=o.id;
 delete from public.work_activity_operation_people where operation_id=o.id;
 delete from public.work_activity_operations where id=o.id;
end; $$;

create or replace function public._work_activity_start_setup(p_shift public.time_shifts,p_clock_client uuid,p_prior uuid default null) returns uuid
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare person public.work_activity_operation_people; o public.work_activity_operations; at_time timestamptz; created uuid;
begin
 o:=public._work_activity_operation();person:=public._work_activity_touch(p_shift.profile_id);
 if o.actor_id is distinct from p_shift.profile_id or not public._work_config_internal(p_shift.profile_id)
   or (person.before_state->>'revision')::bigint>=9007199254740991
   or exists(select 1 from public.work_activity_safety_events where profile_id=p_shift.profile_id) then return null;end if;
 if p_prior is null and (o.route<>'clock_in_setup' or o.request_id is distinct from p_clock_client) then
   raise exception using errcode='23514',message='Initial setup requires the explicit clock adapter.';
 end if;
 at_time:=case when p_prior is null then p_shift.clock_in_at else coalesce(p_shift.last_punch_at,o.arrival_at) end;
 created:=public._work_activity_insert_source(p_shift.profile_id,'setup',jsonb_build_object('id',gen_random_uuid(),'profile_id',p_shift.profile_id,
   'shift_id',p_shift.id,'clock_client_id',p_clock_client,'resumed_from_id',p_prior,'started_at',at_time,'start_transition_id',person.transition_id),
   at_time,case when p_prior is null then 'clock_in' else 'break_end' end);
 if exists(select 1 from public.work_cross_job_shifts where shift_id=p_shift.id) then perform public._work_cross_job_bind('setup',created,p_shift.id,null,at_time,case when p_prior is not null then (select closure_history_id from public.work_cross_job_resume where profile_id=p_shift.profile_id) end);end if;
 return created;
end; $$;

create or replace function public._work_activity_shift_lifecycle() returns trigger
language plpgsql security definer set search_path=public,pg_temp as $$
declare person public.work_activity_operation_people; s public.personal_activity_state; o public.work_activity_operations; boundary timestamptz; cause text; saved boolean; resumed boolean;
begin
 o:=public._work_activity_operation();person:=public._work_activity_touch(case when tg_op='DELETE' then old.profile_id else new.profile_id end);
 select * into s from public.personal_activity_state where profile_id=person.profile_id;
 if tg_op='DELETE' then
   if s.shift_id=old.id then perform public._work_activity_close_all(old.profile_id,o.arrival_at,'correction');end if;
   return old;
 end if;
 if tg_op='INSERT' then
   -- Historical imports never start/close today's activity. Ordinary new
   -- clock-ins clear stale claims before explicit setup can be opened.
   if new.source_import is null and new.status='open' and new.clock_out_at is null then
     perform public._work_activity_close_all(new.profile_id,new.clock_in_at,'clock_in');
   end if;
   return new;
 end if;
 if new.clock_out_at is not null and old.clock_out_at is null then boundary:=new.clock_out_at;cause:='clock_out';
 elsif new.status<>'open' and old.status='open' then boundary:=coalesce(new.clock_out_at,o.arrival_at);cause:=case when new.status='voided' then 'void' else 'correction' end;
 elsif new.break_started_at is not null and old.break_started_at is null then boundary:=new.break_started_at;cause:='break_start';
 elsif new.break_started_at is null and old.break_started_at is not null and new.clock_out_at is null and new.status='open' then
   boundary:=coalesce(new.last_punch_at,o.arrival_at);
   resumed:=false;
   if o.route='end_break' and o.actor_id=new.profile_id then resumed:=public._work_activity_resume(s,new,boundary);end if;
   update public.personal_activity_state set resume_token=null,resume_source_kind=null,resume_source_id=null,resume_definition_version_id=null,
    resume_shift_id=null,resume_from_revision=null,resume_after_break_transition_id=null,resume_authority_revision=null,
    choice_required=not resumed where profile_id=new.profile_id;
   delete from public.work_cross_job_resume where profile_id=new.profile_id;
   return new;
 else return new;end if;
 -- A historical correction to another shift cannot end today's timer.
 if s.shift_id is distinct from new.id then return new;end if;
 saved:=cause='break_start' and s.integrity_state='clean' and s.active_source_id is not null and s.revision<9007199254740991
   and s.effective_since is not null and s.effective_since<=boundary
   and not exists(select 1 from public.work_activity_safety_events where profile_id=new.profile_id);
 perform public._work_activity_close_all(new.profile_id,boundary,cause);
 if saved then saved:=public._work_cross_job_save(s,new.id,boundary,person.transition_id);
 else delete from public.work_cross_job_resume where profile_id=new.profile_id;end if;
 update public.personal_activity_state set active_source_kind=null,active_source_id=null,active_definition_version_id=null,effective_since=null,
  resume_token=case when saved then gen_random_uuid() end,resume_source_kind=case when saved then s.active_source_kind end,
  resume_source_id=case when saved then s.active_source_id end,resume_definition_version_id=case when saved then s.active_definition_version_id end,
  resume_shift_id=case when saved then new.id end,resume_from_revision=case when saved then s.revision end,
  resume_after_break_transition_id=case when saved then person.transition_id end,
  resume_authority_revision=case when saved then public._work_activity_authority_revision() end,choice_required=false where profile_id=new.profile_id;
 return new;
end; $$;

create or replace function public._work_activity_resume(p_state public.personal_activity_state,p_shift public.time_shifts,p_at timestamptz) returns boolean
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare view_state public.personal_activity_state; r jsonb; table_name text; prior_meta public.work_session_capture_metadata;
 intent jsonb; new_id uuid; frame uuid; config_enabled boolean; source_basis jsonb; changes jsonb; columns text[]; before_values jsonb; after_values jsonb; paused_total numeric; allocation uuid; closure uuid; version2 boolean;
begin
 if p_state.profile_id is distinct from auth.uid() or not public._work_config_internal(p_state.profile_id)
   or p_state.resume_token is null or p_state.resume_shift_id is distinct from p_shift.id
   or p_state.resume_after_break_transition_id is distinct from p_state.last_transition_id
   or p_state.resume_authority_revision is distinct from public._work_activity_authority_revision()
   or p_state.resume_authority_revision>=9007199254740991 or p_shift.status<>'open' or p_shift.clock_out_at is not null or p_shift.break_started_at is not null
   or exists(select 1 from public.work_activity_safety_events where profile_id=p_state.profile_id)
   or exists(select 1 from public._work_activity_live_sources(p_state.profile_id)) then return false;end if;
 if not pg_try_advisory_xact_lock(7710,0) then return false;end if;
 if not public._work_cross_job_resume_basis(p_state,p_shift,p_at) then return false;end if;
 version2:=exists(select 1 from public.work_cross_job_shifts where shift_id=p_shift.id);
 select allocation_id,closure_history_id into allocation,closure from public.work_cross_job_resume where profile_id=p_state.profile_id;
 -- Recheck after any domain-lock acquisition. G excludes installed writers;
 -- the check remains explicit so a future adapter cannot rely on old state.
 if p_state.resume_authority_revision is distinct from public._work_activity_authority_revision() then return false;end if;
 view_state:=p_state;view_state.active_source_kind:=p_state.resume_source_kind;view_state.active_source_id:=p_state.resume_source_id;
 view_state.active_definition_version_id:=p_state.resume_definition_version_id;view_state.effective_since:=p_at;
 if public._work_activity_source_view(view_state)->>'visibility' is distinct from 'available' then return false;end if;
 table_name:=case p_state.resume_source_kind when 'custom' then 'custom_work_sessions' when 'unit' then 'unit_sessions' when 'task' then 'task_sessions'
   when 'service' then 'service_time_sessions' when 'phase' then 'opening_phases' when 'setup' then 'work_setup_sessions' end;
 execute format('select to_jsonb(s) from public.%I s where id=$1 for update',table_name) into r using p_state.resume_source_id;
 if p_state.resume_source_kind<>'phase' and ((r->>'ended_at')::timestamptz is null or (r->>'ended_at')::timestamptz>p_at) then return false;end if;
 if p_state.resume_source_kind='setup' then
   if r->>'end_reason'<>'break' then return false;end if;
   select capture_enabled into config_enabled from public.work_activity_authority_generation where singleton;
   if not config_enabled then return false;end if;
   new_id:=public._work_activity_start_setup(p_shift,(r->>'clock_client_id')::uuid,p_state.resume_source_id);
   return new_id is not null;
 end if;
 -- A toolbox refusal is an eligibility outcome for auto-resume. Do not turn
 -- an expired signature into a failed paid break return.
 if p_state.resume_source_kind='custom' and r->>'unit_id' is null then perform public._prep_time_gate(p_state.profile_id);
 else perform public._unit_work_gate(p_state.profile_id);end if;
 if p_state.resume_source_kind in ('unit','task','phase') and not exists(
   select 1 from public.project_openings where id=(r->>'opening_id')::uuid and removed_at is null and status<>'installed' and public._ai_job_visible(project_id,p_state.profile_id)) then return false;end if;
 if p_state.resume_source_kind='custom' then
   if r->>'end_reason'<>'break' or exists(select 1 from public.custom_work_units where id=(r->>'unit_id')::uuid and facts->>'installation_complete'='Yes') then return false;end if;
   select * into prior_meta from public.work_session_capture_metadata where session_id=p_state.resume_source_id;
   if prior_meta.session_id is not null then
     select capture_enabled into config_enabled from public.work_activity_authority_generation where singleton;
     if not config_enabled then return false;end if;
     intent:=jsonb_build_object('kind','switch','projectId',prior_meta.project_id,'selectionId',prior_meta.selection_id,'selectionRevision',prior_meta.selection_revision,
      'menuVersionId',prior_meta.menu_version_id,'definitionVersionId',prior_meta.definition_version_id,'scope',prior_meta.scope,
      'unit',prior_meta.continuation_unit_basis,'machineKind',prior_meta.machine_kind,'values',prior_meta.answers);
     if public._work_activity_validate_switch(intent,p_state.profile_id) is not null then return false;end if;
   end if;
   if version2 then
    if prior_meta.session_id is null then return false;end if;
    new_id:=public._work_cross_job_custom(p_state.profile_id,p_shift,allocation,intent,p_at,'break_end',closure);
   else
   frame:=public._work_activity_context_for(p_state.profile_id,'break_end',p_at);
   new_id:=gen_random_uuid();
   perform public.custom_work_command(gen_random_uuid(),'start',jsonb_build_object('id',new_id,'shift_id',p_shift.id,'unit_id',r->'unit_id',
    'expected_session_id',null,'at',p_at,'participation',r->'participation','stage',r->'stage','description',r->'description'));
   perform public._work_activity_context_close(frame);
   if prior_meta.session_id is not null then
     source_basis:=case when prior_meta.unit_id is not null then public._work_activity_command_basis(public._work_activity_unit_basis(prior_meta.unit_id,p_state.profile_id)) end;
     insert into public.work_session_capture_metadata(session_id,profile_id,project_id,definition_version_id,menu_version_id,scope,unit_id,fact_revision,unit_facts,machine_kind,
       selection_id,selection_revision,answers,unit_basis,continuation_unit_basis)
     values(new_id,p_state.profile_id,prior_meta.project_id,prior_meta.definition_version_id,prior_meta.menu_version_id,prior_meta.scope,prior_meta.unit_id,
       prior_meta.fact_revision,prior_meta.unit_facts,prior_meta.machine_kind,prior_meta.selection_id,prior_meta.selection_revision,prior_meta.answers,
       prior_meta.continuation_unit_basis,source_basis);
   end if;
   end if;
 elsif version2 then
   new_id:=public._work_cross_job_source(p_state.profile_id,p_shift,allocation,p_state.resume_source_kind,r,p_at,'break_end',closure);
 elsif p_state.resume_source_kind='unit' then
   -- Old helper intervals lack an exact summon foreign key. Never infer a
   -- continuation from another helper's or yesterday's similarly named call.
   if r->>'end_reason'<>'break' or r->>'role'='helper' then return false;end if;
   new_id:=public._work_activity_insert_source(p_state.profile_id,'unit',jsonb_build_object('id',gen_random_uuid(),'profile_id',p_state.profile_id,
     'opening_id',r->'opening_id','role',r->'role','is_rework',public._has_open_redo((r->>'opening_id')::uuid),'started_at',p_at),p_at,'break_end');
 elsif p_state.resume_source_kind='task' then
   if r->>'state'<>'on_task' then return false;end if;
   new_id:=public._work_activity_insert_source(p_state.profile_id,'task',jsonb_build_object('id',gen_random_uuid(),'profile_id',p_state.profile_id,
     'opening_id',r->'opening_id','project_id',r->'project_id','state','on_task','started_at',p_at),p_at,'break_end');
 elsif p_state.resume_source_kind='service' then
   if r->>'end_reason'<>'break' or not exists(select 1 from public.service_visits where id=(r->>'visit_id')::uuid and status='active') then return false;end if;
   new_id:=public._work_activity_insert_source(p_state.profile_id,'service',jsonb_build_object('id',gen_random_uuid(),'profile_id',p_state.profile_id,
    'visit_id',r->'visit_id','project_id',r->'project_id','unit_id',r->'unit_id','shift_id',p_shift.id,'kind',r->'kind','stage',r->'stage','description',r->'description','started_at',p_at),p_at,'break_end');
 elsif p_state.resume_source_kind='phase' then
   if r->>'status'<>'active' or r->>'paused_at' is null or (r->>'paused_at')::timestamptz>p_at then return false;end if;
   -- A corrupt/exhausted activity duration must never reject paid break return.
   -- Compute before the integer cast so the eligibility path is deterministic.
   paused_total:=(r->>'paused_seconds')::numeric+greatest(0,round(extract(epoch from p_at-(r->>'paused_at')::timestamptz)));
   if paused_total is null or paused_total<0 or paused_total>2147483647 then return false;end if;
   changes:=jsonb_build_object('paused_at',null,'paused_seconds',paused_total::integer);
   frame:=public._work_activity_context_for(p_state.profile_id,'break_end',p_at);
   columns:=array['paused_at','paused_seconds'];
   select jsonb_object_agg(key,value) into before_values from jsonb_each(r) where key=any(columns||array['id','started_by']);after_values:=before_values||changes;
   perform public._work_activity_expect(frame,'public.opening_phases'::regclass,'UPDATE',p_state.resume_source_id,columns,before_values,after_values);
   update public.opening_phases set paused_at=null,paused_seconds=(changes->>'paused_seconds')::integer where id=p_state.resume_source_id;
   perform public._work_activity_context_close(frame);new_id:=p_state.resume_source_id;
 end if;
 return new_id is not null;
exception when raise_exception or check_violation or foreign_key_violation or unique_violation or insufficient_privilege or numeric_value_out_of_range then
 -- This subtransaction rolls back a partially constructed resume, including
 -- all private frames/events. The outer paid break return stays successful.
 return false;
end; $$;

create or replace function public.clock_in(
 p_project_id uuid,p_cost_code_id uuid,p_photo text,p_lat double precision,p_lng double precision,
 p_note text,p_mode text,p_client_id uuid,p_tapped_at timestamptz,p_clock_checked_at timestamptz,p_clock_skew_ms integer,p_setup_version integer
) returns public.time_shifts language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare actor uuid;operation uuid;h public.time_shifts;prior boolean;enabled boolean;digest text;
begin
 perform public._work_activity_read_committed();
 perform public._work_activity_gate();actor:=public._work_activity_actor();
 if p_setup_version not in(1,2) or p_setup_version is null or (p_setup_version=2 and (not public._work_cross_job_enabled() or not (coalesce((select p.prosrc is not null and encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='b678eca76a31edbf88408302379013b762eea5b2f50d4bdd3a8ebebc55e2f3ea' and pg_get_userbyid(p.proowner)='postgres' and p.proacl::text='{postgres=X/postgres}' and p.prosecdef and p.proconfig=array['search_path=public, pg_temp']::text[] and p.provolatile='s' and not p.proisstrict and not p.proleakproof and p.proparallel='u' and p.prokind='f' and not p.proretset and p.prorettype='boolean'::regtype and p.pronargs=0 and p.pronargdefaults=0 and p.procost=100 and p.prorows=0 and p.prosupport=0 and p.prolang=(select oid from pg_language where lanname='plpgsql') from pg_proc p where p.oid=to_regprocedure('public._work_cross_job_coverage()')),false) and public._work_cross_job_coverage()))) then raise exception using errcode='23514',message='Unsupported paid setup protocol.';end if;
 if p_project_id is not null and not public._ai_job_visible(p_project_id,actor) then raise exception using errcode='42501',message='The clock source is unavailable.';end if;
 if p_client_id is null or p_tapped_at is null or not isfinite(p_tapped_at) or (p_clock_checked_at is not null and not isfinite(p_clock_checked_at)) then
   raise exception using errcode='23514',message='Paid setup requires its original keyed clock stamp.';end if;
 digest:=public._work_activity_clock_setup_digest(p_project_id,p_cost_code_id,p_photo,p_lat,p_lng,p_note,p_mode,p_client_id,p_tapped_at,p_clock_checked_at,p_clock_skew_ms);
 operation:=public._work_activity_operation_enter('clock_in_setup',jsonb_build_object('setupVersion',p_setup_version,'clockPayloadDigest',digest),p_client_id);
 if operation is null then raise exception using errcode='23514',message='Paid setup requires its original clock root.';end if;
 perform public._work_activity_clock_replay_guard(p_client_id,'clock_in');
 prior:=exists(select 1 from public.time_clock_actions where client_id=p_client_id and profile_id=actor)
   or exists(select 1 from public.time_shifts where client_id=p_client_id and profile_id=actor);
 h:=public.clock_in(p_project_id,p_cost_code_id,p_photo,p_lat,p_lng,p_note,p_mode,p_client_id,p_tapped_at,p_clock_checked_at,p_clock_skew_ms);
 select capture_enabled into enabled from public.work_activity_authority_generation where singleton;
 if not prior and enabled and h.profile_id=actor and h.status='open' and h.clock_out_at is null and h.break_started_at is null
  -- A reviewed/fallback payroll arrival remains paid under the original route,
  -- but cannot resurrect automatic capture from an untrusted/delayed tap.
  and exists(select 1 from public.time_clock_actions where client_id=p_client_id and profile_id=actor and shift_id=h.id and action='clock_in' and outcome='clocked_in' and used_tap_time and review_reason is null) then
   if p_setup_version=2 then perform public._work_cross_job_register(h,p_client_id);end if;
   perform public._work_activity_start_setup(h,p_client_id);
 end if;
 perform public._work_activity_operation_exit(operation);
 return h;
end; $$;

create or replace function public._work_activity_claim_clock_setup(p_project_id uuid,p_cost_code_id uuid,p_photo text,p_lat double precision,p_lng double precision,
 p_note text,p_mode text,p_client_id uuid,p_tapped_at timestamptz,p_clock_checked_at timestamptz,p_clock_skew_ms integer) returns boolean
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare o public.work_activity_operations;actor uuid;enabled boolean;generation bigint;s public.personal_activity_state;
begin
 o:=public._work_activity_operation();
 -- All retained direct overloads keep their original admission policy.
 if o.id is null or o.route is distinct from 'clock_in_setup' then return false;end if;
 actor:=auth.uid();
 if actor is null or not public._work_config_internal(actor)
  or o.actor_id is distinct from actor or o.top_xid is distinct from pg_current_xact_id() or o.backend_pid is distinct from pg_backend_pid()
  or p_client_id is null or o.request_id is distinct from p_client_id or o.command_id is not null or o.clock_entry_claimed
  or coalesce(o.arguments->>'setupVersion','') not in('1','2') or (o.arguments->>'setupVersion'='2' and (not public._work_cross_job_enabled() or not (coalesce((select p.prosrc is not null and encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='b678eca76a31edbf88408302379013b762eea5b2f50d4bdd3a8ebebc55e2f3ea' and pg_get_userbyid(p.proowner)='postgres' and p.proacl::text='{postgres=X/postgres}' and p.prosecdef and p.proconfig=array['search_path=public, pg_temp']::text[] and p.provolatile='s' and not p.proisstrict and not p.proleakproof and p.proparallel='u' and p.prokind='f' and not p.proretset and p.prorettype='boolean'::regtype and p.pronargs=0 and p.pronargdefaults=0 and p.procost=100 and p.prorows=0 and p.prosupport=0 and p.prolang=(select oid from pg_language where lanname='plpgsql') from pg_proc p where p.oid=to_regprocedure('public._work_cross_job_coverage()')),false) and public._work_cross_job_coverage())))
  or o.arguments is distinct from jsonb_build_object('setupVersion',(o.arguments->>'setupVersion')::integer,'clockPayloadDigest',public._work_activity_clock_setup_digest(p_project_id,p_cost_code_id,p_photo,p_lat,p_lng,p_note,p_mode,p_client_id,p_tapped_at,p_clock_checked_at,p_clock_skew_ms)) then
   raise exception using errcode='42501',message='Paid setup does not match its original clock entry.';
 end if;
 -- An ordinary caller cannot create this private row, consume this helper,
 -- or relabel a different root. Replays return before reaching this claim.
 update public.work_activity_operations set clock_entry_claimed=true where id=o.id;
 select capture_enabled,revision into enabled,generation from public.work_activity_authority_generation where singleton;
 select * into s from public.personal_activity_state where profile_id=actor;
 -- Closing-only retains existing payroll/replay policy, but cannot grant a
 -- NEW unsigned-start exemption. No setup counter/state is initialized here.
 return coalesce(enabled,false) and generation<9007199254740991
  and (s.profile_id is null or (s.integrity_state='clean' and s.revision<9007199254740991))
  and not exists(select 1 from public.work_activity_safety_events where profile_id=actor);
end; $$;

create or replace function public.work_activity_command(p_command_id uuid,p_protocol_version integer,p_payload jsonb) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare actor uuid; payload jsonb; hash text; prior public.personal_activity_commands; head public.personal_activity_commands;
 s public.personal_activity_state; after_s public.personal_activity_state; h public.time_shifts; obs public.work_activity_observations;
 stream public.work_activity_streams; anchor public.work_activity_observations; clock_action public.time_clock_actions;
 clock_transition public.personal_activity_transitions; definition public.work_activity_definition_versions;
 device uuid; generation uuid; expected bigint; sequence_number bigint; predecessor uuid; kind text; intent jsonb;
 v_status text:='noop'; reason text; source_reason text; result jsonb; arrival timestamptz; selected_at timestamptz;
 pick public.clock_time_pick; not_before timestamptz; operation uuid; frame uuid; nested_request uuid; session_id uuid; person public.work_activity_operation_people;
 enabled boolean; admitted boolean:=false; clock_bridge boolean:=false; observation_lineage boolean:=false; unit_basis jsonb; before_shift jsonb; after_shift jsonb; prior_allocation uuid; allocation uuid; cross_job boolean:=false;
begin
 perform public._work_activity_read_committed();
 perform public._work_activity_gate();
 actor:=public._work_activity_actor();
 if p_command_id is null or (p_protocol_version not in(1,2) or p_protocol_version is null) then raise exception using errcode='23514',message='Invalid activity protocol or command identity.';end if;
 if p_protocol_version=2 then
  if not public._work_cross_job_enabled() or not (coalesce((select p.prosrc is not null and encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='b678eca76a31edbf88408302379013b762eea5b2f50d4bdd3a8ebebc55e2f3ea' and pg_get_userbyid(p.proowner)='postgres' and p.proacl::text='{postgres=X/postgres}' and p.prosecdef and p.proconfig=array['search_path=public, pg_temp']::text[] and p.provolatile='s' and not p.proisstrict and not p.proleakproof and p.proparallel='u' and p.prokind='f' and not p.proretset and p.prorettype='boolean'::regtype and p.pronargs=0 and p.pronargdefaults=0 and p.procost=100 and p.prorows=0 and p.prosupport=0 and p.prolang=(select oid from pg_language where lanname='plpgsql') from pg_proc p where p.oid=to_regprocedure('public._work_cross_job_coverage()')),false) and public._work_cross_job_coverage()) then return jsonb_build_object('protocolVersion',2,'availability','unavailable','receipt',null);end if;
  perform public._work_activity_object(p_payload,array['deviceId','clientGeneration','clientSequence','predecessorCommandId','expectedRevision','basis','shiftRef','tappedAt','clockCheckedAt','clockSkewMs','intent','expectedAllocationId','boundaryMode']);
  prior_allocation:=public._work_activity_uuid(p_payload->'expectedAllocationId',true);
  if p_payload->>'boundaryMode' is distinct from 'trusted_original_tap' then raise exception using errcode='23514',message='Unsupported boundary mode.';end if;
  payload:=public._work_activity_payload(p_payload-'expectedAllocationId'-'boundaryMode')||jsonb_build_object('expectedAllocationId',prior_allocation,'boundaryMode','trusted_original_tap');
 else payload:=public._work_activity_payload(p_payload);end if;hash:=encode(sha256(convert_to(payload::text,'UTF8')),'hex');
 select * into prior from public.personal_activity_commands where command_id=p_command_id;
 if prior.command_id is not null then
   if prior.actor_id is distinct from actor or prior.subject_profile_id is distinct from actor or prior.protocol_version is distinct from p_protocol_version
    or prior.payload_hash is distinct from hash or prior.normalized_payload is distinct from payload then
     return jsonb_build_object('protocolVersion',p_protocol_version,'availability','unavailable','receipt',null);
   end if;
   if p_protocol_version=2 and not public._work_cross_job_scope((prior.normalized_payload#>>'{shiftRef,id}')::uuid,actor) then return jsonb_build_object('protocolVersion',2,'availability','unavailable','receipt',null);end if;
   return jsonb_build_object('protocolVersion',p_protocol_version,'availability','available','receipt',prior.result);
 end if;
 -- G is first. Configuration/source authority is read again after its domain
 -- lock; no before-wait account or menu decision is reused.
 perform pg_advisory_xact_lock(7710,0);actor:=public._work_activity_actor();arrival:=clock_timestamp();
 device:=(payload->>'deviceId')::uuid;generation:=(payload->>'clientGeneration')::uuid;
 expected:=(payload->>'expectedRevision')::bigint;sequence_number:=(payload->>'clientSequence')::bigint;
 predecessor:=(payload->>'predecessorCommandId')::uuid;intent:=payload->'intent';kind:=intent->>'kind';
 if exists(select 1 from public.personal_activity_commands where actor_id=actor and device_id=device and client_generation=generation and client_sequence=sequence_number) then
   return jsonb_build_object('protocolVersion',p_protocol_version,'availability','unavailable','receipt',null);
 end if;
 select * into s from public.personal_activity_state where profile_id=actor for update;
 if s.profile_id is null then s:=public._work_activity_refresh_state(actor);end if;
 cross_job:=exists(select 1 from public.work_cross_job_shifts where shift_id=s.shift_id);
 if cross_job is distinct from (p_protocol_version=2) then return jsonb_build_object('protocolVersion',p_protocol_version,'availability','unavailable','receipt',null);end if;
 if cross_job and not public._work_cross_job_scope(s.shift_id,actor) then return jsonb_build_object('protocolVersion',2,'availability','unavailable','receipt',null);end if;
 select allocation_id into allocation from public.work_cross_job_heads where shift_id=s.shift_id;
 select * into obs from public.work_activity_observations where id=(payload#>>'{basis,observationId}')::uuid and actor_id=actor and device_id=device;
 select * into stream from public.work_activity_streams where actor_id=actor and device_id=device and status in ('active','blocked') for update;
 select capture_enabled into enabled from public.work_activity_authority_generation where singleton;
 -- Permission comes before any referenced source's eligibility/revision reason.
 if kind='switch' then source_reason:=public._work_activity_validate_switch(intent,actor);
 elsif kind='finish_setup' and not public._ai_job_visible((intent->>'projectId')::uuid,actor) then source_reason:='source_unavailable';end if;
 if source_reason='source_unavailable' then v_status:='refused';reason:=source_reason;
 elsif s.integrity_state<>'clean' or s.revision>=9007199254740991 or exists(select 1 from public.work_activity_safety_events where profile_id=actor) then
   v_status:='refused';reason:='reconciliation_required';
 elsif obs.id is null then v_status:='refused';reason:='observation_unavailable';
 elsif kind<>'stop' and obs.expires_at<=arrival then v_status:='refused';reason:='observation_expired';
 elsif kind<>'stop' and (obs.authority_revision is distinct from public._work_activity_authority_revision() or obs.authority_revision>=9007199254740991) then
   v_status:='conflict';reason:='state_changed';
 elsif s.revision<>expected then v_status:='conflict';reason:='state_changed';end if;
 if cross_job and allocation is distinct from prior_allocation and reason is null then v_status:='conflict';reason:='state_changed';end if;
 if kind='establish_stream' then
   if reason is null and (obs.revision<>expected or obs.last_transition_id is distinct from s.last_transition_id
     or obs.shift_id is distinct from s.shift_id or obs.shift_id is distinct from (payload#>>'{shiftRef,id}')::uuid) then
     v_status:='conflict';reason:='state_changed';
   elsif reason is null and (stream.client_generation is distinct from (intent->>'previousGeneration')::uuid
     or stream.head_command_id is distinct from (intent->>'previousHeadCommandId')::uuid
     or obs.current_generation is distinct from (intent->>'previousGeneration')::uuid
     or obs.current_head_command_id is distinct from (intent->>'previousHeadCommandId')::uuid
     or exists(select 1 from public.work_activity_streams where actor_id=actor and device_id=device and client_generation=generation)) then
     v_status:='conflict';reason:='stream_changed';
   end if;
 else
   select * into head from public.personal_activity_commands where command_id=predecessor and actor_id=actor and device_id=device and client_generation=generation;
   admitted:=stream.id is not null and stream.status='active' and stream.client_generation=generation and stream.head_sequence<9007199254740991
     and sequence_number=stream.head_sequence+1 and predecessor=stream.head_command_id and head.status in ('applied','noop');
   if reason is null and not admitted then v_status:='conflict';reason:='stream_changed';end if;
   if payload#>>'{shiftRef,kind}'='clock_command' then
     select * into clock_action from public.time_clock_actions where client_id=(payload#>>'{shiftRef,id}')::uuid and profile_id=actor and action='clock_in';
     select * into h from public.time_shifts where id=clock_action.shift_id and profile_id=actor for update;
     select * into clock_transition from public.personal_activity_transitions where id=s.last_transition_id and profile_id=actor
      and cause='clock_in' and source_request_id=clock_action.client_id and source_shift_id=h.id;
     clock_bridge:=obs.shift_id is null and obs.revision=head.after_revision and obs.last_transition_id is not distinct from
       (select id from public.personal_activity_transitions where profile_id=actor and revision_after=obs.revision)
       and clock_transition.revision_before=obs.revision and clock_transition.revision_after=expected
       and clock_transition.id is not null and head.after_revision+1=expected;
   else select * into h from public.time_shifts where id=(payload#>>'{shiftRef,id}')::uuid and profile_id=actor for update;end if;
   if reason is null and (h.id is null or h.id is distinct from s.shift_id or h.status<>'open' or h.clock_out_at is not null) then v_status:='refused';reason:='shift_unavailable';end if;
   if reason is null and h.break_started_at is not null then v_status:='refused';reason:='on_break';end if;
   if reason is null and head.after_revision<>expected and not coalesce(clock_bridge,false) then v_status:='conflict';reason:='state_changed';end if;
   if stream.id is not null then select * into anchor from public.work_activity_observations where id=stream.anchor_observation_id;end if;
   observation_lineage:=obs.id=stream.anchor_observation_id or (obs.current_generation=generation and exists(
     select 1 from public.personal_activity_commands c where c.command_id=obs.current_head_command_id and c.actor_id=actor and c.device_id=device
       and c.client_generation=generation and c.client_sequence<=head.client_sequence and c.status in ('applied','noop') and c.after_revision=obs.revision));
   if reason is null and (not coalesce(observation_lineage,false) or obs.revision>expected or obs.revision<anchor.revision
     or (not coalesce(clock_bridge,false) and (obs.shift_id is distinct from h.id or obs.shift_clock_in_at is distinct from h.clock_in_at))) then
     v_status:='conflict';reason:='state_changed';end if;
   if reason is null and kind<>'stop' and (not enabled or h.clock_in_at+make_interval(hours=>public.shift_cap_hours())<=arrival) then
     v_status:='refused';reason:=case when not enabled then 'starts_disabled' else 'observation_expired' end;end if;
   if reason is null and source_reason is not null then v_status:='conflict';reason:=source_reason;end if;
   if reason is null and kind='switch' and ((not cross_job and (intent->>'projectId')::uuid is distinct from h.project_id) or s.active_source_kind='setup') then
     v_status:='refused';reason:='shift_unavailable';end if;
   if reason is null and kind='finish_setup' then
     if s.active_source_kind is distinct from 'setup' then v_status:='conflict';reason:='state_changed';
     elsif intent->>'costCodeId' is not null and not exists(select 1 from public.cost_codes where id=(intent->>'costCodeId')::uuid) then
       v_status:='refused';reason:='source_unavailable';end if;
   end if;
   if reason is null and kind in ('switch','finish_setup') and not public._toolbox_signed_today(actor) then v_status:='refused';reason:='toolbox_required';end if;
   if reason is null then
     select greatest(h.clock_in_at,h.last_punch_at,s.effective_since,(select selected_effective_at from public.personal_activity_transitions where id=s.last_transition_id),(select effective_at from public.work_cross_job_allocations where id=allocation)) into not_before;
     pick:=public._clock_pick_time_at((payload->>'tappedAt')::timestamptz,(payload->>'clockCheckedAt')::timestamptz,(payload->>'clockSkewMs')::integer,not_before,arrival);
     if pick.pay_at is null or pick.reason in ('tap_out_of_order','tap_too_old') or (cross_job and not pick.used_tap) then v_status:='refused';reason:='time_out_of_order';else selected_at:=pick.pay_at;end if;
   end if;
   if reason is null and not(kind='stop' and s.active_source_id is null) then
     -- Only the expected legacy business refusal is converted. Integrity,
     -- schema, timeout and deadlock exceptions roll back the entire command.
     begin
       nested_request:=case when kind='switch' then gen_random_uuid() end;
       operation:=public._work_activity_operation_enter('work_activity_command',jsonb_build_object('kind',kind),nested_request,p_command_id);
       if operation is null then raise exception using errcode='23514',message='Activity command cannot nest in another source operation.';end if;
       person:=public._work_activity_touch(actor);
       perform public._work_activity_close_all(actor,selected_at,case when kind='switch' then 'switch' else 'stop' end);
       if cross_job and kind in('switch','finish_setup') then
        allocation:=p_command_id;
        insert into public.work_cross_job_allocations(id,shift_id,profile_id,predecessor_id,event_kind,project_id,cost_code_id,original_tapped_at,clock_checked_at,clock_skew_ms,admitted_at,effective_at,boundary_mode,command_id,transition_id,authority_revision,source_generation)
        values(allocation,h.id,actor,prior_allocation,case when prior_allocation is null then 'initial' else 'handoff' end,(intent->>'projectId')::uuid,case when kind='finish_setup' then (intent->>'costCodeId')::uuid end,
        (payload->>'tappedAt')::timestamptz,(payload->>'clockCheckedAt')::timestamptz,(payload->>'clockSkewMs')::integer,arrival,selected_at,'trusted_original_tap',p_command_id,person.transition_id,public._work_activity_authority_revision(),2);
        insert into public.work_cross_job_heads values(h.id,allocation) on conflict(shift_id) do update set allocation_id=excluded.allocation_id;
       end if;
       if kind='switch' and cross_job then
        session_id:=public._work_cross_job_custom(actor,h,allocation,intent,selected_at,'switch');
       elsif kind='switch' then
         select * into definition from public.work_activity_definition_versions where id=(intent->>'definitionVersionId')::uuid;
         session_id:=gen_random_uuid();frame:=public._work_activity_context_for(actor,'switch',selected_at);
         -- Classic's stage is a bounded display projection (100 characters).
         -- Preserve the complete published label in description and the exact
         -- immutable definition version in private metadata; identity never
         -- depends on this shortened legacy display.
         perform public.custom_work_command(nested_request,'start',jsonb_build_object('id',session_id,'shift_id',h.id,'unit_id',intent#>'{unit,id}',
           'expected_session_id',null,'at',selected_at,'participation','install','stage',left(definition.label_en,100),'description',definition.label_en));
         perform public._work_activity_context_close(frame);
         if intent->>'scope'='specific' then unit_basis:=public._work_activity_command_basis(public._work_activity_unit_basis((intent#>>'{unit,id}')::uuid,actor));end if;
         insert into public.work_session_capture_metadata(session_id,profile_id,project_id,definition_version_id,menu_version_id,scope,unit_id,fact_revision,unit_facts,machine_kind,
           selection_id,selection_revision,answers,unit_basis,continuation_unit_basis)
         values(session_id,actor,(intent->>'projectId')::uuid,definition.id,(intent->>'menuVersionId')::uuid,intent->>'scope',(intent#>>'{unit,id}')::uuid,
           (intent#>>'{unit,factRevision}')::bigint,case when intent->>'scope'='specific' then public._work_activity_fact_snapshot((intent#>>'{unit,id}')::uuid) end,
           intent->>'machineKind',(intent->>'selectionId')::uuid,(intent->>'selectionRevision')::bigint,intent->'values',nullif(intent->'unit','null'::jsonb),unit_basis);
       elsif kind='finish_setup' and not cross_job then
         before_shift:=public._work_activity_evidence('time_shifts',to_jsonb(h));
         after_shift:=before_shift||jsonb_build_object('project_id',intent->'projectId','cost_code_id',intent->'costCodeId');
         frame:=public._work_activity_context_for(actor,'stop',selected_at);
         perform public._work_activity_expect(frame,'public.time_shifts'::regclass,'UPDATE',h.id,array['project_id','cost_code_id'],before_shift,after_shift);
         update public.time_shifts set project_id=(intent->>'projectId')::uuid,cost_code_id=(intent->>'costCodeId')::uuid where id=h.id;
         perform public._work_activity_context_close(frame);
       end if;
       perform public._work_activity_operation_exit(operation);
       select * into after_s from public.personal_activity_state where profile_id=actor;
       if after_s.revision is distinct from s.revision+1 or after_s.last_transition_id is distinct from person.transition_id then
         raise exception using errcode='23514',message='Activity command lacks its one actual transition.';end if;
       v_status:='applied';
     exception when raise_exception then v_status:='refused';reason:='reconciliation_required';selected_at:=null;person.transition_id:=null;
     end;
   end if;
 end if;
 result:=jsonb_build_object('protocolVersion',p_protocol_version,'commandId',p_command_id,'status',v_status,'reasonCode',reason,
   'beforeRevision',s.revision,'afterRevision',case when v_status='applied' then after_s.revision else s.revision end,
   'transitionId',case when v_status='applied' then person.transition_id end,'effectiveAt',case when v_status='applied' then public._work_activity_iso(selected_at) end);
 insert into public.personal_activity_commands(command_id,actor_id,subject_profile_id,protocol_version,normalized_payload,payload_hash,received_at,
   device_id,client_generation,client_sequence,predecessor_command_id,expected_revision,status,reason_code,before_revision,after_revision,transition_id,effective_at,result)
 values(p_command_id,actor,actor,p_protocol_version,payload,hash,arrival,device,generation,sequence_number,predecessor,expected,v_status,reason,s.revision,
   case when v_status='applied' then after_s.revision else s.revision end,case when v_status='applied' then person.transition_id end,case when v_status='applied' then selected_at end,result);
 if kind='establish_stream' and v_status='noop' then
   if stream.id is not null then update public.work_activity_streams set status='retired',retired_at=clock_timestamp() where id=stream.id;end if;
   insert into public.work_activity_streams(actor_id,device_id,client_generation,head_sequence,head_command_id,anchor_observation_id,status)
   values(actor,device,generation,0,p_command_id,obs.id,'active');
 elsif kind<>'establish_stream' and admitted then
   update public.work_activity_streams set head_command_id=p_command_id,head_sequence=sequence_number,status=case when v_status in ('applied','noop') then 'active' else 'blocked' end where id=stream.id;
 end if;
 return jsonb_build_object('protocolVersion',p_protocol_version,'availability','available','receipt',result);
end; $$;

create or replace function public.work_activity_snapshot(p_device_id uuid) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare actor uuid; s public.personal_activity_state; h public.time_shifts; stream public.work_activity_streams; observation public.work_activity_observations;
 result jsonb; state_view jsonb; stream_view jsonb; observation_view jsonb; shift_view jsonb; enabled boolean; ready boolean; personal_status text; state_actions jsonb; as_of timestamptz;
begin
 perform public._work_activity_read_committed();
 perform public._work_activity_gate();actor:=public._work_activity_actor();
 if p_device_id is null then raise exception using errcode='23514',message='A device identity is required.';end if;
 perform pg_advisory_xact_lock(7710,0);actor:=public._work_activity_actor();as_of:=clock_timestamp();
 if exists(select 1 from public.work_activity_safety_events where profile_id=actor) then
   return jsonb_build_object('protocolVersion',1,'asOf',public._work_activity_iso(as_of),'deviceId',p_device_id,
     'capability',jsonb_build_object('mode','unavailable','reasonCode','not_ready'),'observation',null,'stream',null,'state',null);
 end if;
 select capture_enabled into enabled from public.work_activity_authority_generation where singleton;
 select * into s from public.personal_activity_state where profile_id=actor;
 if s.profile_id is null then s:=public._work_activity_refresh_state(actor);end if;
 select * into h from public.time_shifts where id=s.shift_id and profile_id=actor and status='open' and clock_out_at is null;
 ready:=s.integrity_state='clean' and s.revision<9007199254740991 and ((s.shift_id is null and not exists(select 1 from public._work_activity_live_sources(actor)))
   or (h.id is not null and isfinite(h.clock_in_at) and h.clock_in_at<=as_of and h.clock_in_at+make_interval(hours=>public.shift_cap_hours())>as_of));
 if ready then observation:=public._work_activity_observe(p_device_id);end if;
 select * into stream from public.work_activity_streams where actor_id=actor and device_id=p_device_id and status in ('active','blocked');
 if stream.id is not null then stream_view:=jsonb_build_object('clientGeneration',stream.client_generation,'headSequence',stream.head_sequence,'headCommandId',stream.head_command_id,
  'headAfterRevision',(select after_revision from public.personal_activity_commands where command_id=stream.head_command_id),'status',stream.status);end if;
 if observation.id is not null then observation_view:=jsonb_build_object('id',observation.id,'revision',observation.revision,'lastTransitionId',observation.last_transition_id,
  'issuedAt',public._work_activity_iso(observation.issued_at),'expiresAt',public._work_activity_iso(observation.expires_at),
  'shiftRef',case when observation.shift_id is not null then jsonb_build_object('kind','shift','id',observation.shift_id) end,
  'currentGeneration',observation.current_generation,'currentHeadCommandId',observation.current_head_command_id);end if;
 if exists(select 1 from public.work_cross_job_shifts where shift_id=h.id) then return jsonb_build_object('protocolVersion',1,'asOf',public._work_activity_iso(as_of),'deviceId',p_device_id,'capability',jsonb_build_object('mode','unavailable','reasonCode','not_ready'),'observation',null,'stream',null,'state',null);end if;
 if h.id is not null then shift_view:=jsonb_build_object('id',h.id,'clockInCommandId',h.client_id,'clockInAt',public._work_activity_iso(h.clock_in_at),
  'breakStartedAt',public._work_activity_iso(h.break_started_at),'breakType',h.break_type,'status','open','project',public._work_activity_project_view(h.project_id,actor));end if;
 personal_status:=case when s.integrity_state<>'clean' then 'review' when h.id is null then 'off_clock' when h.break_started_at is not null then 'on_break'
  when s.active_source_kind='setup' then 'setup' when s.active_source_id is not null then 'running' else 'unclassified' end;
 state_actions:=jsonb_build_object('canEstablishStream',ready,'canSwitch',ready and enabled and h.id is not null and h.break_started_at is null and s.active_source_kind is distinct from 'setup',
  'canFinishSetup',coalesce(ready and enabled and h.id is not null and h.break_started_at is null and s.active_source_kind='setup',false),
  'canStop',ready and h.id is not null and h.break_started_at is null and s.active_source_id is not null);
 state_view:=jsonb_build_object('revision',s.revision,'lastTransitionId',s.last_transition_id,'integrity',s.integrity_state,'status',personal_status,'choiceRequired',s.choice_required,
  'actions',state_actions,'shift',shift_view,'activity',case when h.id is not null and h.break_started_at is null then public._work_activity_source_view(s) end);
 result:=jsonb_build_object('protocolVersion',1,'asOf',public._work_activity_iso(as_of),'deviceId',p_device_id,
  'capability',jsonb_build_object('mode',case when enabled then 'active' else 'closing_only' end,'reasonCode',case when not enabled then 'starts_disabled' end),
  'observation',observation_view,'stream',stream_view,'state',state_view);
 if octet_length(result::text)>100000 then raise exception using errcode='54000',message='Activity projection is too large.';end if;
 return result;
end; $$;

create or replace function public.work_cross_job_snapshot(p_device_id uuid) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare actor uuid; s public.personal_activity_state; h public.time_shifts; stream public.work_activity_streams; observation public.work_activity_observations;
 result jsonb; state_view jsonb; stream_view jsonb; observation_view jsonb; shift_view jsonb; enabled boolean; ready boolean; personal_status text; state_actions jsonb; as_of timestamptz;
begin
 perform public._work_activity_read_committed();
 perform public._work_activity_gate();actor:=public._work_activity_actor();
 if p_device_id is null then raise exception using errcode='23514',message='A device identity is required.';end if;
 perform pg_advisory_xact_lock(7710,0);actor:=public._work_activity_actor();as_of:=clock_timestamp();
 if exists(select 1 from public.work_activity_safety_events where profile_id=actor) then
   return jsonb_build_object('protocolVersion',2,'asOf',public._work_activity_iso(as_of),'deviceId',p_device_id,
     'capability',jsonb_build_object('mode','unavailable','reasonCode','not_ready'),'observation',null,'stream',null,'state',null);
 end if;
 select capture_enabled into enabled from public.work_activity_authority_generation where singleton;
 select * into s from public.personal_activity_state where profile_id=actor;
 if s.profile_id is null then s:=public._work_activity_refresh_state(actor);end if;
 select * into h from public.time_shifts where id=s.shift_id and profile_id=actor and status='open' and clock_out_at is null;
 ready:=s.integrity_state='clean' and s.revision<9007199254740991 and ((s.shift_id is null and not exists(select 1 from public._work_activity_live_sources(actor)))
   or (h.id is not null and isfinite(h.clock_in_at) and h.clock_in_at<=as_of and h.clock_in_at+make_interval(hours=>public.shift_cap_hours())>as_of));
 if ready then observation:=public._work_activity_observe(p_device_id);end if;
 select * into stream from public.work_activity_streams where actor_id=actor and device_id=p_device_id and status in ('active','blocked');
 if stream.id is not null then stream_view:=jsonb_build_object('clientGeneration',stream.client_generation,'headSequence',stream.head_sequence,'headCommandId',stream.head_command_id,
  'headAfterRevision',(select after_revision from public.personal_activity_commands where command_id=stream.head_command_id),'status',stream.status);end if;
 if observation.id is not null then observation_view:=jsonb_build_object('id',observation.id,'revision',observation.revision,'lastTransitionId',observation.last_transition_id,
  'issuedAt',public._work_activity_iso(observation.issued_at),'expiresAt',public._work_activity_iso(observation.expires_at),
  'shiftRef',case when observation.shift_id is not null then jsonb_build_object('kind','shift','id',observation.shift_id) end,
  'currentGeneration',observation.current_generation,'currentHeadCommandId',observation.current_head_command_id);end if;
 if not public._work_cross_job_enabled() or not (coalesce((select p.prosrc is not null and encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='b678eca76a31edbf88408302379013b762eea5b2f50d4bdd3a8ebebc55e2f3ea' and pg_get_userbyid(p.proowner)='postgres' and p.proacl::text='{postgres=X/postgres}' and p.prosecdef and p.proconfig=array['search_path=public, pg_temp']::text[] and p.provolatile='s' and not p.proisstrict and not p.proleakproof and p.proparallel='u' and p.prokind='f' and not p.proretset and p.prorettype='boolean'::regtype and p.pronargs=0 and p.pronargdefaults=0 and p.procost=100 and p.prorows=0 and p.prosupport=0 and p.prolang=(select oid from pg_language where lanname='plpgsql') from pg_proc p where p.oid=to_regprocedure('public._work_cross_job_coverage()')),false) and public._work_cross_job_coverage()) or not public._work_cross_job_scope(h.id,actor) then return jsonb_build_object('protocolVersion',2,'availability','unavailable','state',null);end if;
 if h.id is not null then shift_view:=jsonb_build_object('id',h.id,'clockInCommandId',h.client_id,'clockInAt',public._work_activity_iso(h.clock_in_at),
  'breakStartedAt',public._work_activity_iso(h.break_started_at),'breakType',h.break_type,'status','open','project',public._work_activity_project_view((select a.project_id from public.work_cross_job_heads x join public.work_cross_job_allocations a on a.id=x.allocation_id where x.shift_id=h.id),actor),'allocationId',(select allocation_id from public.work_cross_job_heads where shift_id=h.id));end if;
 personal_status:=case when s.integrity_state<>'clean' then 'review' when h.id is null then 'off_clock' when h.break_started_at is not null then 'on_break'
  when s.active_source_kind='setup' then 'setup' when s.active_source_id is not null then 'running' else 'unclassified' end;
 state_actions:=jsonb_build_object('canEstablishStream',ready,'canSwitch',ready and enabled and h.id is not null and h.break_started_at is null and s.active_source_kind is distinct from 'setup',
  'canFinishSetup',coalesce(ready and enabled and h.id is not null and h.break_started_at is null and s.active_source_kind='setup',false),
  'canStop',ready and h.id is not null and h.break_started_at is null and s.active_source_id is not null);
 state_view:=jsonb_build_object('revision',s.revision,'lastTransitionId',s.last_transition_id,'integrity',s.integrity_state,'status',personal_status,'choiceRequired',s.choice_required,
  'actions',state_actions,'shift',shift_view,'activity',case when h.id is not null and h.break_started_at is null then public._work_activity_source_view(s) end);
 result:=jsonb_build_object('protocolVersion',2,'asOf',public._work_activity_iso(as_of),'deviceId',p_device_id,
  'capability',jsonb_build_object('mode',case when enabled then 'active' else 'closing_only' end,'reasonCode',case when not enabled then 'starts_disabled' end),
  'observation',observation_view,'stream',stream_view,'state',state_view);
 if octet_length(result::text)>100000 then raise exception using errcode='54000',message='Activity projection is too large.';end if;
 return result;
end; $$;

create or replace function public.work_activity_command_receipt(p_command_id uuid) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare actor uuid; receipt jsonb;
begin
 perform public._work_activity_read_committed();
 perform public._work_activity_gate();actor:=public._work_activity_actor();
 if p_command_id is null then raise exception using errcode='23514',message='A command identity is required.';end if;
 select result into receipt from public.personal_activity_commands where command_id=p_command_id and actor_id=actor and subject_profile_id=actor and protocol_version=1;
 return jsonb_build_object('protocolVersion',1,'availability',case when receipt is null then 'unavailable' else 'available' end,'receipt',receipt);
end; $$;

create function public.work_cross_job_receipt(p_command_id uuid) returns jsonb language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare actor uuid;c public.personal_activity_commands;a public.work_cross_job_allocations;
begin
 perform public._work_activity_read_committed();perform public._work_activity_gate();perform pg_advisory_xact_lock(7710,0);actor:=public._work_activity_actor();
 select * into c from public.personal_activity_commands where command_id=p_command_id and actor_id=actor and subject_profile_id=actor and protocol_version=2;
 if c.command_id is null or not public._work_cross_job_enabled() or not (coalesce((select p.prosrc is not null and encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='b678eca76a31edbf88408302379013b762eea5b2f50d4bdd3a8ebebc55e2f3ea' and pg_get_userbyid(p.proowner)='postgres' and p.proacl::text='{postgres=X/postgres}' and p.prosecdef and p.proconfig=array['search_path=public, pg_temp']::text[] and p.provolatile='s' and not p.proisstrict and not p.proleakproof and p.proparallel='u' and p.prokind='f' and not p.proretset and p.prorettype='boolean'::regtype and p.pronargs=0 and p.pronargdefaults=0 and p.procost=100 and p.prorows=0 and p.prosupport=0 and p.prolang=(select oid from pg_language where lanname='plpgsql') from pg_proc p where p.oid=to_regprocedure('public._work_cross_job_coverage()')),false) and public._work_cross_job_coverage()) or not public._work_cross_job_scope((c.normalized_payload#>>'{shiftRef,id}')::uuid,actor) then return jsonb_build_object('protocolVersion',2,'availability','unavailable','receipt',null,'allocation',null);end if;
 select * into a from public.work_cross_job_allocations where command_id=c.command_id;
 return jsonb_build_object('protocolVersion',2,'availability','available','receipt',c.result,'allocation',case when a.id is not null then jsonb_build_object('id',a.id,'predecessorId',a.predecessor_id,'boundaryMode',a.boundary_mode,'originalTappedAt',public._work_activity_iso(a.original_tapped_at),'effectiveAt',public._work_activity_iso(a.effective_at),'shiftId',a.shift_id,'transitionId',a.transition_id) end);
end$$;

create or replace function public._work_activity_clock_replay_guard(p_client uuid,p_action text,p_shift uuid default null) returns void
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare r public.work_activity_clock_receipts;o public.work_activity_operations;v record;
begin
 if p_client is null then return;end if;
 o:=public._work_activity_operation();
 if o.id is null or o.actor_id is null or o.actor_id is distinct from auth.uid() then raise exception using errcode='42501',message='Clock receipt unavailable.';end if;
 select * into r from public.work_activity_clock_receipts where client_id=p_client;
 if r.client_id is null then
  if p_action='clock_in' and o.route in('clock_in','clock_in_setup') then
   if exists(select 1 from public.work_cross_job_clock_requests where client_id=p_client)
    or exists(select 1 from public.time_clock_actions where client_id=p_client and profile_id is distinct from o.actor_id)
    or exists(select 1 from public.time_shifts where client_id=p_client and profile_id is distinct from o.actor_id) then
    raise exception using errcode='42501',message='Clock receipt unavailable.';
   end if;
   if o.route='clock_in_setup' and o.arguments->>'setupVersion'='2'
    and (exists(select 1 from public.time_clock_actions where client_id=p_client and profile_id=o.actor_id)
      or exists(select 1 from public.time_shifts where client_id=p_client and profile_id=o.actor_id)) then
    raise exception using errcode='23514',message='Clock command identity conflicts.';
   end if;
  end if;
  return;
 end if;
 if r.profile_id is distinct from o.actor_id then raise exception using errcode='42501',message='Clock receipt unavailable.';end if;
 if r.action is distinct from p_action or (p_shift is not null and r.shift_id is distinct from p_shift) then raise exception using errcode='23514',message='Clock command identity conflicts.';end if;
 if o.route='clock_in_setup' and (r.receipt_protocol<>'setup_v1' or r.setup_payload_digest is distinct from o.arguments->>'clockPayloadDigest') then
   raise exception using errcode='23514',message='Clock command identity conflicts.';end if;
 if p_action='clock_in' and o.route in('clock_in','clock_in_setup') then
  select * into v from public.work_cross_job_clock_requests where client_id=r.client_id;
  if v.client_id is not null and (v.profile_id is distinct from r.profile_id or v.shift_id is distinct from r.shift_id or v.receipt_sha256 is distinct from public._work_cross_job_clock_receipt_fingerprint(r)) then raise exception using errcode='42501',message='Clock receipt unavailable.';end if;
  if (o.route='clock_in_setup' and coalesce(o.arguments->>'setupVersion','')='2') is distinct from coalesce(v.setup_version=2,false) then
   raise exception using errcode='23514',message='Clock command identity conflicts.';
  end if;
 end if;
 -- A retained acknowledgement survives source deletion. Never reapply the
 -- original command after its mutable/cascading legacy lookup disappeared.
 if not exists(select 1 from public.time_clock_actions where client_id=r.client_id and profile_id=r.profile_id and shift_id=r.shift_id and action=r.action)
    or not exists(select 1 from public.time_shifts where id=r.shift_id and profile_id=r.profile_id) then
   raise exception using errcode='42501',message='Clock receipt unavailable.';
 end if;
end; $$;

create or replace function public.work_activity_clock_receipt(p_client_id uuid) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare actor uuid;r record;t record;retention text;protocol text;present boolean;
 missing constant jsonb:='{"protocolVersion":1,"availability":"unavailable","receipt":null}'::jsonb;
begin
 perform public._work_activity_read_committed();perform public._work_activity_gate();actor:=public._work_activity_actor();
 if p_client_id is null then raise exception using errcode='23514',message='A clock command identity is required.';end if;
 select x.client_id,x.profile_id,x.shift_id,x.action,x.outcome,x.tapped_at,x.arrived_at,x.clock_checked_at,x.clock_skew_ms,x.used_tap_time,x.review_reason,x.receipt_protocol
 into r from public.work_activity_clock_receipts x where x.client_id=p_client_id and x.profile_id=actor;
 if found then retention:='retained';protocol:=r.receipt_protocol;
 else
  select x.client_id,x.profile_id,x.shift_id,x.action,x.outcome,x.tapped_at,x.arrived_at,x.clock_checked_at,x.clock_skew_ms,x.used_tap_time,x.review_reason,'legacy'::text receipt_protocol
  into r from public.time_clock_actions x where x.client_id=p_client_id and x.profile_id=actor;
  if not found then return missing;end if;retention:='legacy';protocol:='legacy';
 end if;
 if r.action='clock_in' and r.receipt_protocol='setup_v1'
  and exists(select 1 from public.work_cross_job_shifts where shift_id=r.shift_id) then return missing;end if;
 -- Unsupported historical evidence remains unavailable rather than coercing
 -- a nonfinite time or an unknown disposition into a truthful completion.
 if (r.review_reason is not null and length(r.review_reason)>80) or not isfinite(r.arrived_at) or (r.tapped_at is not null and not isfinite(r.tapped_at))
   or (r.clock_checked_at is not null and not isfinite(r.clock_checked_at))
   or r.outcome<>all(case r.action when 'clock_in' then array['clocked_in'] when 'clock_out' then array['clocked_out','requires_review']
      when 'break_start' then array['started','already_on_break','requires_review'] when 'break_end' then array['ended','no_break_running','shift_closed','requires_review'] else array[]::text[] end)
 then return missing;end if;
 select x.id,x.revision_before,x.revision_after into t from public.personal_activity_transitions x
 where x.profile_id=actor and x.source_request_id=p_client_id and x.actor_id=actor and x.source_shift_id=r.shift_id;
 present:=exists(select 1 from public.time_shifts where id=r.shift_id and profile_id=actor)
   and exists(select 1 from public.time_clock_actions where client_id=p_client_id and profile_id=actor and shift_id=r.shift_id);
 return jsonb_build_object('protocolVersion',1,'availability','available','receipt',jsonb_build_object(
  'clientId',r.client_id,'action',r.action,'outcome',r.outcome,'shiftId',r.shift_id,'tappedAt',public._work_activity_iso(r.tapped_at),
  'arrivedAt',public._work_activity_iso(r.arrived_at),'clockCheckedAt',public._work_activity_iso(r.clock_checked_at),'clockSkewMs',r.clock_skew_ms,
  'usedTapTime',r.used_tap_time,'reviewReason',r.review_reason,'receiptProtocol',protocol,'retention',retention,'sourcePresent',present,
  'activityTransition',case when t.id is not null then jsonb_build_object('id',t.id,'beforeRevision',t.revision_before,'afterRevision',t.revision_after) else 'null'::jsonb end));
end; $$;

create or replace function public._work_activity_clock_contract_marker() returns text
language sql immutable security definer set search_path=public,pg_temp as $marker$
 select '2ac3aad6d095d5bf9584bb656ce7123392884b946b0df46e2c6d84beeba3d32a'::text
$marker$;

create or replace function public.work_activity_clock_capability() returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $capability$
declare actor uuid;as_of timestamptz;enabled boolean;generation bigint;s public.personal_activity_state;
 mode text;reason text;author_setup boolean:=false;e jsonb;actual jsonb;
begin
 perform public._work_activity_read_committed();
 perform public._work_activity_gate();actor:=public._work_activity_actor();as_of:=clock_timestamp();
 if not coalesce((select p.prosrc is not null and encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='3f4d03d090a1428ce0dd8b410a285029903d156576da41a86237daa30e0e1d25' and pg_get_userbyid(p.proowner)='postgres' and p.proacl::text='{postgres=X/postgres}' and p.prosecdef and p.proconfig=array['search_path=public, pg_temp']::text[] and p.provolatile='i' and p.proisstrict and not p.proleakproof and p.proparallel='u' and p.prokind='f' and not p.proretset and p.prorettype='text'::regtype and p.pronargs=1 and p.pronargdefaults=0 and p.procost=100 and p.prorows=0 and p.prosupport=0 and p.prolang=(select oid from pg_language where lanname='sql') from pg_proc p where p.oid=to_regprocedure('public._work_cross_job_clock_receipt_fingerprint(public.work_activity_clock_receipts)')),false) or not coalesce((select p.prosrc is not null and encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='c3a7df2b8818e95a0962e6a6a2e87de398371a5e4d2a8812044324d001debd66' and pg_get_userbyid(p.proowner)='postgres' and p.proacl::text='{postgres=X/postgres}' and p.prosecdef and p.proconfig=array['search_path=public, pg_temp']::text[] and p.provolatile='i' and not p.proisstrict and not p.proleakproof and p.proparallel='u' and p.prokind='f' and not p.proretset and p.prorettype='text'::regtype and p.pronargs=0 and p.pronargdefaults=0 and p.procost=100 and p.prorows=0 and p.prosupport=0 and p.prolang=(select oid from pg_language where lanname='sql') from pg_proc p where p.oid=to_regprocedure('public._work_activity_clock_contract_marker()')),false) or public._work_activity_clock_contract_marker() is distinct from '2ac3aad6d095d5bf9584bb656ce7123392884b946b0df46e2c6d84beeba3d32a' then
 raise exception using errcode='55000',message='Clock protocol is unavailable.';end if;
 -- Bounded cheap runtime drift check, after caller permission. The complete
 -- installation contract above covers every transformed entry and callback.
 for e in select value from jsonb_array_elements($protocol$[{"name":"_toolbox_gate_open","args":"p_uid uuid","value":{"anon":false,"body":"ed3ecd2fafe012b9cd7a03da6dea485e29f20d591b9dd13960d7d37088f92f8f","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":false,"returns":"boolean","language":"sql","volatility":"s","authenticated":true}},{"name":"_toolbox_signed_today","args":"p_uid uuid","value":{"anon":false,"body":"c6afbff1f69461549975380dfcc9dd3c8b345df37affa2359f087aa16d1b4ca0","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":false,"returns":"boolean","language":"sql","volatility":"s","authenticated":true}},{"name":"_work_activity_actor","args":"","value":{"anon":false,"body":"7890c48b8af43f142610895f8da5d8361178470db58d384bf1ff2f48c52f8122","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"uuid","language":"plpgsql","volatility":"v","authenticated":false}},{"name":"_work_activity_claim_clock_setup","args":"p_project_id uuid, p_cost_code_id uuid, p_photo text, p_lat double precision, p_lng double precision, p_note text, p_mode text, p_client_id uuid, p_tapped_at timestamp with time zone, p_clock_checked_at timestamp with time zone, p_clock_skew_ms integer","value":{"anon":false,"body":"1759026baaad344be1149a3ae04632e1eabf5b6cae69899c39be736cf3d85277","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"boolean","language":"plpgsql","volatility":"v","authenticated":false}},{"name":"_work_activity_clock_replay_guard","args":"p_client uuid, p_action text, p_shift uuid","value":{"anon":false,"body":"34a7483501a87bacd451d9ba6671b78edc48b526520f73ba2b70906b604e00ec","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"void","language":"plpgsql","volatility":"v","authenticated":false}},{"name":"_work_activity_clock_setup_digest","args":"p_project_id uuid, p_cost_code_id uuid, p_photo text, p_lat double precision, p_lng double precision, p_note text, p_mode text, p_client_id uuid, p_tapped_at timestamp with time zone, p_clock_checked_at timestamp with time zone, p_clock_skew_ms integer","value":{"anon":false,"body":"7cbf137bffb2f5134b3cd66a35bc7e207ea5c39a58cfed03acad2cbc017211d3","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":false,"returns":"text","language":"sql","volatility":"s","authenticated":false}},{"name":"_work_activity_gate","args":"","value":{"anon":false,"body":"24e3624af1c057c5048b5e5e06206e802d17bb5a4aae1fdf5de9e48b87f4b6e8","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"void","language":"plpgsql","volatility":"v","authenticated":false}},{"name":"_work_activity_keep_clock_receipt","args":"","value":{"anon":false,"body":"0adc5b1eac8c882ea941c5c6bceea3242db7f9a66de8ded254bd96e8ad0a0291","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"trigger","language":"plpgsql","volatility":"v","authenticated":false}},{"name":"_work_activity_read_committed","args":"","value":{"anon":false,"body":"5c692d2459dd18fad5e0f49e698a619b1c26097e7ee335a69c460d44c4611b2a","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"void","language":"plpgsql","volatility":"v","authenticated":false}},{"name":"_work_config_internal","args":"p_uid uuid","value":{"anon":false,"body":"40350856480c2e8dc1c84247091981d9e70e9d766f7bb47b56fde7847a673407","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"boolean","language":"sql","volatility":"s","authenticated":false}},{"name":"clock_in","args":"p_project_id uuid, p_cost_code_id uuid, p_photo text, p_lat double precision, p_lng double precision","value":{"anon":false,"body":"c062f0c38a76f236bd2e4e459b2cdb39b99547865599717261334092d18d01e8","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"time_shifts","language":"plpgsql","volatility":"v","authenticated":true}},{"name":"clock_in","args":"p_project_id uuid, p_cost_code_id uuid, p_photo text, p_lat double precision, p_lng double precision, p_client_id uuid","value":{"anon":false,"body":"ee48d7b0c3fefd68678b570424c1cc2822f264a52f3099f5c0c98837c3dc9cb6","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"time_shifts","language":"plpgsql","volatility":"v","authenticated":true}},{"name":"clock_in","args":"p_project_id uuid, p_cost_code_id uuid, p_photo text, p_lat double precision, p_lng double precision, p_client_id uuid, p_note text","value":{"anon":false,"body":"4413958dd1c2e33a3e1bb5690dc33333bee29d57ca633610c444baf9547e439f","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"time_shifts","language":"plpgsql","volatility":"v","authenticated":true}},{"name":"clock_in","args":"p_project_id uuid, p_cost_code_id uuid, p_photo text, p_lat double precision, p_lng double precision, p_note text","value":{"anon":false,"body":"b1d566d9758bcab88df16b138f795c3792eff2a0a0c55750d089d2608c4a598b","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"time_shifts","language":"plpgsql","volatility":"v","authenticated":true}},{"name":"clock_in","args":"p_project_id uuid, p_cost_code_id uuid, p_photo text, p_lat double precision, p_lng double precision, p_note text, p_mode text","value":{"anon":false,"body":"c3fe0f2a5111f4d21bf5ef5149c79846ea53ec904f977765d75e5e7117fd5f09","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"time_shifts","language":"plpgsql","volatility":"v","authenticated":true}},{"name":"clock_in","args":"p_project_id uuid, p_cost_code_id uuid, p_photo text, p_lat double precision, p_lng double precision, p_note text, p_mode text, p_client_id uuid, p_tapped_at timestamp with time zone, p_clock_checked_at timestamp with time zone, p_clock_skew_ms integer","value":{"anon":false,"body":"ad7268b517980f7a4fc9f8cf7949bda734b127ccd2ee7eeec04119bffaf1c7e5","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"time_shifts","language":"plpgsql","volatility":"v","authenticated":true}},{"name":"clock_in","args":"p_project_id uuid, p_cost_code_id uuid, p_photo text, p_lat double precision, p_lng double precision, p_note text, p_mode text, p_client_id uuid, p_tapped_at timestamp with time zone, p_clock_checked_at timestamp with time zone, p_clock_skew_ms integer, p_setup_version integer","value":{"anon":false,"body":"da22feb375a950deb6c8c21664ec075bed55397e54ef0f91dafe7f2d2c2ecd99","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"time_shifts","language":"plpgsql","volatility":"v","authenticated":true}},{"name":"clock_out","args":"p_shift_id uuid, p_photo text, p_injured boolean, p_time_confirmed boolean, p_break_seconds integer, p_lat double precision, p_lng double precision, p_injury_note text","value":{"anon":false,"body":"085e2e0382392ee105bf5dfb1322e786cb464f3dad2a43d981f1359ec562d1b4","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"time_shifts","language":"plpgsql","volatility":"v","authenticated":true}},{"name":"clock_out","args":"p_shift_id uuid, p_photo text, p_injured boolean, p_time_confirmed boolean, p_break_seconds integer, p_lat double precision, p_lng double precision, p_injury_note text, p_client_id uuid, p_tapped_at timestamp with time zone, p_clock_checked_at timestamp with time zone, p_clock_skew_ms integer","value":{"anon":false,"body":"2ddaca78ba00333dde9100492716df17f279c6ab1fc99d3b17ce20f77c0bb636","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"time_shifts","language":"plpgsql","volatility":"v","authenticated":true}},{"name":"end_break","args":"p_shift_id uuid","value":{"anon":false,"body":"f930e2e95a4d59e547eea6e7ee30135bfe39a13b002c76abfe6f72d1451c1ada","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"time_shifts","language":"plpgsql","volatility":"v","authenticated":true}},{"name":"end_break","args":"p_shift_id uuid, p_client_id uuid, p_tapped_at timestamp with time zone, p_clock_checked_at timestamp with time zone, p_clock_skew_ms integer","value":{"anon":false,"body":"470a0539693065c6cbd7ff51d8033fd74500570db13cdc2b990719a0eb2f7fc4","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"jsonb","language":"plpgsql","volatility":"v","authenticated":true}},{"name":"start_break","args":"p_shift_id uuid, p_break_type text","value":{"anon":false,"body":"4f12f25fc5d7060f59ad7cbe9d717c6a23de4a6ba860301200815063a1d24b06","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"time_shifts","language":"plpgsql","volatility":"v","authenticated":true}},{"name":"start_break","args":"p_shift_id uuid, p_break_type text, p_client_id uuid, p_tapped_at timestamp with time zone, p_clock_checked_at timestamp with time zone, p_clock_skew_ms integer","value":{"anon":false,"body":"02f00615f0264ad7f3b0b21a949df2c5e8a9257b9b66f714ef866df913d84cbc","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"time_shifts","language":"plpgsql","volatility":"v","authenticated":true}},{"name":"work_activity_clock_receipt","args":"p_client_id uuid","value":{"anon":false,"body":"e031a0d945fda344cafbdee6c5a2d228c368488d8cafdb0c75da60fcea7320b1","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"jsonb","language":"plpgsql","volatility":"v","authenticated":true}},{"name":"_work_cross_job_clock_request_admit","args":"","value":{"anon":false,"body":"acd71517a152215a32812a572df400ec9d3756d737e9ad8d4298a1fa035df836","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"trigger","language":"plpgsql","volatility":"v","authenticated":false}},{"name":"_work_cross_job_clock_request_stamp","args":"","value":{"anon":false,"body":"1cc06ac928c2a0a4c0cfd5244febac56eb275384f92dc8b57235bf98b3c4240c","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"trigger","language":"plpgsql","volatility":"v","authenticated":false}},{"name":"_work_cross_job_clock_receipt_fingerprint","args":"p_receipt work_activity_clock_receipts","value":{"anon":false,"body":"3f4d03d090a1428ce0dd8b410a285029903d156576da41a86237daa30e0e1d25","kind":"f","owner":"postgres","config":["search_path=public, pg_temp"],"public":false,"definer":true,"returns":"text","language":"sql","volatility":"i","authenticated":false}}]$protocol$::jsonb) loop
 select jsonb_build_object('body',encode(sha256(convert_to(p.prosrc,'UTF8')),'hex'),'owner',pg_get_userbyid(p.proowner),'definer',p.prosecdef,'volatility',p.provolatile,'kind',p.prokind,'language',l.lanname,'returns',pg_get_function_result(p.oid),'config',p.proconfig,'public',exists(select 1 from aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a where a.grantee=0 and a.privilege_type='EXECUTE'),'anon',has_function_privilege('anon',p.oid,'EXECUTE'),'authenticated',has_function_privilege('authenticated',p.oid,'EXECUTE')) into actual from pg_proc p join pg_namespace n on n.oid=p.pronamespace join pg_language l on l.oid=p.prolang
 where n.nspname='public' and p.proname=e->>'name' and pg_get_function_identity_arguments(p.oid)=e->>'args';
 if actual is distinct from e->'value' then raise exception using errcode='55000',message='Clock protocol is unavailable.';end if;
 end loop;
 select capture_enabled,revision into enabled,generation from public.work_activity_authority_generation where singleton;
 select * into s from public.personal_activity_state where profile_id=actor;
 if enabled is null or generation is null or generation>=9007199254740991
  or (s.profile_id is not null and (s.integrity_state<>'clean' or s.revision>=9007199254740991))
  or exists(select 1 from public.work_activity_safety_events where profile_id=actor) then
 mode:='unavailable';reason:='not_ready';
 elsif exists(select 1 from public.work_cross_job_shifts x join public.time_shifts h on h.id=x.shift_id where x.profile_id=actor and h.profile_id=actor and h.status='open' and h.clock_out_at is null) then
 mode:='unavailable';reason:='not_ready';
 elsif not enabled then mode:='closing_only';reason:='starts_disabled';
 else
 -- The exact setup_v1 root may start paid setup before signing. Ordinary
 -- overloads keep their existing toolbox/company-date policy.
 mode:='active';author_setup:=true;
 end if;
 return jsonb_build_object('protocolVersion',1,'asOf',public._work_activity_iso(as_of),
 'clockProtocol','setup_v1','receiptProtocol','retained_v1','mode',mode,'canAuthorSetup',author_setup,'setupReason',reason,
 'canDispatchExistingSetup',true,'canReadOwnReceipts',true,'canDispatchPayrollSafety',true);
exception when undefined_function or undefined_table or undefined_column then
 raise exception using errcode='55000',message='Clock protocol is unavailable.';
end;$capability$;

create or replace function public.person_record_counts(p_id uuid)
returns jsonb
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select jsonb_build_object(
    'hex_learning_reviews.author_id', (select count(*) from hex_learning_reviews where author_id = p_id),
    'hex_learning_reviews.reviewer_id', (select count(*) from hex_learning_reviews where reviewer_id = p_id),
    'hex_learning_reviews.decided_by', (select count(*) from hex_learning_reviews where decided_by = p_id),
    'hex_learning_review_events.actor_id', (select count(*) from hex_learning_review_events where actor_id = p_id),
    'hex_learning_reviews.withdrawn_by', (select count(*) from hex_learning_reviews where withdrawn_by = p_id),
    'hex_learning_deliveries.last_caller', (select count(*) from hex_learning_deliveries where last_caller = p_id),
    'hex_learning_withdrawals.last_caller', (select count(*) from hex_learning_withdrawals where last_caller = p_id),
    'ai_field_requests.profile_id', (select count(*) from ai_field_requests where profile_id = p_id),
    'ai_field_actions.profile_id', (select count(*) from ai_field_actions where profile_id = p_id),
    'daily_log_contributions.actor_id', (select count(*) from daily_log_contributions where actor_id = p_id),
    'crew_work_records.filed_by', (select count(*) from crew_work_records where filed_by = p_id),
    'crew_work_record_people.profile_id', (select count(*) from crew_work_record_people where profile_id = p_id),
 'hex_portal_cases.asker_id',(select count(*) from public.hex_portal_cases where asker_id=p_id),
 'hex_portal_outcomes.actor_id',(select count(*) from public.hex_portal_outcomes where actor_id=p_id),
 'hex_portal_guidance_receipts.actor_id',(select count(*) from public.hex_portal_guidance_receipts where actor_id=p_id),'time_off_requests.profile_id',(select count(*) from time_off_requests where profile_id=p_id),'crew_reminders.profile_id',(select count(*) from crew_reminders where profile_id=p_id)) || jsonb_build_object('service_visits.created_by',(select count(*) from service_visits where created_by=p_id),'service_visit_units.created_by',(select count(*) from service_visit_units where created_by=p_id),'service_time_sessions.profile_id',(select count(*) from service_time_sessions where profile_id=p_id),'service_media.created_by',(select count(*) from service_media where created_by=p_id),'service_audit.actor_id',(select count(*) from service_audit where actor_id=p_id),'service_commands.profile_id',(select count(*) from service_commands where profile_id=p_id)) || jsonb_build_object(
    'custom_work_units.created_by', (select count(*) from custom_work_units where created_by = p_id),
    'custom_work_sessions.profile_id', (select count(*) from custom_work_sessions where profile_id = p_id),
    'custom_work_history.actor_id', (select count(*) from custom_work_history where actor_id = p_id),
    'custom_work_commands.profile_id', (select count(*) from custom_work_commands where profile_id = p_id),

    'workflow_plans.created_by', (select count(*) from workflow_plans where created_by = p_id),
    'workflow_plan_revisions.actor', (select count(*) from workflow_plan_revisions where actor = p_id),
    'workflow_notice_outbox.profile_id', (select count(*) from workflow_notice_outbox where profile_id = p_id),
    -- Time and money.
    'time_clock_actions.profile_id',
      (select count(*) from time_clock_actions where profile_id = p_id),
    'time_shifts.profile_id',
      (select count(*) from time_shifts where profile_id = p_id),
    'unit_sessions.profile_id',
      (select count(*) from unit_sessions where profile_id = p_id),
    'install_events.installer_id',
      (select count(*) from install_events where installer_id = p_id),
    'install_events.credited_to',
      (select count(*) from install_events where credited_to = p_id),
    'receipts.uploaded_by',
      (select count(*) from receipts where uploaded_by = p_id),
    'pay_rates.profile_id',
      (select count(*) from pay_rates where profile_id = p_id),
    'overtime_rules.profile_id',
      (select count(*) from overtime_rules where profile_id = p_id),
    'semimonthly_timecard_periods.profile_id',
      (select count(*) from semimonthly_timecard_periods where profile_id = p_id),
    'timecard_periods.profile_id',
      (select count(*) from timecard_periods where profile_id = p_id),
    'time_shift_edits.edited_by',
      (select count(*) from time_shift_edits where edited_by = p_id),
    -- Safety and training.
    'certifications.profile_id',
      (select count(*) from certifications where profile_id = p_id),
    'toolbox_completions.profile_id',
      (select count(*) from toolbox_completions where profile_id = p_id),
    'safety_acks.profile_id',
      (select count(*) from safety_acks where profile_id = p_id),
    'capability_badges.installer_id',
      (select count(*) from capability_badges where installer_id = p_id),
    'installer_clearance.installer_id',
      (select count(*) from installer_clearance where installer_id = p_id),
    'learn_progress.profile_id',
      (select count(*) from learn_progress where profile_id = p_id),
    'learning_video_quiz_attempts.profile_id',
      (select count(*) from learning_video_quiz_attempts where profile_id = p_id),
    'education_credits.profile_id',
      (select count(*) from education_credits where profile_id = p_id),
    -- The job site.
    'daily_logs.filed_by',
      (select count(*) from daily_logs where filed_by = p_id),
    'opening_phases.started_by',
      (select count(*) from opening_phases where started_by = p_id),
    'opening_phases.submitted_by',
      (select count(*) from opening_phases where submitted_by = p_id),
    'flash_run_assignments.assigned_by',
      (select count(*) from flash_run_assignments where assigned_by = p_id),
    'flash_run_assignments.profile_id',
      (select count(*) from flash_run_assignments where profile_id = p_id),
    'summons.requested_by',
      (select count(*) from summons where requested_by = p_id),
    'summon_helpers.profile_id',
      (select count(*) from summon_helpers where profile_id = p_id),
    'summon_declines.profile_id',
      (select count(*) from summon_declines where profile_id = p_id),
    'unit_redos.pressed_by',
      (select count(*) from unit_redos where pressed_by = p_id),
    'schedule_assignment_members.profile_id',
      (select count(*) from schedule_assignment_members where profile_id = p_id),
    'trip_crew.profile_id',
      (select count(*) from trip_crew where profile_id = p_id),
    'vehicle_drivers.profile_id',
      (select count(*) from vehicle_drivers where profile_id = p_id),
    -- What they said and what they were given credit for.
    'points_ledger.profile_id',
      (select count(*) from points_ledger where profile_id = p_id),
    'task_sessions.profile_id',
      (select count(*) from task_sessions where profile_id = p_id),
    'project_messages.author_id',
      (select count(*) from project_messages where author_id = p_id),
    'ask_question_log.asker_id',
      (select count(*) from ask_question_log where asker_id = p_id)
  ) || jsonb_build_object(
    -- Monthly core-value reviews (20261106000000). All seven profile-reference CASCADE columns
    -- (see the table definitions above) — losing them with the account would
    -- lose a record of review work given or received.
    'values_assignments.rater_id', (select count(*) from values_assignments where rater_id = p_id),
    'values_assignments.subject_id', (select count(*) from values_assignments where subject_id = p_id),
    'values_submissions.rater_id', (select count(*) from values_submissions where rater_id = p_id),
    'values_submissions.subject_id', (select count(*) from values_submissions where subject_id = p_id),
    'values_quarterly_ratings.subject_id', (select count(*) from values_quarterly_ratings where subject_id = p_id),
    'values_quarterly_manifest.rater_id', (select count(*) from values_quarterly_manifest where rater_id = p_id),
    'values_reminder_claims.profile_id', (select count(*) from values_reminder_claims where profile_id = p_id)
  ) || jsonb_build_object(
    'work_activity_definitions.created_by',(select count(*) from public.work_activity_definitions where created_by=p_id),
    'work_activity_definition_versions.published_by',(select count(*) from public.work_activity_definition_versions where published_by=p_id),
    'work_capture_menus.created_by',(select count(*) from public.work_capture_menus where created_by=p_id),
    'work_capture_menu_versions.published_by',(select count(*) from public.work_capture_menu_versions where published_by=p_id),
    'work_job_menu_selections.selected_by',(select count(*) from public.work_job_menu_selections where selected_by=p_id),
    'work_job_management_grants.profile_id',(select count(*) from public.work_job_management_grants where profile_id=p_id),
    'work_job_management_grants.granted_by',(select count(*) from public.work_job_management_grants where granted_by=p_id),
    'work_job_management_grants.revoked_by',(select count(*) from public.work_job_management_grants where revoked_by=p_id),
    'personal_activity_state.profile_id',(select count(*) from public.personal_activity_state where profile_id=p_id),
    'personal_activity_commands.actor_id',(select count(*) from public.personal_activity_commands where actor_id=p_id),
    'personal_activity_commands.subject_profile_id',(select count(*) from public.personal_activity_commands where subject_profile_id=p_id),
    'personal_activity_transitions.profile_id',(select count(*) from public.personal_activity_transitions where profile_id=p_id),
    'personal_activity_transitions.actor_id',(select count(*) from public.personal_activity_transitions where actor_id=p_id),
    'work_session_capture_metadata.profile_id',(select count(*) from public.work_session_capture_metadata where profile_id=p_id),
    'work_configuration_commands.actor_id',(select count(*) from public.work_configuration_commands where actor_id=p_id),
    'work_configuration_draft_revisions.proposed_by',(select count(*) from public.work_configuration_draft_revisions where proposed_by=p_id),
    'work_unit_fact_revisions.actor_id',(select count(*) from public.work_unit_fact_revisions where actor_id=p_id),
    'work_unit_fact_revisions.observation_actor_id',(select count(*) from public.work_unit_fact_revisions where observation_actor_id=p_id),
    'work_unit_fact_revisions.origin_author_id',(select count(*) from public.work_unit_fact_revisions where origin_author_id=p_id),
    'work_activity_observations.actor_id',(select count(*) from public.work_activity_observations where actor_id=p_id),
    'work_activity_streams.actor_id',(select count(*) from public.work_activity_streams where actor_id=p_id),
    'work_setup_sessions.profile_id',(select count(*) from public.work_setup_sessions where profile_id=p_id),
    'personal_activity_transition_sources.profile_id',(select count(*) from public.personal_activity_transition_sources where profile_id=p_id),
    'work_activity_safety_events.profile_id',(select count(*) from public.work_activity_safety_events where profile_id=p_id),
    'work_activity_safety_events.actor_id',(select count(*) from public.work_activity_safety_events where actor_id=p_id),
    'work_activity_clock_receipts.profile_id',(select count(*) from public.work_activity_clock_receipts where profile_id=p_id)
  ) || jsonb_build_object(
'work_cross_job_clock_requests.profile_id',(select count(*) from public.work_cross_job_clock_requests where profile_id=p_id),
'work_cross_job_shifts.profile_id',(select count(*) from public.work_cross_job_shifts where profile_id=p_id),
'work_cross_job_allocations.profile_id',(select count(*) from public.work_cross_job_allocations where profile_id=p_id),
'work_cross_job_bindings.profile_id',(select count(*) from public.work_cross_job_bindings where profile_id=p_id),
'work_cross_job_resume.profile_id',(select count(*) from public.work_cross_job_resume where profile_id=p_id),
'work_activity_source_history.actor_id',(select count(*) from public.work_activity_source_history where actor_id=p_id),
'work_unit_review_commands.actor_id',(select count(*) from public.work_unit_review_commands where actor_id=p_id),
'work_unit_dimension_verifications.observation_actor_id',(select count(*) from public.work_unit_dimension_verifications where observation_actor_id=p_id),
'work_unit_dimension_verifications.reviewer_id',(select count(*) from public.work_unit_dimension_verifications where reviewer_id=p_id),
'work_unit_review_events.actor_id',(select count(*) from public.work_unit_review_events where actor_id=p_id),
'work_unit_review_defects.creator_id',(select count(*) from public.work_unit_review_defects where creator_id=p_id),
'work_unit_review_defect_events.actor_id',(select count(*) from public.work_unit_review_defect_events where actor_id=p_id),
'work_activity_source_history.original_identities',(select count(*) from public.work_activity_source_history where jsonb_path_exists(before_value,'$.** ? (@ == $person)',jsonb_build_object('person',p_id::text)) or jsonb_path_exists(after_value,'$.** ? (@ == $person)',jsonb_build_object('person',p_id::text))),
'work_unit_review_events.original_identities',(select count(*) from public.work_unit_review_events where jsonb_path_exists(scope_manifest,'$.** ? (@ == $person)',jsonb_build_object('person',p_id::text)))
);
$$;

do $acl$ declare f record;begin
 for f in select oid::regprocedure identity from pg_proc where pronamespace='public'::regnamespace and (starts_with(proname,'_work_cross_job_') or starts_with(proname,'work_cross_job_')) loop
 execute format('revoke all on function %s from public,anon,authenticated,service_role',f.identity);
 end loop;end $acl$;
grant execute on function public.work_cross_job_snapshot(uuid),public.work_cross_job_receipt(uuid) to authenticated;
-- CROSS_JOB_RUNTIME_END
select public.attach_sandbox_guards();
-- Exact revision2 contract. Seed is a reviewed assembly constant, not live drift.
create table public.work_cross_job_contract (
 proof_key text primary key check(proof_key='cross_job_kernel_2'),
 expected_catalog_sha256 text not null check(expected_catalog_sha256 ~ '^[0-9a-f]{64}$')
);
revoke all on table public.work_cross_job_contract from public,anon,authenticated,service_role;
alter table public.work_cross_job_contract enable row level security;
create function public._work_cross_job_coverage() returns boolean
language plpgsql stable security definer set search_path=public,pg_temp as $combined_coverage$
declare actual text;
begin
 if current_setting('extra_float_digits') is distinct from '1' then
  return false;
 end if;
 select encode(sha256(convert_to(c.value::text,'UTF8')),'hex') into actual from (
select jsonb_build_object('publicCatalog',(select value from (-- Deliberately closed source-derived public catalog. Unknown live drift refuses;
-- this is not a request to normalize a provider to the disposable fixture.
select jsonb_build_object(
 'types',(select jsonb_agg(jsonb_build_object('name',t.typname,'kind',t.typtype,'owner',pg_get_userbyid(t.typowner),'acl',t.typacl::text,'category',t.typcategory,'preferred',t.typispreferred,'defined',t.typisdefined,'notNull',t.typnotnull,'base',format_type(nullif(t.typbasetype,0),t.typtypmod),'element',format_type(nullif(t.typelem,0),null),'collation',case when t.typcollation<>0 then t.typcollation::regcollation::text end,'default',t.typdefault,'defaultExpression',pg_get_expr(t.typdefaultbin,0),'input',t.typinput::regprocedure::text,'output',t.typoutput::regprocedure::text,'receive',t.typreceive::regprocedure::text,'send',t.typsend::regprocedure::text,'length',t.typlen,'byValue',t.typbyval,'alignment',t.typalign,'storage',t.typstorage,'delimiter',t.typdelim,'access',(select jsonb_object_agg(r.rolname,has_type_privilege(r.oid,t.oid,'USAGE')) from pg_roles r where r.rolname in('anon','authenticated','service_role')),'enum',(select jsonb_agg(jsonb_build_object('label',e.enumlabel,'sort',e.enumsortorder) order by e.enumsortorder) from pg_enum e where e.enumtypid=t.oid),'constraints',(select jsonb_agg(jsonb_build_object('name',k.conname,'definition',pg_get_constraintdef(k.oid,true),'validated',k.convalidated) order by k.conname) from pg_constraint k where k.contypid=t.oid),'range',(select jsonb_build_object('subtype',format_type(r.rngsubtype,null),'collation',r.rngcollation::regcollation::text,'opclass',(select n.nspname||'.'||o.opcname from pg_opclass o join pg_namespace n on n.oid=o.opcnamespace where o.oid=r.rngsubopc),'canonical',r.rngcanonical::regprocedure::text,'subdiff',r.rngsubdiff::regprocedure::text) from pg_range r where r.rngtypid=t.oid)) order by t.typname) from pg_type t where t.typnamespace='public'::regnamespace),
 'sequences',(select jsonb_agg(jsonb_build_object('name',c.relname,'owner',pg_get_userbyid(c.relowner),'acl',c.relacl::text,'type',format_type(s.seqtypid,null),'start',s.seqstart,'increment',s.seqincrement,'max',s.seqmax,'min',s.seqmin,'cache',s.seqcache,'cycle',s.seqcycle,'access',(select jsonb_agg(jsonb_build_object('role',r.rolname,'privilege',v.p,'allowed',has_sequence_privilege(r.oid,c.oid,v.p)) order by r.rolname,v.p) from pg_roles r cross join unnest(array['SELECT','UPDATE','USAGE'])v(p) where r.rolname in('anon','authenticated','service_role'))) order by c.relname) from pg_class c join pg_sequence s on s.seqrelid=c.oid where c.relnamespace='public'::regnamespace),
 'foreignTables',(select jsonb_agg(jsonb_build_object('table',c.relname,'options',f.ftoptions,'server',s.srvname,'serverOwner',pg_get_userbyid(s.srvowner),'serverType',s.srvtype,'serverVersion',s.srvversion,'serverOptionsDigest',encode(sha256(convert_to(coalesce(s.srvoptions::text,''),'UTF8')),'hex'),'serverAcl',s.srvacl::text,'serverAccess',(select jsonb_object_agg(r.rolname,has_server_privilege(r.oid,s.oid,'USAGE')) from pg_roles r where r.rolname in('anon','authenticated','service_role')),'wrapper',w.fdwname,'wrapperOwner',pg_get_userbyid(w.fdwowner),'wrapperAcl',w.fdwacl::text,'wrapperAccess',(select jsonb_object_agg(r.rolname,has_foreign_data_wrapper_privilege(r.oid,w.oid,'USAGE')) from pg_roles r where r.rolname in('anon','authenticated','service_role')),'handler',w.fdwhandler::regprocedure::text,'validator',w.fdwvalidator::regprocedure::text,'wrapperOptionsDigest',encode(sha256(convert_to(coalesce(w.fdwoptions::text,''),'UTF8')),'hex')) order by c.relname) from pg_foreign_table f join pg_class c on c.oid=f.ftrelid join pg_foreign_server s on s.oid=f.ftserver join pg_foreign_data_wrapper w on w.oid=s.srvfdw where c.relnamespace='public'::regnamespace),
 'functions',(select jsonb_agg(jsonb_build_object('name',p.proname,'arguments',pg_get_function_identity_arguments(p.oid),'body',encode(sha256(convert_to(p.prosrc,'UTF8')),'hex'),'result',pg_get_function_result(p.oid),'owner',pg_get_userbyid(p.proowner),'acl',p.proacl::text,'language',l.lanname,'kind',p.prokind,'definer',p.prosecdef,'config',p.proconfig,'volatility',p.provolatile,'strict',p.proisstrict,'leakproof',p.proleakproof,'cost',p.procost,'rows',p.prorows,'support',p.prosupport::regprocedure::text,'parallel',p.proparallel,'defaults',pg_get_expr(p.proargdefaults,0),'access',(select jsonb_object_agg(r.rolname,has_function_privilege(r.oid,p.oid,'EXECUTE')) from pg_roles r where r.rolname in('anon','authenticated','service_role'))) order by p.proname,pg_get_function_identity_arguments(p.oid)) from pg_proc p join pg_language l on l.oid=p.prolang where p.pronamespace='public'::regnamespace and not exists(select 1 from pg_depend d where d.classid='pg_proc'::regclass and d.objid=p.oid and d.deptype='e')),
 'relations',(select jsonb_agg(jsonb_build_object('name',c.relname,'kind',c.relkind,'owner',pg_get_userbyid(c.relowner),'rls',c.relrowsecurity,'forcedRls',c.relforcerowsecurity,'acl',c.relacl::text,'access',(select jsonb_agg(jsonb_build_object('role',r.rolname,'privilege',v.p,'table',has_table_privilege(r.oid,c.oid,v.p),'column',case when v.p in('SELECT','INSERT','UPDATE','REFERENCES') then has_any_column_privilege(r.oid,c.oid,v.p) end) order by r.rolname,v.p) from pg_roles r cross join unnest(array['SELECT','INSERT','UPDATE','DELETE','TRUNCATE','REFERENCES','TRIGGER'])v(p) where r.rolname in('anon','authenticated','service_role'))) order by c.relname) from pg_class c where c.relnamespace='public'::regnamespace and c.relkind in('r','p','v','m','f','c')),
 'columns',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',a.attname,'type',format_type(a.atttypid,a.atttypmod),'notNull',a.attnotnull,'generated',a.attgenerated,'identity',a.attidentity,'acl',a.attacl::text,'default',pg_get_expr(d.adbin,d.adrelid),'access',(select jsonb_agg(jsonb_build_object('role',r.rolname,'privilege',v.p,'allowed',has_column_privilege(r.oid,c.oid,a.attnum,v.p)) order by r.rolname,v.p) from pg_roles r cross join unnest(array['SELECT','INSERT','UPDATE','REFERENCES'])v(p) where r.rolname in('anon','authenticated','service_role'))) order by c.relname,a.attnum) from pg_class c join pg_attribute a on a.attrelid=c.oid and a.attnum>0 and not a.attisdropped left join pg_attrdef d on d.adrelid=c.oid and d.adnum=a.attnum where c.relnamespace='public'::regnamespace and c.relkind in('r','p','v','m','f','c')),
 'constraints',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',k.conname,'definition',pg_get_constraintdef(k.oid,true),'validated',k.convalidated,'noInherit',k.connoinherit,'enforced',coalesce((to_jsonb(k)->>'conenforced')::boolean,true)) order by c.relname,k.conname) from pg_constraint k join pg_class c on c.oid=k.conrelid where c.relnamespace='public'::regnamespace and k.contype<>'n'),
 'notNullConstraints',(select jsonb_agg(jsonb_build_object('table',c.relname,'column',a.attname,'validated',coalesce(n.validated,true),'enforced',coalesce(n.enforced,true),'noInherit',coalesce(n.no_inherit,false)) order by c.relname,a.attnum) from pg_class c join pg_attribute a on a.attrelid=c.oid and a.attnum>0 and not a.attisdropped left join lateral(select bool_and(k.convalidated) validated,bool_and(coalesce((to_jsonb(k)->>'conenforced')::boolean,true)) enforced,bool_or(k.connoinherit) no_inherit from pg_constraint k where k.conrelid=c.oid and k.contype='n' and a.attnum=any(k.conkey))n on true where c.relnamespace='public'::regnamespace and c.relkind in('r','p')),
 'indexes',(select jsonb_agg(jsonb_build_object('table',t.relname,'name',c.relname,'definition',pg_get_indexdef(i.indexrelid),'valid',i.indisvalid,'ready',i.indisready) order by t.relname,c.relname) from pg_index i join pg_class c on c.oid=i.indexrelid join pg_class t on t.oid=i.indrelid where t.relnamespace='public'::regnamespace),
 'triggers',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',t.tgname,'definition',pg_get_triggerdef(t.oid,true),'enabled',t.tgenabled) order by c.relname,t.tgname) from pg_trigger t join pg_class c on c.oid=t.tgrelid where c.relnamespace='public'::regnamespace and not t.tgisinternal),
 'policies',(select jsonb_agg(to_jsonb(p) order by p.tablename,p.policyname) from pg_policies p where schemaname='public'),
 'views',(select jsonb_agg(jsonb_build_object('name',c.relname,'definition',pg_get_viewdef(c.oid,true)) order by c.relname) from pg_class c where c.relnamespace='public'::regnamespace and c.relkind in('v','m'))
) value) public_catalog),'metadataCatalog',(select value from (select jsonb_build_object('metadataActorRetentionTriggers',(select coalesce(jsonb_agg(jsonb_build_object('table',c.relname,'constraintTable',d.relname,'constraint',k.conname,'function',t.tgfoid::regprocedure::text,'type',t.tgtype,'enabled',t.tgenabled,'internal',t.tgisinternal,'deferrable',t.tgdeferrable,'initiallyDeferred',t.tginitdeferred,'attributes',t.tgattr::text,'arguments',encode(t.tgargs,'hex'),'qual',pg_get_expr(t.tgqual,t.tgrelid)) order by d.relname,c.relname,t.tgfoid::regprocedure::text),'[]') from pg_trigger t join pg_constraint k on k.oid=t.tgconstraint join pg_class c on c.oid=t.tgrelid join pg_class d on d.oid=k.conrelid join pg_namespace n on n.oid=d.relnamespace where n.nspname='public' and starts_with(d.relname,'_work_unit_metadata_') and k.conname='metadata_actor_retention'),'metadataIndexes',(select coalesce(jsonb_agg(jsonb_build_object('name',c.relname,'definition',pg_get_indexdef(c.oid),'unique',i.indisunique,'valid',i.indisvalid,'ready',i.indisready) order by c.relname),'[]') from pg_index i join pg_class c on c.oid=i.indexrelid join pg_class t on t.oid=i.indrelid join pg_namespace n on n.oid=t.relnamespace where n.nspname='public' and starts_with(t.relname,'_work_unit_metadata_')),'metadataNamespaceTypes',(select coalesce(jsonb_agg(jsonb_build_object('name',t.typname,'kind',t.typtype,'relation',c.relname) order by t.typname),'[]') from pg_type t join pg_namespace n on n.oid=t.typnamespace left join pg_class c on c.oid=t.typrelid where n.nspname='public' and (starts_with(t.typname,'_work_unit_metadata_') or starts_with(t.typname,'work_unit_metadata_'))),'namespaceRelations',(select coalesce(jsonb_agg(jsonb_build_object('name',c.relname,'kind',c.relkind) order by c.relname),'[]') from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and (starts_with(c.relname,'_work_unit_contributors_') or starts_with(c.relname,'_work_unit_metadata_') or starts_with(c.relname,'work_unit_metadata_'))),'namespace',(select coalesce(jsonb_agg(jsonb_build_object('name',p.proname,'args',pg_get_function_identity_arguments(p.oid)) order by p.proname,pg_get_function_identity_arguments(p.oid)),'[]') from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and (p.proname='work_unit_contributors_read' or (starts_with(p.proname,'_work_unit_contributors_') or starts_with(p.proname,'_work_unit_metadata_') or starts_with(p.proname,'work_unit_metadata_') or p.proname=any(array['work_unit_metadata_read','work_unit_metadata_command','work_unit_metadata_receipt','work_unit_cohorts_read'])))),
 'functions',(select jsonb_agg(jsonb_build_object('name',p.proname,'args',pg_get_function_identity_arguments(p.oid),'language',(select lanname from pg_language where oid=p.prolang),'kind',p.prokind,'result',pg_get_function_result(p.oid),'defaults',pg_get_expr(p.proargdefaults,0),'strict',p.proisstrict,'parallel',p.proparallel,'leakproof',p.proleakproof,'cost',p.procost,'rows',p.prorows,'support',p.prosupport::regprocedure::text,'setReturning',p.proretset,'rawAcl',p.proacl::text,'body',encode(sha256(convert_to(p.prosrc,'UTF8')),'hex'),'config',p.proconfig,'owner',pg_get_userbyid(p.proowner),'definer',p.prosecdef,'volatility',p.provolatile) order by p.proname,pg_get_function_identity_arguments(p.oid)) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname=any(array['_ai_job_visible','_is_lead','_is_supervisor','_work_activity_actor','_work_activity_answers','_work_activity_authority_changed','_work_activity_authority_guard','_work_activity_authority_revision','_work_activity_bookkeeping_guard','_work_activity_claim_clock_setup','_work_activity_clock_replay_guard','_work_activity_clock_review','_work_activity_clock_setup_digest','_work_activity_close_all','_work_activity_close_source','_work_activity_command_basis','_work_activity_consume','_work_activity_context_assert','_work_activity_context_close','_work_activity_context_commit_guard','_work_activity_context_for','_work_activity_context_guard','_work_activity_context_open','_work_activity_ensure_state','_work_activity_ephemeral_commit_guard','_work_activity_establish_payload','_work_activity_establish_stream','_work_activity_event','_work_activity_evidence','_work_activity_expect','_work_activity_expected_guard','_work_activity_fact_snapshot','_work_activity_finish','_work_activity_gate','_work_activity_insert_source','_work_activity_instant','_work_activity_integer','_work_activity_iso','_work_activity_keep_clock_receipt','_work_activity_live_sources','_work_activity_no_truncate','_work_activity_object','_work_activity_observe','_work_activity_operation','_work_activity_operation_enter','_work_activity_operation_exit','_work_activity_parent_gate','_work_activity_parent_source_history','_work_activity_payload','_work_activity_profile_delete_guard','_work_activity_project_view','_work_activity_read_committed','_work_activity_refresh_state','_work_activity_resume','_work_activity_retain_source','_work_activity_review_visit','_work_activity_row_allowance','_work_activity_row_before','_work_activity_row_event','_work_activity_safety_exit','_work_activity_safety_guard','_work_activity_setup_guard','_work_activity_setup_ledger_guard','_work_activity_shift_lifecycle','_work_activity_source_material','_work_activity_source_view','_work_activity_start_setup','_work_activity_statement_begin','_work_activity_statement_end','_work_activity_stream_guard','_work_activity_touch','_work_activity_transition_source_guard','_work_activity_unit_basis','_work_activity_uuid','_work_activity_validate_switch','_work_config_can_manage_menu','_work_config_internal','_work_config_is_foreman','_work_config_is_owner','_work_config_is_supervisor','_work_config_replay','_work_config_store_receipt','_work_config_validate_menu_draft_items','_work_config_validate_typed_fields','_work_totals_capture','_work_totals_coverage','_work_totals_shift','_work_totals_source','_work_totals_visible','_work_unit_contributors_coverage','_work_unit_contributors_person','_work_unit_contributors_shift','_work_unit_fact_bump_epoch','_work_unit_fact_context_visible','_work_unit_fact_peek_epoch','_work_unit_metadata_aggregate','_work_unit_metadata_area','_work_unit_metadata_area_add','_work_unit_metadata_basis','_work_unit_metadata_binding','_work_unit_metadata_bucket','_work_unit_metadata_coverage','_work_unit_metadata_decimal','_work_unit_metadata_floor_basis','_work_unit_metadata_fraction','_work_unit_metadata_gate','_work_unit_metadata_immutable','_work_unit_metadata_jobs_visible','_work_unit_metadata_live','_work_unit_metadata_members','_work_unit_metadata_number','_work_unit_metadata_object','_work_unit_metadata_origins','_work_unit_metadata_partition','_work_unit_metadata_person_counts','_work_unit_metadata_ratio','_work_unit_metadata_review','_work_unit_metadata_scope','_work_unit_metadata_shift_ids','_work_unit_metadata_state','_work_unit_metadata_sum_bucket','_work_unit_metadata_uuid','_work_unit_metadata_validate_definition','_work_unit_metadata_validate_values','_work_unit_metadata_version','_work_unit_review_authority','_work_unit_review_coverage','_work_unit_review_defect_projection','_work_unit_review_scope','_work_unit_review_view','attach_sandbox_guards','clock_in','clock_out','custom_work_internal','end_break','guard_test_account_sandbox_only','is_partner_user','is_sandbox_project','is_test_profile','person_record_counts','row_project_id','sandbox_scoped_tables','service_job_access','shift_cap_hours','start_break','work_activity_command','work_activity_snapshot','work_activity_totals_read','work_capture_immutable_record','work_publish_activity_version','work_publish_menu_version','work_select_job_menu','work_unit_cohorts_read','work_unit_contributors_read','work_unit_metadata_command','work_unit_metadata_read','work_unit_metadata_receipt'])),
 'triggers',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',t.tgname,'definition',pg_get_triggerdef(t.oid,true),'enabled',t.tgenabled) order by c.relname,t.tgname) from pg_trigger t join pg_class c on c.oid=t.tgrelid join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract']) and not t.tgisinternal),
 'columns',(select jsonb_agg(jsonb_build_object('table',c.relname,'column',a.attname,'type',format_type(a.atttypid,a.atttypmod),'nullable',not a.attnotnull,'default',(select pg_get_expr(d.adbin,d.adrelid) from pg_attrdef d where d.adrelid=a.attrelid and d.adnum=a.attnum),'collation',a.attcollation::regcollation::text,'rawAcl',a.attacl::text,'notNullValidated',coalesce(nn.validated,true),'notNullEnforced',coalesce(nn.enforced,true),'notNullNoInherit',coalesce(nn.no_inherit,false),'generated',a.attgenerated,'identity',a.attidentity) order by c.relname,a.attnum) from pg_class c join pg_namespace n on n.oid=c.relnamespace join pg_attribute a on a.attrelid=c.oid and a.attnum>0 and not a.attisdropped left join lateral (select bool_and(k.convalidated) validated,bool_and(coalesce((to_jsonb(k)->>'conenforced')::boolean,true)) enforced,bool_or(k.connoinherit) no_inherit from pg_constraint k where k.conrelid=a.attrelid and k.contype='n' and a.attnum=any(k.conkey)) nn on true where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract'])),
 'functionAccess',(select jsonb_agg(jsonb_build_object('name',p.proname,'args',pg_get_function_identity_arguments(p.oid),'role',r.rolname,'execute',has_function_privilege(r.oid,p.oid,'EXECUTE')) order by p.proname,pg_get_function_identity_arguments(p.oid),r.rolname) from pg_proc p join pg_namespace n on n.oid=p.pronamespace cross join pg_roles r where n.nspname='public' and p.proname=any(array['_ai_job_visible','_is_lead','_is_supervisor','_work_activity_actor','_work_activity_answers','_work_activity_authority_changed','_work_activity_authority_guard','_work_activity_authority_revision','_work_activity_bookkeeping_guard','_work_activity_claim_clock_setup','_work_activity_clock_replay_guard','_work_activity_clock_review','_work_activity_clock_setup_digest','_work_activity_close_all','_work_activity_close_source','_work_activity_command_basis','_work_activity_consume','_work_activity_context_assert','_work_activity_context_close','_work_activity_context_commit_guard','_work_activity_context_for','_work_activity_context_guard','_work_activity_context_open','_work_activity_ensure_state','_work_activity_ephemeral_commit_guard','_work_activity_establish_payload','_work_activity_establish_stream','_work_activity_event','_work_activity_evidence','_work_activity_expect','_work_activity_expected_guard','_work_activity_fact_snapshot','_work_activity_finish','_work_activity_gate','_work_activity_insert_source','_work_activity_instant','_work_activity_integer','_work_activity_iso','_work_activity_keep_clock_receipt','_work_activity_live_sources','_work_activity_no_truncate','_work_activity_object','_work_activity_observe','_work_activity_operation','_work_activity_operation_enter','_work_activity_operation_exit','_work_activity_parent_gate','_work_activity_parent_source_history','_work_activity_payload','_work_activity_profile_delete_guard','_work_activity_project_view','_work_activity_read_committed','_work_activity_refresh_state','_work_activity_resume','_work_activity_retain_source','_work_activity_review_visit','_work_activity_row_allowance','_work_activity_row_before','_work_activity_row_event','_work_activity_safety_exit','_work_activity_safety_guard','_work_activity_setup_guard','_work_activity_setup_ledger_guard','_work_activity_shift_lifecycle','_work_activity_source_material','_work_activity_source_view','_work_activity_start_setup','_work_activity_statement_begin','_work_activity_statement_end','_work_activity_stream_guard','_work_activity_touch','_work_activity_transition_source_guard','_work_activity_unit_basis','_work_activity_uuid','_work_activity_validate_switch','_work_config_can_manage_menu','_work_config_internal','_work_config_is_foreman','_work_config_is_owner','_work_config_is_supervisor','_work_config_replay','_work_config_store_receipt','_work_config_validate_menu_draft_items','_work_config_validate_typed_fields','_work_totals_capture','_work_totals_coverage','_work_totals_shift','_work_totals_source','_work_totals_visible','_work_unit_contributors_coverage','_work_unit_contributors_person','_work_unit_contributors_shift','_work_unit_fact_bump_epoch','_work_unit_fact_context_visible','_work_unit_fact_peek_epoch','_work_unit_metadata_aggregate','_work_unit_metadata_area','_work_unit_metadata_area_add','_work_unit_metadata_basis','_work_unit_metadata_binding','_work_unit_metadata_bucket','_work_unit_metadata_coverage','_work_unit_metadata_decimal','_work_unit_metadata_floor_basis','_work_unit_metadata_fraction','_work_unit_metadata_gate','_work_unit_metadata_immutable','_work_unit_metadata_jobs_visible','_work_unit_metadata_live','_work_unit_metadata_members','_work_unit_metadata_number','_work_unit_metadata_object','_work_unit_metadata_origins','_work_unit_metadata_partition','_work_unit_metadata_person_counts','_work_unit_metadata_ratio','_work_unit_metadata_review','_work_unit_metadata_scope','_work_unit_metadata_shift_ids','_work_unit_metadata_state','_work_unit_metadata_sum_bucket','_work_unit_metadata_uuid','_work_unit_metadata_validate_definition','_work_unit_metadata_validate_values','_work_unit_metadata_version','_work_unit_review_authority','_work_unit_review_coverage','_work_unit_review_defect_projection','_work_unit_review_scope','_work_unit_review_view','attach_sandbox_guards','clock_in','clock_out','custom_work_internal','end_break','guard_test_account_sandbox_only','is_partner_user','is_sandbox_project','is_test_profile','person_record_counts','row_project_id','sandbox_scoped_tables','service_job_access','shift_cap_hours','start_break','work_activity_command','work_activity_snapshot','work_activity_totals_read','work_capture_immutable_record','work_publish_activity_version','work_publish_menu_version','work_select_job_menu','work_unit_cohorts_read','work_unit_contributors_read','work_unit_metadata_command','work_unit_metadata_read','work_unit_metadata_receipt','_work_unit_contributors_coverage','_work_unit_metadata_coverage']) and r.rolname in('anon','authenticated','service_role')),
 'privateAccess',(select jsonb_agg(jsonb_build_object('table',c.relname,'role',r.rolname,'privilege',v.name,'allowed',has_table_privilege(r.oid,c.oid,v.name)) order by c.relname,r.rolname,v.name) from pg_class c join pg_namespace n on n.oid=c.relnamespace cross join pg_roles r cross join (values('SELECT'),('INSERT'),('UPDATE'),('DELETE'),('TRUNCATE'),('REFERENCES'),('TRIGGER')) v(name) where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract','_work_unit_review_live_sources']) and r.rolname in('anon','authenticated','service_role')),
 -- Effective access includes table-derived rights, role inheritance and PUBLIC.
 'columnAccess',(select jsonb_agg(jsonb_build_object('table',c.relname,'role',r.rolname,'privilege',v.name,'allowed',has_any_column_privilege(r.oid,c.oid,v.name)) order by c.relname,r.rolname,v.name) from pg_class c join pg_namespace n on n.oid=c.relnamespace cross join pg_roles r cross join (values('SELECT'),('INSERT'),('UPDATE'),('REFERENCES')) v(name) where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract','_work_unit_review_live_sources']) and r.rolname in('anon','authenticated','service_role')),
 'constraints',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',k.conname,'definition',pg_get_constraintdef(k.oid,true),'validated',k.convalidated,'enforced',coalesce((to_jsonb(k)->>'conenforced')::boolean,true),'deferrable',k.condeferrable,'deferred',k.condeferred) order by c.relname,k.conname) from pg_constraint k join pg_class c on c.oid=k.conrelid join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and k.contype<>'n' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract'])),
 'policies',(select jsonb_agg(jsonb_build_object('table',tablename,'name',policyname,'permissive',permissive,'roles',roles,'command',cmd,'using',qual,'check',with_check) order by tablename,policyname) from pg_policies where schemaname='public' and tablename=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract'])),
 'view',pg_get_viewdef('public._work_unit_review_live_sources'::regclass,true),
 'tables',(select jsonb_agg(jsonb_build_object('table',c.relname,'rls',c.relrowsecurity,'forcedRls',c.relforcerowsecurity,'kind',c.relkind,'persistence',c.relpersistence,'rawAcl',c.relacl::text,'owner',pg_get_userbyid(c.relowner)) order by c.relname) from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract']))
) value) metadata_catalog)) value
)c;
 return (select count(*)=1 and bool_and(proof_key='cross_job_kernel_2' and expected_catalog_sha256=actual) from public.work_cross_job_contract)
  and (select count(*)=1 and bool_and(proof_key='metadata_v1' and expected_catalog_sha256=actual) from public._work_unit_metadata_contract);
end;
$combined_coverage$;
revoke all on function public._work_cross_job_coverage() from public,anon,authenticated,service_role;
create or replace function public._work_unit_review_coverage() returns boolean language sql stable security definer set search_path=public,pg_temp as $$
 select (coalesce((select p.prosrc is not null and encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='b678eca76a31edbf88408302379013b762eea5b2f50d4bdd3a8ebebc55e2f3ea' and pg_get_userbyid(p.proowner)='postgres' and p.proacl::text='{postgres=X/postgres}' and p.prosecdef and p.proconfig=array['search_path=public, pg_temp']::text[] and p.provolatile='s' and not p.proisstrict and not p.proleakproof and p.proparallel='u' and p.prokind='f' and not p.proretset and p.prorettype='boolean'::regtype and p.pronargs=0 and p.pronargdefaults=0 and p.procost=100 and p.prorows=0 and p.prosupport=0 and p.prolang=(select oid from pg_language where lanname='plpgsql') from pg_proc p where p.oid=to_regprocedure('public._work_cross_job_coverage()')),false) and public._work_cross_job_coverage()) and not exists(select 1 from public.work_cross_job_shifts)
$$;
revoke all on function public._work_unit_review_coverage() from public,anon,authenticated,service_role;
create or replace function public._work_totals_coverage() returns boolean language sql stable security definer set search_path=public,pg_temp as $$
 select (coalesce((select p.prosrc is not null and encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='b678eca76a31edbf88408302379013b762eea5b2f50d4bdd3a8ebebc55e2f3ea' and pg_get_userbyid(p.proowner)='postgres' and p.proacl::text='{postgres=X/postgres}' and p.prosecdef and p.proconfig=array['search_path=public, pg_temp']::text[] and p.provolatile='s' and not p.proisstrict and not p.proleakproof and p.proparallel='u' and p.prokind='f' and not p.proretset and p.prorettype='boolean'::regtype and p.pronargs=0 and p.pronargdefaults=0 and p.procost=100 and p.prorows=0 and p.prosupport=0 and p.prolang=(select oid from pg_language where lanname='plpgsql') from pg_proc p where p.oid=to_regprocedure('public._work_cross_job_coverage()')),false) and public._work_cross_job_coverage()) and not exists(select 1 from public.work_cross_job_shifts)
$$;
revoke all on function public._work_totals_coverage() from public,anon,authenticated,service_role;
create or replace function public._work_unit_contributors_coverage() returns boolean language sql stable security definer set search_path=public,pg_temp as $$
 select (coalesce((select p.prosrc is not null and encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='b678eca76a31edbf88408302379013b762eea5b2f50d4bdd3a8ebebc55e2f3ea' and pg_get_userbyid(p.proowner)='postgres' and p.proacl::text='{postgres=X/postgres}' and p.prosecdef and p.proconfig=array['search_path=public, pg_temp']::text[] and p.provolatile='s' and not p.proisstrict and not p.proleakproof and p.proparallel='u' and p.prokind='f' and not p.proretset and p.prorettype='boolean'::regtype and p.pronargs=0 and p.pronargdefaults=0 and p.procost=100 and p.prorows=0 and p.prosupport=0 and p.prolang=(select oid from pg_language where lanname='plpgsql') from pg_proc p where p.oid=to_regprocedure('public._work_cross_job_coverage()')),false) and public._work_cross_job_coverage()) and not exists(select 1 from public.work_cross_job_shifts)
$$;
revoke all on function public._work_unit_contributors_coverage() from public,anon,authenticated,service_role;

-- Explicit frozen function ACLs for static review; no privilege expansion.
revoke all on function public._work_cross_job_enabled() from public, anon, authenticated, service_role;
revoke all on function public._work_cross_job_table(text) from public, anon, authenticated, service_role;
revoke all on function public._work_cross_job_history(text, uuid) from public, anon, authenticated, service_role;
revoke all on function public._work_cross_job_scope(uuid, uuid, boolean) from public, anon, authenticated, service_role;
revoke all on function public._work_cross_job_register(time_shifts, uuid) from public, anon, authenticated, service_role;
revoke all on function public._work_cross_job_birth_guard(text, jsonb, jsonb) from public, anon, authenticated, service_role;
revoke all on function public._work_cross_job_bind(text, uuid, uuid, uuid, timestamp with time zone, uuid) from public, anon, authenticated, service_role;
revoke all on function public._work_cross_job_local_valid(text, jsonb, time_shifts) from public, anon, authenticated, service_role;
revoke all on function public._work_cross_job_custom(uuid, time_shifts, uuid, jsonb, timestamp with time zone, text, uuid) from public, anon, authenticated, service_role;
revoke all on function public._work_cross_job_save(personal_activity_state, uuid, timestamp with time zone, uuid) from public, anon, authenticated, service_role;
revoke all on function public._work_cross_job_resume_basis(personal_activity_state, time_shifts, timestamp with time zone) from public, anon, authenticated, service_role;
revoke all on function public.custom_work_follow_shift() from public, anon, authenticated;
grant execute on function public.custom_work_follow_shift() to service_role;
revoke all on function public.service_follow_shift() from public, anon, authenticated;
grant execute on function public.service_follow_shift() to service_role;
revoke all on function public._work_cross_job_source(uuid, time_shifts, uuid, text, jsonb, timestamp with time zone, text, uuid) from public, anon, authenticated, service_role;
revoke all on function public._work_cross_job_head_valid(uuid) from public, anon, authenticated, service_role;
revoke all on function public._work_cross_job_allocation_guard() from public, anon, authenticated, service_role;
revoke all on function public._work_cross_job_clock_receipt_fingerprint(work_activity_clock_receipts) from public, anon, authenticated, service_role;
revoke all on function public._work_cross_job_clock_request_admit() from public, anon, authenticated, service_role;
revoke all on function public._work_cross_job_clock_request_stamp() from public, anon, authenticated, service_role;
revoke all on function public._work_activity_row_before() from public, anon, authenticated, service_role;
revoke all on function public._work_activity_operation_exit(uuid) from public, anon, authenticated, service_role;
revoke all on function public._work_activity_start_setup(time_shifts, uuid, uuid) from public, anon, authenticated, service_role;
revoke all on function public._work_activity_shift_lifecycle() from public, anon, authenticated, service_role;
revoke all on function public._work_activity_resume(personal_activity_state, time_shifts, timestamp with time zone) from public, anon, authenticated, service_role;
revoke all on function public.clock_in(uuid, uuid, text, double precision, double precision, text, text, uuid, timestamp with time zone, timestamp with time zone, integer, integer) from public, anon, service_role;
grant execute on function public.clock_in(uuid, uuid, text, double precision, double precision, text, text, uuid, timestamp with time zone, timestamp with time zone, integer, integer) to authenticated;
revoke all on function public._work_activity_claim_clock_setup(uuid, uuid, text, double precision, double precision, text, text, uuid, timestamp with time zone, timestamp with time zone, integer) from public, anon, authenticated, service_role;
revoke all on function public.work_activity_command(uuid, integer, jsonb) from public, anon, service_role;
grant execute on function public.work_activity_command(uuid, integer, jsonb) to authenticated;
revoke all on function public.work_activity_snapshot(uuid) from public, anon, service_role;
grant execute on function public.work_activity_snapshot(uuid) to authenticated;
revoke all on function public.work_cross_job_snapshot(uuid) from public, anon, service_role;
grant execute on function public.work_cross_job_snapshot(uuid) to authenticated;
revoke all on function public.work_activity_command_receipt(uuid) from public, anon, service_role;
grant execute on function public.work_activity_command_receipt(uuid) to authenticated;
revoke all on function public.work_cross_job_receipt(uuid) from public, anon, service_role;
grant execute on function public.work_cross_job_receipt(uuid) to authenticated;
revoke all on function public._work_activity_clock_replay_guard(uuid, text, uuid) from public, anon, authenticated, service_role;
revoke all on function public.work_activity_clock_receipt(uuid) from public, anon, service_role;
grant execute on function public.work_activity_clock_receipt(uuid) to authenticated;
revoke all on function public._work_activity_clock_contract_marker() from public, anon, authenticated, service_role;
revoke all on function public.work_activity_clock_capability() from public, anon, service_role;
grant execute on function public.work_activity_clock_capability() to authenticated;
revoke all on function public.person_record_counts(uuid) from public, anon, authenticated;
grant execute on function public.person_record_counts(uuid) to service_role;
revoke all on function public._work_cross_job_coverage() from public, anon, authenticated, service_role;
revoke all on function public._work_unit_review_coverage() from public, anon, authenticated, service_role;
revoke all on function public._work_totals_coverage() from public, anon, authenticated, service_role;
revoke all on function public._work_unit_contributors_coverage() from public, anon, authenticated, service_role;

-- METADATA DDL AFTER BOTH ORIGINAL PREFLIGHTS
create table public._work_unit_metadata_definitions(
 id uuid primary key,kind text not null check(kind in ('category','subtype','material','component','field','floor','group')),
 code text not null check(code ~ '^[a-z][a-z0-9_]{0,79}$'),project_id uuid,actor_id uuid not null,recorded_at timestamptz not null default clock_timestamp(),
 check((kind='floor')=(project_id is not null))
);
create unique index work_unit_metadata_definition_global on public._work_unit_metadata_definitions(kind,code) where project_id is null;
create unique index work_unit_metadata_definition_project on public._work_unit_metadata_definitions(project_id,kind,code) where project_id is not null;
create table public._work_unit_metadata_versions(
 id uuid primary key,definition_id uuid not null references public._work_unit_metadata_definitions(id),version integer not null check(version>0),
 predecessor_id uuid references public._work_unit_metadata_versions(id),state text not null check(state in ('published','retired')),
 value jsonb not null check(jsonb_typeof(value)='object' and octet_length(value::text)<=24000),actor_id uuid not null,command_id uuid not null,recorded_at timestamptz not null default clock_timestamp(),unique(definition_id,version)
);
create table public._work_unit_metadata_proposals(
 id uuid primary key,actor_id uuid not null,command_id uuid not null,project_id uuid,value jsonb not null check(jsonb_typeof(value)='object' and octet_length(value::text)<=32768),recorded_at timestamptz not null default clock_timestamp()
);
create table public._work_unit_metadata_revisions(
 id uuid primary key,unit_id uuid not null,incarnation bigint not null check(incarnation between 0 and 9007199254740991),revision integer not null check(revision>0),
 predecessor_id uuid references public._work_unit_metadata_revisions(id),binding jsonb not null,origin_jobs jsonb not null,
 value jsonb not null check(jsonb_typeof(value)='object' and octet_length(value::text)<=24000),observed_fact_id uuid,
 actor_id uuid not null,command_id uuid not null,recorded_at timestamptz not null default clock_timestamp(),unique(unit_id,revision)
);
create table public._work_unit_metadata_current(unit_id uuid primary key,revision_id uuid not null references public._work_unit_metadata_revisions(id));
create table public._work_unit_metadata_floors(
 id uuid primary key,unit_id uuid not null,incarnation bigint not null check(incarnation between 0 and 9007199254740991),revision integer not null check(revision>0),
 predecessor_id uuid references public._work_unit_metadata_floors(id),basis jsonb not null,origin_jobs jsonb not null,
 state text not null check(state in ('unknown','unallocated','single','multilevel')),shares jsonb not null check(jsonb_typeof(shares)='array' and jsonb_array_length(shares)<=32),
 reason text not null check(length(btrim(reason)) between 3 and 500),actor_id uuid not null,command_id uuid not null,recorded_at timestamptz not null default clock_timestamp(),unique(unit_id,revision)
);
create table public._work_unit_metadata_floor_current(unit_id uuid primary key,revision_id uuid not null references public._work_unit_metadata_floors(id));
create table public._work_unit_metadata_commands(
 command_id uuid primary key,actor_id uuid not null,unit_id uuid,unit_binding jsonb,project_id uuid,origin_jobs jsonb not null,
 check((unit_id is null and unit_binding is null) or (unit_id is not null and unit_binding is not null and jsonb_typeof(unit_binding)='object' and unit_binding->>'unitId'=unit_id::text)),
 request jsonb not null check(jsonb_typeof(request)='object' and octet_length(request::text)<=32768),result jsonb not null,
 recorded_at timestamptz not null default clock_timestamp()
);

-- Actor history keeps the named profile. RESTRICT never erases or detaches evidence.
alter table public._work_unit_metadata_definitions add constraint metadata_actor_retention foreign key(actor_id) references public.profiles(id) on delete restrict not deferrable;
create index work_unit_metadata_actor_definitions on public._work_unit_metadata_definitions(actor_id);
alter table public._work_unit_metadata_versions add constraint metadata_actor_retention foreign key(actor_id) references public.profiles(id) on delete restrict not deferrable;
create index work_unit_metadata_actor_versions on public._work_unit_metadata_versions(actor_id);
alter table public._work_unit_metadata_proposals add constraint metadata_actor_retention foreign key(actor_id) references public.profiles(id) on delete restrict not deferrable;
create index work_unit_metadata_actor_proposals on public._work_unit_metadata_proposals(actor_id);
alter table public._work_unit_metadata_revisions add constraint metadata_actor_retention foreign key(actor_id) references public.profiles(id) on delete restrict not deferrable;
create index work_unit_metadata_actor_revisions on public._work_unit_metadata_revisions(actor_id);
alter table public._work_unit_metadata_floors add constraint metadata_actor_retention foreign key(actor_id) references public.profiles(id) on delete restrict not deferrable;
create index work_unit_metadata_actor_floors on public._work_unit_metadata_floors(actor_id);
alter table public._work_unit_metadata_commands add constraint metadata_actor_retention foreign key(actor_id) references public.profiles(id) on delete restrict not deferrable;
create index work_unit_metadata_actor_commands on public._work_unit_metadata_commands(actor_id);

create index work_unit_metadata_commands_unit on public._work_unit_metadata_commands(unit_id) where unit_id is not null;

create table public._work_unit_metadata_contract(proof_key text primary key check(proof_key='metadata_v1'),expected_catalog_sha256 text not null check(expected_catalog_sha256 ~ '^[0-9a-f]{64}$'));

create function public._work_unit_metadata_immutable() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
begin raise exception using errcode='23514',message='Unit metadata history is immutable.';end$$;
create function public._work_unit_metadata_gate() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
begin perform public._work_activity_read_committed();perform public._work_activity_gate();perform pg_advisory_xact_lock(7710,0);return null;end$$;
-- METADATA_TABLE_CONTROLS_BEGIN
alter table public._work_unit_metadata_definitions enable row level security;
revoke all on table public._work_unit_metadata_definitions from public,anon,authenticated,service_role;
create trigger metadata_gate before insert or update or delete or truncate on public._work_unit_metadata_definitions for each statement execute function public._work_unit_metadata_gate();
create trigger metadata_immutable before update or delete or truncate on public._work_unit_metadata_definitions for each statement execute function public._work_unit_metadata_immutable();
alter table public._work_unit_metadata_versions enable row level security;
revoke all on table public._work_unit_metadata_versions from public,anon,authenticated,service_role;
create trigger metadata_gate before insert or update or delete or truncate on public._work_unit_metadata_versions for each statement execute function public._work_unit_metadata_gate();
create trigger metadata_immutable before update or delete or truncate on public._work_unit_metadata_versions for each statement execute function public._work_unit_metadata_immutable();
alter table public._work_unit_metadata_proposals enable row level security;
revoke all on table public._work_unit_metadata_proposals from public,anon,authenticated,service_role;
create trigger metadata_gate before insert or update or delete or truncate on public._work_unit_metadata_proposals for each statement execute function public._work_unit_metadata_gate();
create trigger metadata_immutable before update or delete or truncate on public._work_unit_metadata_proposals for each statement execute function public._work_unit_metadata_immutable();
alter table public._work_unit_metadata_revisions enable row level security;
revoke all on table public._work_unit_metadata_revisions from public,anon,authenticated,service_role;
create trigger metadata_gate before insert or update or delete or truncate on public._work_unit_metadata_revisions for each statement execute function public._work_unit_metadata_gate();
create trigger metadata_immutable before update or delete or truncate on public._work_unit_metadata_revisions for each statement execute function public._work_unit_metadata_immutable();
alter table public._work_unit_metadata_current enable row level security;
revoke all on table public._work_unit_metadata_current from public,anon,authenticated,service_role;
create trigger metadata_gate before insert or update or delete or truncate on public._work_unit_metadata_current for each statement execute function public._work_unit_metadata_gate();
alter table public._work_unit_metadata_floors enable row level security;
revoke all on table public._work_unit_metadata_floors from public,anon,authenticated,service_role;
create trigger metadata_gate before insert or update or delete or truncate on public._work_unit_metadata_floors for each statement execute function public._work_unit_metadata_gate();
create trigger metadata_immutable before update or delete or truncate on public._work_unit_metadata_floors for each statement execute function public._work_unit_metadata_immutable();
alter table public._work_unit_metadata_floor_current enable row level security;
revoke all on table public._work_unit_metadata_floor_current from public,anon,authenticated,service_role;
create trigger metadata_gate before insert or update or delete or truncate on public._work_unit_metadata_floor_current for each statement execute function public._work_unit_metadata_gate();
alter table public._work_unit_metadata_commands enable row level security;
revoke all on table public._work_unit_metadata_commands from public,anon,authenticated,service_role;
create trigger metadata_gate before insert or update or delete or truncate on public._work_unit_metadata_commands for each statement execute function public._work_unit_metadata_gate();
create trigger metadata_immutable before update or delete or truncate on public._work_unit_metadata_commands for each statement execute function public._work_unit_metadata_immutable();
alter table public._work_unit_metadata_contract enable row level security;
revoke all on table public._work_unit_metadata_contract from public,anon,authenticated,service_role;
create trigger metadata_gate before insert or update or delete or truncate on public._work_unit_metadata_contract for each statement execute function public._work_unit_metadata_gate();
-- METADATA_TABLE_CONTROLS_END

-- Refuse any unrelated repair: the existing attacher may add only these three
-- newly constructed project-scoped tables. No old trigger is normalized.
do $metadata_sandbox$ begin
 if exists(select 1 from public.sandbox_scoped_tables() s where s.table_name not in ('_work_unit_metadata_commands','_work_unit_metadata_definitions','_work_unit_metadata_proposals') and not exists(
 select 1 from pg_trigger t join pg_class c on c.oid=t.tgrelid join pg_namespace n on n.oid=c.relnamespace
 where n.nspname='public' and c.relname=s.table_name and t.tgname='guard_test_account_sandbox_only' and not t.tgisinternal
 and t.tgfoid='public.guard_test_account_sandbox_only()'::regprocedure and t.tgtype=31 and t.tgenabled in ('O','A')
 and t.tgargs=convert_to(s.link_column,'UTF8')||decode('00','hex')||convert_to(s.link_kind,'UTF8')||decode('00','hex'))) then
 raise exception using errcode='55000',message='Unit metadata sandbox source is unavailable.';end if;
end $metadata_sandbox$;
select public.attach_sandbox_guards();

create function public._work_unit_metadata_object(v jsonb,required text[],optional text[] default '{}') returns boolean
language sql immutable set search_path=public,pg_temp as $$
 select case when jsonb_typeof(v)='object' then v?&required and not exists(select 1 from jsonb_object_keys(v) k where not k=any(required||optional)) else false end
$$;
create function public._work_unit_metadata_decimal(v jsonb,positive boolean default false) returns numeric
language plpgsql immutable set search_path=public,pg_temp as $$
declare s text;n numeric;begin
 if jsonb_typeof(v) is distinct from 'string' then raise exception using errcode='23514',message='Invalid exact decimal.';end if;
 s:=v#>>'{}';if length(s) not between 1 and 100 or s!~'^[0-9]+([.][0-9]+)?$' then raise exception using errcode='23514',message='Invalid exact decimal.';end if;
 n:=s::numeric;if positive and n<=0 then raise exception using errcode='23514',message='A positive exact decimal is required.';end if;return n;end$$;
create function public._work_unit_metadata_uuid(v jsonb) returns uuid language plpgsql immutable set search_path=public,pg_temp as $$
begin if jsonb_typeof(v) is distinct from 'string' or (v#>>'{}')!~'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then raise exception using errcode='23514',message='Invalid metadata identity.';end if;return (v#>>'{}')::uuid;end$$;
create function public._work_unit_metadata_binding(p_unit uuid) returns jsonb language sql stable security definer set search_path=public,pg_temp as $$
 select jsonb_build_object('unitId',u.id,'incarnation',public._work_unit_fact_peek_epoch('unit_incarnation',u.id)::text,
 'projectId',u.project_id,'openingId',u.opening_id,'authorId',u.created_by,'authorIsTest',public.is_test_profile(u.created_by),'bindingEpoch',public._work_unit_fact_peek_epoch('unit_binding',u.id)::text,
 'projectEpoch',case when u.project_id is null then null else public._work_unit_fact_peek_epoch('project',u.project_id)::text end,
 'openingEpoch',case when u.opening_id is null then null else public._work_unit_fact_peek_epoch('opening',u.opening_id)::text end)
 from public.custom_work_units u where u.id=p_unit
$$;
create function public._work_unit_metadata_jobs_visible(actor uuid,jobs jsonb) returns boolean language plpgsql stable security definer set search_path=public,pg_temp as $$
declare j jsonb;begin if jsonb_typeof(jobs) is distinct from 'array' then return false;end if;for j in select value from jsonb_array_elements(jobs) loop
 if not public._ai_job_visible((j#>>'{}')::uuid,actor) then return false;end if;end loop;return true;end$$;
create function public._work_unit_metadata_origins(actor uuid,p_unit uuid) returns boolean language plpgsql stable security definer set search_path=public,pg_temp as $$
declare jobs jsonb;origin jsonb;begin
 for jobs in select origin_jobs from public._work_unit_metadata_revisions where unit_id=p_unit
 union all select origin_jobs from public._work_unit_metadata_floors where unit_id=p_unit
 union all select origin_jobs from public._work_unit_metadata_commands where unit_id=p_unit loop
 if not public._work_unit_metadata_jobs_visible(actor,jobs) then return false;end if;end loop;
 for origin in select binding from public._work_unit_metadata_revisions where unit_id=p_unit
 union all select basis->'binding' from public._work_unit_metadata_floors where unit_id=p_unit
 union all select unit_binding from public._work_unit_metadata_commands where unit_id=p_unit loop
 if origin is null or not public._work_unit_fact_context_visible(actor,case when origin->>'projectId' is null then 'unassigned' else 'job' end,
 (origin->>'projectId')::uuid,(origin->>'openingId')::uuid,(origin->>'authorId')::uuid,(origin->>'authorIsTest')::boolean,true) then return false;end if;end loop;
 return true;end$$;
create function public._work_unit_metadata_coverage() returns boolean
language plpgsql stable security definer set search_path=public,pg_temp as $combined_coverage$
declare actual text;
begin
 if current_setting('extra_float_digits') is distinct from '1' then
  return false;
 end if;
 select encode(sha256(convert_to(c.value::text,'UTF8')),'hex') into actual from (
select jsonb_build_object('publicCatalog',(select value from (-- Deliberately closed source-derived public catalog. Unknown live drift refuses;
-- this is not a request to normalize a provider to the disposable fixture.
select jsonb_build_object(
 'types',(select jsonb_agg(jsonb_build_object('name',t.typname,'kind',t.typtype,'owner',pg_get_userbyid(t.typowner),'acl',t.typacl::text,'category',t.typcategory,'preferred',t.typispreferred,'defined',t.typisdefined,'notNull',t.typnotnull,'base',format_type(nullif(t.typbasetype,0),t.typtypmod),'element',format_type(nullif(t.typelem,0),null),'collation',case when t.typcollation<>0 then t.typcollation::regcollation::text end,'default',t.typdefault,'defaultExpression',pg_get_expr(t.typdefaultbin,0),'input',t.typinput::regprocedure::text,'output',t.typoutput::regprocedure::text,'receive',t.typreceive::regprocedure::text,'send',t.typsend::regprocedure::text,'length',t.typlen,'byValue',t.typbyval,'alignment',t.typalign,'storage',t.typstorage,'delimiter',t.typdelim,'access',(select jsonb_object_agg(r.rolname,has_type_privilege(r.oid,t.oid,'USAGE')) from pg_roles r where r.rolname in('anon','authenticated','service_role')),'enum',(select jsonb_agg(jsonb_build_object('label',e.enumlabel,'sort',e.enumsortorder) order by e.enumsortorder) from pg_enum e where e.enumtypid=t.oid),'constraints',(select jsonb_agg(jsonb_build_object('name',k.conname,'definition',pg_get_constraintdef(k.oid,true),'validated',k.convalidated) order by k.conname) from pg_constraint k where k.contypid=t.oid),'range',(select jsonb_build_object('subtype',format_type(r.rngsubtype,null),'collation',r.rngcollation::regcollation::text,'opclass',(select n.nspname||'.'||o.opcname from pg_opclass o join pg_namespace n on n.oid=o.opcnamespace where o.oid=r.rngsubopc),'canonical',r.rngcanonical::regprocedure::text,'subdiff',r.rngsubdiff::regprocedure::text) from pg_range r where r.rngtypid=t.oid)) order by t.typname) from pg_type t where t.typnamespace='public'::regnamespace),
 'sequences',(select jsonb_agg(jsonb_build_object('name',c.relname,'owner',pg_get_userbyid(c.relowner),'acl',c.relacl::text,'type',format_type(s.seqtypid,null),'start',s.seqstart,'increment',s.seqincrement,'max',s.seqmax,'min',s.seqmin,'cache',s.seqcache,'cycle',s.seqcycle,'access',(select jsonb_agg(jsonb_build_object('role',r.rolname,'privilege',v.p,'allowed',has_sequence_privilege(r.oid,c.oid,v.p)) order by r.rolname,v.p) from pg_roles r cross join unnest(array['SELECT','UPDATE','USAGE'])v(p) where r.rolname in('anon','authenticated','service_role'))) order by c.relname) from pg_class c join pg_sequence s on s.seqrelid=c.oid where c.relnamespace='public'::regnamespace),
 'foreignTables',(select jsonb_agg(jsonb_build_object('table',c.relname,'options',f.ftoptions,'server',s.srvname,'serverOwner',pg_get_userbyid(s.srvowner),'serverType',s.srvtype,'serverVersion',s.srvversion,'serverOptionsDigest',encode(sha256(convert_to(coalesce(s.srvoptions::text,''),'UTF8')),'hex'),'serverAcl',s.srvacl::text,'serverAccess',(select jsonb_object_agg(r.rolname,has_server_privilege(r.oid,s.oid,'USAGE')) from pg_roles r where r.rolname in('anon','authenticated','service_role')),'wrapper',w.fdwname,'wrapperOwner',pg_get_userbyid(w.fdwowner),'wrapperAcl',w.fdwacl::text,'wrapperAccess',(select jsonb_object_agg(r.rolname,has_foreign_data_wrapper_privilege(r.oid,w.oid,'USAGE')) from pg_roles r where r.rolname in('anon','authenticated','service_role')),'handler',w.fdwhandler::regprocedure::text,'validator',w.fdwvalidator::regprocedure::text,'wrapperOptionsDigest',encode(sha256(convert_to(coalesce(w.fdwoptions::text,''),'UTF8')),'hex')) order by c.relname) from pg_foreign_table f join pg_class c on c.oid=f.ftrelid join pg_foreign_server s on s.oid=f.ftserver join pg_foreign_data_wrapper w on w.oid=s.srvfdw where c.relnamespace='public'::regnamespace),
 'functions',(select jsonb_agg(jsonb_build_object('name',p.proname,'arguments',pg_get_function_identity_arguments(p.oid),'body',encode(sha256(convert_to(p.prosrc,'UTF8')),'hex'),'result',pg_get_function_result(p.oid),'owner',pg_get_userbyid(p.proowner),'acl',p.proacl::text,'language',l.lanname,'kind',p.prokind,'definer',p.prosecdef,'config',p.proconfig,'volatility',p.provolatile,'strict',p.proisstrict,'leakproof',p.proleakproof,'cost',p.procost,'rows',p.prorows,'support',p.prosupport::regprocedure::text,'parallel',p.proparallel,'defaults',pg_get_expr(p.proargdefaults,0),'access',(select jsonb_object_agg(r.rolname,has_function_privilege(r.oid,p.oid,'EXECUTE')) from pg_roles r where r.rolname in('anon','authenticated','service_role'))) order by p.proname,pg_get_function_identity_arguments(p.oid)) from pg_proc p join pg_language l on l.oid=p.prolang where p.pronamespace='public'::regnamespace and not exists(select 1 from pg_depend d where d.classid='pg_proc'::regclass and d.objid=p.oid and d.deptype='e')),
 'relations',(select jsonb_agg(jsonb_build_object('name',c.relname,'kind',c.relkind,'owner',pg_get_userbyid(c.relowner),'rls',c.relrowsecurity,'forcedRls',c.relforcerowsecurity,'acl',c.relacl::text,'access',(select jsonb_agg(jsonb_build_object('role',r.rolname,'privilege',v.p,'table',has_table_privilege(r.oid,c.oid,v.p),'column',case when v.p in('SELECT','INSERT','UPDATE','REFERENCES') then has_any_column_privilege(r.oid,c.oid,v.p) end) order by r.rolname,v.p) from pg_roles r cross join unnest(array['SELECT','INSERT','UPDATE','DELETE','TRUNCATE','REFERENCES','TRIGGER'])v(p) where r.rolname in('anon','authenticated','service_role'))) order by c.relname) from pg_class c where c.relnamespace='public'::regnamespace and c.relkind in('r','p','v','m','f','c')),
 'columns',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',a.attname,'type',format_type(a.atttypid,a.atttypmod),'notNull',a.attnotnull,'generated',a.attgenerated,'identity',a.attidentity,'acl',a.attacl::text,'default',pg_get_expr(d.adbin,d.adrelid),'access',(select jsonb_agg(jsonb_build_object('role',r.rolname,'privilege',v.p,'allowed',has_column_privilege(r.oid,c.oid,a.attnum,v.p)) order by r.rolname,v.p) from pg_roles r cross join unnest(array['SELECT','INSERT','UPDATE','REFERENCES'])v(p) where r.rolname in('anon','authenticated','service_role'))) order by c.relname,a.attnum) from pg_class c join pg_attribute a on a.attrelid=c.oid and a.attnum>0 and not a.attisdropped left join pg_attrdef d on d.adrelid=c.oid and d.adnum=a.attnum where c.relnamespace='public'::regnamespace and c.relkind in('r','p','v','m','f','c')),
 'constraints',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',k.conname,'definition',pg_get_constraintdef(k.oid,true),'validated',k.convalidated,'noInherit',k.connoinherit,'enforced',coalesce((to_jsonb(k)->>'conenforced')::boolean,true)) order by c.relname,k.conname) from pg_constraint k join pg_class c on c.oid=k.conrelid where c.relnamespace='public'::regnamespace and k.contype<>'n'),
 'notNullConstraints',(select jsonb_agg(jsonb_build_object('table',c.relname,'column',a.attname,'validated',coalesce(n.validated,true),'enforced',coalesce(n.enforced,true),'noInherit',coalesce(n.no_inherit,false)) order by c.relname,a.attnum) from pg_class c join pg_attribute a on a.attrelid=c.oid and a.attnum>0 and not a.attisdropped left join lateral(select bool_and(k.convalidated) validated,bool_and(coalesce((to_jsonb(k)->>'conenforced')::boolean,true)) enforced,bool_or(k.connoinherit) no_inherit from pg_constraint k where k.conrelid=c.oid and k.contype='n' and a.attnum=any(k.conkey))n on true where c.relnamespace='public'::regnamespace and c.relkind in('r','p')),
 'indexes',(select jsonb_agg(jsonb_build_object('table',t.relname,'name',c.relname,'definition',pg_get_indexdef(i.indexrelid),'valid',i.indisvalid,'ready',i.indisready) order by t.relname,c.relname) from pg_index i join pg_class c on c.oid=i.indexrelid join pg_class t on t.oid=i.indrelid where t.relnamespace='public'::regnamespace),
 'triggers',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',t.tgname,'definition',pg_get_triggerdef(t.oid,true),'enabled',t.tgenabled) order by c.relname,t.tgname) from pg_trigger t join pg_class c on c.oid=t.tgrelid where c.relnamespace='public'::regnamespace and not t.tgisinternal),
 'policies',(select jsonb_agg(to_jsonb(p) order by p.tablename,p.policyname) from pg_policies p where schemaname='public'),
 'views',(select jsonb_agg(jsonb_build_object('name',c.relname,'definition',pg_get_viewdef(c.oid,true)) order by c.relname) from pg_class c where c.relnamespace='public'::regnamespace and c.relkind in('v','m'))
) value) public_catalog),'metadataCatalog',(select value from (select jsonb_build_object('metadataActorRetentionTriggers',(select coalesce(jsonb_agg(jsonb_build_object('table',c.relname,'constraintTable',d.relname,'constraint',k.conname,'function',t.tgfoid::regprocedure::text,'type',t.tgtype,'enabled',t.tgenabled,'internal',t.tgisinternal,'deferrable',t.tgdeferrable,'initiallyDeferred',t.tginitdeferred,'attributes',t.tgattr::text,'arguments',encode(t.tgargs,'hex'),'qual',pg_get_expr(t.tgqual,t.tgrelid)) order by d.relname,c.relname,t.tgfoid::regprocedure::text),'[]') from pg_trigger t join pg_constraint k on k.oid=t.tgconstraint join pg_class c on c.oid=t.tgrelid join pg_class d on d.oid=k.conrelid join pg_namespace n on n.oid=d.relnamespace where n.nspname='public' and starts_with(d.relname,'_work_unit_metadata_') and k.conname='metadata_actor_retention'),'metadataIndexes',(select coalesce(jsonb_agg(jsonb_build_object('name',c.relname,'definition',pg_get_indexdef(c.oid),'unique',i.indisunique,'valid',i.indisvalid,'ready',i.indisready) order by c.relname),'[]') from pg_index i join pg_class c on c.oid=i.indexrelid join pg_class t on t.oid=i.indrelid join pg_namespace n on n.oid=t.relnamespace where n.nspname='public' and starts_with(t.relname,'_work_unit_metadata_')),'metadataNamespaceTypes',(select coalesce(jsonb_agg(jsonb_build_object('name',t.typname,'kind',t.typtype,'relation',c.relname) order by t.typname),'[]') from pg_type t join pg_namespace n on n.oid=t.typnamespace left join pg_class c on c.oid=t.typrelid where n.nspname='public' and (starts_with(t.typname,'_work_unit_metadata_') or starts_with(t.typname,'work_unit_metadata_'))),'namespaceRelations',(select coalesce(jsonb_agg(jsonb_build_object('name',c.relname,'kind',c.relkind) order by c.relname),'[]') from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and (starts_with(c.relname,'_work_unit_contributors_') or starts_with(c.relname,'_work_unit_metadata_') or starts_with(c.relname,'work_unit_metadata_'))),'namespace',(select coalesce(jsonb_agg(jsonb_build_object('name',p.proname,'args',pg_get_function_identity_arguments(p.oid)) order by p.proname,pg_get_function_identity_arguments(p.oid)),'[]') from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and (p.proname='work_unit_contributors_read' or (starts_with(p.proname,'_work_unit_contributors_') or starts_with(p.proname,'_work_unit_metadata_') or starts_with(p.proname,'work_unit_metadata_') or p.proname=any(array['work_unit_metadata_read','work_unit_metadata_command','work_unit_metadata_receipt','work_unit_cohorts_read'])))),
 'functions',(select jsonb_agg(jsonb_build_object('name',p.proname,'args',pg_get_function_identity_arguments(p.oid),'language',(select lanname from pg_language where oid=p.prolang),'kind',p.prokind,'result',pg_get_function_result(p.oid),'defaults',pg_get_expr(p.proargdefaults,0),'strict',p.proisstrict,'parallel',p.proparallel,'leakproof',p.proleakproof,'cost',p.procost,'rows',p.prorows,'support',p.prosupport::regprocedure::text,'setReturning',p.proretset,'rawAcl',p.proacl::text,'body',encode(sha256(convert_to(p.prosrc,'UTF8')),'hex'),'config',p.proconfig,'owner',pg_get_userbyid(p.proowner),'definer',p.prosecdef,'volatility',p.provolatile) order by p.proname,pg_get_function_identity_arguments(p.oid)) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname=any(array['_ai_job_visible','_is_lead','_is_supervisor','_work_activity_actor','_work_activity_answers','_work_activity_authority_changed','_work_activity_authority_guard','_work_activity_authority_revision','_work_activity_bookkeeping_guard','_work_activity_claim_clock_setup','_work_activity_clock_replay_guard','_work_activity_clock_review','_work_activity_clock_setup_digest','_work_activity_close_all','_work_activity_close_source','_work_activity_command_basis','_work_activity_consume','_work_activity_context_assert','_work_activity_context_close','_work_activity_context_commit_guard','_work_activity_context_for','_work_activity_context_guard','_work_activity_context_open','_work_activity_ensure_state','_work_activity_ephemeral_commit_guard','_work_activity_establish_payload','_work_activity_establish_stream','_work_activity_event','_work_activity_evidence','_work_activity_expect','_work_activity_expected_guard','_work_activity_fact_snapshot','_work_activity_finish','_work_activity_gate','_work_activity_insert_source','_work_activity_instant','_work_activity_integer','_work_activity_iso','_work_activity_keep_clock_receipt','_work_activity_live_sources','_work_activity_no_truncate','_work_activity_object','_work_activity_observe','_work_activity_operation','_work_activity_operation_enter','_work_activity_operation_exit','_work_activity_parent_gate','_work_activity_parent_source_history','_work_activity_payload','_work_activity_profile_delete_guard','_work_activity_project_view','_work_activity_read_committed','_work_activity_refresh_state','_work_activity_resume','_work_activity_retain_source','_work_activity_review_visit','_work_activity_row_allowance','_work_activity_row_before','_work_activity_row_event','_work_activity_safety_exit','_work_activity_safety_guard','_work_activity_setup_guard','_work_activity_setup_ledger_guard','_work_activity_shift_lifecycle','_work_activity_source_material','_work_activity_source_view','_work_activity_start_setup','_work_activity_statement_begin','_work_activity_statement_end','_work_activity_stream_guard','_work_activity_touch','_work_activity_transition_source_guard','_work_activity_unit_basis','_work_activity_uuid','_work_activity_validate_switch','_work_config_can_manage_menu','_work_config_internal','_work_config_is_foreman','_work_config_is_owner','_work_config_is_supervisor','_work_config_replay','_work_config_store_receipt','_work_config_validate_menu_draft_items','_work_config_validate_typed_fields','_work_totals_capture','_work_totals_coverage','_work_totals_shift','_work_totals_source','_work_totals_visible','_work_unit_contributors_coverage','_work_unit_contributors_person','_work_unit_contributors_shift','_work_unit_fact_bump_epoch','_work_unit_fact_context_visible','_work_unit_fact_peek_epoch','_work_unit_metadata_aggregate','_work_unit_metadata_area','_work_unit_metadata_area_add','_work_unit_metadata_basis','_work_unit_metadata_binding','_work_unit_metadata_bucket','_work_unit_metadata_coverage','_work_unit_metadata_decimal','_work_unit_metadata_floor_basis','_work_unit_metadata_fraction','_work_unit_metadata_gate','_work_unit_metadata_immutable','_work_unit_metadata_jobs_visible','_work_unit_metadata_live','_work_unit_metadata_members','_work_unit_metadata_number','_work_unit_metadata_object','_work_unit_metadata_origins','_work_unit_metadata_partition','_work_unit_metadata_person_counts','_work_unit_metadata_ratio','_work_unit_metadata_review','_work_unit_metadata_scope','_work_unit_metadata_shift_ids','_work_unit_metadata_state','_work_unit_metadata_sum_bucket','_work_unit_metadata_uuid','_work_unit_metadata_validate_definition','_work_unit_metadata_validate_values','_work_unit_metadata_version','_work_unit_review_authority','_work_unit_review_coverage','_work_unit_review_defect_projection','_work_unit_review_scope','_work_unit_review_view','attach_sandbox_guards','clock_in','clock_out','custom_work_internal','end_break','guard_test_account_sandbox_only','is_partner_user','is_sandbox_project','is_test_profile','person_record_counts','row_project_id','sandbox_scoped_tables','service_job_access','shift_cap_hours','start_break','work_activity_command','work_activity_snapshot','work_activity_totals_read','work_capture_immutable_record','work_publish_activity_version','work_publish_menu_version','work_select_job_menu','work_unit_cohorts_read','work_unit_contributors_read','work_unit_metadata_command','work_unit_metadata_read','work_unit_metadata_receipt'])),
 'triggers',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',t.tgname,'definition',pg_get_triggerdef(t.oid,true),'enabled',t.tgenabled) order by c.relname,t.tgname) from pg_trigger t join pg_class c on c.oid=t.tgrelid join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract']) and not t.tgisinternal),
 'columns',(select jsonb_agg(jsonb_build_object('table',c.relname,'column',a.attname,'type',format_type(a.atttypid,a.atttypmod),'nullable',not a.attnotnull,'default',(select pg_get_expr(d.adbin,d.adrelid) from pg_attrdef d where d.adrelid=a.attrelid and d.adnum=a.attnum),'collation',a.attcollation::regcollation::text,'rawAcl',a.attacl::text,'notNullValidated',coalesce(nn.validated,true),'notNullEnforced',coalesce(nn.enforced,true),'notNullNoInherit',coalesce(nn.no_inherit,false),'generated',a.attgenerated,'identity',a.attidentity) order by c.relname,a.attnum) from pg_class c join pg_namespace n on n.oid=c.relnamespace join pg_attribute a on a.attrelid=c.oid and a.attnum>0 and not a.attisdropped left join lateral (select bool_and(k.convalidated) validated,bool_and(coalesce((to_jsonb(k)->>'conenforced')::boolean,true)) enforced,bool_or(k.connoinherit) no_inherit from pg_constraint k where k.conrelid=a.attrelid and k.contype='n' and a.attnum=any(k.conkey)) nn on true where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract'])),
 'functionAccess',(select jsonb_agg(jsonb_build_object('name',p.proname,'args',pg_get_function_identity_arguments(p.oid),'role',r.rolname,'execute',has_function_privilege(r.oid,p.oid,'EXECUTE')) order by p.proname,pg_get_function_identity_arguments(p.oid),r.rolname) from pg_proc p join pg_namespace n on n.oid=p.pronamespace cross join pg_roles r where n.nspname='public' and p.proname=any(array['_ai_job_visible','_is_lead','_is_supervisor','_work_activity_actor','_work_activity_answers','_work_activity_authority_changed','_work_activity_authority_guard','_work_activity_authority_revision','_work_activity_bookkeeping_guard','_work_activity_claim_clock_setup','_work_activity_clock_replay_guard','_work_activity_clock_review','_work_activity_clock_setup_digest','_work_activity_close_all','_work_activity_close_source','_work_activity_command_basis','_work_activity_consume','_work_activity_context_assert','_work_activity_context_close','_work_activity_context_commit_guard','_work_activity_context_for','_work_activity_context_guard','_work_activity_context_open','_work_activity_ensure_state','_work_activity_ephemeral_commit_guard','_work_activity_establish_payload','_work_activity_establish_stream','_work_activity_event','_work_activity_evidence','_work_activity_expect','_work_activity_expected_guard','_work_activity_fact_snapshot','_work_activity_finish','_work_activity_gate','_work_activity_insert_source','_work_activity_instant','_work_activity_integer','_work_activity_iso','_work_activity_keep_clock_receipt','_work_activity_live_sources','_work_activity_no_truncate','_work_activity_object','_work_activity_observe','_work_activity_operation','_work_activity_operation_enter','_work_activity_operation_exit','_work_activity_parent_gate','_work_activity_parent_source_history','_work_activity_payload','_work_activity_profile_delete_guard','_work_activity_project_view','_work_activity_read_committed','_work_activity_refresh_state','_work_activity_resume','_work_activity_retain_source','_work_activity_review_visit','_work_activity_row_allowance','_work_activity_row_before','_work_activity_row_event','_work_activity_safety_exit','_work_activity_safety_guard','_work_activity_setup_guard','_work_activity_setup_ledger_guard','_work_activity_shift_lifecycle','_work_activity_source_material','_work_activity_source_view','_work_activity_start_setup','_work_activity_statement_begin','_work_activity_statement_end','_work_activity_stream_guard','_work_activity_touch','_work_activity_transition_source_guard','_work_activity_unit_basis','_work_activity_uuid','_work_activity_validate_switch','_work_config_can_manage_menu','_work_config_internal','_work_config_is_foreman','_work_config_is_owner','_work_config_is_supervisor','_work_config_replay','_work_config_store_receipt','_work_config_validate_menu_draft_items','_work_config_validate_typed_fields','_work_totals_capture','_work_totals_coverage','_work_totals_shift','_work_totals_source','_work_totals_visible','_work_unit_contributors_coverage','_work_unit_contributors_person','_work_unit_contributors_shift','_work_unit_fact_bump_epoch','_work_unit_fact_context_visible','_work_unit_fact_peek_epoch','_work_unit_metadata_aggregate','_work_unit_metadata_area','_work_unit_metadata_area_add','_work_unit_metadata_basis','_work_unit_metadata_binding','_work_unit_metadata_bucket','_work_unit_metadata_coverage','_work_unit_metadata_decimal','_work_unit_metadata_floor_basis','_work_unit_metadata_fraction','_work_unit_metadata_gate','_work_unit_metadata_immutable','_work_unit_metadata_jobs_visible','_work_unit_metadata_live','_work_unit_metadata_members','_work_unit_metadata_number','_work_unit_metadata_object','_work_unit_metadata_origins','_work_unit_metadata_partition','_work_unit_metadata_person_counts','_work_unit_metadata_ratio','_work_unit_metadata_review','_work_unit_metadata_scope','_work_unit_metadata_shift_ids','_work_unit_metadata_state','_work_unit_metadata_sum_bucket','_work_unit_metadata_uuid','_work_unit_metadata_validate_definition','_work_unit_metadata_validate_values','_work_unit_metadata_version','_work_unit_review_authority','_work_unit_review_coverage','_work_unit_review_defect_projection','_work_unit_review_scope','_work_unit_review_view','attach_sandbox_guards','clock_in','clock_out','custom_work_internal','end_break','guard_test_account_sandbox_only','is_partner_user','is_sandbox_project','is_test_profile','person_record_counts','row_project_id','sandbox_scoped_tables','service_job_access','shift_cap_hours','start_break','work_activity_command','work_activity_snapshot','work_activity_totals_read','work_capture_immutable_record','work_publish_activity_version','work_publish_menu_version','work_select_job_menu','work_unit_cohorts_read','work_unit_contributors_read','work_unit_metadata_command','work_unit_metadata_read','work_unit_metadata_receipt','_work_unit_contributors_coverage','_work_unit_metadata_coverage']) and r.rolname in('anon','authenticated','service_role')),
 'privateAccess',(select jsonb_agg(jsonb_build_object('table',c.relname,'role',r.rolname,'privilege',v.name,'allowed',has_table_privilege(r.oid,c.oid,v.name)) order by c.relname,r.rolname,v.name) from pg_class c join pg_namespace n on n.oid=c.relnamespace cross join pg_roles r cross join (values('SELECT'),('INSERT'),('UPDATE'),('DELETE'),('TRUNCATE'),('REFERENCES'),('TRIGGER')) v(name) where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract','_work_unit_review_live_sources']) and r.rolname in('anon','authenticated','service_role')),
 -- Effective access includes table-derived rights, role inheritance and PUBLIC.
 'columnAccess',(select jsonb_agg(jsonb_build_object('table',c.relname,'role',r.rolname,'privilege',v.name,'allowed',has_any_column_privilege(r.oid,c.oid,v.name)) order by c.relname,r.rolname,v.name) from pg_class c join pg_namespace n on n.oid=c.relnamespace cross join pg_roles r cross join (values('SELECT'),('INSERT'),('UPDATE'),('REFERENCES')) v(name) where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract','_work_unit_review_live_sources']) and r.rolname in('anon','authenticated','service_role')),
 'constraints',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',k.conname,'definition',pg_get_constraintdef(k.oid,true),'validated',k.convalidated,'enforced',coalesce((to_jsonb(k)->>'conenforced')::boolean,true),'deferrable',k.condeferrable,'deferred',k.condeferred) order by c.relname,k.conname) from pg_constraint k join pg_class c on c.oid=k.conrelid join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and k.contype<>'n' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract'])),
 'policies',(select jsonb_agg(jsonb_build_object('table',tablename,'name',policyname,'permissive',permissive,'roles',roles,'command',cmd,'using',qual,'check',with_check) order by tablename,policyname) from pg_policies where schemaname='public' and tablename=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract'])),
 'view',pg_get_viewdef('public._work_unit_review_live_sources'::regclass,true),
 'tables',(select jsonb_agg(jsonb_build_object('table',c.relname,'rls',c.relrowsecurity,'forcedRls',c.relforcerowsecurity,'kind',c.relkind,'persistence',c.relpersistence,'rawAcl',c.relacl::text,'owner',pg_get_userbyid(c.relowner)) order by c.relname) from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract']))
) value) metadata_catalog)) value
)c;
 return (select count(*)=1 and bool_and(proof_key='cross_job_kernel_2' and expected_catalog_sha256=actual) from public.work_cross_job_contract)
  and (select count(*)=1 and bool_and(proof_key='metadata_v1' and expected_catalog_sha256=actual) from public._work_unit_metadata_contract);
end;
$combined_coverage$;
create function public._work_unit_metadata_number(v jsonb) returns numeric language plpgsql immutable set search_path=public,pg_temp as $$
declare s text;begin s:=v#>>'{}';if jsonb_typeof(v) is distinct from 'string' or length(s) not between 1 and 100 or s!~'^-?[0-9]+([.][0-9]+)?$' then raise exception using errcode='23514',message='Invalid exact number.';end if;return s::numeric;end$$;
create function public._work_unit_metadata_version(p_id uuid,p_kind text,p_project uuid,p_active boolean default true) returns jsonb
language plpgsql stable security definer set search_path=public,pg_temp as $$
declare r public._work_unit_metadata_versions;d public._work_unit_metadata_definitions;lastrow public._work_unit_metadata_versions;
begin
 select * into r from public._work_unit_metadata_versions where id=p_id;select * into d from public._work_unit_metadata_definitions where id=r.definition_id;
 if r.id is null or d.kind is distinct from p_kind or d.project_id is distinct from p_project or r.state<>'published' then return null;end if;
 if not exists(select 1 from public._work_unit_metadata_commands c where c.command_id=r.command_id and c.actor_id=r.actor_id
 and c.request->>'action'='publish' and c.request#>>'{data,definitionId}'=d.id::text and c.request#>'{data,definition}'=r.value
 and c.result#>>'{result,versionId}'=r.id::text and (c.request#>>'{data,expectedVersion}')::integer=r.version-1)
 or r.predecessor_id is distinct from (select id from public._work_unit_metadata_versions where definition_id=d.id and version=r.version-1)
 or d.kind is distinct from r.value->>'kind' or d.code is distinct from r.value->>'code' then return null;end if;
 select * into lastrow from public._work_unit_metadata_versions where definition_id=d.id order by version desc limit 1;
 if p_active and (lastrow.id<>r.id or lastrow.state<>'published') then return null;end if;
 return jsonb_build_object('id',r.id,'definitionId',d.id,'version',r.version,'kind',d.kind,'projectId',d.project_id,'code',d.code,'value',r.value,'retired',lastrow.state='retired');
end$$;
create function public._work_unit_metadata_validate_definition(v jsonb,p_project uuid) returns void
language plpgsql stable security definer set search_path=public,pg_temp as $$
declare k text;parent jsonb;x jsonb;ids text[]:='{}';t text;lo numeric;hi numeric;begin
 if not public._work_unit_metadata_object(v,array['kind','code','labelEn','labelEs'],array['parentVersionId','fieldType','required','unit','min','max','options','dimension','members']) then raise exception using errcode='23514',message='Invalid metadata definition.';end if;
 k:=v->>'kind';if k is null or k not in ('category','subtype','material','component','field','floor','group') or jsonb_typeof(v->'code') is distinct from 'string' or (v->>'code')!~'^[a-z][a-z0-9_]{0,79}$'
 or jsonb_typeof(v->'labelEn') is distinct from 'string' or length(btrim(v->>'labelEn')) not between 1 and 120 or jsonb_typeof(v->'labelEs') is distinct from 'string' or length(btrim(v->>'labelEs')) not between 1 and 120
 or ((k='floor') is distinct from (p_project is not null)) then raise exception using errcode='23514',message='Invalid metadata definition.';end if;
 if k='category' and v->>'code' not in ('window','door','storefront') then raise exception using errcode='23514',message='Unknown root category.';end if;
 if k not in ('subtype','group') and v?'parentVersionId' or k<>'field' and v?|array['fieldType','required','min','max','options'] or k not in ('field','component') and v?'unit' or k<>'group' and v?|array['dimension','members'] then raise exception using errcode='23514',message='Invalid definition attributes.';end if;
 if k='subtype' then
 parent:=public._work_unit_metadata_version(public._work_unit_metadata_uuid(v->'parentVersionId'),'category',null);if parent is null then raise exception using errcode='23514',message='Category version is unavailable.';end if;
 end if;
 if k='component' and (jsonb_typeof(v->'unit') is distinct from 'string' or v->>'unit' not in ('count','in','ft','mm','cm','sq_ft','sq_m')) then raise exception using errcode='23514',message='Component quantity unit is required.';end if;
 if k='field' then
 t:=v->>'fieldType';if t is null or t not in ('text','number','boolean','single_select','multi_select') or jsonb_typeof(v->'required') is distinct from 'boolean' then raise exception using errcode='23514',message='Invalid typed field.';end if;
 if t<>'number' and v?|array['min','max','unit'] or t not in ('single_select','multi_select') and v?'options' then raise exception using errcode='23514',message='Invalid typed field attributes.';end if;
 if t='number' then
 if v?'min' then lo:=public._work_unit_metadata_number(v->'min');end if;if v?'max' then hi:=public._work_unit_metadata_number(v->'max');end if;
 if lo>hi or (v?'unit' and (jsonb_typeof(v->'unit')<>'string' or v->>'unit' not in ('count','in','ft','mm','cm','sq_ft','sq_m','min','h','lb','kg'))) then raise exception using errcode='23514',message='Invalid numeric field bounds.';end if;
 end if;
 if t in ('single_select','multi_select') then
 if jsonb_typeof(v->'options') is distinct from 'array' or jsonb_array_length(v->'options') not between 1 and 40 then raise exception using errcode='23514',message='Invalid field options.';end if;
 for x in select value from jsonb_array_elements(v->'options') loop
 if not public._work_unit_metadata_object(x,array['id','labelEn','labelEs']) or jsonb_typeof(x->'id')<>'string' or (x->>'id')!~'^[a-z][a-z0-9_]{0,79}$' or x->>'id'=any(ids)
 or jsonb_typeof(x->'labelEn')<>'string' or length(btrim(x->>'labelEn')) not between 1 and 120 or jsonb_typeof(x->'labelEs')<>'string' or length(btrim(x->>'labelEs')) not between 1 and 120 then raise exception using errcode='23514',message='Invalid field option.';end if;ids:=array_append(ids,x->>'id');end loop;
 end if;
 end if;
 if k='group' then
 if jsonb_typeof(v->'dimension') is distinct from 'string' or v->>'dimension' not in ('category','subtype','material') or jsonb_typeof(v->'members') is distinct from 'array' or jsonb_array_length(v->'members') not between 1 and 100 then raise exception using errcode='23514',message='Invalid exclusive group.';end if;
 if v?'parentVersionId' and v->'parentVersionId'<>'null' then parent:=public._work_unit_metadata_version(public._work_unit_metadata_uuid(v->'parentVersionId'),'group',null);if parent is null or parent#>>'{value,dimension}'<>v->>'dimension' then raise exception using errcode='23514',message='Parent group is unavailable.';end if;end if;
 for x in select value from jsonb_array_elements(v->'members') loop
 if public._work_unit_metadata_version(public._work_unit_metadata_uuid(x),v->>'dimension',null) is null or x#>>'{}'=any(ids) then raise exception using errcode='23514',message='Invalid group membership.';end if;
 if parent is not null and not (parent#>'{value,members}')@>jsonb_build_array(x) then raise exception using errcode='23514',message='Group is outside its parent.';end if;ids:=array_append(ids,x#>>'{}');end loop;
 end if;
end$$;
create function public._work_unit_metadata_validate_values(v jsonb,p_active boolean default true) returns void language plpgsql stable security definer set search_path=public,pg_temp as $$
declare k text;x jsonb;d jsonb;category_id text;ids text[]:='{}';options text[];item jsonb;n numeric;t text;begin
 if not public._work_unit_metadata_object(v,array['category','subtype','frameMaterial','components','fields']) then raise exception using errcode='23514',message='Invalid unit classification.';end if;
 foreach k in array array['category','subtype','frameMaterial'] loop
 x:=v->k;if x=jsonb_build_object('state','unknown') then continue;end if;
 if not public._work_unit_metadata_object(x,array['state','versionId']) or x->>'state' is distinct from 'known' then raise exception using errcode='23514',message='Invalid classification value.';end if;
 d:=public._work_unit_metadata_version(public._work_unit_metadata_uuid(x->'versionId'),case k when 'frameMaterial' then 'material' else k end,null,p_active);
 if d is null then raise exception using errcode='23514',message='Classification version is unavailable.';end if;
 if k='category' then category_id:=x->>'versionId';elsif k='subtype' and d#>>'{value,parentVersionId}' is distinct from category_id then raise exception using errcode='23514',message='Subtype requires its exact category version.';end if;
 end loop;
 if jsonb_typeof(v->'components') is distinct from 'array' or jsonb_array_length(v->'components')>30 or jsonb_typeof(v->'fields') is distinct from 'array' or jsonb_array_length(v->'fields')>40 then raise exception using errcode='23514',message='Classification list is too large.';end if;
 for x in select value from jsonb_array_elements(v->'components') loop
 if not public._work_unit_metadata_object(x,array['versionId','quantity']) then raise exception using errcode='23514',message='Invalid component.';end if;
 d:=public._work_unit_metadata_version(public._work_unit_metadata_uuid(x->'versionId'),'component',null,p_active);if d is null or x->>'versionId'=any(ids) then raise exception using errcode='23514',message='Component version is unavailable or duplicated.';end if;
 perform public._work_unit_metadata_decimal(x->'quantity',true);ids:=array_append(ids,x->>'versionId');end loop;
 ids:='{}';
 for x in select value from jsonb_array_elements(v->'fields') loop
 if not public._work_unit_metadata_object(x,array['versionId','state'],array['value']) or jsonb_typeof(x->'state') is distinct from 'string' or x->>'state' not in ('known','unknown','not_applicable') then raise exception using errcode='23514',message='Invalid field answer.';end if;
 d:=public._work_unit_metadata_version(public._work_unit_metadata_uuid(x->'versionId'),'field',null,p_active);if d is null or x->>'versionId'=any(ids) then raise exception using errcode='23514',message='Field version is unavailable or duplicated.';end if;ids:=array_append(ids,x->>'versionId');
 if x->>'state'<>'known' then if x?'value' or (d#>>'{value,required}')::boolean then raise exception using errcode='23514',message='Required field needs a known value.';end if;continue;end if;
 if not x?'value' then raise exception using errcode='23514',message='A known field needs its value.';end if;t:=d#>>'{value,fieldType}';
 if t='text' and (jsonb_typeof(x->'value')<>'string' or length(x->>'value')>1000 or ((d#>>'{value,required}')::boolean and length(btrim(x->>'value'))=0)) or t='boolean' and jsonb_typeof(x->'value')<>'boolean' then raise exception using errcode='23514',message='Invalid field value type.';end if;
 if t='number' then n:=public._work_unit_metadata_number(x->'value');if (d->'value'?'min' and n<public._work_unit_metadata_number(d#>'{value,min}')) or (d->'value'?'max' and n>public._work_unit_metadata_number(d#>'{value,max}')) then raise exception using errcode='23514',message='Field value is outside its bounds.';end if;end if;
 if t in ('single_select','multi_select') then
 select array_agg(z->>'id') into options from jsonb_array_elements(d#>'{value,options}')z;
 if t='single_select' then if jsonb_typeof(x->'value')<>'string' or not x->>'value'=any(options) then raise exception using errcode='23514',message='Unknown field option.';end if;
 else
 if jsonb_typeof(x->'value')<>'array' or jsonb_array_length(x->'value')>40 or ((d#>>'{value,required}')::boolean and jsonb_array_length(x->'value')=0) or (select count(*) from jsonb_array_elements(x->'value'))<>(select count(distinct a) from jsonb_array_elements(x->'value')a) then raise exception using errcode='23514',message='Invalid multiple selection.';end if;
 for item in select value from jsonb_array_elements(x->'value') loop if jsonb_typeof(item)<>'string' or not item#>>'{}'=any(options) then raise exception using errcode='23514',message='Unknown field option.';end if;end loop;
 end if;end if;
 end loop;
end$$;
create function public._work_unit_metadata_floor_basis(s jsonb,r jsonb) returns jsonb language sql stable security definer set search_path=public,pg_temp as $$
 select jsonb_build_object('binding',public._work_unit_metadata_binding((s#>>'{unit,id}')::uuid),'factId',s#>'{unit,fact,id}','factRevision',s#>'{unit,fact,revision}',
 'verificationId',r#>'{dimensionVerification,verificationId}','dimensionManifest',s->'dimension','scopeToken',s->'scopeToken',
 'reviewRevision',coalesce((r#>>'{basis,reviewRevision}')::integer,0),'submissionId',r#>'{basis,submissionId}','generation',r#>'{basis,generation}',
 'qcEventId',(select latest_qc_event_id from public.work_unit_review_current where unit_id=(s#>>'{unit,id}')::uuid and incarnation=(s#>>'{unit,incarnationEpoch}')::bigint))
$$;
create function public._work_unit_metadata_state(actor uuid,s jsonb,r jsonb) returns jsonb language plpgsql stable security definer set search_path=public,pg_temp as $$
declare u uuid:=(s#>>'{unit,id}')::uuid;m public._work_unit_metadata_revisions;f public._work_unit_metadata_floors;b jsonb;fb jsonb;floorok boolean:=true;x jsonb;v jsonb;begin
 if s is null or r is null or not public._work_unit_metadata_origins(actor,u) then return null;end if;
 select q.* into m from public._work_unit_metadata_revisions q join public._work_unit_metadata_current c on c.revision_id=q.id where c.unit_id=u;
 select q.* into f from public._work_unit_metadata_floors q join public._work_unit_metadata_floor_current c on c.revision_id=q.id where c.unit_id=u;
 if coalesce(m.revision,0)<>(select count(*) from public._work_unit_metadata_revisions where unit_id=u) or m.unit_id is distinct from u and m.id is not null
 or coalesce(f.revision,0)<>(select count(*) from public._work_unit_metadata_floors where unit_id=u) or f.unit_id is distinct from u and f.id is not null then return null;end if;
 if exists(select 1 from public._work_unit_metadata_revisions a where a.unit_id=u and
 ((a.revision=1 and a.predecessor_id is not null) or (a.revision>1 and not exists(select 1 from public._work_unit_metadata_revisions p where p.id=a.predecessor_id and p.unit_id=u and p.revision=a.revision-1)) or not exists(select 1 from public._work_unit_metadata_commands c where c.command_id=a.command_id and c.actor_id=a.actor_id and c.unit_id=u))) then return null;end if;
 if exists(select 1 from public._work_unit_metadata_floors a where a.unit_id=u and
 ((a.revision=1 and a.predecessor_id is not null) or (a.revision>1 and not exists(select 1 from public._work_unit_metadata_floors p where p.id=a.predecessor_id and p.unit_id=u and p.revision=a.revision-1)) or not exists(select 1 from public._work_unit_metadata_commands c where c.command_id=a.command_id and c.actor_id=a.actor_id and c.unit_id=u))) then return null;end if;
 if m.id is not null then
 begin perform public._work_unit_metadata_validate_values(m.value,false);exception when check_violation or invalid_text_representation or numeric_value_out_of_range then return null;end;
 if not exists(select 1 from public._work_unit_metadata_commands c where c.command_id=m.command_id and c.request->>'action'='assign'
 and c.request#>'{data,classification}'=m.value and c.request#>'{data,basis,binding}'=m.binding and c.result#>>'{result,revisionId}'=m.id::text) then return null;end if;
 end if;
 if f.id is not null then
 if not exists(select 1 from public._work_unit_metadata_commands c where c.command_id=f.command_id and c.request->>'action'='allocate'
 and (c.request#>'{data,basis}')-'floorRevision'=f.basis-'dimensionManifest' and c.request#>>'{data,state}'=f.state and c.result#>>'{result,revisionId}'=f.id::text
 and c.origin_jobs=f.origin_jobs and jsonb_array_length(c.request#>'{data,shares}')=jsonb_array_length(f.shares)
 and not exists(select 1 from jsonb_array_elements(f.shares) stored where not exists(select 1 from jsonb_array_elements(c.request#>'{data,shares}') requested
 where stored->>'versionId'=requested->>'versionId' and (stored->>'numerator')::numeric*(requested->>'denominator')::numeric=(requested->>'numerator')::numeric*(stored->>'denominator')::numeric))) then return null;end if;
 end if;
 b:=public._work_unit_metadata_binding(u);fb:=public._work_unit_metadata_floor_basis(s,r);
 if f.id is not null then for x in select value from jsonb_array_elements(f.shares) loop
 v:=public._work_unit_metadata_version((x->>'versionId')::uuid,'floor',(b->>'projectId')::uuid);if v is null then floorok:=false;end if;end loop;end if;
 return jsonb_build_object('unitId',u,'metadataBasis',jsonb_build_object('binding',b,'metadataRevision',coalesce(m.revision,0)),
 'floorBasis',(fb-'dimensionManifest')||jsonb_build_object('floorRevision',coalesce(f.revision,0)),
 'classification',jsonb_build_object('state',case when m.id is null then 'unknown' when m.binding=b then 'current' else 'noncurrent' end,'revisionId',m.id,'revision',coalesce(m.revision,0),'values',m.value),
 'floor',jsonb_build_object('state',coalesce(f.state,'unallocated'),'revisionId',f.id,'revision',coalesce(f.revision,0),'current',f.id is not null and f.basis=fb and floorok and r#>>'{dimensionVerification,state}'='verified' and r#>>'{qc,qcAccepted}'='true','shares',coalesce(f.shares,'[]')));
end$$;

create function public._work_unit_metadata_basis(v jsonb,p_floor boolean) returns void language plpgsql immutable set search_path=public,pg_temp as $$
declare b jsonb;k text;begin
 if not public._work_unit_metadata_object(v,case when p_floor then array['binding','factId','factRevision','verificationId','scopeToken','reviewRevision','submissionId','generation','qcEventId','floorRevision'] else array['binding','metadataRevision'] end) then raise exception using errcode='23514',message='Invalid metadata basis.';end if;
 b:=v->'binding';if not public._work_unit_metadata_object(b,array['unitId','incarnation','projectId','openingId','authorId','authorIsTest','bindingEpoch','projectEpoch','openingEpoch']) or jsonb_typeof(b->'authorIsTest') is distinct from 'boolean' then raise exception using errcode='23514',message='Invalid binding basis.';end if;
 perform public._work_unit_metadata_uuid(b->'unitId');
 foreach k in array array['projectId','openingId','authorId'] loop if b->k<>'null' then perform public._work_unit_metadata_uuid(b->k);end if;end loop;
 foreach k in array array['incarnation','bindingEpoch','projectEpoch','openingEpoch'] loop
 if b->k='null' and k in ('projectEpoch','openingEpoch') then continue;end if;
 if jsonb_typeof(b->k) is distinct from 'string' or (b->>k)!~'^[0-9]{1,16}$' or (b->>k)::numeric>9007199254740991 then raise exception using errcode='23514',message='Invalid binding epoch.';end if;end loop;
 foreach k in array case when p_floor then array['floorRevision','reviewRevision','generation','factRevision'] else array['metadataRevision'] end loop
 if p_floor and k='factRevision' and v->k='null' then continue;end if;
 if jsonb_typeof(v->k) is distinct from 'number' or (v->>k)!~'^[0-9]{1,10}$' or (v->>k)::numeric>2147483647 then raise exception using errcode='23514',message='Invalid metadata revision.';end if;end loop;
 if p_floor then
 foreach k in array array['factId','verificationId','submissionId','qcEventId'] loop if v->k<>'null' then perform public._work_unit_metadata_uuid(v->k);end if;end loop;
 if jsonb_typeof(v->'scopeToken') is distinct from 'string' or (v->>'scopeToken')!~'^ur1:[0-9a-f]{64}$' then raise exception using errcode='23514',message='Invalid floor scope token.';end if;
 end if;
end$$;
create function public.work_unit_metadata_read(p_unit_id uuid,p_protocol_version integer default 1) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare a uuid;s jsonb;r jsonb;m jsonb;catalog jsonb;begin
 if p_protocol_version is distinct from 1 or p_unit_id is null then raise exception using errcode='23514',message='Invalid metadata request.';end if;
 -- METADATA_BOUNDARY_a_BEGIN
 perform public._work_activity_read_committed();perform public._work_activity_gate();a:=public._work_activity_actor();perform pg_advisory_xact_lock(7710,0);a:=public._work_activity_actor();
 if not coalesce((select encode(sha256(convert_to(pin.value::text,'UTF8')),'hex')='43ffd737b1582224f5b360cd90f2c6651e3cc45486899ee5e15a93bb64541744' from (select jsonb_build_object('body',p.prosrc,'owner',pg_get_userbyid(p.proowner),'acl',p.proacl::text,'definer',p.prosecdef,'config',p.proconfig,'volatility',p.provolatile,'strict',p.proisstrict,'leakproof',p.proleakproof,'parallel',p.proparallel,'kind',p.prokind,'set',p.proretset,'result',pg_get_function_result(p.oid),'args',pg_get_function_identity_arguments(p.oid),'defaults',pg_get_expr(p.proargdefaults,0),'cost',p.procost,'rows',p.prorows,'support',p.prosupport::regprocedure::text,'language',(select lanname from pg_language where oid=p.prolang)) value from pg_proc p where p.oid=to_regprocedure('public._work_unit_metadata_coverage()'))pin),false) then a:=null;
 elsif not public._work_unit_metadata_coverage() or not public._work_unit_review_coverage() or not public._work_totals_coverage() or not public._work_unit_contributors_coverage() then a:=null;end if;
 -- METADATA_BOUNDARY_a_END
if a is not null then s:=public._work_unit_review_scope(a,p_unit_id);r:=public._work_unit_review_view(a,s);m:=public._work_unit_metadata_state(a,s,r);end if;
 if m is null then return jsonb_build_object('protocolVersion',1,'availability','unavailable','metadata',null);end if;
 select coalesce(jsonb_agg(jsonb_build_object('definitionId',d.id,'versionId',v.id,'version',v.version,'kind',d.kind,'projectId',d.project_id,'code',d.code,'state',v.state,'definition',v.value) order by d.kind,d.id,v.version),'[]') into catalog
 from public._work_unit_metadata_definitions d join public._work_unit_metadata_versions v on v.definition_id=d.id
 where d.project_id is null or d.project_id=(s#>>'{unit,projectId}')::uuid;
 if jsonb_array_length(catalog)>500 or octet_length(catalog::text)>1000000 then return jsonb_build_object('protocolVersion',1,'availability','unavailable','metadata',null);end if;
 return jsonb_build_object('protocolVersion',1,'availability','available','metadata',m||jsonb_build_object('asOf',public._work_activity_iso(clock_timestamp()),'catalog',catalog,
 'capabilities',jsonb_build_object('assign',public._is_lead(a) or exists(select 1 from public.custom_work_units where id=p_unit_id and created_by=a),'allocate',public._work_unit_review_authority(a,s->'jobs','dimensions_edit'),'publish',public._work_config_is_owner(a),'propose',public._work_config_is_supervisor(a))));
end$$;
create function public.work_unit_metadata_receipt(p_command_id uuid,p_protocol_version integer default 1) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare a uuid;c public._work_unit_metadata_commands;s jsonb;begin
 if p_protocol_version is distinct from 1 or p_command_id is null then raise exception using errcode='23514',message='Invalid metadata receipt request.';end if;
 -- METADATA_BOUNDARY_a_BEGIN
 perform public._work_activity_read_committed();perform public._work_activity_gate();a:=public._work_activity_actor();perform pg_advisory_xact_lock(7710,0);a:=public._work_activity_actor();
 if not coalesce((select encode(sha256(convert_to(pin.value::text,'UTF8')),'hex')='43ffd737b1582224f5b360cd90f2c6651e3cc45486899ee5e15a93bb64541744' from (select jsonb_build_object('body',p.prosrc,'owner',pg_get_userbyid(p.proowner),'acl',p.proacl::text,'definer',p.prosecdef,'config',p.proconfig,'volatility',p.provolatile,'strict',p.proisstrict,'leakproof',p.proleakproof,'parallel',p.proparallel,'kind',p.prokind,'set',p.proretset,'result',pg_get_function_result(p.oid),'args',pg_get_function_identity_arguments(p.oid),'defaults',pg_get_expr(p.proargdefaults,0),'cost',p.procost,'rows',p.prorows,'support',p.prosupport::regprocedure::text,'language',(select lanname from pg_language where oid=p.prolang)) value from pg_proc p where p.oid=to_regprocedure('public._work_unit_metadata_coverage()'))pin),false) then a:=null;
 elsif not public._work_unit_metadata_coverage() or not public._work_unit_review_coverage() or not public._work_totals_coverage() or not public._work_unit_contributors_coverage() then a:=null;end if;
 -- METADATA_BOUNDARY_a_END
 if a is null then return jsonb_build_object('protocolVersion',1,'availability','unavailable','receipt',null);end if;
 select * into c from public._work_unit_metadata_commands where command_id=p_command_id and actor_id=a;
 if a is null or c.command_id is null or not public._work_unit_metadata_jobs_visible(a,c.origin_jobs) then return jsonb_build_object('protocolVersion',1,'availability','unavailable','receipt',null);end if;
 if c.unit_id is not null then
 s:=public._work_unit_review_scope(a,c.unit_id);if s is null or c.unit_binding->>'incarnation' is distinct from s#>>'{unit,incarnationEpoch}' or not public._work_unit_metadata_origins(a,c.unit_id) then return jsonb_build_object('protocolVersion',1,'availability','unavailable','receipt',null);end if;
 end if;
 return jsonb_build_object('protocolVersion',1,'availability','available','receipt',c.result);
end$$;
create function public.work_unit_metadata_command(p_command_id uuid,p_protocol_version integer,p_request jsonb) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare a uuid;act text;data jsonb;target uuid;project uuid;d public._work_unit_metadata_definitions;v public._work_unit_metadata_versions;
 unitrow public.custom_work_units;c public._work_unit_metadata_commands;s jsonb;r jsonb;m jsonb;jobs jsonb:='[]';result jsonb;outid uuid:=gen_random_uuid();reason text;applied boolean:=true;
 mr public._work_unit_metadata_revisions;fr public._work_unit_metadata_floors;binding jsonb;definition jsonb;k text;prev uuid;ver integer;expected integer;
 x jsonb;fv jsonb;shares jsonb:='[]';seen uuid[]:='{}';n numeric;den numeric;sn numeric:=0;sd numeric:=1;g numeric;parent uuid;depth integer;
begin
 -- METADATA_BOUNDARY_a_BEGIN
 perform public._work_activity_read_committed();perform public._work_activity_gate();a:=public._work_activity_actor();perform pg_advisory_xact_lock(7710,0);a:=public._work_activity_actor();
 if not coalesce((select encode(sha256(convert_to(pin.value::text,'UTF8')),'hex')='43ffd737b1582224f5b360cd90f2c6651e3cc45486899ee5e15a93bb64541744' from (select jsonb_build_object('body',p.prosrc,'owner',pg_get_userbyid(p.proowner),'acl',p.proacl::text,'definer',p.prosecdef,'config',p.proconfig,'volatility',p.provolatile,'strict',p.proisstrict,'leakproof',p.proleakproof,'parallel',p.proparallel,'kind',p.prokind,'set',p.proretset,'result',pg_get_function_result(p.oid),'args',pg_get_function_identity_arguments(p.oid),'defaults',pg_get_expr(p.proargdefaults,0),'cost',p.procost,'rows',p.prorows,'support',p.prosupport::regprocedure::text,'language',(select lanname from pg_language where oid=p.prolang)) value from pg_proc p where p.oid=to_regprocedure('public._work_unit_metadata_coverage()'))pin),false) then a:=null;
 elsif not public._work_unit_metadata_coverage() or not public._work_unit_review_coverage() or not public._work_totals_coverage() or not public._work_unit_contributors_coverage() then a:=null;end if;
 -- METADATA_BOUNDARY_a_END
 if a is null then return jsonb_build_object('protocolVersion',1,'availability','unavailable','receipt',null);end if;
 if p_command_id is null or p_protocol_version is distinct from 1 or not public._work_unit_metadata_object(p_request,array['action','data']) or octet_length(p_request::text)>32768 or jsonb_typeof(p_request->'action')<>'string' or jsonb_typeof(p_request->'data')<>'object' then raise exception using errcode='23514',message='Invalid metadata command.';end if;
 act:=p_request->>'action';data:=p_request->'data';if act not in ('publish','propose','retire','assign','allocate') then raise exception using errcode='23514',message='Unknown metadata command.';end if;
 

 if act in ('publish','propose','retire') then
 if not public._work_config_is_supervisor(a) or (act<>'propose' and not public._work_config_is_owner(a)) then raise exception using errcode='42501',message='Metadata publishing authority is required.';end if;
 if act='retire' then
 if not public._work_unit_metadata_object(data,array['definitionId','expectedVersion']) then raise exception using errcode='23514',message='Invalid retire command.';end if;
 else
 if not public._work_unit_metadata_object(data,array['definitionId','expectedVersion','projectId','definition']) then raise exception using errcode='23514',message='Invalid definition command.';end if;
 end if;
 target:=public._work_unit_metadata_uuid(data->'definitionId');select * into d from public._work_unit_metadata_definitions where id=target;
 project:=case when act='retire' then d.project_id when data->'projectId'='null' then null else public._work_unit_metadata_uuid(data->'projectId') end;
 if project is not null and not public._ai_job_visible(project,a) or d.project_id is not null and not public._ai_job_visible(d.project_id,a) then return jsonb_build_object('protocolVersion',1,'availability','unavailable','receipt',null);end if;
 if project is not null then jobs:=jsonb_build_array(project);end if;
 if d.id is not null and d.project_id is distinct from project then raise exception using errcode='23514',message='A definition cannot move between projects.';end if;
 else
 if act='assign' then
 if not public._work_unit_metadata_object(data,array['unitId','basis','classification']) then raise exception using errcode='23514',message='Invalid classification command.';end if;
 else if not public._work_unit_metadata_object(data,array['unitId','basis','state','shares','reason']) then raise exception using errcode='23514',message='Invalid floor command.';end if;end if;
 perform public._work_unit_metadata_basis(data->'basis',act='allocate');
 target:=public._work_unit_metadata_uuid(data->'unitId');s:=public._work_unit_review_scope(a,target);r:=public._work_unit_review_view(a,s);m:=public._work_unit_metadata_state(a,s,r);
 if m is null then return jsonb_build_object('protocolVersion',1,'availability','unavailable','receipt',null);end if;
 select * into unitrow from public.custom_work_units where id=target;project:=unitrow.project_id;jobs:=s->'jobs';
 if act='assign' and not (unitrow.created_by=a or public._is_lead(a)) or act='allocate' and not public._work_unit_review_authority(a,jobs,'dimensions_edit') then raise exception using errcode='42501',message='Unit metadata authority is required.';end if;
 end if;
 -- Fresh authority precedes lookup. Global G serializes even missing-key retries.
 select * into c from public._work_unit_metadata_commands where command_id=p_command_id;
 if found then
 if c.actor_id<>a or c.request<>p_request or (c.unit_id is not null and (c.unit_id is distinct from target or c.unit_binding->>'incarnation' is distinct from m#>>'{metadataBasis,binding,incarnation}')) or not public._work_unit_metadata_jobs_visible(a,c.origin_jobs) then return jsonb_build_object('protocolVersion',1,'availability','unavailable','receipt',null);end if;
 return jsonb_build_object('protocolVersion',1,'availability','available','receipt',c.result);end if;
 if act in ('publish','propose','retire') then
 if jsonb_typeof(data->'expectedVersion') is distinct from 'number' or (data->>'expectedVersion')!~'^[0-9]{1,9}$' then raise exception using errcode='23514',message='Invalid definition revision.';end if;expected:=(data->>'expectedVersion')::integer;
 select * into d from public._work_unit_metadata_definitions where id=target for update;
 select * into v from public._work_unit_metadata_versions where definition_id=target order by version desc limit 1;
 ver:=coalesce(v.version,0);if expected<>ver or ver>=2147483646 then applied:=false;reason:='stale_basis';end if;
 if act='retire' then if d.id is null then applied:=false;reason:='stale_basis';end if;definition:=v.value;
 else definition:=data->'definition';perform public._work_unit_metadata_validate_definition(definition,project);end if;
 if d.id is not null and act<>'retire' and (d.kind is distinct from definition->>'kind' or d.code is distinct from definition->>'code') then raise exception using errcode='23514',message='Definition identity cannot change kind or code.';end if;
 if act='propose' then
 insert into public._work_unit_metadata_proposals values(outid,a,p_command_id,project,data,clock_timestamp());result:=jsonb_build_object('proposalId',outid);applied:=true;
 elsif applied then
 if definition->>'kind'='group' then
 parent:=nullif(definition->>'parentVersionId','')::uuid;depth:=0;
 while parent is not null loop
 select * into v from public._work_unit_metadata_versions where id=parent;depth:=depth+1;
 if v.definition_id=target or depth>=8 then raise exception using errcode='23514',message='Group ancestry is cyclic or too deep.';end if;parent:=nullif(v.value->>'parentVersionId','')::uuid;end loop;
 if exists(select 1 from public._work_unit_metadata_versions z join public._work_unit_metadata_definitions zd on zd.id=z.definition_id
 where zd.kind='group' and zd.id<>target and z.state='published' and not exists(select 1 from public._work_unit_metadata_versions newer where newer.definition_id=zd.id and newer.version>z.version)
 and z.value->>'dimension'=definition->>'dimension' and z.value->>'parentVersionId' is not distinct from definition->>'parentVersionId'
 and exists(select 1 from jsonb_array_elements(z.value->'members') item(value) where definition->'members'@>jsonb_build_array(item.value))) then raise exception using errcode='23514',message='Exclusive sibling groups overlap.';end if;
 end if;
 if d.id is null then insert into public._work_unit_metadata_definitions(id,kind,code,project_id,actor_id) values(target,definition->>'kind',definition->>'code',project,a);end if;
 select id into prev from public._work_unit_metadata_versions where definition_id=target order by version desc limit 1;
 insert into public._work_unit_metadata_versions(id,definition_id,version,predecessor_id,state,value,actor_id,command_id) values(outid,target,ver+1,prev,case when act='retire' then 'retired' else 'published' end,definition,a,p_command_id);
 result:=jsonb_build_object('definitionId',target,'versionId',outid,'version',ver+1);
 end if;
 else
 perform 1 from public.custom_work_units where id=target for update;
 -- No physical fact/operational revision occurs in classification CAS.
 if act='assign' then
 select q.* into mr from public._work_unit_metadata_revisions q join public._work_unit_metadata_current cc on cc.revision_id=q.id where cc.unit_id=target;
 if data->'basis' is distinct from m->'metadataBasis' or coalesce(mr.revision,0)>=2147483646 then applied:=false;reason:='stale_basis';end if;
 perform public._work_unit_metadata_validate_values(data->'classification');
 if applied then
 binding:=public._work_unit_metadata_binding(target);
 insert into public._work_unit_metadata_revisions(id,unit_id,incarnation,revision,predecessor_id,binding,origin_jobs,value,observed_fact_id,actor_id,command_id)
 values(outid,target,(binding->>'incarnation')::bigint,coalesce(mr.revision,0)+1,mr.id,binding,jobs,data->'classification',(s#>>'{unit,fact,id}')::uuid,a,p_command_id);
 insert into public._work_unit_metadata_current values(target,outid) on conflict(unit_id) do update set revision_id=excluded.revision_id;
 result:=jsonb_build_object('unitId',target,'revisionId',outid,'revision',coalesce(mr.revision,0)+1);end if;
 else
 select q.* into fr from public._work_unit_metadata_floors q join public._work_unit_metadata_floor_current cc on cc.revision_id=q.id where cc.unit_id=target;
 if data->'basis' is distinct from m->'floorBasis' or coalesce(fr.revision,0)>=2147483646 then applied:=false;reason:='stale_basis';end if;
 if data->>'state' not in ('unknown','unallocated','single','multilevel') or jsonb_typeof(data->'state') is distinct from 'string' or jsonb_typeof(data->'shares') is distinct from 'array' or jsonb_array_length(data->'shares')>32 or jsonb_typeof(data->'reason') is distinct from 'string' or length(btrim(data->>'reason')) not between 3 and 500 then raise exception using errcode='23514',message='Invalid floor allocation.';end if;
 if data->>'state' in ('unknown','unallocated') then if data->'shares'<>'[]' then raise exception using errcode='23514',message='Unallocated floors cannot contain trusted shares.';end if;
 else
 if r#>>'{dimensionVerification,state}'<>'verified' or r#>>'{qc,qcAccepted}'<>'true' then applied:=false;reason:='physical_proof_required';end if;
 if (data->>'state'='single' and jsonb_array_length(data->'shares')<>1) or (data->>'state'='multilevel' and jsonb_array_length(data->'shares')<2) then raise exception using errcode='23514',message='Allocation state disagrees with its shares.';end if;
 for x in select value from jsonb_array_elements(data->'shares') loop
 if not public._work_unit_metadata_object(x,array['versionId','numerator','denominator']) then raise exception using errcode='23514',message='Invalid floor share.';end if;
 fv:=public._work_unit_metadata_version(public._work_unit_metadata_uuid(x->'versionId'),'floor',project);
 if fv is null or (fv->>'definitionId')::uuid=any(seen) then raise exception using errcode='23514',message='Floor version is unavailable or duplicated.';end if;seen:=array_append(seen,(fv->>'definitionId')::uuid);
 if (x->>'numerator')!~'^[0-9]{1,100}$' or (x->>'denominator')!~'^[0-9]{1,100}$' then raise exception using errcode='23514',message='Floor shares require exact integers.';end if;
 n:=public._work_unit_metadata_decimal(x->'numerator',true);den:=public._work_unit_metadata_decimal(x->'denominator',true);g:=gcd(n,den);n:=n/g;den:=den/g;sn:=sn*den+n*sd;sd:=sd*den;g:=gcd(sn,sd);sn:=sn/g;sd:=sd/g;
 shares:=shares||jsonb_build_array(jsonb_build_object('versionId',x->'versionId','floorId',fv->'definitionId','numerator',trim_scale(n)::text,'denominator',trim_scale(den)::text));end loop;
 if sn<>sd then raise exception using errcode='23514',message='Floor shares must sum exactly to one.';end if;
 end if;
 if applied then
 binding:=public._work_unit_metadata_binding(target);
 insert into public._work_unit_metadata_floors(id,unit_id,incarnation,revision,predecessor_id,basis,origin_jobs,state,shares,reason,actor_id,command_id)
 values(outid,target,(binding->>'incarnation')::bigint,coalesce(fr.revision,0)+1,fr.id,public._work_unit_metadata_floor_basis(s,r),jobs,data->>'state',shares,data->>'reason',a,p_command_id);
 insert into public._work_unit_metadata_floor_current values(target,outid) on conflict(unit_id) do update set revision_id=excluded.revision_id;
 result:=jsonb_build_object('unitId',target,'revisionId',outid,'revision',coalesce(fr.revision,0)+1);end if;
 end if;
 end if;
 result:=jsonb_build_object('commandId',p_command_id,'action',act,'status',case when applied then 'applied' else 'rejected' end,'reason',case when applied then null else reason end,'result',case when applied then result else null end);
 insert into public._work_unit_metadata_commands(command_id,actor_id,unit_id,unit_binding,project_id,origin_jobs,request,result) values(p_command_id,a,case when act in ('assign','allocate') then target else null end,case when act in ('assign','allocate') then m#>'{metadataBasis,binding}' else null end,project,jobs,p_request,result);
 return jsonb_build_object('protocolVersion',1,'availability','available','receipt',result);
end$$;

create function public._work_unit_metadata_members(p_units uuid[]) returns jsonb language sql stable security definer set search_path=public,pg_temp as $$
with versions as materialized (
 select source_kind kind,source_id,b.value from public.work_activity_source_history h cross join lateral(values(h.before_value),(h.after_value)) b(value) where b.value<>'{}'
 union all select case e.source_kind when 'custom' then 'custom_work_sessions' when 'unit' then 'unit_sessions' when 'task' then 'task_sessions' when 'service' then 'service_time_sessions' when 'phase' then 'opening_phases' when 'helper' then 'summon_helpers' end,e.source_id::text,b.value
 from public.personal_activity_transition_sources e cross join lateral(values(e.before_evidence),(e.after_evidence))b(value) where e.source_kind in ('custom','unit','task','service','phase','helper') and b.value<>'{}'
), units as materialized(select u.id uid,u.opening_id from public.custom_work_units u where u.id=any(p_units)),
roots as materialized(
 select u.uid,v.value->>'opening_id' id from units u join versions v on v.kind='custom_work_units' and v.source_id=u.uid::text
 union select u.uid,u.opening_id::text from units u),
mapped as materialized(select uid,id from roots where id is not null),
windows as materialized(
 select m.uid,v.value->>'assigned_window_id' id from mapped m join versions v on v.kind='project_openings' and v.source_id=m.id
 union select m.uid,r.assigned_window_id::text from mapped m join public.project_openings r on r.id::text=m.id),
service_units as materialized(
 select u.uid,v.source_id id from units u join versions v on v.kind='service_visit_units' and v.value->>'work_unit_id'=u.uid::text
 union select m.uid,v.source_id from mapped m join versions v on v.kind='service_visit_units' and v.value->>'opening_id'=m.id
 union select w.uid,v.source_id from windows w join versions v on v.kind='service_visit_units' and v.value->>'window_id'=w.id
 union select u.uid,r.id::text from units u join public.service_visit_units r on r.work_unit_id=u.uid
 union select m.uid,r.id::text from mapped m join public.service_visit_units r on r.opening_id::text=m.id
 union select w.uid,r.id::text from windows w join public.service_visit_units r on r.window_id::text=w.id),
summons_for_unit as materialized(
 select m.uid,v.source_id id from mapped m join versions v on v.kind='summons' and v.value->>'opening_id'=m.id
 union select m.uid,r.id::text from mapped m join public.summons r on r.opening_id::text=m.id),
crew as materialized(
 select u.uid,v.source_id id from units u join versions v on v.kind='crew_work_records' and v.value->>'unit_id'=u.uid::text
 union select u.uid,r.id::text from units u join public.crew_work_records r on r.unit_id=u.uid),
custom_sessions as materialized(
 select u.uid,v.source_id id from units u join versions v on v.kind='custom_work_sessions' and v.value->>'unit_id'=u.uid::text
 union select u.uid,v.value->>'session_id' from units u join versions v on v.kind='work_session_capture_metadata' and v.value->>'unit_id'=u.uid::text
 union select u.uid,r.id::text from units u join public.custom_work_sessions r on r.unit_id=u.uid
 union select u.uid,r.session_id::text from units u join public.work_session_capture_metadata r on r.unit_id=u.uid),
visits as materialized(
 select su.uid,v.value->>'visit_id' id from service_units su join versions v on v.kind='service_visit_units' and v.source_id=su.id
 union select su.uid,r.visit_id::text from service_units su join public.service_visit_units r on r.id::text=su.id),
selected as materialized(
 select u.uid,v.kind,v.source_id from units u join versions v on v.kind='custom_work_units' and v.source_id=u.uid::text
 union select m.uid,v.kind,v.source_id from mapped m join versions v on v.kind='project_openings' and v.source_id=m.id
 union select m.uid,v.kind,v.source_id from mapped m join versions v on v.kind in('unit_sessions','task_sessions','opening_phases','unit_redos') and v.value->>'opening_id'=m.id
 union select m.uid,v.kind,v.source_id from mapped m join versions v on v.kind in('qc_checks','install_events') and v.value->>'project_opening_id'=m.id
 union select c.uid,v.kind,v.source_id from custom_sessions c join versions v on v.kind='custom_work_sessions' and v.source_id=c.id
 union select su.uid,v.kind,v.source_id from service_units su join versions v on v.kind='service_visit_units' and v.source_id=su.id
 union select su.uid,v.kind,v.source_id from service_units su join versions v on v.kind='service_time_sessions' and v.value->>'unit_id'=su.id
 union select vi.uid,v.kind,v.source_id from visits vi join versions v on v.kind='service_visits' and v.source_id=vi.id
 union select sm.uid,v.kind,v.source_id from summons_for_unit sm join versions v on v.kind='summons' and v.source_id=sm.id
 union select sm.uid,v.kind,v.source_id from summons_for_unit sm join versions v on v.kind='summon_helpers' and v.value->>'summon_id'=sm.id
 union select c.uid,v.kind,v.source_id from crew c join versions v on v.kind='crew_work_records' and v.source_id=c.id
 union select c.uid,v.kind,v.source_id from crew c join versions v on v.kind='crew_work_record_people' and v.value->>'record_id'=c.id
 union select u.uid,v.kind,v.source_id from units u join versions v on v.kind='work_session_capture_metadata' and v.value->>'unit_id'=u.uid::text
 union select c.uid,v.kind,v.source_id from custom_sessions c join versions v on v.kind='work_session_capture_metadata' and v.source_id=c.id
 union select c.uid,v.kind,v.source_id from custom_sessions c join versions v on v.kind='custom_work_history' and v.value->>'entity_id'=c.id
 union select u.uid,v.kind,v.source_id from units u join versions v on v.kind='custom_work_history' and v.value->>'entity_id'=u.uid::text
 and (v.value->>'action' not in('unit','link') or v.value#>'{before_value,facts,installation_complete}' is distinct from v.value#>'{after_value,facts,installation_complete}')
 union select u.uid,'custom_work_units'::text,r.id::text from units u join public.custom_work_units r on r.id=u.uid
 union select u.uid,'project_openings'::text,r.id::text from mapped u join public.project_openings r on r.id::text=u.id
 union select u.uid,'unit_sessions'::text,r.id::text from mapped u join public.unit_sessions r on r.opening_id::text=u.id
 union select u.uid,'task_sessions'::text,r.id::text from mapped u join public.task_sessions r on r.opening_id::text=u.id
 union select u.uid,'opening_phases'::text,r.id::text from mapped u join public.opening_phases r on r.opening_id::text=u.id
 union select u.uid,'unit_redos'::text,r.id::text from mapped u join public.unit_redos r on r.opening_id::text=u.id
 union select u.uid,'qc_checks'::text,r.id::text from mapped u join public.qc_checks r on r.project_opening_id::text=u.id
 union select u.uid,'install_events'::text,r.id::text from mapped u join public.install_events r on r.project_opening_id::text=u.id
 union select u.uid,'custom_work_sessions'::text,r.id::text from custom_sessions u join public.custom_work_sessions r on r.id::text=u.id
 union select u.uid,'service_visit_units'::text,r.id::text from service_units u join public.service_visit_units r on r.id::text=u.id
 union select u.uid,'service_time_sessions'::text,r.id::text from service_units u join public.service_time_sessions r on r.unit_id::text=u.id
 union select u.uid,'service_visits'::text,r.id::text from visits u join public.service_visits r on r.id::text=u.id
 union select u.uid,'summons'::text,r.id::text from summons_for_unit u join public.summons r on r.id::text=u.id
 union select u.uid,'summon_helpers'::text,r.id::text from summons_for_unit u join public.summon_helpers r on r.summon_id::text=u.id
 union select u.uid,'crew_work_records'::text,r.id::text from crew u join public.crew_work_records r on r.id::text=u.id
 union select u.uid,'crew_work_record_people'::text,r.record_id::text||':'||r.profile_id::text from crew u join public.crew_work_record_people r on r.record_id::text=u.id
 union select u.uid,'work_session_capture_metadata'::text,r.session_id::text from units u join public.work_session_capture_metadata r on r.unit_id=u.uid
 union select u.uid,'work_session_capture_metadata'::text,r.session_id::text from custom_sessions u join public.work_session_capture_metadata r on r.session_id::text=u.id
 union select u.uid,'custom_work_history'::text,r.id::text from custom_sessions u join public.custom_work_history r on r.entity_id::text=u.id
 union select u.uid,'custom_work_history'::text,r.id::text from units u join public.custom_work_history r on r.entity_id=u.uid and (r.action not in('unit','link') or r.before_value#>'{facts,installation_complete}' is distinct from r.after_value#>'{facts,installation_complete}')
), grouped as(select u.uid,coalesce(jsonb_agg(jsonb_build_object('kind',s.kind,'id',s.source_id) order by s.kind,s.source_id) filter(where s.source_id is not null),'[]') sources
 from units u left join selected s on s.uid=u.uid group by u.uid)
 select case when (select count(*) from selected)>200000 or (select count(distinct(kind,source_id)) from selected)>20000 then null
 else coalesce(jsonb_object_agg(uid::text,sources),'{}') end from grouped
$$;

-- METADATA_REVIEW_ADAPTER_BEGIN
create function public._work_unit_metadata_live(p_sourceids jsonb) returns table(kind text,source_id text,value jsonb)
language sql stable security definer set search_path=public,pg_temp as $$
 with selected as materialized(select distinct x->>'kind' kind,x->>'id' id from jsonb_array_elements(p_sourceids)x)
 select 'custom_work_units'::text kind,r.id::text source_id,public._work_activity_source_material('custom_work_units',to_jsonb(r)) value from public.custom_work_units r where exists(select 1 from selected x where x.kind='custom_work_units' and x.id=r.id::text)
 union all
 select 'project_openings'::text kind,r.id::text source_id,public._work_activity_source_material('project_openings',to_jsonb(r)) value from public.project_openings r where exists(select 1 from selected x where x.kind='project_openings' and x.id=r.id::text)
 union all
 select 'service_visit_units'::text kind,r.id::text source_id,public._work_activity_source_material('service_visit_units',to_jsonb(r)) value from public.service_visit_units r where exists(select 1 from selected x where x.kind='service_visit_units' and x.id=r.id::text)
 union all
 select 'service_visits'::text kind,r.id::text source_id,public._work_activity_source_material('service_visits',to_jsonb(r)) value from public.service_visits r where exists(select 1 from selected x where x.kind='service_visits' and x.id=r.id::text)
 union all
 select 'summons'::text kind,r.id::text source_id,public._work_activity_source_material('summons',to_jsonb(r)) value from public.summons r where exists(select 1 from selected x where x.kind='summons' and x.id=r.id::text)
 union all
 select 'unit_redos'::text kind,r.id::text source_id,public._work_activity_source_material('unit_redos',to_jsonb(r)) value from public.unit_redos r where exists(select 1 from selected x where x.kind='unit_redos' and x.id=r.id::text)
 union all
 select 'qc_checks'::text kind,r.id::text source_id,public._work_activity_source_material('qc_checks',to_jsonb(r)) value from public.qc_checks r where exists(select 1 from selected x where x.kind='qc_checks' and x.id=r.id::text)
 union all
 select 'install_events'::text kind,r.id::text source_id,public._work_activity_source_material('install_events',to_jsonb(r)) value from public.install_events r where exists(select 1 from selected x where x.kind='install_events' and x.id=r.id::text)
 union all
 select 'crew_work_records'::text kind,r.id::text source_id,public._work_activity_source_material('crew_work_records',to_jsonb(r)) value from public.crew_work_records r where exists(select 1 from selected x where x.kind='crew_work_records' and x.id=r.id::text)
 union all
 select 'crew_work_record_people'::text kind,r.record_id::text||':'||r.profile_id::text source_id,public._work_activity_source_material('crew_work_record_people',to_jsonb(r)) value from public.crew_work_record_people r where exists(select 1 from selected x where x.kind='crew_work_record_people' and x.id=r.record_id::text||':'||r.profile_id::text)
 union all
 select 'work_session_capture_metadata'::text kind,r.session_id::text source_id,public._work_activity_source_material('work_session_capture_metadata',to_jsonb(r)) value from public.work_session_capture_metadata r where exists(select 1 from selected x where x.kind='work_session_capture_metadata' and x.id=r.session_id::text)
 union all
 select 'custom_work_history'::text kind,r.id::text source_id,public._work_activity_source_material('custom_work_history',to_jsonb(r)) value from public.custom_work_history r where exists(select 1 from selected x where x.kind='custom_work_history' and x.id=r.id::text)
 union all
 select 'custom_work_sessions'::text kind,r.id::text source_id,public._work_activity_source_material('custom_work_sessions',to_jsonb(r)) value from public.custom_work_sessions r where exists(select 1 from selected x where x.kind='custom_work_sessions' and x.id=r.id::text)
 union all
 select 'unit_sessions'::text kind,r.id::text source_id,public._work_activity_source_material('unit_sessions',to_jsonb(r)) value from public.unit_sessions r where exists(select 1 from selected x where x.kind='unit_sessions' and x.id=r.id::text)
 union all
 select 'task_sessions'::text kind,r.id::text source_id,public._work_activity_source_material('task_sessions',to_jsonb(r)) value from public.task_sessions r where exists(select 1 from selected x where x.kind='task_sessions' and x.id=r.id::text)
 union all
 select 'service_time_sessions'::text kind,r.id::text source_id,public._work_activity_source_material('service_time_sessions',to_jsonb(r)) value from public.service_time_sessions r where exists(select 1 from selected x where x.kind='service_time_sessions' and x.id=r.id::text)
 union all
 select 'opening_phases'::text kind,r.id::text source_id,public._work_activity_source_material('opening_phases',to_jsonb(r)) value from public.opening_phases r where exists(select 1 from selected x where x.kind='opening_phases' and x.id=r.id::text)
 union all
 select 'summon_helpers'::text kind,r.id::text source_id,public._work_activity_source_material('summon_helpers',to_jsonb(r)) value from public.summon_helpers r where exists(select 1 from selected x where x.kind='summon_helpers' and x.id=r.id::text)
$$;
create function public._work_unit_metadata_scope(actor uuid,unit_id uuid,p_sourceids jsonb) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare ub jsonb;u public.custom_work_units;f public.work_unit_fact_revisions;
 history jsonb;live jsonb;jobs jsonb;openings jsonb;fact_origins jsonb;people uuid[];sourceids jsonb;v jsonb;w jsonb;j uuid;o uuid;
 active integer:=0;pending integer:=0;proven boolean:=true;dimension_proven boolean:=true;normal_sources jsonb;shift_history jsonb;dimension jsonb;manifest jsonb;integrity jsonb;inc bigint;
begin
 ub:=public._work_activity_unit_basis(unit_id,actor);if ub is null then return null;end if;
 select * into u from public.custom_work_units where id=unit_id;
 select r.* into f from public.work_unit_fact_revisions r join public.work_unit_fact_current c on c.current_revision_id=r.id where c.unit_id=u.id;
 inc:=(ub->>'incarnationEpoch')::bigint;
 if f.id is not null and (f.unit_id is distinct from u.id or not exists(select 1 from public.work_unit_fact_current c where c.unit_id=u.id and c.current_revision_id=f.id and c.current_revision=f.revision)) then return null;end if;
 -- A reused physical UUID cannot inherit a pre-existing history partition.
 -- Canonical writers already refuse it; administrative reconciliation is explicit.
 if inc<>0 then proven:=false;end if;
 sourceids:=p_sourceids;
 if jsonb_typeof(sourceids) is distinct from 'array' then return null;end if;
 if jsonb_array_length(sourceids)>4000 then return null;end if;
 select coalesce(jsonb_agg(to_jsonb(h) order by h.id),'[]') into history from public.work_activity_source_history h
 where exists(select 1 from jsonb_array_elements(sourceids) x where x->>'kind'=h.source_kind and x->>'id'=h.source_id);
 -- Baseline captures current rows only; missing pre-install intermediate work is unknown.
 if exists(select 1 from jsonb_array_elements(history) h where h->>'legacy_baseline'='true') then proven:=false;end if;
 if jsonb_array_length(history)>10000 or octet_length(history::text)>2000000 then return null;end if;
 select coalesce(jsonb_agg(jsonb_build_object('kind',s.kind,'id',s.source_id,'value',s.value) order by s.kind,s.source_id),'[]') into live
 from public._work_unit_metadata_live(sourceids) s;
 -- Re-enabled triggers cannot make an uncaptured live source trustworthy.
 -- Compare only the terminal captured state, including captured tombstones.
 -- An older matching NEW cannot conceal a bypassed A -> B -> A reversal.
 with recursive included as materialized (
 select h.* from public.work_activity_source_history h where exists(
 select 1 from jsonb_array_elements(sourceids) s where s->>'kind'=h.source_kind and s->>'id'=h.source_id)
 ), heads as (
 select h.* from included h where not exists(select 1 from included n where n.predecessor_id=h.id)
 ), chain(id,predecessor_id) as (
 select id,predecessor_id from heads union select h.id,h.predecessor_id from included h join chain n on h.id=n.predecessor_id
 ) select proven and not (
 exists(select 1 from jsonb_array_elements(sourceids) s where
 (select count(*) from heads h where h.source_kind=s->>'kind' and h.source_id=s->>'id')<>1
 or (select count(*) from included h where h.source_kind=s->>'kind' and h.source_id=s->>'id' and h.predecessor_id is null)<>1
 or coalesce((select h.after_value from heads h where h.source_kind=s->>'kind' and h.source_id=s->>'id' order by h.id limit 1),'{}')
 is distinct from coalesce((select l->'value' from jsonb_array_elements(live) l where l->>'kind'=s->>'kind' and l->>'id'=s->>'id'),'{}'))
 or exists(select 1 from included h where h.predecessor_id is not null and not exists(
 select 1 from included p where p.id=h.predecessor_id and p.source_kind=h.source_kind and p.source_id=h.source_id))
 or exists(select 1 from included where predecessor_id is not null group by predecessor_id having count(*)>1)
 or (select count(*) from chain)<>(select count(*) from included)
 ) into proven;
 select coalesce(jsonb_agg(jsonb_build_object('source',to_jsonb(e),'actor',t.actor_id,'recordedAt',t.received_at,
 'selectedAt',t.selected_effective_at,'timeReason',t.time_selection_reason,'commandId',t.command_id,'requestId',t.source_request_id) order by e.id),'[]') into normal_sources
 from public.personal_activity_transition_sources e join public.personal_activity_transitions t on t.id=e.transition_id
 where exists(select 1 from jsonb_array_elements(sourceids) x where x->>'id'=e.source_id::text and x->>'kind'=case e.source_kind when 'custom' then 'custom_work_sessions' when 'unit' then 'unit_sessions' when 'task' then 'task_sessions' when 'service' then 'service_time_sessions' when 'phase' then 'opening_phases' when 'helper' then 'summon_helpers' end);
 -- Only shift mutations that affect an included interval/binding enter its
 -- lifecycle. A later unrelated activity or break on the same shift does not.
 with intervals as (
 select distinct r.value v from jsonb_array_elements(history) h
 cross join lateral(values(h->'before_value'),(h->'after_value')) r(value)
 where h->>'source_kind' in ('custom_work_sessions','service_time_sessions') and r.value->>'shift_id' is not null
 ), relevant as (
 select distinct h.* from public.work_activity_source_history h join intervals i on h.source_kind='time_shifts' and h.source_id=i.v->>'shift_id'
 where h.legacy_baseline or h.after_value='{}'
 or (h.before_value<>'{}' and (h.before_value->'profile_id' is distinct from h.after_value->'profile_id' or h.before_value->'project_id' is distinct from h.after_value->'project_id'))
 or exists(select 1 from (values(h.before_value),(h.after_value)) b(v) where b.v<>'{}' and
 (b.v->>'status' in ('needs_finish','rejected','voided') or b.v->>'profile_id' is distinct from i.v->>'profile_id'
 or (b.v->>'clock_in_at')::timestamptz>(i.v->>'started_at')::timestamptz
 or (i.v->>'ended_at' is not null and b.v->>'clock_out_at' is not null and (b.v->>'clock_out_at')::timestamptz<(i.v->>'ended_at')::timestamptz)))
 ) select coalesce(jsonb_agg(to_jsonb(h) order by h.id),'[]') into shift_history from relevant h;
 if exists(select 1 from jsonb_array_elements(shift_history) h where h->>'legacy_baseline'='true') then proven:=false;end if;
 -- Old collapsed engine events do not prove their lost intermediate bindings.
 if exists(select 1 from jsonb_array_elements(normal_sources) n where not exists(
 select 1 from public.work_activity_source_history h where h.source_id=n#>>'{source,source_id}' and not h.legacy_baseline
 and (n#>>'{source,transition_id}')::uuid=any(h.transition_ids)
 and h.source_kind=case n#>>'{source,source_kind}' when 'custom' then 'custom_work_sessions' when 'unit' then 'unit_sessions' when 'task' then 'task_sessions' when 'service' then 'service_time_sessions' when 'phase' then 'opening_phases' when 'helper' then 'summon_helpers' end)) then proven:=false;end if;
 -- Captured and prior-review facts keep their original source partition even
 -- after a replacement observation moves the current fact to another context.
 select coalesce(jsonb_agg(to_jsonb(r) order by r.id),'[]') into fact_origins
 from public.work_unit_fact_revisions r where r.unit_id=u.id and r.unit_incarnation_epoch=inc and
 (r.id=f.id or exists(select 1 from jsonb_array_elements(live) m where m->>'kind'='work_session_capture_metadata' and m#>>'{value,unit_id}'=u.id::text and (m#>>'{value,fact_revision}')::bigint=r.revision)
 or exists(select 1 from public.work_unit_review_events e where e.unit_id=u.id and e.incarnation=inc and e.basis->>'factId'=r.id::text));
 for v in select value from jsonb_array_elements(fact_origins) loop
 if not public._work_unit_fact_context_visible(actor,v->>'origin_kind',(v->>'origin_project_id')::uuid,(v->>'origin_opening_id')::uuid,(v->>'origin_author_id')::uuid,(v->>'origin_is_test')::boolean,true) then return null;end if;
 end loop;
 -- Every historical/current direct job and opening, plus retained review origins.
 with material as (
 select r.value from jsonb_array_elements(history) h cross join lateral(values(h->'before_value'),(h->'after_value')) r(value)
 union all select x->'value' from jsonb_array_elements(live) x
 union all select r.value from jsonb_array_elements(normal_sources) e cross join lateral(values(e#>'{source,before_evidence}'),(e#>'{source,after_evidence}')) r(value)
 ), shift_refs as (
 select distinct value->>'shift_id' id from material where value->>'shift_id' is not null
 union select n#>>'{source,source_shift_id}' from jsonb_array_elements(normal_sources) n where n#>>'{source,source_shift_id}' is not null
 ), deps as (
 select value->>'project_id' job,coalesce(value->>'opening_id',value->>'project_opening_id') opening from material
 union all select t.project_id::text,null from public.time_shifts t where t.id::text in(select id from shift_refs)
 union all select r.value->>'project_id',null from public.work_activity_source_history h cross join lateral(values(h.before_value),(h.after_value)) r(value) where h.source_kind='time_shifts' and h.source_id in(select id from shift_refs)
 union all select u.project_id::text,u.opening_id::text
 union all select f.origin_project_id::text,f.origin_opening_id::text
 union all select x->>'origin_project_id',x->>'origin_opening_id' from jsonb_array_elements(fact_origins) x
 union all select x#>>'{}',null from public.work_unit_review_events e cross join lateral jsonb_array_elements(e.scope_manifest->'jobs') x where e.unit_id=u.id and e.incarnation=inc
 union all select null,x#>>'{}' from public.work_unit_review_events e cross join lateral jsonb_array_elements(e.scope_manifest->'openings') x where e.unit_id=u.id and e.incarnation=inc
 ) select (select coalesce(jsonb_agg(job order by job),'[]') from(select distinct job from deps where job is not null) a),
 (select coalesce(jsonb_agg(opening order by opening),'[]') from(select distinct opening from deps where opening is not null) b) into jobs,openings;
 for v in select value from jsonb_array_elements(openings) loop
 select project_id into j from public.project_openings where id=(v#>>'{}')::uuid and removed_at is null;
 if j is null or not public._ai_job_visible(j,actor) then return null;end if;
 jobs:=jobs||to_jsonb(j);
 end loop;
 select coalesce(jsonb_agg(distinct value order by value),'[]') into jobs from jsonb_array_elements(jobs);
 for v in select value from jsonb_array_elements(jobs) loop
 if not public._ai_job_visible((v#>>'{}')::uuid,actor) then return null;end if;
 end loop;
 -- Service grants are an additional source gate, never replaced by job visibility.
 for v in select h->'value' from jsonb_array_elements(live) h where h->>'kind' like 'service_%'
 union all select r.value from jsonb_array_elements(history) h cross join lateral(values(h->'before_value'),(h->'after_value')) r(value) where h->>'source_kind' like 'service_%' and r.value<>'{}' loop
 if v->>'project_id' is null or not public.service_job_access((v->>'project_id')::uuid) then return null;end if;
 end loop;
 -- Source transfer retains and authorizes BOTH unit contexts, without treating
 -- all work on that destination unit as work on this unit.
 for v in select r.value from jsonb_array_elements(history) h cross join lateral(values(h->'before_value'),(h->'after_value')) r(value)
 where h->>'source_kind' in ('custom_work_sessions','work_session_capture_metadata','service_visit_units') loop
 j:=coalesce(v->>'work_unit_id',v->>'unit_id')::uuid;
 if j is not null and public._work_activity_unit_basis(j,actor) is null then return null;end if;
 end loop;
 -- Only actual engine subjects belong here: sessions/helpers use profile_id,
 -- phases use started_by. Creators/reviewers are not guessed work subjects.
 select array_agg(distinct p.id::uuid) filter(where p.id is not null) into people
 from (select h->>'source_kind' kind,r.value v from jsonb_array_elements(history) h
 cross join lateral(values(h->'before_value'),(h->'after_value')) r(value)
 union all select l->>'kind',l->'value' from jsonb_array_elements(live) l) x
 cross join lateral(values(x.v->>'profile_id'),(case when x.kind='opening_phases' then x.v->>'started_by' end)) p(id);
 -- Exact source safety never depends on an independently collected person set.
 -- Source-less state uncertainty remains conservative: backdated or missing
 -- intervals cannot prove that it affected only some other unit.
 select coalesce(jsonb_agg(to_jsonb(e) order by e.id),'[]') into integrity from public.work_activity_safety_events e
 where (e.source_kind='state' and e.profile_id=any(coalesce(people,'{}')))
 or exists(select 1 from jsonb_array_elements(sourceids) x where x->>'id'=e.source_id::text and x->>'kind'=case e.source_kind when 'custom' then 'custom_work_sessions' when 'unit' then 'unit_sessions' when 'task' then 'task_sessions' when 'service' then 'service_time_sessions' when 'phase' then 'opening_phases' when 'helper' then 'summon_helpers' end);
 if integrity<>'[]' then proven:=false;end if;
 if exists(select 1 from public.personal_activity_state where profile_id=any(coalesce(people,'{}')) and (revision>=9007199254740991 or integrity_state<>'clean')) then proven:=false;end if;
 if exists(select 1 from public.service_time_sessions t where t.unit_id is not null and to_jsonb(t.project_id) in(select value from jsonb_array_elements(jobs)) and not exists(select 1 from public.work_activity_source_history h where h.source_kind='service_visit_units' and h.source_id=t.unit_id::text)) then proven:=false;end if;
 if exists(select 1 from public.work_unit_fact_context_epochs where epoch>=9007199254740991 and
 ((scope_kind like 'unit_%' and scope_id=u.id) or (scope_kind='opening' and to_jsonb(scope_id) in(select value from jsonb_array_elements(openings))) or (scope_kind='project' and to_jsonb(scope_id) in(select value from jsonb_array_elements(jobs))))) then proven:=false;dimension_proven:=false;end if;
 for v in select value from jsonb_array_elements(live) loop
 w:=v->'value';
 if v->>'kind' in ('custom_work_sessions','unit_sessions','task_sessions','service_time_sessions') then
 if w->>'started_at' is null or (w->>'ended_at' is not null and (w->>'ended_at')::timestamptz<(w->>'started_at')::timestamptz) then proven:=false;end if;
 if w->>'ended_at' is null and (v->>'kind'<>'task_sessions' or w->>'state'='on_task') then active:=active+1;end if;
 if w->>'review_required'='true' or w->>'shift_status' in ('needs_finish','rejected','voided') then pending:=pending+1;proven:=false;end if;
 if w->>'shift_id' is not null then
 if not exists(select 1 from public.time_shifts s where s.id=(w->>'shift_id')::uuid and s.status not in ('needs_finish','rejected','voided') and s.profile_id=(w->>'profile_id')::uuid
 and s.clock_in_at<=(w->>'started_at')::timestamptz and (s.clock_out_at is null or (w->>'ended_at' is not null and s.clock_out_at>=(w->>'ended_at')::timestamptz))) then proven:=false;pending:=pending+1;end if;
 end if;
 elsif v->>'kind'='opening_phases' and w->>'status' not in ('submitted','approved','done','complete') then pending:=pending+1;
 elsif v->>'kind'='summon_helpers' and w->>'completed_at' is null and w->>'canceled_at' is null then active:=active+1;
 elsif v->>'kind'='unit_redos' and w->>'resolved_at' is null then pending:=pending+1;
 elsif v->>'kind'='qc_checks' and w->>'status'='callback' then pending:=pending+1;
 elsif v->>'kind'='service_visit_units' and w->>'outcome'<>'resolved' then pending:=pending+1;
 end if;
 end loop;
 select pending+count(*)::integer into pending from public.personal_activity_state s where s.resume_token is not null and exists(
 select 1 from jsonb_array_elements(sourceids) x where x->>'id'=s.resume_source_id::text and x->>'kind'=case s.resume_source_kind when 'custom' then 'custom_work_sessions' when 'unit' then 'unit_sessions' when 'task' then 'task_sessions' when 'service' then 'service_time_sessions' when 'phase' then 'opening_phases' end);
 -- Snapshot the current intervals/review-required state; no global authority
 -- generation or unrelated person's revision appears in the unit token.
 dimension:=jsonb_build_object('version',1,'unit',ub-array['operationalRevision','eligibleForCapture','ineligibleReason'],'fact',to_jsonb(f));
 manifest:=jsonb_build_object('version',1,'unitId',u.id,'incarnation',inc,'dimension',dimension,
 'jobs',jobs,'openings',openings,'factOrigins',fact_origins,'completion',u.facts->'installation_complete','history',history,'current',live,'transitions',normal_sources,'shiftLifecycle',shift_history,'safety',integrity,'active',active,'pending',pending);
 if octet_length(manifest::text)>2500000 then return null;end if;
 return jsonb_build_object('unit',ub,'dimension',dimension,'manifest',manifest,'jobs',jobs,'openings',openings,
 'scopeToken','ur1:'||encode(sha256(convert_to(manifest::text,'UTF8')),'hex'),
 'proven',proven,'dimensionProven',dimension_proven,'active',active,'pending',pending,'observation',case when f.raw_observation is null then null else
 jsonb_build_object('observerId',f.observation_actor_id,'source',f.measurement_source,'widthDecimal',trim_scale((f.raw_observation->>'width')::numeric)::text,
 'heightDecimal',trim_scale((f.raw_observation->>'height')::numeric)::text,'unit',f.measurement_unit,'sourceReference',f.source_reference) end);
end; $$;
create function public._work_unit_metadata_review(actor uuid,s jsonb) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare c public.work_unit_review_current;verification public.work_unit_dimension_verifications;submission public.work_unit_review_events;
 q public.work_unit_review_events;b jsonb;defects jsonb;observation jsonb;inc bigint;uid uuid;ready boolean;proof boolean;matches boolean;qcstate text;acceptance text;dvstate text;
 verify_allowed boolean;reviewer boolean;factusable boolean;
begin
 if s is null then return null;end if;uid:=(s#>>'{unit,id}')::uuid;inc:=(s#>>'{unit,incarnationEpoch}')::bigint;
 select * into c from public.work_unit_review_current where unit_id=uid and incarnation=inc;
 if c.unit_id is null and exists(select 1 from public.work_unit_review_events where unit_id=uid and incarnation=inc) then return null;end if;
 if c.unit_id is not null and not exists(select 1 from public.work_unit_review_events e where e.id=c.latest_event_id and e.unit_id=uid and e.incarnation=inc and e.review_revision=c.review_revision and e.generation=c.generation) then return null;end if;
 select * into verification from public.work_unit_dimension_verifications where id=c.dimension_verification_id;
 if verification.id is not null and (verification.unit_id<>uid or verification.incarnation<>inc) then return null;end if;
 select * into submission from public.work_unit_review_events where id=c.current_submission_id;
 select * into q from public.work_unit_review_events where id=c.latest_qc_event_id;
 defects:=public._work_unit_review_defect_projection(uid,inc);
 if jsonb_array_length(defects)>200 or jsonb_array_length(defects)<>(select count(*) from public.work_unit_review_defects where unit_id=uid and incarnation=inc) then return null;end if;
 observation:=s->'observation';
 factusable:=s#>>'{unit,fact,id}' is not null and observation<>'null'::jsonb
 and s#>>'{unit,fact,eventKind}' not in ('incomplete','cleared')
 and (s#>>'{dimension,fact,unit_binding_epoch}')::bigint=(s#>>'{unit,bindingEpoch}')::bigint;
 factusable:=coalesce(factusable,false);
 proof:=(s->>'proven')::boolean; -- Top-level admission already attested exact coverage.
 ready:=(s->>'active')::integer=0 and (s->>'pending')::integer=0;
 matches:=submission.id is not null and submission.scope_manifest=s->'manifest' and submission.scope_token=s->>'scopeToken';
 qcstate:=coalesce(c.qc_state,'not_submitted');
 acceptance:='not_accepted';
 if qcstate in ('passed','awaiting_review') and not coalesce(matches,false) then qcstate:='not_submitted';acceptance:='noncurrent';end if;
 if c.qc_state='passed' and coalesce(matches,false) then
 if q.action<>'pass' or q.unit_id is distinct from uid or q.incarnation is distinct from inc or q.generation is distinct from c.generation or q.submission_id is distinct from c.current_submission_id then return null;end if;
 acceptance:=case when not proof then 'recorded_only' when ready and not exists(select 1 from jsonb_array_elements(defects) x where x->>'state'<>'verified_resolved') then 'accepted' else 'noncurrent' end;
 end if;
 dvstate:=case when verification.id is null then 'unverified' when verification.dimension_manifest=s->'dimension' and (s->>'dimensionProven')::boolean then 'verified' else 'noncurrent' end;
 reviewer:=public._work_unit_review_authority(actor,s->'jobs','final_qc');
 verify_allowed:=factusable and (s->>'dimensionProven')::boolean and observation->>'observerId' is not null and observation->>'observerId'<>actor::text and public._work_unit_review_authority(actor,s->'jobs','dimensions_edit');
 b:=case when s#>>'{unit,fact,id}' is null then null else jsonb_build_object('unitId',uid,'unitRevision',s#>'{unit,operationalRevision}',
 'factId',s#>'{unit,fact,id}','factRevision',s#>'{unit,fact,revision}','scopeToken',s->'scopeToken',
 'reviewRevision',coalesce(c.review_revision,0),'submissionId',c.current_submission_id,'generation',coalesce(c.generation,0)) end;
 return jsonb_build_object('basis',b,'basisStatus',case when b is null then 'unavailable' else 'current' end,
 'capabilities',jsonb_build_object('verifyDimensions',coalesce(verify_allowed,false),'submit',factusable and ready,
 'pass',factusable and reviewer and ready and coalesce(matches,false) and qcstate='awaiting_review' and not exists(select 1 from jsonb_array_elements(defects) x where x->>'state'='open'),
 'fail',factusable and reviewer and c.current_submission_id is not null,
 'claimResolved',factusable and exists(select 1 from jsonb_array_elements(defects) x where x->>'state'='open'),
 'reopen',factusable and reviewer),
 'observation',observation,'dimensionVerification',jsonb_build_object('state',dvstate,'verificationId',verification.id),
 'qc',jsonb_build_object('state',qcstate,'acceptance',acceptance,'lifecycle',case when proof then 'proven' else 'unproven' end,'qcAccepted',acceptance='accepted'),
 'work',jsonb_build_object('availability','available','activeCount',s->'active','pendingCount',s->'pending'),'defects',defects);
end; $$;
-- METADATA_REVIEW_ADAPTER_END
-- METADATA_PARTITION_ADAPTER_BEGIN
create function public._work_unit_metadata_shift_ids(p_project_id uuid,p_unit_id uuid,unit_scope jsonb) returns uuid[]
language sql stable security definer set search_path=public,pg_temp as $$
 select array_agg(distinct id) from (
 select id from public.time_shifts where p_unit_id is null and project_id=p_project_id
 union select s.shift_id from public.custom_work_sessions s where (p_unit_id is null and s.project_id=p_project_id) or (p_unit_id is not null and s.unit_id=p_unit_id)
 union select s.shift_id from public.custom_work_sessions s join public.work_session_capture_metadata m on m.session_id=s.id where (p_unit_id is null and m.project_id=p_project_id) or (p_unit_id is not null and m.unit_id=p_unit_id)
 union select (case when source_kind='time_shifts' then source_id else before_value->>'shift_id' end)::uuid from public.work_activity_source_history where source_kind in ('custom_work_sessions','service_time_sessions','time_shifts','task_sessions','project_openings') and p_unit_id is null and before_value->>'project_id'=p_project_id::text
 union select (case when source_kind='time_shifts' then source_id else after_value->>'shift_id' end)::uuid from public.work_activity_source_history where source_kind in ('custom_work_sessions','service_time_sessions','time_shifts','task_sessions','project_openings') and p_unit_id is null and after_value->>'project_id'=p_project_id::text
 union select (case when source_kind='time_shifts' then source_id else before_value->>'shift_id' end)::uuid from public.work_activity_source_history where source_kind='custom_work_sessions' and p_unit_id is not null and before_value->>'unit_id'=p_unit_id::text
 union select (case when source_kind='time_shifts' then source_id else after_value->>'shift_id' end)::uuid from public.work_activity_source_history where source_kind='custom_work_sessions' and p_unit_id is not null and after_value->>'unit_id'=p_unit_id::text
 union select (n#>>'{source,source_shift_id}')::uuid from jsonb_array_elements(unit_scope#>'{manifest,transitions}') n
 union select e.source_shift_id from public.personal_activity_transition_sources e where p_unit_id is null and (e.before_evidence->>'project_id'=p_project_id::text or e.after_evidence->>'project_id'=p_project_id::text)
 union select e.source_shift_id from public.personal_activity_transition_sources e join public.project_openings o on o.id::text=coalesce(e.after_evidence->>'opening_id',e.before_evidence->>'opening_id') where p_unit_id is null and o.project_id=p_project_id
 union select e.source_shift_id from public.personal_activity_transition_sources e join public.work_activity_source_history h on h.source_kind='project_openings' and h.source_id=coalesce(e.after_evidence->>'opening_id',e.before_evidence->>'opening_id') where p_unit_id is null and (h.before_value->>'project_id'=p_project_id::text or h.after_value->>'project_id'=p_project_id::text)
 ) q where id is not null;
$$;
create function public._work_unit_metadata_partition(actor uuid,p_project_id uuid,p_unit_id uuid,stamp timestamptz,unit_scope jsonb,review jsonb,ids uuid[],p_ledgers jsonb) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare sid uuid;ledger jsonb;ledgers jsonb:='[]';rows jsonb;unitrow public.custom_work_units;
 available constant jsonb:='{"protocolVersion":1,"availability":"unavailable","totals":null}';complete boolean:=true;personal_complete boolean:=true;trusted boolean:=false;
 orphan record;orphan_proof jsonb;scope_unproven boolean:=false;own_scope_unproven boolean:=false;reconciliation_authorized boolean:=false;reconciliation_ledgers jsonb;orphan_count integer:=0;cohort jsonb;reason text[]:='{}';area numeric;factor_num numeric;factor_den numeric;labor numeric;own_labor numeric;actual numeric;cohort_scope boolean;
begin
 reconciliation_authorized:=public._work_unit_review_authority(actor,jsonb_build_array(p_project_id),'final_qc');
 if p_unit_id is not null then
 select * into unitrow from public.custom_work_units where id=p_unit_id;
 if unitrow.id is null or unitrow.project_id<>p_project_id then return available;end if;
 if unit_scope is null or review is null then return available;end if;
 reconciliation_authorized:=reconciliation_authorized and public._work_unit_review_authority(actor,unit_scope->'jobs','final_qc');
 own_scope_unproven:=exists(select 1 from jsonb_array_elements(unit_scope#>'{manifest,history}') h where h->>'source_kind' in ('custom_work_sessions','unit_sessions','task_sessions','service_time_sessions') and (h#>>'{before_value,profile_id}'=actor::text or h#>>'{after_value,profile_id}'=actor::text) and not exists(select 1 from jsonb_array_elements(unit_scope#>'{manifest,transitions}') t where t#>>'{source,source_id}'=h->>'source_id' and t#>>'{source,source_shift_id}' is not null));
 scope_unproven:=not coalesce((unit_scope->>'proven')::boolean,false) or exists(
 select 1 from jsonb_array_elements(unit_scope#>'{manifest,history}') h where h->>'source_kind' in ('custom_work_sessions','unit_sessions','task_sessions','service_time_sessions')
 and not exists(select 1 from jsonb_array_elements(unit_scope#>'{manifest,transitions}') t where t#>>'{source,source_id}'=h->>'source_id' and t#>>'{source,source_shift_id}' is not null));
 end if;
 -- A legacy source without a retained payroll/transition binding cannot
 -- silently disappear into a zero. Check its original grants before the flag.
 for orphan in
 select distinct h.source_kind,h.source_id from public.work_activity_source_history h
 where h.source_kind in ('custom_work_sessions','service_time_sessions','task_sessions')
 and p_unit_id is null and (h.before_value->>'project_id'=p_project_id::text or h.after_value->>'project_id'=p_project_id::text)
 and not exists(select 1 from public.personal_activity_transition_sources e where e.source_id=h.source_id::uuid and e.source_shift_id is not null
 and e.source_kind=case h.source_kind when 'custom_work_sessions' then 'custom' when 'service_time_sessions' then 'service' else 'task' end)
 loop
 orphan_count:=orphan_count+1;if orphan_count>500 then return available;end if;
 orphan_proof:=public._work_totals_source(orphan.source_kind,orphan.source_id);
 if not public._work_totals_visible(actor,orphan.source_kind,orphan_proof) then return available;end if;
 scope_unproven:=true;
 reconciliation_authorized:=reconciliation_authorized and public._work_totals_visible(actor,orphan.source_kind,orphan_proof,0,true);
 own_scope_unproven:=own_scope_unproven or orphan_proof#>>'{current,profile_id}'=actor::text or exists(select 1 from jsonb_array_elements(orphan_proof->'history') h where h#>>'{before_value,profile_id}'=actor::text or h#>>'{after_value,profile_id}'=actor::text);
 end loop;
 complete:=not scope_unproven;personal_complete:=not scope_unproven;
 -- Include current payroll allocations and original captured project bindings.
 -- A missing retained shift is unavailable; it never becomes synthetic zero.
 if coalesce(array_length(ids,1),0)>500 then return available;end if;
 foreach sid in array coalesce(ids,'{}') loop
 ledger:=p_ledgers->sid::text;
 if ledger is null or ledger->>'availability' is distinct from 'available' then return available;end if;
 ledgers:=ledgers||jsonb_build_array(ledger);
 reconciliation_authorized:=reconciliation_authorized and coalesce((ledger->>'reconciliationAuthorized')::boolean,false);
 complete:=complete and (ledger->>'complete')::boolean;
 if ledger->>'profileId'=actor::text then personal_complete:=personal_complete and (ledger->>'complete')::boolean;end if;
 end loop;
 if octet_length(ledgers::text)>5000000 then return available;end if;
 -- Detailed payroll/review evidence has a stricter boundary than activity totals.
 select coalesce(jsonb_agg(l),'[]') into reconciliation_ledgers from jsonb_array_elements(ledgers) l where reconciliation_authorized or l->>'profileId'=actor::text;
 own_scope_unproven:=coalesce(own_scope_unproven,false) or exists(select 1 from jsonb_array_elements(reconciliation_ledgers) l where l->>'profileId'=actor::text and not (l->>'complete')::boolean);
 with claims as(select c.* from jsonb_array_elements(ledgers) l cross join lateral jsonb_to_recordset(l->'claims') as c("profileId" uuid,"projectId" uuid,"unitId" uuid,"definitionId" uuid,"definitionVersionId" uuid,"definitionVersion" integer,scope text,"labelEn" text,"labelEs" text,"machineKind" text,microseconds text,live boolean)
 where ((p_unit_id is null and c."projectId"=p_project_id and c.scope='general') or (p_unit_id is not null and c.scope='specific' and c."unitId"=p_unit_id))),
 grouped as(select "definitionId","definitionVersionId","definitionVersion",scope,"labelEn","labelEs",sum(microseconds::numeric) us,
 coalesce(sum(microseconds::numeric) filter(where "profileId"=actor),0) own,bool_or(live and "profileId"=actor) live from claims group by 1,2,3,4,5,6)
 select coalesce(jsonb_agg(jsonb_build_object('definitionId',g."definitionId",'definitionVersionId',g."definitionVersionId",'definitionVersion',g."definitionVersion",'scope',g.scope,
 'labelEn',g."labelEn",'labelEs',g."labelEs",'retired',d.retired_at is not null,
 'personal',jsonb_build_object('state',case when personal_complete then 'known' else 'partial' end,'microseconds',case when personal_complete then g.own::text end,'knownMicros',g.own::text,'includesLive',g.live),
 'scopeTotal',jsonb_build_object('state',case when complete then 'known' else 'partial' end,'microseconds',case when complete then g.us::text end,'knownMicros',g.us::text),
 'machineSubsets',(select coalesce(jsonb_agg(jsonb_build_object('machineKind',m.kind,'microseconds',m.us::text) order by m.kind),'[]') from(
 select "machineKind" kind,sum(microseconds::numeric) us from claims c where c."definitionVersionId"=g."definitionVersionId" and "machineKind" is not null group by 1)m)
 ) order by g."definitionId",g."definitionVersion"),'[]') into rows from grouped g join public.work_activity_definitions d on d.id=g."definitionId";
 select coalesce(sum((c->>'microseconds')::numeric),0),coalesce(sum((c->>'microseconds')::numeric)filter(where c->>'profileId'=actor::text),0) into labor,own_labor
 from jsonb_array_elements(ledgers) l cross join lateral jsonb_array_elements(l->'claims')c
 where ((p_unit_id is null and c->>'projectId'=p_project_id::text and c->>'scope'='general') or (p_unit_id is not null and c->>'scope'='specific' and c->>'unitId'=p_unit_id::text));
 cohort_scope:=p_unit_id is not null and reconciliation_authorized and public._work_unit_review_authority(actor,unit_scope->'jobs','final_qc');
 if not cohort_scope then cohort:=jsonb_build_object('availability','unavailable','reason',case when p_unit_id is null then 'unit_selection_required' else 'role_restricted' end);
 else
 if not complete then reason:=array_append(reason,'coverage_incomplete');end if;
 if exists(select 1 from jsonb_array_elements(ledgers)l where (l->>'unclassifiedMicros')::numeric>0) then reason:=array_append(reason,'unclassified_coverage');end if;
 if exists(select 1 from jsonb_array_elements(ledgers)l where not (l->>'approved')::boolean or (l->>'policyAdjustmentMicros')::numeric<>0) then reason:=array_append(reason,'payroll_not_trusted');end if;
 if review#>>'{dimensionVerification,state}'<>'verified' then reason:=array_append(reason,'dimensions_unverified');end if;
 if review#>>'{qc,qcAccepted}' is distinct from 'true' then reason:=array_append(reason,'qc_not_current_accepted');end if;
 if (unit_scope->>'active')::integer<>0 or (unit_scope->>'pending')::integer<>0 then reason:=array_append(reason,'active_or_rework');end if;
 if labor<=0 then reason:=array_append(reason,'no_attributed_labor');end if;
 factor_num:=case unit_scope#>>'{observation,unit}' when 'in' then 1 when 'ft' then 12 when 'mm' then 5 when 'cm' then 50 end;
 factor_den:=case unit_scope#>>'{observation,unit}' when 'mm' then 127 when 'cm' then 127 else 1 end;
 -- Exact rational area, no floating-point transport or rounded comparisons.
 if factor_num is null or unit_scope#>>'{observation,widthDecimal}' is null then reason:=array_append(reason,'area_unknown');
 else area:=(unit_scope#>>'{observation,widthDecimal}')::numeric*(unit_scope#>>'{observation,heightDecimal}')::numeric*factor_num*factor_num;end if;
 trusted:=cardinality(reason)=0;
 cohort:=jsonb_build_object('availability','available','unitId',p_unit_id,'eligible',trusted,'exclusions',to_jsonb(reason),
 'actualLaborMicros',labor::text,'excludedLaborMicros',case when trusted then '0' else labor::text end,
 'eligibleUnitIds',case when trusted then jsonb_build_array(p_unit_id) else '[]'::jsonb end,
 'laborNumeratorMicros',case when trusted then labor::text else '0' end,
 'areaSquareFeetNumerator',case when trusted then trim_scale(area)::text else '0' end,
 'areaSquareFeetDenominator',trim_scale(factor_den*factor_den*144)::text,
 'dimensionSource',unit_scope#>'{observation,source}','dimensionVerification',review#>'{dimensionVerification,state}',
 'floor',jsonb_build_object('state','unallocated','label',nullif(unitrow.facts->>'story',''),'areaCountedOnce',true),'generalOverheadIncluded',false);
 end if;
 return jsonb_build_object('protocolVersion',1,'availability','available','totals',jsonb_build_object('asOf',public._work_activity_iso(stamp),'actorId',actor,'projectId',p_project_id,'unitId',p_unit_id,
 'window',jsonb_build_object('kind','all_retained_selected_scope','from',null,'until',public._work_activity_iso(stamp),'personalScope','actual_actor_selected_scope'),
 'complete',complete,'personalComplete',personal_complete,'activities',rows,'scopeKnownMicros',labor::text,'personalKnownMicros',own_labor::text,
 'reconciliation',(select jsonb_build_object('scope',case when reconciliation_authorized then 'authorized_scope' else 'personal' end,'unresolvedScope',case when reconciliation_authorized then scope_unproven else own_scope_unproven end,'ledgerCount',count(*),'grossMicros',case when count(*)filter(where l->>'grossMicros' is null)=0 then sum((l->>'grossMicros')::numeric)::text end,
 'payrollMicros',case when count(*)filter(where l->>'payrollMicros' is null)=0 then sum((l->>'payrollMicros')::numeric)::text end,
 'classifiedMicros',coalesce(sum((l->>'classifiedMicros')::numeric),0)::text,'setupMicros',coalesce(sum((l->>'setupMicros')::numeric),0)::text,
 'unclassifiedMicros',coalesce(sum((l->>'unclassifiedMicros')::numeric),0)::text,'breakElapsedMicros',coalesce(sum((l->>'breakElapsedMicros')::numeric),0)::text,
 'breakDeductionMicros',coalesce(sum((l->>'breakDeductionMicros')::numeric),0)::text,'policyAdjustmentMicros',coalesce(sum((l->>'policyAdjustmentMicros')::numeric),0)::text,
 'issues',(select coalesce(jsonb_agg(distinct i),'[]') from jsonb_array_elements(reconciliation_ledgers)z cross join lateral jsonb_array_elements(z->'issues')i)) from jsonb_array_elements(reconciliation_ledgers)l),
 'cohort',cohort));
end$$;
-- METADATA_PARTITION_ADAPTER_END
create function public._work_unit_metadata_fraction(n numeric,d numeric) returns jsonb language plpgsql immutable set search_path=public,pg_temp as $$
declare f numeric;g numeric;begin if n is null or d is null or n<0 or d<=0 then return null;end if;f:=('1'||repeat('0',greatest(scale(n),scale(d))))::numeric;n:=n*f;d:=d*f;g:=gcd(n,d);return jsonb_build_object('numerator',trim_scale(n/g)::text,'denominator',trim_scale(d/g)::text);end$$;
create function public._work_unit_metadata_area(s jsonb) returns jsonb language plpgsql immutable set search_path=public,pg_temp as $$
declare n numeric;d numeric;begin
 n:=case s#>>'{observation,unit}' when 'in' then 1 when 'ft' then 12 when 'mm' then 5 when 'cm' then 50 end;d:=case s#>>'{observation,unit}' when 'mm' then 127 when 'cm' then 127 else 1 end;
 if n is null or s#>>'{observation,widthDecimal}' is null or s#>>'{observation,heightDecimal}' is null then return null;end if;
 return public._work_unit_metadata_fraction((s#>>'{observation,widthDecimal}')::numeric*(s#>>'{observation,heightDecimal}')::numeric*n*n,d*d*144);end$$;
create function public._work_unit_metadata_area_add(a jsonb,b jsonb) returns jsonb language sql immutable set search_path=public,pg_temp as $$
 select public._work_unit_metadata_fraction((a->>'numerator')::numeric*(b->>'denominator')::numeric+(b->>'numerator')::numeric*(a->>'denominator')::numeric,(a->>'denominator')::numeric*(b->>'denominator')::numeric)
$$;
create function public._work_unit_metadata_ratio(us numeric,area jsonb) returns jsonb language sql immutable set search_path=public,pg_temp as $$
 select case when (area->>'numerator')::numeric>0 then public._work_unit_metadata_fraction(us*(area->>'denominator')::numeric,3600000000*(area->>'numerator')::numeric) else null end
$$;
create function public._work_unit_metadata_bucket(m jsonb,k text) returns jsonb language plpgsql stable security definer set search_path=public,pg_temp as $$
declare x jsonb;v jsonb;begin
 if m#>>'{classification,state}'='noncurrent' then return jsonb_build_object('state','noncurrent','versionId',null,'label',null);end if;
 x:=m#>array['classification','values',k];if m#>>'{classification,state}'='unknown' or x->>'state'='unknown' then return jsonb_build_object('state','unknown','versionId',null,'label',null);end if;
 v:=public._work_unit_metadata_version((x->>'versionId')::uuid,case k when 'frameMaterial' then 'material' else k end,null,false);
 if v is null then return null;end if;return jsonb_build_object('state','known','versionId',v->'id','label',v#>'{value,labelEn}');end$$;
create function public._work_unit_metadata_sum_bucket(groups jsonb,key text,bucket jsonb,unit_id uuid,us numeric,area jsonb) returns jsonb
language plpgsql immutable set search_path=public,pg_temp as $$
declare v jsonb;total numeric;ar jsonb;begin
 v:=groups->key;if v is null then v:=bucket||jsonb_build_object('eligibleUnitIds','[]'::jsonb,'laborMicros','0','area',jsonb_build_object('numerator','0','denominator','1'));end if;
 if v->'eligibleUnitIds'@>jsonb_build_array(unit_id) then return groups;end if;
 total:=(v->>'laborMicros')::numeric+us;ar:=public._work_unit_metadata_area_add(v->'area',area);
 v:=v||jsonb_build_object('eligibleUnitIds',(v->'eligibleUnitIds')||jsonb_build_array(unit_id),'laborMicros',trim_scale(total)::text,'area',ar,'hoursPerSquareFoot',public._work_unit_metadata_ratio(total,ar));
 return groups||jsonb_build_object(key,v);end$$;
create function public._work_unit_metadata_aggregate(p_rows jsonb) returns jsonb language plpgsql stable security definer set search_path=public,pg_temp as $$
declare row jsonb;u uuid;us numeric;area jsonb;raw jsonb:='{"numerator":"0","denominator":"1"}';eligible_area jsonb:=raw;labor numeric:=0;actual numeric:=0;eligible_ids jsonb:='[]';
 groups jsonb:='{}';facets jsonb:='{}';floors jsonb:='{}';floorproductivity jsonb:='{}';customgroups jsonb:='{}';b jsonb;k text;key text;x jsonb;v jsonb;sharearea jsonb;fr jsonb;gr record;level record;group_rows jsonb;all_group_rows jsonb;blocked_dimensions text[]:='{}';chosen jsonb;matches integer;residual text;
begin
 select coalesce(jsonb_agg(jsonb_build_object('id',v.id,'value',v.value) order by v.id),'[]') into group_rows
 from public._work_unit_metadata_versions v join public._work_unit_metadata_definitions d on d.id=v.definition_id
 where d.kind='group' and v.state='published' and not exists(select 1 from public._work_unit_metadata_versions n where n.definition_id=d.id and n.version>v.version);
 -- Current trees require exact currently published parents. Renaming/retiring
 -- a parent never silently adopts its children into another grouping version.
 all_group_rows:=group_rows;
 for gr in select value item from jsonb_array_elements(group_rows) loop
 if gr.item#>>'{value,dimension}' not in ('category','subtype','material') or gr.item#>>'{value,dimension}' is null then blocked_dimensions:=array['category','subtype','material'];continue;end if;
 if public._work_unit_metadata_version((gr.item->>'id')::uuid,'group',null) is null
 or (gr.item#>>'{value,parentVersionId}' is not null and not exists(select 1 from jsonb_array_elements(group_rows)p where p->>'id'=gr.item#>>'{value,parentVersionId}' and p#>>'{value,dimension}'=gr.item#>>'{value,dimension}' and p#>'{value,members}'@>(gr.item#>'{value,members}'))) then
 blocked_dimensions:=array_append(blocked_dimensions,gr.item#>>'{value,dimension}');end if;
 end loop;
 select coalesce(jsonb_agg(item),'[]') into group_rows from jsonb_array_elements(group_rows)item where not item#>>'{value,dimension}'=any(blocked_dimensions);
 for row in select value from jsonb_array_elements(p_rows) loop
 if row->>'selected'='true' then actual:=actual+(row#>>'{recorded,knownMicros}')::numeric;if row->'rawArea'<>'null' then raw:=public._work_unit_metadata_area_add(raw,row->'rawArea');end if;end if;
 if row->>'eligible'<>'true' then continue;end if;u:=(row->>'unitId')::uuid;us:=(row#>>'{recorded,knownMicros}')::numeric;area:=row->'rawArea';labor:=labor+us;eligible_area:=public._work_unit_metadata_area_add(eligible_area,area);eligible_ids:=eligible_ids||jsonb_build_array(u);
 foreach k in array array['category','subtype','frameMaterial'] loop
 b:=row#>array['classificationBuckets',k];key:=k||':'||coalesce(b->>'versionId',b->>'state');groups:=public._work_unit_metadata_sum_bucket(groups,key,b||jsonb_build_object('dimension',k,'additive',true),u,us,area);end loop;
 if row#>>'{metadata,classification,state}'='current' then
 for x in select value from jsonb_array_elements(row#>'{metadata,classification,values,components}') loop
 v:=public._work_unit_metadata_version((x->>'versionId')::uuid,'component',null,false);if v is null then return null;end if;
 facets:=public._work_unit_metadata_sum_bucket(facets,'component:'||(x->>'versionId'),jsonb_build_object('dimension','component','versionId',x->'versionId','label',v#>'{value,labelEn}','additive',false),u,us,area);end loop;
 end if;
 fr:=row#>'{metadata,floor}';
 if fr->>'current'='true' and fr->>'state' in ('single','multilevel') then
 for x in select value from jsonb_array_elements(fr->'shares') loop
 v:=public._work_unit_metadata_version((x->>'versionId')::uuid,'floor',(row->>'projectId')::uuid);if v is null then return null;end if;
 sharearea:=public._work_unit_metadata_fraction((area->>'numerator')::numeric*(x->>'numerator')::numeric,(area->>'denominator')::numeric*(x->>'denominator')::numeric);
 key:=x->>'versionId';b:=jsonb_build_object('state','allocated','versionId',x->'versionId','floorId',x->'floorId','label',v#>'{value,labelEn}');
 floors:=public._work_unit_metadata_sum_bucket(floors,key,b,u,0,sharearea);
 if fr->>'state'='single' then floorproductivity:=public._work_unit_metadata_sum_bucket(floorproductivity,key,b,u,us,area);end if;
 end loop;
 else
 key:=case when fr->>'state'='unknown' then 'unknown' when fr->>'state'='unallocated' then 'unallocated' else 'noncurrent' end;
 floors:=public._work_unit_metadata_sum_bucket(floors,key,jsonb_build_object('state',key,'versionId',null,'floorId',null,'label',null),u,0,area);
 end if;
 -- At each exact parent, children plus explicit residuals partition that
 -- parent's eligible unit set. These levels remain nonadditive across levels.
 for level in
 select distinct item#>>'{value,dimension}' dimension,null::text parent_id,null::jsonb members from jsonb_array_elements(group_rows)item
 union all
 select item#>>'{value,dimension}',item->>'id',item#>'{value,members}' from jsonb_array_elements(group_rows)item
 where exists(select 1 from jsonb_array_elements(group_rows)child where child#>>'{value,parentVersionId}'=item->>'id')
 loop
 k:=case level.dimension when 'material' then 'frameMaterial' else level.dimension end;b:=row#>array['classificationBuckets',k];
 if level.parent_id is not null and (b->>'state'<>'known' or not level.members@>jsonb_build_array(b->'versionId')) then continue;end if;
 select count(*),jsonb_agg(child)->0 into matches,chosen from jsonb_array_elements(group_rows)child
 where child#>>'{value,dimension}'=level.dimension and child#>>'{value,parentVersionId}' is not distinct from level.parent_id
 and b->>'state'='known' and child#>'{value,members}'@>jsonb_build_array(b->'versionId');
 if matches>1 then blocked_dimensions:=array_append(blocked_dimensions,level.dimension);continue;end if;
 if matches=1 then
 key:=chosen->>'id';v:=jsonb_build_object('versionId',chosen->'id','dimension',k,'label',chosen#>'{value,labelEn}','parentVersionId',level.parent_id,'state','known','additive',false,'exclusiveWithinExactParentVersion',true);
 else
 residual:=case b->>'state' when 'unknown' then 'unknown' when 'noncurrent' then 'noncurrent' else 'unassigned' end;
 key:='residual:'||level.dimension||':'||coalesce(level.parent_id,'root')||':'||residual;
 v:=jsonb_build_object('versionId',null,'dimension',k,'label',null,'parentVersionId',level.parent_id,'state',residual,'additive',false,'exclusiveWithinExactParentVersion',true);
 end if;
 customgroups:=public._work_unit_metadata_sum_bucket(customgroups,key,v,u,us,area);
 end loop;
 end loop;
 return jsonb_build_object('actualKnownMicros',trim_scale(actual)::text,'eligibleUnitIds',eligible_ids,'laborMicros',trim_scale(labor)::text,'area',eligible_area,'hoursPerSquareFoot',public._work_unit_metadata_ratio(labor,eligible_area),'rawKnownArea',raw,
 'groups',(select coalesce(jsonb_agg(entry.value order by entry.key),'[]') from jsonb_each(groups)entry),
 'componentFacets',(select coalesce(jsonb_agg(entry.value order by entry.key),'[]') from jsonb_each(facets)entry),
 'customGroups',jsonb_build_object('availability',case when cardinality(blocked_dimensions)=0 then 'available' when not exists(select 1 from jsonb_array_elements(all_group_rows)item where not item#>>'{value,dimension}'=any(blocked_dimensions)) then 'unavailable' else 'partial' end,
 'trees',(select coalesce(jsonb_agg(jsonb_build_object('dimension',case dimensions.dimension when 'material' then 'frameMaterial' else dimensions.dimension end,
 'availability',case when dimensions.dimension=any(blocked_dimensions) then 'unavailable' else 'available' end,
 'groups',case when dimensions.dimension=any(blocked_dimensions) then null else (select coalesce(jsonb_agg(entry.value order by entry.key),'[]') from jsonb_each(customgroups)entry where entry.value->>'dimension'=case dimensions.dimension when 'material' then 'frameMaterial' else dimensions.dimension end) end) order by dimensions.dimension),'[]')
 from (select distinct item#>>'{value,dimension}' dimension from jsonb_array_elements(all_group_rows)item where item#>>'{value,dimension}' in ('category','subtype','material') union select unnest(blocked_dimensions))dimensions)),
 'floors',(select coalesce(jsonb_agg((entry.value-array['laborMicros','hoursPerSquareFoot'])||jsonb_build_object('areaOnly',true,'singleFloorProductivity',floorproductivity->entry.key) order by entry.key),'[]') from jsonb_each(floors)entry));
end$$;
create function public.work_unit_cohorts_read(p_project_id uuid,p_protocol_version integer default 1,p_filter jsonb default '{}') returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
declare actor uuid;stamp timestamptz;units uuid[];uid uuid;sid uuid;members jsonb;scopes jsonb:='{}';reviews jsonb:='{}';metadatas jsonb:='{}';partitions jsonb:='{}';ledgers jsonb:='{}';s jsonb;r jsonb;m jsonb;l jsonb;part jsonb;general jsonb;summary jsonb;rows jsonb:='[]';
 ids uuid[];allids uuid[]:='{}';ar jsonb;buckets jsonb;bucket jsonb;k text;x jsonb;selected boolean;eligible boolean;complete boolean:=true;result jsonb;bytes bigint:=0;history_count bigint:=0;transition_count bigint:=0;
 unavailable constant jsonb:='{"protocolVersion":1,"availability":"unavailable","cohort":null}';
begin
 -- METADATA_BOUNDARY_actor_BEGIN
 perform public._work_activity_read_committed();perform public._work_activity_gate();actor:=public._work_activity_actor();perform pg_advisory_xact_lock(7710,0);actor:=public._work_activity_actor();
 if not coalesce((select encode(sha256(convert_to(pin.value::text,'UTF8')),'hex')='43ffd737b1582224f5b360cd90f2c6651e3cc45486899ee5e15a93bb64541744' from (select jsonb_build_object('body',p.prosrc,'owner',pg_get_userbyid(p.proowner),'acl',p.proacl::text,'definer',p.prosecdef,'config',p.proconfig,'volatility',p.provolatile,'strict',p.proisstrict,'leakproof',p.proleakproof,'parallel',p.proparallel,'kind',p.prokind,'set',p.proretset,'result',pg_get_function_result(p.oid),'args',pg_get_function_identity_arguments(p.oid),'defaults',pg_get_expr(p.proargdefaults,0),'cost',p.procost,'rows',p.prorows,'support',p.prosupport::regprocedure::text,'language',(select lanname from pg_language where oid=p.prolang)) value from pg_proc p where p.oid=to_regprocedure('public._work_unit_metadata_coverage()'))pin),false) then actor:=null;
 elsif not public._work_unit_metadata_coverage() or not public._work_unit_review_coverage() or not public._work_totals_coverage() or not public._work_unit_contributors_coverage() then actor:=null;end if;
 -- METADATA_BOUNDARY_actor_END
 if actor is null then return unavailable;end if;
 if p_project_id is null or p_protocol_version is distinct from 1 or not public._work_unit_metadata_object(p_filter,'{}',array['categoryVersionIds','subtypeVersionIds','materialVersionIds']) or octet_length(p_filter::text)>16384 then raise exception using errcode='23514',message='Invalid cohort request.';end if;
 for k,x in select key,value from jsonb_each(p_filter) loop
 if jsonb_typeof(x)<>'array' or jsonb_array_length(x)>100 then raise exception using errcode='23514',message='Invalid cohort filter.';end if;for bucket in select value from jsonb_array_elements(x) loop perform public._work_unit_metadata_uuid(bucket);end loop;end loop;
 

 if not public._work_config_is_supervisor(actor) then raise exception using errcode='42501',message='A current supervisor or owner is required.';end if;
 stamp:=clock_timestamp();if not public._ai_job_visible(p_project_id,actor) then return unavailable;end if;
 if (select count(*) from public._work_unit_metadata_versions v join public._work_unit_metadata_definitions d on d.id=v.definition_id where d.project_id is null or d.project_id=p_project_id)>500 then return unavailable;end if;
 for k,x in select key,value from jsonb_each(p_filter) loop
 for bucket in select value from jsonb_array_elements(x) loop
 if public._work_unit_metadata_version((bucket#>>'{}')::uuid,case k when 'categoryVersionIds' then 'category' when 'subtypeVersionIds' then 'subtype' else 'material' end,null,false) is null then return unavailable;end if;end loop;end loop;
 select array_agg(id order by id) into units from public.custom_work_units where project_id=p_project_id;
 if coalesce(cardinality(units),0)>100 then return unavailable;end if;
 members:=public._work_unit_metadata_members(coalesce(units,'{}'));if members is null then return unavailable;end if;bytes:=octet_length(members::text);
 foreach uid in array coalesce(units,'{}') loop
 s:=public._work_unit_metadata_scope(actor,uid,members->uid::text);r:=public._work_unit_metadata_review(actor,s);m:=public._work_unit_metadata_state(actor,s,r);
 if s is null or r is null or m is null then return unavailable;end if;
 history_count:=history_count+jsonb_array_length(s#>'{manifest,history}');transition_count:=transition_count+jsonb_array_length(s#>'{manifest,transitions}');
 bytes:=bytes+octet_length(s::text)+octet_length(r::text)+octet_length(m::text);
 if bytes>20000000 or history_count>100000 or transition_count>50000 then return unavailable;end if;
 scopes:=scopes||jsonb_build_object(uid::text,s);reviews:=reviews||jsonb_build_object(uid::text,r);metadatas:=metadatas||jsonb_build_object(uid::text,m);
 ids:=public._work_unit_metadata_shift_ids(p_project_id,uid,s);if coalesce(cardinality(ids),0)>500 then return unavailable;end if;
 partitions:=partitions||jsonb_build_object(uid::text,to_jsonb(coalesce(ids,'{}')));allids:=allids||coalesce(ids,'{}');end loop;
 ids:=public._work_unit_metadata_shift_ids(p_project_id,null,null);if coalesce(cardinality(ids),0)>500 then return unavailable;end if;
 partitions:=partitions||jsonb_build_object('general',to_jsonb(coalesce(ids,'{}')));allids:=allids||coalesce(ids,'{}');
 select coalesce(array_agg(distinct i order by i),'{}') into allids from unnest(allids)i;
 if cardinality(allids)>2000 then return unavailable;end if;
 foreach sid in array allids loop
 -- Exactly one actual frozen ledger invocation per distinct union identity.
 l:=public._work_totals_shift(actor,sid,stamp);if l->>'availability' is distinct from 'available' then return unavailable;end if;
 bytes:=bytes+octet_length(l::text);if bytes>20000000 then return unavailable;end if;ledgers:=ledgers||jsonb_build_object(sid::text,l);end loop;
 select coalesce(array_agg(item.value::uuid),'{}') into ids from jsonb_array_elements_text(partitions->'general')item(value);
 general:=public._work_unit_metadata_partition(actor,p_project_id,null,stamp,null,null,ids,ledgers);if general->>'availability' is distinct from 'available' then return unavailable;end if;complete:=(general#>>'{totals,complete}')::boolean;
 foreach uid in array coalesce(units,'{}') loop
 s:=scopes->uid::text;r:=reviews->uid::text;m:=metadatas->uid::text;
 select coalesce(array_agg(item.value::uuid),'{}') into ids from jsonb_array_elements_text(partitions->uid::text)item(value);
 part:=public._work_unit_metadata_partition(actor,p_project_id,uid,stamp,s,r,ids,ledgers);if part->>'availability' is distinct from 'available' then return unavailable;end if;
 complete:=complete and (part#>>'{totals,complete}')::boolean;selected:=true;buckets:='{}';
 foreach k in array array['category','subtype','frameMaterial'] loop
 bucket:=public._work_unit_metadata_bucket(m,k);if bucket is null then return unavailable;end if;buckets:=buckets||jsonb_build_object(k,bucket);
 x:=p_filter->case k when 'category' then 'categoryVersionIds' when 'subtype' then 'subtypeVersionIds' else 'materialVersionIds' end;
 if x is not null and (bucket->>'state'<>'known' or not x@>jsonb_build_array(bucket->'versionId')) then selected:=false;end if;end loop;
 ar:=public._work_unit_metadata_area(s);eligible:=selected and coalesce((part#>>'{totals,cohort,eligible}')::boolean,false);
 rows:=rows||jsonb_build_array(jsonb_build_object('unitId',uid,'projectId',p_project_id,'incarnation',s#>>'{unit,incarnationEpoch}','selected',selected,'eligible',eligible,
 'physicalEligible',coalesce((part#>>'{totals,cohort,eligible}')::boolean,false),'exclusions',coalesce(part#>'{totals,cohort,exclusions}','[]'),
 'proof',jsonb_build_object('factId',s#>'{unit,fact,id}','factRevision',s#>'{unit,fact,revision}','scopeToken',s->'scopeToken','reviewBasis',r->'basis'),
 'rawArea',ar,'dimensionVerification',r->'dimensionVerification','qc',r->'qc','metadata',m-array['metadataBasis','floorBasis'],'classificationBuckets',buckets,
 'recorded',jsonb_build_object('knownMicros',part#>'{totals,scopeKnownMicros}','complete',part#>'{totals,complete}','personalKnownMicros',part#>'{totals,personalKnownMicros}','personalComplete',part#>'{totals,personalComplete}','activities',part#>'{totals,activities}','reconciliation',part#>'{totals,reconciliation}')));
 end loop;
 summary:=public._work_unit_metadata_aggregate(rows);if summary is null then return unavailable;end if;
 result:=jsonb_build_object('protocolVersion',1,'availability','available','cohort',jsonb_build_object('asOf',public._work_activity_iso(stamp),'projectId',p_project_id,'window','all_retained_unit_labor_current_inventory','filter',p_filter,'complete',complete,'units',rows,'summary',summary,'general',general->'totals','generalOverheadIncluded',false,'sourceVersion','701-only'));
 if octet_length(result::text)>2000000 then return unavailable;end if;return result;
end$$;

-- METADATA_IMPLEMENTATION_CONTINUE
-- A supplemental service census preserves the exact frozen predecessor census.
-- Its G lock makes this count coherent with metadata writers; the later Auth
-- delete is a different transaction, protected independently by actor RESTRICT.
create function public._work_unit_metadata_person_counts(p_id uuid,p_actor_id uuid default null) returns jsonb
language plpgsql volatile security definer set search_path=public,pg_temp as $$
begin
 -- METADATA_BOUNDARY_service_BEGIN
 perform public._work_activity_read_committed();perform public._work_activity_gate();perform pg_advisory_xact_lock(7710,0);
 if not coalesce((select encode(sha256(convert_to(pin.value::text,'UTF8')),'hex')='43ffd737b1582224f5b360cd90f2c6651e3cc45486899ee5e15a93bb64541744' from (select jsonb_build_object('body',p.prosrc,'owner',pg_get_userbyid(p.proowner),'acl',p.proacl::text,'definer',p.prosecdef,'config',p.proconfig,'volatility',p.provolatile,'strict',p.proisstrict,'leakproof',p.proleakproof,'parallel',p.proparallel,'kind',p.prokind,'set',p.proretset,'result',pg_get_function_result(p.oid),'args',pg_get_function_identity_arguments(p.oid),'defaults',pg_get_expr(p.proargdefaults,0),'cost',p.procost,'rows',p.prorows,'support',p.prosupport::regprocedure::text,'language',(select lanname from pg_language where oid=p.prolang)) value from pg_proc p where p.oid=to_regprocedure('public._work_unit_metadata_coverage()'))pin),false) then raise exception using errcode='55000',message='Person history source is unavailable.';
 elsif not public._work_unit_metadata_coverage() or not public._work_unit_review_coverage() or not public._work_totals_coverage() or not public._work_unit_contributors_coverage() then raise exception using errcode='55000',message='Person history source is unavailable.';end if;
 -- METADATA_BOUNDARY_service_END
 if p_actor_id is not null and not exists(select 1 from public.profiles where id=p_actor_id and role in ('owner','big_boss') and access_revoked_at is null and retired_at is null and not coalesce(is_partner,false)) then raise exception using errcode='42501',message='A current owner is required.';end if;
 if p_id is null then raise exception using errcode='23514',message='A person identity is required.';end if;
 if not exists(select 1 from public.profiles where id=p_id) then raise exception using errcode='P0002',message='Person is unavailable.';end if;
 return public.person_record_counts(p_id)||jsonb_build_object(
 '_work_unit_metadata_definitions.actor_id',(select count(*) from public._work_unit_metadata_definitions where actor_id=p_id),
 '_work_unit_metadata_versions.actor_id',(select count(*) from public._work_unit_metadata_versions where actor_id=p_id),
 '_work_unit_metadata_proposals.actor_id',(select count(*) from public._work_unit_metadata_proposals where actor_id=p_id),
 '_work_unit_metadata_revisions.actor_id',(select count(*) from public._work_unit_metadata_revisions where actor_id=p_id),
 '_work_unit_metadata_floors.actor_id',(select count(*) from public._work_unit_metadata_floors where actor_id=p_id),
 '_work_unit_metadata_commands.actor_id',(select count(*) from public._work_unit_metadata_commands where actor_id=p_id));
end$$;

-- METADATA_FUNCTION_ACLS_BEGIN
revoke all on function public._work_unit_metadata_aggregate(p_rows jsonb) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_area(s jsonb) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_area_add(a jsonb, b jsonb) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_basis(v jsonb, p_floor boolean) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_binding(p_unit uuid) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_bucket(m jsonb, k text) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_coverage() from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_decimal(v jsonb, positive boolean) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_floor_basis(s jsonb, r jsonb) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_fraction(n numeric, d numeric) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_gate() from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_immutable() from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_jobs_visible(actor uuid, jobs jsonb) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_live(p_sourceids jsonb) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_members(p_units uuid[]) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_number(v jsonb) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_object(v jsonb, required text[], optional text[]) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_origins(actor uuid, p_unit uuid) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_partition(actor uuid, p_project_id uuid, p_unit_id uuid, stamp timestamp with time zone, unit_scope jsonb, review jsonb, ids uuid[], p_ledgers jsonb) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_person_counts(p_id uuid, p_actor_id uuid) from public,anon,authenticated,service_role;
grant execute on function public._work_unit_metadata_person_counts(p_id uuid, p_actor_id uuid) to service_role;
revoke all on function public._work_unit_metadata_ratio(us numeric, area jsonb) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_review(actor uuid, s jsonb) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_scope(actor uuid, unit_id uuid, p_sourceids jsonb) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_shift_ids(p_project_id uuid, p_unit_id uuid, unit_scope jsonb) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_state(actor uuid, s jsonb, r jsonb) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_sum_bucket(groups jsonb, key text, bucket jsonb, unit_id uuid, us numeric, area jsonb) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_uuid(v jsonb) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_validate_definition(v jsonb, p_project uuid) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_validate_values(v jsonb, p_active boolean) from public,anon,authenticated,service_role;
revoke all on function public._work_unit_metadata_version(p_id uuid, p_kind text, p_project uuid, p_active boolean) from public,anon,authenticated,service_role;
revoke all on function public.work_unit_cohorts_read(p_project_id uuid, p_protocol_version integer, p_filter jsonb) from public,anon,service_role;
grant execute on function public.work_unit_cohorts_read(p_project_id uuid, p_protocol_version integer, p_filter jsonb) to authenticated;
revoke all on function public.work_unit_metadata_command(p_command_id uuid, p_protocol_version integer, p_request jsonb) from public,anon,service_role;
grant execute on function public.work_unit_metadata_command(p_command_id uuid, p_protocol_version integer, p_request jsonb) to authenticated;
revoke all on function public.work_unit_metadata_read(p_unit_id uuid, p_protocol_version integer) from public,anon,service_role;
grant execute on function public.work_unit_metadata_read(p_unit_id uuid, p_protocol_version integer) to authenticated;
revoke all on function public.work_unit_metadata_receipt(p_command_id uuid, p_protocol_version integer) from public,anon,service_role;
grant execute on function public.work_unit_metadata_receipt(p_command_id uuid, p_protocol_version integer) to authenticated;
-- METADATA_FUNCTION_ACLS_END
-- METADATA_COVERAGE_BEGIN
create or replace function public._work_unit_metadata_coverage() returns boolean
language plpgsql stable security definer set search_path=public,pg_temp as $combined_coverage$
declare actual text;
begin
 if current_setting('extra_float_digits') is distinct from '1' then
  return false;
 end if;
 select encode(sha256(convert_to(c.value::text,'UTF8')),'hex') into actual from (
select jsonb_build_object('publicCatalog',(select value from (-- Deliberately closed source-derived public catalog. Unknown live drift refuses;
-- this is not a request to normalize a provider to the disposable fixture.
select jsonb_build_object(
 'types',(select jsonb_agg(jsonb_build_object('name',t.typname,'kind',t.typtype,'owner',pg_get_userbyid(t.typowner),'acl',t.typacl::text,'category',t.typcategory,'preferred',t.typispreferred,'defined',t.typisdefined,'notNull',t.typnotnull,'base',format_type(nullif(t.typbasetype,0),t.typtypmod),'element',format_type(nullif(t.typelem,0),null),'collation',case when t.typcollation<>0 then t.typcollation::regcollation::text end,'default',t.typdefault,'defaultExpression',pg_get_expr(t.typdefaultbin,0),'input',t.typinput::regprocedure::text,'output',t.typoutput::regprocedure::text,'receive',t.typreceive::regprocedure::text,'send',t.typsend::regprocedure::text,'length',t.typlen,'byValue',t.typbyval,'alignment',t.typalign,'storage',t.typstorage,'delimiter',t.typdelim,'access',(select jsonb_object_agg(r.rolname,has_type_privilege(r.oid,t.oid,'USAGE')) from pg_roles r where r.rolname in('anon','authenticated','service_role')),'enum',(select jsonb_agg(jsonb_build_object('label',e.enumlabel,'sort',e.enumsortorder) order by e.enumsortorder) from pg_enum e where e.enumtypid=t.oid),'constraints',(select jsonb_agg(jsonb_build_object('name',k.conname,'definition',pg_get_constraintdef(k.oid,true),'validated',k.convalidated) order by k.conname) from pg_constraint k where k.contypid=t.oid),'range',(select jsonb_build_object('subtype',format_type(r.rngsubtype,null),'collation',r.rngcollation::regcollation::text,'opclass',(select n.nspname||'.'||o.opcname from pg_opclass o join pg_namespace n on n.oid=o.opcnamespace where o.oid=r.rngsubopc),'canonical',r.rngcanonical::regprocedure::text,'subdiff',r.rngsubdiff::regprocedure::text) from pg_range r where r.rngtypid=t.oid)) order by t.typname) from pg_type t where t.typnamespace='public'::regnamespace),
 'sequences',(select jsonb_agg(jsonb_build_object('name',c.relname,'owner',pg_get_userbyid(c.relowner),'acl',c.relacl::text,'type',format_type(s.seqtypid,null),'start',s.seqstart,'increment',s.seqincrement,'max',s.seqmax,'min',s.seqmin,'cache',s.seqcache,'cycle',s.seqcycle,'access',(select jsonb_agg(jsonb_build_object('role',r.rolname,'privilege',v.p,'allowed',has_sequence_privilege(r.oid,c.oid,v.p)) order by r.rolname,v.p) from pg_roles r cross join unnest(array['SELECT','UPDATE','USAGE'])v(p) where r.rolname in('anon','authenticated','service_role'))) order by c.relname) from pg_class c join pg_sequence s on s.seqrelid=c.oid where c.relnamespace='public'::regnamespace),
 'foreignTables',(select jsonb_agg(jsonb_build_object('table',c.relname,'options',f.ftoptions,'server',s.srvname,'serverOwner',pg_get_userbyid(s.srvowner),'serverType',s.srvtype,'serverVersion',s.srvversion,'serverOptionsDigest',encode(sha256(convert_to(coalesce(s.srvoptions::text,''),'UTF8')),'hex'),'serverAcl',s.srvacl::text,'serverAccess',(select jsonb_object_agg(r.rolname,has_server_privilege(r.oid,s.oid,'USAGE')) from pg_roles r where r.rolname in('anon','authenticated','service_role')),'wrapper',w.fdwname,'wrapperOwner',pg_get_userbyid(w.fdwowner),'wrapperAcl',w.fdwacl::text,'wrapperAccess',(select jsonb_object_agg(r.rolname,has_foreign_data_wrapper_privilege(r.oid,w.oid,'USAGE')) from pg_roles r where r.rolname in('anon','authenticated','service_role')),'handler',w.fdwhandler::regprocedure::text,'validator',w.fdwvalidator::regprocedure::text,'wrapperOptionsDigest',encode(sha256(convert_to(coalesce(w.fdwoptions::text,''),'UTF8')),'hex')) order by c.relname) from pg_foreign_table f join pg_class c on c.oid=f.ftrelid join pg_foreign_server s on s.oid=f.ftserver join pg_foreign_data_wrapper w on w.oid=s.srvfdw where c.relnamespace='public'::regnamespace),
 'functions',(select jsonb_agg(jsonb_build_object('name',p.proname,'arguments',pg_get_function_identity_arguments(p.oid),'body',encode(sha256(convert_to(p.prosrc,'UTF8')),'hex'),'result',pg_get_function_result(p.oid),'owner',pg_get_userbyid(p.proowner),'acl',p.proacl::text,'language',l.lanname,'kind',p.prokind,'definer',p.prosecdef,'config',p.proconfig,'volatility',p.provolatile,'strict',p.proisstrict,'leakproof',p.proleakproof,'cost',p.procost,'rows',p.prorows,'support',p.prosupport::regprocedure::text,'parallel',p.proparallel,'defaults',pg_get_expr(p.proargdefaults,0),'access',(select jsonb_object_agg(r.rolname,has_function_privilege(r.oid,p.oid,'EXECUTE')) from pg_roles r where r.rolname in('anon','authenticated','service_role'))) order by p.proname,pg_get_function_identity_arguments(p.oid)) from pg_proc p join pg_language l on l.oid=p.prolang where p.pronamespace='public'::regnamespace and not exists(select 1 from pg_depend d where d.classid='pg_proc'::regclass and d.objid=p.oid and d.deptype='e')),
 'relations',(select jsonb_agg(jsonb_build_object('name',c.relname,'kind',c.relkind,'owner',pg_get_userbyid(c.relowner),'rls',c.relrowsecurity,'forcedRls',c.relforcerowsecurity,'acl',c.relacl::text,'access',(select jsonb_agg(jsonb_build_object('role',r.rolname,'privilege',v.p,'table',has_table_privilege(r.oid,c.oid,v.p),'column',case when v.p in('SELECT','INSERT','UPDATE','REFERENCES') then has_any_column_privilege(r.oid,c.oid,v.p) end) order by r.rolname,v.p) from pg_roles r cross join unnest(array['SELECT','INSERT','UPDATE','DELETE','TRUNCATE','REFERENCES','TRIGGER'])v(p) where r.rolname in('anon','authenticated','service_role'))) order by c.relname) from pg_class c where c.relnamespace='public'::regnamespace and c.relkind in('r','p','v','m','f','c')),
 'columns',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',a.attname,'type',format_type(a.atttypid,a.atttypmod),'notNull',a.attnotnull,'generated',a.attgenerated,'identity',a.attidentity,'acl',a.attacl::text,'default',pg_get_expr(d.adbin,d.adrelid),'access',(select jsonb_agg(jsonb_build_object('role',r.rolname,'privilege',v.p,'allowed',has_column_privilege(r.oid,c.oid,a.attnum,v.p)) order by r.rolname,v.p) from pg_roles r cross join unnest(array['SELECT','INSERT','UPDATE','REFERENCES'])v(p) where r.rolname in('anon','authenticated','service_role'))) order by c.relname,a.attnum) from pg_class c join pg_attribute a on a.attrelid=c.oid and a.attnum>0 and not a.attisdropped left join pg_attrdef d on d.adrelid=c.oid and d.adnum=a.attnum where c.relnamespace='public'::regnamespace and c.relkind in('r','p','v','m','f','c')),
 'constraints',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',k.conname,'definition',pg_get_constraintdef(k.oid,true),'validated',k.convalidated,'noInherit',k.connoinherit,'enforced',coalesce((to_jsonb(k)->>'conenforced')::boolean,true)) order by c.relname,k.conname) from pg_constraint k join pg_class c on c.oid=k.conrelid where c.relnamespace='public'::regnamespace and k.contype<>'n'),
 'notNullConstraints',(select jsonb_agg(jsonb_build_object('table',c.relname,'column',a.attname,'validated',coalesce(n.validated,true),'enforced',coalesce(n.enforced,true),'noInherit',coalesce(n.no_inherit,false)) order by c.relname,a.attnum) from pg_class c join pg_attribute a on a.attrelid=c.oid and a.attnum>0 and not a.attisdropped left join lateral(select bool_and(k.convalidated) validated,bool_and(coalesce((to_jsonb(k)->>'conenforced')::boolean,true)) enforced,bool_or(k.connoinherit) no_inherit from pg_constraint k where k.conrelid=c.oid and k.contype='n' and a.attnum=any(k.conkey))n on true where c.relnamespace='public'::regnamespace and c.relkind in('r','p')),
 'indexes',(select jsonb_agg(jsonb_build_object('table',t.relname,'name',c.relname,'definition',pg_get_indexdef(i.indexrelid),'valid',i.indisvalid,'ready',i.indisready) order by t.relname,c.relname) from pg_index i join pg_class c on c.oid=i.indexrelid join pg_class t on t.oid=i.indrelid where t.relnamespace='public'::regnamespace),
 'triggers',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',t.tgname,'definition',pg_get_triggerdef(t.oid,true),'enabled',t.tgenabled) order by c.relname,t.tgname) from pg_trigger t join pg_class c on c.oid=t.tgrelid where c.relnamespace='public'::regnamespace and not t.tgisinternal),
 'policies',(select jsonb_agg(to_jsonb(p) order by p.tablename,p.policyname) from pg_policies p where schemaname='public'),
 'views',(select jsonb_agg(jsonb_build_object('name',c.relname,'definition',pg_get_viewdef(c.oid,true)) order by c.relname) from pg_class c where c.relnamespace='public'::regnamespace and c.relkind in('v','m'))
) value) public_catalog),'metadataCatalog',(select value from (select jsonb_build_object('metadataActorRetentionTriggers',(select coalesce(jsonb_agg(jsonb_build_object('table',c.relname,'constraintTable',d.relname,'constraint',k.conname,'function',t.tgfoid::regprocedure::text,'type',t.tgtype,'enabled',t.tgenabled,'internal',t.tgisinternal,'deferrable',t.tgdeferrable,'initiallyDeferred',t.tginitdeferred,'attributes',t.tgattr::text,'arguments',encode(t.tgargs,'hex'),'qual',pg_get_expr(t.tgqual,t.tgrelid)) order by d.relname,c.relname,t.tgfoid::regprocedure::text),'[]') from pg_trigger t join pg_constraint k on k.oid=t.tgconstraint join pg_class c on c.oid=t.tgrelid join pg_class d on d.oid=k.conrelid join pg_namespace n on n.oid=d.relnamespace where n.nspname='public' and starts_with(d.relname,'_work_unit_metadata_') and k.conname='metadata_actor_retention'),'metadataIndexes',(select coalesce(jsonb_agg(jsonb_build_object('name',c.relname,'definition',pg_get_indexdef(c.oid),'unique',i.indisunique,'valid',i.indisvalid,'ready',i.indisready) order by c.relname),'[]') from pg_index i join pg_class c on c.oid=i.indexrelid join pg_class t on t.oid=i.indrelid join pg_namespace n on n.oid=t.relnamespace where n.nspname='public' and starts_with(t.relname,'_work_unit_metadata_')),'metadataNamespaceTypes',(select coalesce(jsonb_agg(jsonb_build_object('name',t.typname,'kind',t.typtype,'relation',c.relname) order by t.typname),'[]') from pg_type t join pg_namespace n on n.oid=t.typnamespace left join pg_class c on c.oid=t.typrelid where n.nspname='public' and (starts_with(t.typname,'_work_unit_metadata_') or starts_with(t.typname,'work_unit_metadata_'))),'namespaceRelations',(select coalesce(jsonb_agg(jsonb_build_object('name',c.relname,'kind',c.relkind) order by c.relname),'[]') from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and (starts_with(c.relname,'_work_unit_contributors_') or starts_with(c.relname,'_work_unit_metadata_') or starts_with(c.relname,'work_unit_metadata_'))),'namespace',(select coalesce(jsonb_agg(jsonb_build_object('name',p.proname,'args',pg_get_function_identity_arguments(p.oid)) order by p.proname,pg_get_function_identity_arguments(p.oid)),'[]') from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and (p.proname='work_unit_contributors_read' or (starts_with(p.proname,'_work_unit_contributors_') or starts_with(p.proname,'_work_unit_metadata_') or starts_with(p.proname,'work_unit_metadata_') or p.proname=any(array['work_unit_metadata_read','work_unit_metadata_command','work_unit_metadata_receipt','work_unit_cohorts_read'])))),
 'functions',(select jsonb_agg(jsonb_build_object('name',p.proname,'args',pg_get_function_identity_arguments(p.oid),'language',(select lanname from pg_language where oid=p.prolang),'kind',p.prokind,'result',pg_get_function_result(p.oid),'defaults',pg_get_expr(p.proargdefaults,0),'strict',p.proisstrict,'parallel',p.proparallel,'leakproof',p.proleakproof,'cost',p.procost,'rows',p.prorows,'support',p.prosupport::regprocedure::text,'setReturning',p.proretset,'rawAcl',p.proacl::text,'body',encode(sha256(convert_to(p.prosrc,'UTF8')),'hex'),'config',p.proconfig,'owner',pg_get_userbyid(p.proowner),'definer',p.prosecdef,'volatility',p.provolatile) order by p.proname,pg_get_function_identity_arguments(p.oid)) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname=any(array['_ai_job_visible','_is_lead','_is_supervisor','_work_activity_actor','_work_activity_answers','_work_activity_authority_changed','_work_activity_authority_guard','_work_activity_authority_revision','_work_activity_bookkeeping_guard','_work_activity_claim_clock_setup','_work_activity_clock_replay_guard','_work_activity_clock_review','_work_activity_clock_setup_digest','_work_activity_close_all','_work_activity_close_source','_work_activity_command_basis','_work_activity_consume','_work_activity_context_assert','_work_activity_context_close','_work_activity_context_commit_guard','_work_activity_context_for','_work_activity_context_guard','_work_activity_context_open','_work_activity_ensure_state','_work_activity_ephemeral_commit_guard','_work_activity_establish_payload','_work_activity_establish_stream','_work_activity_event','_work_activity_evidence','_work_activity_expect','_work_activity_expected_guard','_work_activity_fact_snapshot','_work_activity_finish','_work_activity_gate','_work_activity_insert_source','_work_activity_instant','_work_activity_integer','_work_activity_iso','_work_activity_keep_clock_receipt','_work_activity_live_sources','_work_activity_no_truncate','_work_activity_object','_work_activity_observe','_work_activity_operation','_work_activity_operation_enter','_work_activity_operation_exit','_work_activity_parent_gate','_work_activity_parent_source_history','_work_activity_payload','_work_activity_profile_delete_guard','_work_activity_project_view','_work_activity_read_committed','_work_activity_refresh_state','_work_activity_resume','_work_activity_retain_source','_work_activity_review_visit','_work_activity_row_allowance','_work_activity_row_before','_work_activity_row_event','_work_activity_safety_exit','_work_activity_safety_guard','_work_activity_setup_guard','_work_activity_setup_ledger_guard','_work_activity_shift_lifecycle','_work_activity_source_material','_work_activity_source_view','_work_activity_start_setup','_work_activity_statement_begin','_work_activity_statement_end','_work_activity_stream_guard','_work_activity_touch','_work_activity_transition_source_guard','_work_activity_unit_basis','_work_activity_uuid','_work_activity_validate_switch','_work_config_can_manage_menu','_work_config_internal','_work_config_is_foreman','_work_config_is_owner','_work_config_is_supervisor','_work_config_replay','_work_config_store_receipt','_work_config_validate_menu_draft_items','_work_config_validate_typed_fields','_work_totals_capture','_work_totals_coverage','_work_totals_shift','_work_totals_source','_work_totals_visible','_work_unit_contributors_coverage','_work_unit_contributors_person','_work_unit_contributors_shift','_work_unit_fact_bump_epoch','_work_unit_fact_context_visible','_work_unit_fact_peek_epoch','_work_unit_metadata_aggregate','_work_unit_metadata_area','_work_unit_metadata_area_add','_work_unit_metadata_basis','_work_unit_metadata_binding','_work_unit_metadata_bucket','_work_unit_metadata_coverage','_work_unit_metadata_decimal','_work_unit_metadata_floor_basis','_work_unit_metadata_fraction','_work_unit_metadata_gate','_work_unit_metadata_immutable','_work_unit_metadata_jobs_visible','_work_unit_metadata_live','_work_unit_metadata_members','_work_unit_metadata_number','_work_unit_metadata_object','_work_unit_metadata_origins','_work_unit_metadata_partition','_work_unit_metadata_person_counts','_work_unit_metadata_ratio','_work_unit_metadata_review','_work_unit_metadata_scope','_work_unit_metadata_shift_ids','_work_unit_metadata_state','_work_unit_metadata_sum_bucket','_work_unit_metadata_uuid','_work_unit_metadata_validate_definition','_work_unit_metadata_validate_values','_work_unit_metadata_version','_work_unit_review_authority','_work_unit_review_coverage','_work_unit_review_defect_projection','_work_unit_review_scope','_work_unit_review_view','attach_sandbox_guards','clock_in','clock_out','custom_work_internal','end_break','guard_test_account_sandbox_only','is_partner_user','is_sandbox_project','is_test_profile','person_record_counts','row_project_id','sandbox_scoped_tables','service_job_access','shift_cap_hours','start_break','work_activity_command','work_activity_snapshot','work_activity_totals_read','work_capture_immutable_record','work_publish_activity_version','work_publish_menu_version','work_select_job_menu','work_unit_cohorts_read','work_unit_contributors_read','work_unit_metadata_command','work_unit_metadata_read','work_unit_metadata_receipt'])),
 'triggers',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',t.tgname,'definition',pg_get_triggerdef(t.oid,true),'enabled',t.tgenabled) order by c.relname,t.tgname) from pg_trigger t join pg_class c on c.oid=t.tgrelid join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract']) and not t.tgisinternal),
 'columns',(select jsonb_agg(jsonb_build_object('table',c.relname,'column',a.attname,'type',format_type(a.atttypid,a.atttypmod),'nullable',not a.attnotnull,'default',(select pg_get_expr(d.adbin,d.adrelid) from pg_attrdef d where d.adrelid=a.attrelid and d.adnum=a.attnum),'collation',a.attcollation::regcollation::text,'rawAcl',a.attacl::text,'notNullValidated',coalesce(nn.validated,true),'notNullEnforced',coalesce(nn.enforced,true),'notNullNoInherit',coalesce(nn.no_inherit,false),'generated',a.attgenerated,'identity',a.attidentity) order by c.relname,a.attnum) from pg_class c join pg_namespace n on n.oid=c.relnamespace join pg_attribute a on a.attrelid=c.oid and a.attnum>0 and not a.attisdropped left join lateral (select bool_and(k.convalidated) validated,bool_and(coalesce((to_jsonb(k)->>'conenforced')::boolean,true)) enforced,bool_or(k.connoinherit) no_inherit from pg_constraint k where k.conrelid=a.attrelid and k.contype='n' and a.attnum=any(k.conkey)) nn on true where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract'])),
 'functionAccess',(select jsonb_agg(jsonb_build_object('name',p.proname,'args',pg_get_function_identity_arguments(p.oid),'role',r.rolname,'execute',has_function_privilege(r.oid,p.oid,'EXECUTE')) order by p.proname,pg_get_function_identity_arguments(p.oid),r.rolname) from pg_proc p join pg_namespace n on n.oid=p.pronamespace cross join pg_roles r where n.nspname='public' and p.proname=any(array['_ai_job_visible','_is_lead','_is_supervisor','_work_activity_actor','_work_activity_answers','_work_activity_authority_changed','_work_activity_authority_guard','_work_activity_authority_revision','_work_activity_bookkeeping_guard','_work_activity_claim_clock_setup','_work_activity_clock_replay_guard','_work_activity_clock_review','_work_activity_clock_setup_digest','_work_activity_close_all','_work_activity_close_source','_work_activity_command_basis','_work_activity_consume','_work_activity_context_assert','_work_activity_context_close','_work_activity_context_commit_guard','_work_activity_context_for','_work_activity_context_guard','_work_activity_context_open','_work_activity_ensure_state','_work_activity_ephemeral_commit_guard','_work_activity_establish_payload','_work_activity_establish_stream','_work_activity_event','_work_activity_evidence','_work_activity_expect','_work_activity_expected_guard','_work_activity_fact_snapshot','_work_activity_finish','_work_activity_gate','_work_activity_insert_source','_work_activity_instant','_work_activity_integer','_work_activity_iso','_work_activity_keep_clock_receipt','_work_activity_live_sources','_work_activity_no_truncate','_work_activity_object','_work_activity_observe','_work_activity_operation','_work_activity_operation_enter','_work_activity_operation_exit','_work_activity_parent_gate','_work_activity_parent_source_history','_work_activity_payload','_work_activity_profile_delete_guard','_work_activity_project_view','_work_activity_read_committed','_work_activity_refresh_state','_work_activity_resume','_work_activity_retain_source','_work_activity_review_visit','_work_activity_row_allowance','_work_activity_row_before','_work_activity_row_event','_work_activity_safety_exit','_work_activity_safety_guard','_work_activity_setup_guard','_work_activity_setup_ledger_guard','_work_activity_shift_lifecycle','_work_activity_source_material','_work_activity_source_view','_work_activity_start_setup','_work_activity_statement_begin','_work_activity_statement_end','_work_activity_stream_guard','_work_activity_touch','_work_activity_transition_source_guard','_work_activity_unit_basis','_work_activity_uuid','_work_activity_validate_switch','_work_config_can_manage_menu','_work_config_internal','_work_config_is_foreman','_work_config_is_owner','_work_config_is_supervisor','_work_config_replay','_work_config_store_receipt','_work_config_validate_menu_draft_items','_work_config_validate_typed_fields','_work_totals_capture','_work_totals_coverage','_work_totals_shift','_work_totals_source','_work_totals_visible','_work_unit_contributors_coverage','_work_unit_contributors_person','_work_unit_contributors_shift','_work_unit_fact_bump_epoch','_work_unit_fact_context_visible','_work_unit_fact_peek_epoch','_work_unit_metadata_aggregate','_work_unit_metadata_area','_work_unit_metadata_area_add','_work_unit_metadata_basis','_work_unit_metadata_binding','_work_unit_metadata_bucket','_work_unit_metadata_coverage','_work_unit_metadata_decimal','_work_unit_metadata_floor_basis','_work_unit_metadata_fraction','_work_unit_metadata_gate','_work_unit_metadata_immutable','_work_unit_metadata_jobs_visible','_work_unit_metadata_live','_work_unit_metadata_members','_work_unit_metadata_number','_work_unit_metadata_object','_work_unit_metadata_origins','_work_unit_metadata_partition','_work_unit_metadata_person_counts','_work_unit_metadata_ratio','_work_unit_metadata_review','_work_unit_metadata_scope','_work_unit_metadata_shift_ids','_work_unit_metadata_state','_work_unit_metadata_sum_bucket','_work_unit_metadata_uuid','_work_unit_metadata_validate_definition','_work_unit_metadata_validate_values','_work_unit_metadata_version','_work_unit_review_authority','_work_unit_review_coverage','_work_unit_review_defect_projection','_work_unit_review_scope','_work_unit_review_view','attach_sandbox_guards','clock_in','clock_out','custom_work_internal','end_break','guard_test_account_sandbox_only','is_partner_user','is_sandbox_project','is_test_profile','person_record_counts','row_project_id','sandbox_scoped_tables','service_job_access','shift_cap_hours','start_break','work_activity_command','work_activity_snapshot','work_activity_totals_read','work_capture_immutable_record','work_publish_activity_version','work_publish_menu_version','work_select_job_menu','work_unit_cohorts_read','work_unit_contributors_read','work_unit_metadata_command','work_unit_metadata_read','work_unit_metadata_receipt','_work_unit_contributors_coverage','_work_unit_metadata_coverage']) and r.rolname in('anon','authenticated','service_role')),
 'privateAccess',(select jsonb_agg(jsonb_build_object('table',c.relname,'role',r.rolname,'privilege',v.name,'allowed',has_table_privilege(r.oid,c.oid,v.name)) order by c.relname,r.rolname,v.name) from pg_class c join pg_namespace n on n.oid=c.relnamespace cross join pg_roles r cross join (values('SELECT'),('INSERT'),('UPDATE'),('DELETE'),('TRUNCATE'),('REFERENCES'),('TRIGGER')) v(name) where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract','_work_unit_review_live_sources']) and r.rolname in('anon','authenticated','service_role')),
 -- Effective access includes table-derived rights, role inheritance and PUBLIC.
 'columnAccess',(select jsonb_agg(jsonb_build_object('table',c.relname,'role',r.rolname,'privilege',v.name,'allowed',has_any_column_privilege(r.oid,c.oid,v.name)) order by c.relname,r.rolname,v.name) from pg_class c join pg_namespace n on n.oid=c.relnamespace cross join pg_roles r cross join (values('SELECT'),('INSERT'),('UPDATE'),('REFERENCES')) v(name) where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract','_work_unit_review_live_sources']) and r.rolname in('anon','authenticated','service_role')),
 'constraints',(select jsonb_agg(jsonb_build_object('table',c.relname,'name',k.conname,'definition',pg_get_constraintdef(k.oid,true),'validated',k.convalidated,'enforced',coalesce((to_jsonb(k)->>'conenforced')::boolean,true),'deferrable',k.condeferrable,'deferred',k.condeferred) order by c.relname,k.conname) from pg_constraint k join pg_class c on c.oid=k.conrelid join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and k.contype<>'n' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract'])),
 'policies',(select jsonb_agg(jsonb_build_object('table',tablename,'name',policyname,'permissive',permissive,'roles',roles,'command',cmd,'using',qual,'check',with_check) order by tablename,policyname) from pg_policies where schemaname='public' and tablename=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract'])),
 'view',pg_get_viewdef('public._work_unit_review_live_sources'::regclass,true),
 'tables',(select jsonb_agg(jsonb_build_object('table',c.relname,'rls',c.relrowsecurity,'forcedRls',c.relforcerowsecurity,'kind',c.relkind,'persistence',c.relpersistence,'rawAcl',c.relacl::text,'owner',pg_get_userbyid(c.relowner)) order by c.relname) from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relname=any(array['time_shifts','personal_activity_state','personal_activity_transition_sources','personal_activity_transitions','work_activity_safety_events','work_unit_fact_revisions','work_unit_fact_current','work_unit_fact_context_epochs','custom_work_units','project_openings','service_visit_units','service_visits','summons','unit_redos','qc_checks','install_events','crew_work_records','crew_work_record_people','work_session_capture_metadata','custom_work_history','custom_work_sessions','unit_sessions','task_sessions','service_time_sessions','opening_phases','summon_helpers','work_activity_source_history','work_unit_review_commands','work_unit_dimension_verifications','work_unit_review_events','work_unit_review_current','work_unit_review_defects','work_unit_review_defect_events','work_setup_sessions','personal_activity_commands','work_activity_definitions','work_activity_definition_versions','work_capture_menus','work_capture_menu_versions','work_capture_menu_items','work_job_menu_selections','profiles','projects','sandbox_projects','work_job_management_grants','_work_unit_metadata_definitions','_work_unit_metadata_versions','_work_unit_metadata_proposals','_work_unit_metadata_revisions','_work_unit_metadata_current','_work_unit_metadata_floors','_work_unit_metadata_floor_current','_work_unit_metadata_commands','_work_unit_metadata_contract']))
) value) metadata_catalog)) value
)c;
 return (select count(*)=1 and bool_and(proof_key='cross_job_kernel_2' and expected_catalog_sha256=actual) from public.work_cross_job_contract)
  and (select count(*)=1 and bool_and(proof_key='metadata_v1' and expected_catalog_sha256=actual) from public._work_unit_metadata_contract);
end;
$combined_coverage$;
revoke all on function public._work_unit_metadata_coverage() from public,anon,authenticated,service_role;
-- METADATA_COVERAGE_END
-- METADATA_PROOF_SEED_BEGIN
-- METADATA_PROOF_SEED_END

-- Authored read-only historical recovery. No provider session attestation is supplied.
create function public.work_activity_clock_receipt_v2(
 p_project_id uuid,p_cost_code_id uuid,p_photo text,p_lat double precision,p_lng double precision,
 p_note text,p_mode text,p_client_id uuid,p_tapped_at timestamptz,p_clock_checked_at timestamptz,p_clock_skew_ms integer,p_setup_version integer
) returns jsonb language plpgsql volatile security definer set search_path=public,pg_temp as $paid_reader$
declare actor uuid;r public.work_activity_clock_receipts;stamp public.work_cross_job_clock_requests;
 registration public.work_cross_job_shifts;digest text;fingerprint text;present boolean;registered boolean;as_of timestamptz;
 missing constant jsonb:='{"protocolVersion":2,"contract":"paid_setup_v2_recovery_v1","availability":"unavailable","receipt":null,"proof":null,"current":null}'::jsonb;
begin
 -- Float serialization is part of the original request digest. Never try alternate settings.
 if current_setting('extra_float_digits') is distinct from '1' then
  raise exception using errcode='55000',message='Paid recovery serialization setting is unavailable.';
 end if;
 perform public._work_activity_read_committed();
 perform public._work_activity_gate();perform pg_advisory_xact_lock(7710,0);actor:=public._work_activity_actor();
 if not (coalesce((select p.prosrc is not null and encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='b678eca76a31edbf88408302379013b762eea5b2f50d4bdd3a8ebebc55e2f3ea' and pg_get_userbyid(p.proowner)='postgres' and p.proacl::text='{postgres=X/postgres}' and p.prosecdef and p.proconfig=array['search_path=public, pg_temp']::text[] and p.provolatile='s' and not p.proisstrict and not p.proleakproof and p.proparallel='u' and p.prokind='f' and not p.proretset and p.prorettype='boolean'::regtype and p.pronargs=0 and p.pronargdefaults=0 and p.procost=100 and p.prorows=0 and p.prosupport=0 and p.prolang=(select oid from pg_language where lanname='plpgsql') from pg_proc p where p.oid=to_regprocedure('public._work_cross_job_coverage()')),false) and public._work_cross_job_coverage()) then
  raise exception using errcode='55000',message='Paid recovery source contract is unavailable.';
 end if;
 -- These are the keyed outer writer's admitted typed stamp conditions, not new authoring rules.
 if p_client_id is null or p_tapped_at is null or not isfinite(p_tapped_at)
  or (p_clock_checked_at is not null and not isfinite(p_clock_checked_at))
  or p_setup_version is distinct from 2 then
  raise exception using errcode='23514',message='The exact original protocol 2 clock request is required.';
 end if;
 select * into r from public.work_activity_clock_receipts where client_id=p_client_id and profile_id=actor;
 if not found then return missing;end if;
 select * into stamp from public.work_cross_job_clock_requests where client_id=p_client_id and profile_id=actor;
 if not found then return missing;end if;
 if r.client_id is distinct from p_client_id or r.profile_id is distinct from actor or r.shift_id is null
  or r.action is distinct from 'clock_in' or r.outcome is distinct from 'clocked_in' or r.receipt_protocol is distinct from 'setup_v1'
  or r.used_tap_time is null or r.tapped_at is null or not isfinite(r.tapped_at)
  or r.arrived_at is null or not isfinite(r.arrived_at) or r.source_created_at is null or not isfinite(r.source_created_at)
  or r.recorded_at is null or not isfinite(r.recorded_at) or (r.clock_checked_at is not null and not isfinite(r.clock_checked_at))
  or r.setup_payload_digest is null or r.setup_payload_digest !~ '^[0-9a-f]{64}$'
  or stamp.client_id is distinct from r.client_id or stamp.profile_id is distinct from r.profile_id
  or stamp.shift_id is distinct from r.shift_id or stamp.setup_version is distinct from 2 or stamp.operation_id is null
 then return missing;end if;
 digest:=public._work_activity_clock_setup_digest(p_project_id,p_cost_code_id,p_photo,p_lat,p_lng,p_note,p_mode,p_client_id,p_tapped_at,p_clock_checked_at,p_clock_skew_ms);
 fingerprint:=public._work_cross_job_clock_receipt_fingerprint(r);
 if digest is distinct from r.setup_payload_digest or r.tapped_at is distinct from p_tapped_at
  or r.clock_checked_at is distinct from p_clock_checked_at or r.clock_skew_ms is distinct from p_clock_skew_ms
  or stamp.receipt_sha256 is distinct from fingerprint then return missing;end if;
 -- Registration absence is valid for original protocol 2 fallback. Present registration must agree.
 select * into registration from public.work_cross_job_shifts where shift_id=r.shift_id;
 registered:=found;
 if exists(select 1 from public.work_cross_job_shifts where clock_request_id=r.client_id
  and (shift_id is distinct from r.shift_id or profile_id is distinct from actor or generation is distinct from 2)) then return missing;end if;
 if registered and (registration.profile_id is distinct from actor or registration.clock_request_id is distinct from r.client_id
  or registration.generation is distinct from 2) then return missing;end if;
 -- Current source presence is a separate observation; neither visibility nor source retention rewrites history.
 present:=exists(select 1 from public.time_shifts where id=r.shift_id and profile_id=actor)
  and exists(select 1 from public.time_clock_actions where client_id=r.client_id and profile_id=actor and shift_id=r.shift_id and action='clock_in');
 as_of:=clock_timestamp();
 return jsonb_build_object('protocolVersion',2,'contract','paid_setup_v2_recovery_v1','availability','available',
 'receipt',jsonb_build_object('clientId',r.client_id,'profileId',r.profile_id,'shiftId',r.shift_id,'action',r.action,'outcome',r.outcome,
 'tappedAt',public._work_activity_iso(r.tapped_at),'arrivedAt',public._work_activity_iso(r.arrived_at),
 'clockCheckedAt',public._work_activity_iso(r.clock_checked_at),'clockSkewMs',r.clock_skew_ms,'usedTapTime',r.used_tap_time,
 'reviewReason',r.review_reason,'sourceCreatedAt',public._work_activity_iso(r.source_created_at),'receiptProtocol',r.receipt_protocol,
 'setupPayloadDigest',r.setup_payload_digest,'recordedAt',public._work_activity_iso(r.recorded_at)),
 'proof',jsonb_build_object('originalSetupVersion',2,'match','full_original_setup_digest','fingerprintVersion',1,'receiptSha256',fingerprint),
 'current',jsonb_build_object('asOf',public._work_activity_iso(as_of),'sourcePresent',present,'captureRegistered',registered));
end;
$paid_reader$;
revoke all on function public.work_activity_clock_receipt_v2(uuid,uuid,text,double precision,double precision,text,text,uuid,timestamptz,timestamptz,integer,integer) from public,anon,authenticated,service_role;
grant execute on function public.work_activity_clock_receipt_v2(uuid,uuid,text,double precision,double precision,text,text,uuid,timestamptz,timestamptz,integer,integer) to authenticated;

-- Proof DATA is authored after final bodies, before immutable contract triggers.
insert into public.work_cross_job_contract values('cross_job_kernel_2','df8a3fcecdec0c58073ce2f83be49b8f00d0808afcdce58aa7313d3f2422921d');
insert into public._work_unit_metadata_contract(proof_key,expected_catalog_sha256) values('metadata_v1','df8a3fcecdec0c58073ce2f83be49b8f00d0808afcdce58aa7313d3f2422921d');
create trigger work_cross_job_contract_immutable before insert or update or delete on public.work_cross_job_contract for each row execute function public.work_capture_immutable_record();
create trigger work_cross_job_contract_no_truncate before truncate on public.work_cross_job_contract for each statement execute function public.work_capture_immutable_record();
create trigger metadata_immutable before update or delete or truncate on public._work_unit_metadata_contract for each statement execute function public._work_unit_metadata_immutable();

do $final_contract$ begin
 if not public._work_cross_job_coverage() or not public._work_unit_metadata_coverage()
 or not public._work_unit_review_coverage() or not public._work_totals_coverage() or not public._work_unit_contributors_coverage() then
 raise exception using errcode='55000',message='Combined authored catalog or pre-registration report guards differ.';end if;
 if not public._work_cross_job_enabled() then raise exception using errcode='55000',message='Authored disposable active gate is missing.';end if;
end $final_contract$;
-- AUTHORIZED DISPOSABLE FIXTURE SEAM: no fixture executes by default.
rollback;
