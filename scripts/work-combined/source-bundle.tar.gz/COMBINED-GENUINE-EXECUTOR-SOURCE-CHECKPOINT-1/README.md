# Disposable combined executor source proposal

This proposal runs the existing checks in one test database and the combined candidate in separate copies of the same starting database. The separation matters: the old 47-control script commits 0847, while the combined candidate requires 0846 before either of its preserved preflights. Installing the candidate after that old script in the same database would be invalid.

Nothing in this checkpoint has contacted PostgreSQL, a provider or an operational database. No workflow was enrolled. The default command and `--check-plan` only validate local files. The source proposal needs actual independent review before a separately authorized CI run.

## Files and approved source

- `combined_executor.py` is the proposed explicit executor; `author_variants.py` authors expectations from pinned source, never from observed catalogs.
- `executor-profile.json` pins inputs and variants. It deliberately does not self-pin the executor/profile/test cycle: the final manifest and future reviewed workflow must pin those files externally.
- `test_combined_executor.py` exercises no-contact validation, source invariants, subprocess output and failure paths. It is not a SQL interpreter.
- `approved-source3/` preserves all 103 manifest-listed files of the actual approved held source. Candidate SHA is `2a323f3d59e622b80cf235c68d7d39533ae1b98717b1a9769a5e5923046f69cd`; its catalog root is `d7d520dd7c227fedb6594117d017cde3307981156162aedf2c37dfbfd06467b2`.
- `pinned-repository/` contains exact predecessor/runtime helper inputs. The new executor imports only the side-effect-free V2 helper module and invokes the unmodified 47/66 scripts as separate processes. Their source checks continue to run against the copied pinned tree.
- `premise/` preserves the actual six-turn source-3 approval and the root-confirmed clone/restoration corrections before authoring.

The prior approval covers the combined candidate and its fixtures as held concrete source. It does not approve this new executor, variant or infrastructure contract.

## Fresh cluster and database construction

The proposed target is exactly `localhost` or `127.0.0.1`, explicit port 5432, database `forge_work_activity_role_test`, login `supabase_admin`, password `fixture-only`, with no URL options. These are disposable fixture credentials, not provider credentials. The only initial databases allowed are that baseline plus `postgres`, `template0` and `template1`. PostgreSQL must be version 17. Baseline ownership must be the nonsuperuser `postgres` source owner; the separate fixture administrator must actually have SUPERUSER and CREATEDB. Enabled event triggers are refused.

Before any 0847 predecessor runs, the executor constructs explicit synthetic actors and uses supported toolbox/publication/unit constructors on the exact 0846 baseline. It does not insert paid receipts, clock-request stamps or ledger history. The constructor path before 0847 is a genuine runtime prerequisite to verify, not a source-pass claim.

Three clones are then created sequentially, with distinct database OIDs:

| Branch | Database | Source |
|---|---|---|
| Inactive | `forge_combined_inactive_test` | Exact approved candidate |
| Active | `forge_combined_active_test` | Fresh authored literal-true gate variant |
| Negative | `forge_combined_negative_test` | Exact approved stale-capability variant |

There must be no baseline connections when each clone is created. The executor refuses instead of terminating another connection. Targets must not already exist. It does not reuse, drop or repair an existing database.

Cloning does not copy database ACLs. The executor therefore **constructs** each new database's ACL from the pinned role-parity fixture, with owner `postgres`. It first removes the new database's default PUBLIC privileges, then creates the exact authored ACL: PUBLIC has TEMPORARY/CONNECT; postgres has CREATE/TEMPORARY/CONNECT; the two named storage/ETL ACL-only roles have CREATE; dashboard_user has CREATE/TEMPORARY/CONNECT. It creates no role or role membership and does not normalize function/table owners or observed catalogs. Unexpected ACLs fail. Database-specific settings are required to be absent on the starting cluster; the pinned authenticator 8-second limits are global role settings. No copied auth-role grants are repaired.

The complete initial global role, membership and configuration rows are retained. The role fixture's named runtime attributes and grants are compared; the additional PG17 system-role names and three ACL-only bootstrap roles are explicitly enumerated. Extra roles are refused. No new global roles or settings are allowed from these two pinned predecessors. The broader prerequisite workflow's already-created role inventory is distinct from this executor's new database infrastructure. Role/configuration rows must remain exact after each predecessor and at the end.

Every branch is checked against the same authored old catalog, and its logical rows and sequence state are compared to the pre-clone baseline. State fingerprints include public/auth ordinary and partitioned tables plus sequences, with full JSON row values, counts and hashes; they exclude system statistics, views and external/foreign data. These observed state fingerprints compare clone state only. They never become an expected catalog or proof root. Server system identifier, postmaster start, version, time zone, source hashes and distinct database names/OIDs are recorded separately. This is not same-database paid/report evidence or cross-instance causal timing.

## Predecessors and immutable construction

The exact 47 and 66 scripts run together on the original database after all clones exist. Their counts, source digests, settings restoration, 22 fresh sessions, same original database identity and authored installed catalog must match. JSON receipts alone are not accepted as instance proof. Their stdout/logs and receipt hashes are retained. Their existing mutation controls are confined to that original database; the new executor neither ports those corruption mechanisms into a combined branch nor disables its proof triggers.

Each combined branch then installs its complete fresh SQL in one transaction. The original source files still end in ROLLBACK. The explicit fixture operation substitutes only that final boundary with COMMIT, preserving both preflights before DDL and proof insertion before immutable triggers. Every post-install live catalog is compared with its independent authored JSON and PostgreSQL canonicalization of that authored JSON. Actual PostgreSQL must establish the constant assumptions about composite/array types, ACLs, relation access, RI rows and `connoinherit`. The executor never learns or repairs expected values from live output.

The active variant changes only `_work_cross_job_enabled()` from `select false` to `select true` in the catalog. It rebuilds both proof data roots before immutable trigger creation and adjusts the final fixture gate assertion. It proves no dependent body embeds the old gate hash; an unexpected dependency refuses authoring. The reader and all other function bodies are unchanged. Closing-only is authority data under the unchanged inactive catalog, not another gate body. Variant files remain terminal ROLLBACK.

## Runtime cases proposed, not executed

The pinned helper's fresh `authenticator` login, SET ROLE authenticated and synthetic JWT-subject GUC checks are reused. Every connection must retain installed 8-second statement and lock limits. A synthetic JWT GUC is fixture identity, not a provider token or provider-session attestation. Inspection sessions have 20-second statements and 12-second locks, and each psql process has a 35-second limit. Predecessor processes have a finite 1200-second limit. No timeout is raised to pass a case.

The inactive branch first establishes V1 active and closing-only capability positives, then executes the exact approved float fixtures and real V1 clock/break/return/out calls. A separate negative branch must have the same capability-consumed actor/profile/state/safety and authority values before the stale-capability refusal counts. The authority guard independently stamps `updated_at` on each sequential update, while capability reads only capture_enabled/revision. That unread timestamp is excluded from the comparison and each complete raw row is retained separately. Nothing is rewritten to equalize it. Generic 55000 alone is insufficient evidence.

The active branch uses real original protocol-2 clock writers for distinct capture-disabled fallback and registered cases. It checks the complete request digest, incoming version 2, fifteen-field immutable receipt and microsecond fingerprint; lookup by the other eligible actor must not expose data. It retries original clock and allocation requests, checks UTC/Denver behavior and a wrong-float writer refusal, and performs a finite general A-to-B allocation plus actual paid break/return/out while preserving physical A. It then turns authority capture off and repeats historical lookup under the retained active catalog.

This is **not execution of source3's original inactive-root historical fixture**: that fixture's header requires returning to inactive final source. Its file remains unchanged. Registered historical portability under the inactive base catalog is a REQUIRED open paid-recovery/integration gate. The active-variant reader body is identical, but that does not prove the inactive-root case. No post-V2 ledger is copied between databases and no synthetic receipt INSERT substitutes for a real writer.

After registration, the three old report guards must still be false while combined coverage is true. The expected public unavailable responses, visible review's available/unproven response and private census refusal are characterized as functional holds. The private census negative uses the source-owner connection, not a service transport success proof. No guard is relaxed and no generic registered-2 report/census support is claimed. Only general capture is proposed here; other source families remain outside this finite run.

## Evidence, failures and restoration limits

Every SQL call is saved before its wait, with exact SQL hash, database/login/context, complete stdout/stderr and a finite process deadline. JSON scalars are explicitly serialized in SQL with `to_jsonb`; the decoder never converts raw psql t/f or UUID text. Subprocess output is captured through independent pipes, not a file descriptor also being seeked by the parent. The logged wall time includes psql and connection work; it is not an isolated lock wait or paid budget result. Review and catalog inspection are not represented as paid-operation timing.

The initial partial receipt is written before source/target checks. Each wait, primary failure and cleanup failure is retained. If installation returns ambiguously, the executor compares the surviving catalog to either exact old or exact authored new state, and refuses any unknown state. Cleanup failure is fatal and never replaced by a successful process/container-disposal message.

On installed branches, the executor sets authority capture false using the existing G gate, verifies no measured paid/source/receipt/history rows or business counts changed, verifies the exact branch catalog, records final counts/full state fingerprints, checks settings/identity and checks absence of temporary relations. Global roles/settings must still match. These are per-database receipts, never merged paid totals.

The active database deliberately retains its exact literal-true fixture catalog and history. **Inactive catalog restoration is false.** Authority false is verified separately. Dropping the database or service later is external disposal, not proof of catalog/data restoration. Failed or unused clone creation is not presented as cleaned up. The predecessor database retains the exact inert 0847 catalog and its own synthetic history.

## Required next gate

Root must arrange actual independent source review of the new executor, variants, ACL/clone contract and tests. Only after that may root package the pinned bundle and enroll an explicit disposable CI job after the unchanged 0841–46 prerequisites. No existing workflow is changed here.

Full 20 client / 42 kernel / 65 metadata completion, provider session/float transport, inactive-root registered historical portability, registered-2 report/census compatibility, all source families, races, volume/paid wait, physical devices, old-client cooperation, safety resolution, owner policies and installed-K6 upgrade remain open.
