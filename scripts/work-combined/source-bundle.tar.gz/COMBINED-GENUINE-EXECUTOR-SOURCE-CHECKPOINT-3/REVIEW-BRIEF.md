# Bounded correction 3 review

Read the preserved actual 13-turn source2 approval, CORRECTION.patch, the changed main/test modules, HANDOFF, and evidence/noninstall-before-after.json. The earlier B1 closure remains intact; this correction promotes the review's nonblocking non-install race to a required final-state boundary.

Trace all unresolved outcomes, including process timeout, signal, connection/startup exit and process exceptions. Verify exact expected SQL refusal uses psql ON_ERROR_STOP exit 3 and is not reclassified as an unknown send. Check branch guards include the postgres administrator database; global guards cover all recorded databases. Confirm a still-live/unknown mutation cannot produce finalFlags, finalCensus, finalState, cleanupVerified, predecessor-state or final inventory claims.

Verify multiple settlement errors are all retained, the original primary failure survives, monitor failures do not trigger unbounded recursive monitoring, and a later committed state is read only after its backend exits. Read the source2 counterexample and the new tests for untagged failed predecessors. No protected driver has changed; failed predecessor quiescence is an explicit fatal unknown rather than a snapshot-based restoration claim.

Source1 and source2 remain immutable sibling inputs. The runtime needs source1 plus correction3; tests also need the exact source2 main file. Root-owned packaging must verify their manifests and externally pin current source. No absolute workspace authority, mutable symlink or old-source overlay is supported.

No SQL, PostgreSQL, provider, repository/workflow edit or actual fixture execution is authorized by this review. Return a held-source verdict with exact findings. All existing runtime/owner and inactive-root historical gates remain open.
