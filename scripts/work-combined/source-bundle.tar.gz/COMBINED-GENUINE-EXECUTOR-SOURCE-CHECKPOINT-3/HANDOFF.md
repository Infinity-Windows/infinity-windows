# Correction 3 handoff: final state needs settled writers

The earlier correction protected uncertain installation. This correction also protects the final data snapshots: cleanup cannot mark a branch finalized while any unresolved call on that branch or the administrator database may still commit. Global, predecessor-state and database-inventory assertions require unresolved calls across all databases to settle first.

Every call begins with its existing unique tag and `requiresBackendSettlement: true`. A validated successful response clears that requirement. An exact expected SQL refusal with psql ON_ERROR_STOP exit 3 is a known refusal, not an unknown send. Timeout, unexpected process exit, signal, malformed/unknown process result or exception leaves the call unresolved. No statement timeout or killed process is used as evidence of server exit.

The existing bounded monitor verifies the exact tagged backend's absence, database/login ownership, administrator visibility and original cluster identity. It retains all samples, uses the unchanged 15-second per-target budget and at most 5 seconds per monitor process, and never terminates a backend. A guard processes a finite snapshot of pending calls, records every failure, and fails if any remain unknown or alive. Failed monitor calls are not recursively monitored within the same pass; that pass cannot certify final state. Later scopes also remain blocked until all their unresolved calls settle.

This covers authority setters, paid mutations, and calls on postgres such as clone/ACL construction. A late commit is allowed to finish before finalization; it is never assumed rolled back. The primary failure still makes the overall fixture fail even if cleanup later verifies a settled state.

The pinned 47/66 drivers have untagged internal connections and remain unchanged. Execution is marked unproved before their launch and cleared only after a successful pinned process/receipt/source/settings/catalog validation. A failed or timed-out predecessor leaves `predecessorBackendQuiescenceUnproved` true. Cleanup records `predecessor_backend_quiescence_unproved` and suppresses final global/predecessor/inventory restoration claims. This checkpoint does not infer their connection cleanup or terminate anything.

## Evidence and scope

All 69 no-contact tests pass, both plan modes remain no-contact, and the two changed Python files compile. All 60 earlier tests remain; 57 methods are unchanged. Two fake SQL-refusal tests now use actual psql SQL-error exit 3 instead of generic exit 1. The earlier monitor-failure test now requires global snapshots to be skipped, because taking those snapshots is precisely the newly prohibited behavior. Nine methods were added. SOURCE-AUDIT records the exact method inventory and reasons.

The actual frozen source2 executor counterexample finalizes while a simulated non-install backend remains alive. The new executor blocks that finalization. A late-commit test proves the Python control flow waits before recording its final snapshot. Alive/unknown admin and predecessor cases, unexpected exits, expected refusals and multiple retained cleanup errors are covered. These are no-contact orchestration tests, not PostgreSQL execution or authenticated paid safety proof.

Source1's 188 files and source2's 19 files remain byte-identical; 283 protected audit entries were reverified. Candidate SQL, both catalog roots, all variants, the profile and protected repositories are unchanged. No SQL, provider, database, workflow or CI execution occurred. No repository was edited.

## Portable package and next action

Keep immutable source1, immutable correction2 and this correction3 as sibling directories with their existing names. Runtime uses only source1 plus correction3's main/profile. Tests additionally read correction2/combined_executor.py for the actual prior-source counterexample; its exact hash is in INPUT-REFERENCES. Root must verify each manifest and its file entries before using the package, then externally pin this correction's main/test/profile. No overlay into a prior checkpoint, symlink or absolute workstation path is an authority.

From the parent directory, the supported no-contact commands are:

```
python3 COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-3/test_combined_executor.py
python3 COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-3/combined_executor.py
python3 COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-3/combined_executor.py --check-plan
```

Use correction3 as the future explicit executor only after actual independent review and separately authorized CI packaging. This checkpoint is ready for that review; ownership returns to root. The previous proposal archive must not be mistaken for a package containing this correction.

All prior runtime and owner gates stay open: genuine PG17 tag/disconnect behavior, seed/ACL/catalog checks, provider and float transport, inactive-root registered historical portability, registered-2 report/census support, full client/kernel/metadata acceptance, devices, old clients, safety resolution, owner policy, paid-wait budget and installed-K6 upgrade. Active catalog restoration remains false. No activation or end-to-end delivery is claimed.
