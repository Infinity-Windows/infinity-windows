# Bounded independent review request

Review source6 sequence handling and proposed native smoke. Confirm r/p SQL bytes unchanged, every raw r/p/S relation still covered, explicit three-field PG17 sequence state, unknown inputs fail closed, and no claim of PostgreSQL execution. Review smoke syntax, independent expected values, exact old-query counterexample, temporary sequence mutation/rollback limits and finite runner/quiescence requirements.

Read diagnosis first (captured SQL/error and seeded-write boundary), then full CORRECTION.patch, build_fingerprint_smoke.py/fingerprint-smoke.sql, HANDOFF.md and NATIVE-SMOKE-PLAN.md. Check 88 tests with original80 AST-identical and protected source audit. No SQL/schema/role/timeout/guard/candidate change is proposed. Root owns execution after approval, first a finite realPG17 smoke, then any independently approved full trial.

Source5 and package4 approval do not approve these new bytes. Actual peer review is pending; this receipt is authored by Codex only.
