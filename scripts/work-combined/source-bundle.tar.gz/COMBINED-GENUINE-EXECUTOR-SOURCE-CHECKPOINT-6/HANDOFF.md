# Source 6: sequence fingerprint correction, ready for independent review

The third genuine trial stopped because the fingerprint query treated a sequence like a table row. PostgreSQL 17 cannot turn that sequence whole row into JSON. This is a fixture query bug, not evidence that the combined candidate is correct or incorrect.

## Observed failure and writes

Run **37331813122**, head **7eb89dcaa06d1bfec293423d308de4bb0adf2915**, job **111836525276**. Artifact **11356065091**, ZIP SHA-256 **04b3e621d1b5ade3988e6a67463866dbd28be2047dd072db12d22e61e8408544**. The local extracted inventory has 201 files; every file hash is in `diagnosis/ARTIFACT-FILES.json`.

The initializer passed. Nine checks and 62 calls were recorded. Enumeration found 243 relations: 234 ordinary tables and nine sequences. Calls31–57 completed 27 table fingerprints. Call58 first encountered `public.container_serial_seq` and failed with SQLSTATE42809, `relation "container_serial_seq" does not have a composite type`. The exact SQL and stderr are frozen in `diagnosis/`.

Call9 committed five synthetic auth users and five profiles, two projects, one cost code and one opening. Supported toolbox signing, publishing/menu selection and a unit constructor then ran. This is **not** a no-write failure. The receipt has no branches, no finite cases and no completed baseline data fingerprint. No database clone or combined candidate install occurred.

Call59 observed the exact failed-call backend gone. Call60's global role/config snapshot exactly equals `globalBefore`; call61 captured the original four-database inventory. These are specific observations, not seed-data restoration. Empty cleanupFailures does not prove a rollback of the committed seed. No data-restoration claim is made.

## Narrow source change

`combined_executor.py` now selects a query by the already-enumerated relation kind. The ordinary and partitioned table query remains byte-identical. A sequence uses explicit `last_value`, `log_cnt` and `is_called` JSON fields instead of `to_jsonb(x)`. Those are the complete PostgreSQL17 sequence state tuple fields. Count, canonical JSON array ordering, SHA-256/UTF-8 and the relation inventory are unchanged. Unknown helper kinds and invalid identifiers refuse. The fingerprint does not advance or reset a sequence.

Primary references: [PostgreSQL17 sequence tuple source](https://raw.githubusercontent.com/postgres/postgres/REL_17_STABLE/src/include/commands/sequence.h) and [CREATE SEQUENCE documentation](https://www.postgresql.org/docs/17/sql-createsequence.html). Clone preservation of sequence state, including log_cnt, is **not yet tested**. Do not remove fields to make clone comparison pass.

## Checks completed here

- **88 no-contact tests pass**, including all 80 earlier methods unchanged by AST comparison and eight added controls.
- The new tests use captured native failure bytes, preserve every captured enumerated relation, exercise kind dispatch and explicit state projection, and show the old source fails the new sequence-shape control. These are source/mock regressions, not PostgreSQL execution.
- Default and `--check-plan` pass with `databaseContacted:false`; Python compilation passes.
- Five previous checkpoint manifests and every listed file verify unchanged. All 283 source1 protected input entries verify unchanged. Profile and inactive/active candidates/catalog roots remain unchanged.
- Generated smoke SQL exactly matches its source generator and executor queries. It has **not** run.

## Mandatory next validation before another full trial

Review this overlay and the native smoke first. In a fresh disposable PG17 service, run `fingerprint-smoke.sql` through real psql before the expensive six prerequisites. See `NATIVE-SMOKE-PLAN.md`. It uses temporary tables, a partitioned table and a sequence; it requires the old whole-row query to produce the exact 42809 failure, then checks the corrected results, duplicates/nulls, an empty table, a bigint beyond JavaScript's exact integer range and read-only sequence behavior. No public/auth data is written. This tests PostgreSQL syntax and row semantics that the earlier no-contact suite missed.

Only after genuine smoke success should root consider repackaging/reviewing a full trial. A failed smoke is a new finite diagnosis; do not repeat the full trial unchanged. This is a method correction after three wrapper bugs, not a claim that every remaining executor SQL statement is now validated.

## Portable packaging and ownership

Runtime assembly requires the immutable source1 directory as a sibling plus source6 main/profile. Verify source1 manifest/all188 entries first, then source6 manifest and exactly declared overlay paths. Replace only `combined_executor.py` and `test_combined_executor.py` in the root-reviewed disposable overlay; include new smoke/generator as separate source artifacts. No absolute workspace path is runtime authority. Retained tests additionally read frozen source2/3/4/5 main files as counterexamples and source6's copied premise fixtures. Keep the immutable siblings, or root can author and review an equivalent portable packaging layout; do not mutate their source to satisfy tests.

Source1 manifest: `57c3e7b498cd5134bd17f99a7cba337fe8d83c6a3c047d0c825df2e66b1b8686`.
Source5 manifest: `cad789b5b104318498a26098eed50afad5dd8f81bdf739dd1ecfc2b5061b718f`.
Candidate: `2a323f3d59e622b80cf235c68d7d39533ae1b98717b1a9769a5e5923046f69cd`.
Inactive canonical catalog root: `d7d520dd7c227fedb6594117d017cde3307981156162aedf2c37dfbfd06467b2`.
Active SQL: `efcc993da1be44fe89235e7b1408b1210ab5b8a81f65dc685bd0129965d6e0cd`.
Active canonical catalog root: `df8a3fcecdec0c58073ce2f83be49b8f00d0808afcdce58aa7313d3f2422921d`.

All repositories, workflows, package proposals, protected SQL and previous checkpoints remain untouched. No database/provider contact, installation, commit, push, operational change or peer dispatch occurred. Full20/42/65, registered2 historical portability, provider/float transport, owner decisions, paid wait, race/volume, installed upgrades and all earlier functional holds remain open. Source correctness and smoke execution require independent review and genuine evidence. Ownership returns to root at this frozen checkpoint.

Read scope: changed fingerprint path, query builder, smoke and tests read fully; inherited callers reused unchanged. Catalogs and protected inputs were rehashed, not reread line by line. `CORRECTION.patch` contains the complete source delta. Root owns actual Claude review and future workflow enrollment.
