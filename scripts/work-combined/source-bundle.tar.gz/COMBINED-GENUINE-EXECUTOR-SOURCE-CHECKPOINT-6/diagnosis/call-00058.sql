\set VERBOSITY verbose
set statement_timeout='20s';set lock_timeout='12s';set search_path=public,pg_temp;
select to_jsonb(__combined_result.value) from (select jsonb_build_object('count',count(*),'sha256',encode(sha256(convert_to(coalesce(jsonb_agg(to_jsonb(x) order by to_jsonb(x)::text),'[]'::jsonb)::text,'UTF8')),'hex')) from "public"."container_serial_seq" x) as __combined_result(value);