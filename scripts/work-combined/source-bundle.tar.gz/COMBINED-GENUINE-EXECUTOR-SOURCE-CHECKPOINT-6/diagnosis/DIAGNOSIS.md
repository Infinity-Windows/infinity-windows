# Frozen premise before correction

Run 37331813122, head 7eb89dcaa06d1bfec293423d308de4bb0adf2915, job 111836525276, artifact 11356065091. Report: nine checks, no branches or finite cases. Initial fingerprint call 58 fails with SQLSTATE 42809: sequence container_serial_seq has no composite type. The enumerator includes r, p and S; the same whole-row to_jsonb(x) query was incorrectly used for every kind.

Call 9 committed five synthetic auth users and five profiles, two projects, one cost code and one opening. Subsequent supported toolbox/publishing/menu/unit constructors ran. The initial fingerprint is incomplete; no clones or combined candidate installation occurred. Call 59 observes no exact tagged backend for failed call 58. Final global/config and database inventories were captured. Empty cleanupFailures does not prove seed rollback or data restoration; no pre-seed full data fingerprint exists.

Recommendation: retain table fingerprints exactly; explicitly project all three PostgreSQL 17 sequence state fields (last_value, log_cnt, is_called). Keep sequence enumeration and equality checks. Do not skip sequences, change catalogs, normalize data, advance sequences, or claim clone equality. A real PG17 temporary-object query-shape smoke is required before another full trial. Source and mock tests cannot validate PostgreSQL execution.

Primary source: https://raw.githubusercontent.com/postgres/postgres/REL_17_STABLE/src/include/commands/sequence.h defines the three sequence tuple fields. https://www.postgresql.org/docs/17/sql-createsequence.html documents reading the special sequence relation and the nontransactional effects of nextval/setval.
