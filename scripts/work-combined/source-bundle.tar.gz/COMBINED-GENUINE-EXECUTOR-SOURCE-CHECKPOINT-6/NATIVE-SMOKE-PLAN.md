# Proposed finite PG17 smoke — no execution in this checkpoint

Purpose: validate the exact fingerprint SQL on real PostgreSQL17 before another full combined trial. AST tests and mock returns cannot answer this question.

Root's later reviewed runner must use a fresh disposable localhost:5432 PostgreSQL17 service, database `forge_work_activity_role_test`, fixture administrator `supabase_admin`. Sanitize inherited PG environment variables, use only the reviewed fixture credentials, and record server/system identity and source hashes. No existing or provider database is authorized. The SQL itself additionally checks database, session/current role and major version.

Generate and byte-compare without database contact:

```
python3 build_fingerprint_smoke.py NEW-fingerprint-smoke.sql
cmp NEW-fingerprint-smoke.sql fingerprint-smoke.sql
```

Proposed psql invocation, **not run here**:

```
psql "$REVIEWED_DISPOSABLE_URL" -X -v ON_ERROR_STOP=1 -f fingerprint-smoke.sql
```

Wrap it in a finite external 35-second deadline; the SQL retains 20-second statement and 12-second lock limits. Preserve complete stdout/stderr, return code, exact source/query hashes and identity. Process death is not backend absence: reuse the reviewed unique application-name/quiescence protocol if an outcome is unknown; do not infer rollback or terminate a backend. The previous executor timeout/restoration safeguards remain unchanged. Root must supply that reviewed runner, not run an unbounded shell command from this document.

All objects are newly created temporary objects inside BEGIN. Only their data is changed. The sole nextval call targets the newly created temporary sequence. It is not a claim that nextval on an existing sequence rolls back. SQL ends with ROLLBACK. On normal success, require both the exact JSON result and successful final ROLLBACK completion; the pre-rollback result intentionally says `rollbackCompleted:false`. An error aborts the transaction; failed/unknown session cleanup must remain unproved until the backend is observed gone. The smoke has no paid activity, public/auth writes or candidate installation.

Native controls authored:

1. Exact old query fails with SQLSTATE42809 and the expected missing-composite-type message.
2. Ordinary table hash preserves three rows, a duplicate and nulls.
3. Partitioned-table root hash equals the same independent expected rows.
4. Empty table yields count zero and hash of the empty JSON array.
5. New sequence initial tuple contains bigint9007199254740993, log_cnt0 and is_calledfalse; corrected fingerprint equals an independent literal expected hash.
6. Before/after direct-column observations prove fingerprint reads do not change initial state.
7. After deliberate nextval on that temporary sequence, the corrected hash includes all three actual state fields, differs from the initial hash and another direct-column observation proves no further mutation.

Limits: no real disk quota/crash, clone state equality, fixture source execution, provider identity, concurrency, production performance or combined paid/report proof. Other executor queries have not been certified by this smoke. Its success is required evidence for this one query shape, not permission to weaken another failing guard.
