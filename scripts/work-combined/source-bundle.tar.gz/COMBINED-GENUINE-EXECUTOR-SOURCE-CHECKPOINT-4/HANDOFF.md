# First genuine failure and correction 4

**The first failure is a caller-selection bug, not a missing administrator capability.** In run 37323394155, head ffdf3c25d0aadf72c771709d164653841d95b488, job 111807885356, call-00002 ran on database `postgres` using login `postgres`. Its SQL explicitly asked whether `session_user` was `supabase_admin`. The result was false, as expected for that connection.

`self.admin = self.r.at('postgres')` selects a database only. It does not change the Runner's default login, which remains `postgres`. The administrator predicate omitted its `user` argument. Correction4 adds only `user='supabase_admin'` to that call. It does not change the SQL predicate, roles, grants, owners, source guards, settings, timeouts or immutable proof data.

The original infrastructure distinction remains correct and unchanged: supabase_admin is the separate SUPERUSER/CREATEDB fixture administrator; postgres is the actual nonsuperuser application source owner. The pinned role fixture declares those exact attributes. Genuine prerequisite1 passed 190 checks, including its separate bootstrap login, nonsuperuser source owner and exact attributes for every pinned role. The combined executor's failed call was not evidence that the administrator lacked those attributes. ROLE-CONTRACT.json preserves the exact source-backed expectations.

## Genuine evidence and limits

The root artifact is API ID 11352165444, ZIP SHA-256 `2372ea19d2e4c4c08fb66de46b5306f7b7d514c2d6ac644a20567e085b533e9c`. The ZIP, all 24 extracted files and full CI log were reverified against the root receipt. The relevant original SQL, stdout, executor partial and prerequisite1 result are copied under premise/; their hashes were frozen before the source edit.

All six prerequisite steps passed. The combined executor then made three successful read-only queries, recorded PG 170011 / database OID 16384, and failed with zero completed checks. Its branches, sessions and cases are empty. It had not reached seed construction, clone creation or candidate installation. That is distinct from a restoration proof: initial_global was not assigned, and no final global/data/catalog/rollback verification was recorded. `cleanupFailures: []` and later service disposal do not establish restoration. The prerequisite fixtures had already committed their own synthetic state.

## Correction validation

All 74 no-contact tests pass: the earlier 69 test methods are unchanged, plus five new controls. The actual frozen source3 infrastructure method reproduces the wrong-login failure using the Runner's real URI construction and fake replies derived from the pinned role fixture and captured read-only outputs. Correction4 reaches the later global-read boundary using supabase_admin for the administrator check and postgres for the nonsuperuser source-owner check. Negative controls still reject an administrator lacking SUPERUSER or CREATEDB and a superuser source owner.

These controls establish source orchestration only. They do not prove the next genuine run will pass clone construction, seed, catalog, paid-reader or cleanup cases. Default and check-plan remain no-contact; the two changed Python modules compile. All prior checkpoint1/2/3 files, all 283 protected audit entries, candidate/variant roots and profile remain unchanged. No repository, workflow or old artifact was edited, and no SQL, provider, installation or CI rerun occurred.

## Packaging and next action

Keep source1, correction2, correction3 and correction4 as immutable sibling directories with their existing names. Runtime uses source1 and correction4. Retained tests need correction2's main for the non-install counterexample; the new tests also need correction3's main for the first-run counterexample. The copied premise evidence is local to correction4. All those inputs are covered by their manifests and SOURCE-AUDIT. Root must externally pin correction4's current main/test/profile and manifest; no overlay into a frozen checkpoint is supported.

From their parent directory, run these no-contact commands:

```
python3 COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-4/test_combined_executor.py
python3 COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-4/combined_executor.py --check-plan
```

Recommendation: actual narrow source review of the one-line caller fix, recorded failure and five regressions, then root-owned repackage/enrollment. No role premise needs relaxing. Ownership returns to root at this frozen checkpoint. All existing runtime, provider, owner, full20/42/65, inactive-root historical portability and paid-wait gates remain open; activation remains false.
