# Narrow correction 4 review

Review premise/DIAGNOSIS.json, original call-00002 SQL/stdout and executor receipt, ROLE-CONTRACT.json, CORRECTION.patch, five new test methods and evidence/first-run-counterexample.json. The actual first run selected postgres while testing session_user=supabase_admin; inspect Runner.at versus Runner.run defaults.

Confirm the only runtime source change is an explicit administrator login argument on the existing predicate. SUPERUSER/CREATEDB requirements and nonsuperuser source-owner requirements must remain unchanged. Check that the old-source counterexample actually uses the prior infrastructure method and real URI construction, while clearly remaining a simulated subprocess/SQL result.

The six predecessor steps passed in genuine disposable PG17, but the combined executor has no successful initialization, clone, seed, candidate or final restoration proof. Empty cleanupFailures is not restoration. No database, provider, package/workflow/repository mutation or rerun is authorized by this review. Return a bounded held-source verdict before root repackages.
