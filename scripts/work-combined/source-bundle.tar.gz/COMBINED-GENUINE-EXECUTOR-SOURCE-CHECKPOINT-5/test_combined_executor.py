#!/usr/bin/env python3
"""No-contact source, subprocess-boundary and failure-path tests. Not SQL proof."""
import ast,contextlib,copy,io,json,re,subprocess,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import combined_executor as e
sys.path.insert(0,str(e.HERE))
import author_variants as v
TARGET='postgresql://supabase_admin:fixture-only@localhost:5432/forge_work_activity_role_test'
class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.profile,cls.variants=e.validate_source();cls.source=Path(e.__file__).read_text()
 def report(self,root):return e.Report(Path(root)/'new'/'combined-executor.json')
 def test_default_no_contact(self):
  with patch.object(subprocess,'run',side_effect=AssertionError('Contact forbidden')),patch.object(subprocess,'Popen',side_effect=AssertionError('Contact forbidden')),contextlib.redirect_stdout(io.StringIO()) as out:self.assertEqual(e.main([]),0)
  self.assertFalse(json.loads(out.getvalue())['databaseContacted'])
 def test_check_plan_no_contact(self):
  with patch.object(subprocess,'run',side_effect=AssertionError('Contact forbidden')),contextlib.redirect_stdout(io.StringIO()) as out:self.assertEqual(e.main(['--check-plan']),0)
  self.assertEqual(json.loads(out.getvalue())['targets'],e.BRANCHES)
 def test_plan_output_refused(self):
  with self.assertRaises(RuntimeError):e.main(['--check-plan','--output','/tmp/not-used/combined-executor.json'])
 def test_modes_mutually_exclusive(self):
  with self.assertRaises(RuntimeError):e.main(['--check-plan','--execute-fixture'])
 def test_exact_target(self):self.assertEqual(e.validate_target(TARGET).hostname,'localhost')
 def test_wrong_targets_refused(self):
  for bad in [TARGET.replace('localhost','db.example.com'),TARGET.replace('5432','5433'),TARGET.replace('fixture-only','real'),TARGET+'?sslmode=disable',TARGET+'#x',TARGET.replace('forge_work_activity_role_test','postgres'),TARGET.replace('supabase_admin','postgres'),TARGET.replace(':5432','')]:
   with self.subTest(target=bad),self.assertRaises(RuntimeError):e.validate_target(bad)
 def test_new_output_required(self):
  with tempfile.TemporaryDirectory() as td:
   r=self.report(td);self.assertEqual(json.loads(r.path.read_text())['stage'],'initial_before_source_target_or_contact')
   with self.assertRaises(RuntimeError):e.Report(r.path)
 def test_invalid_source_receipt_precedes_contact(self):
  with tempfile.TemporaryDirectory() as td:
   out=Path(td)/'new'/'combined-executor.json'
   with patch.object(e,'validate_source',side_effect=RuntimeError('source drift')),patch.object(e.Runner,'run',side_effect=AssertionError('contact')),self.assertRaises(RuntimeError):e.main(['--execute-fixture','--output',str(out)])
   self.assertEqual(json.loads(out.read_text())['status'],'failed');self.assertFalse(json.loads(out.read_text())['databaseContacted'])
 def test_candidate_root_and_bytes_unchanged(self):
  self.assertEqual(e.sha(e.HERE/'approved-source3/candidate.sql'),'2a323f3d59e622b80cf235c68d7d39533ae1b98717b1a9769a5e5923046f69cd')
  self.assertEqual(self.variants['inactive']['root'],'d7d520dd7c227fedb6594117d017cde3307981156162aedf2c37dfbfd06467b2')
 def test_closing_only_is_authority_data_not_new_gate(self):self.assertEqual(self.variants['closing_only'],self.variants['inactive'])
 def test_active_catalog_exact_one_body_delta(self):
  expected=copy.deepcopy(self.variants['inactive']['catalog']);row=next(r for r in expected['publicCatalog']['functions'] if r['name']=='_work_cross_job_enabled');row['body']=v.load_assembler().sha('select true')
  self.assertEqual(expected,self.variants['active']['catalog']);self.assertEqual(len(self.variants['active']['delta']),1)
 def test_active_no_embedded_gate_dependents(self):
  a=v.load_assembler();old=a.sha('select false')
  for fn in a.functions(self.variants['active']['sql']):self.assertNotIn(old,fn[5])
 def test_all_variants_seed_proof_before_immutable(self):
  for variant in self.variants.values():
   s=variant['sql']
   for table,trigger in [('work_cross_job_contract','work_cross_job_contract_immutable'),('_work_unit_metadata_contract','metadata_immutable')]:self.assertLess(s.index('insert into public.'+table),re.search(r'create trigger '+trigger+r' .*? on public\.'+table+r' ',s).start())
   self.assertTrue(s.rstrip().endswith('rollback;'))
 def test_variant_canonical_is_authored(self):
  a=v.load_assembler()
  for name,x in self.variants.items():self.assertEqual(a.sha(a.canonical(x['catalog'])),x['root'])
 def test_explicit_commit_boundary_only(self):
  for x in self.variants.values():self.assertEqual(e.committed_fixture_sql(x['sql']),re.sub(r'rollback;\s*$','commit;\n',x['sql'],flags=re.I))
 def test_invalid_commit_sources_refused(self):
  for bad in ['commit;','begin;commit;','begin;disable trigger x;rollback;','begin;drop trigger x;rollback;']:
   with self.assertRaises(RuntimeError):e.committed_fixture_sql(bad)
 def test_clone_acl_from_pinned_source(self):
  profile=json.loads((e.HERE/'pinned-repository/scripts/fixtures/work-activity-engine-role-parity.json').read_text());sql=e.db_acl_sql(e.BRANCHES['inactive'],profile)
  self.assertIn('REVOKE ALL ON DATABASE',sql);self.assertIn('TO PUBLIC;',sql);self.assertIn('TEMPORARY,CONNECT',sql);self.assertNotIn('CREATE ROLE',sql);self.assertNotIn('GRANT authenticated',sql)
 def test_existing_unapproved_database_acl_refused(self):
  with self.assertRaises(RuntimeError):e.db_acl_sql(e.BASE,{'database':{'owner':'postgres','acl':[]}})
 def test_unexpected_acl_source_refused(self):
  with self.assertRaises(RuntimeError):e.db_acl_sql(e.BRANCHES['inactive'],{'database':{'owner':'postgres','acl':['auth=CTc/admin']}})
 def runner(self,td,stdout='true\n',stderr='',code=0):
  calls=[];report=self.report(td)
  def fake(args,**kw):
   calls.append((args,kw));self.assertEqual(json.loads(report.path.read_text())['calls'][-1]['status'],'waiting');self.assertEqual(json.loads(report.path.read_text())['calls'][-1]['applicationName'],kw['env']['PGAPPNAME']);return SimpleNamespace(returncode=code,stdout=stdout,stderr=stderr)
  return e.Runner(e.validate_target(TARGET),report,execute=fake),calls
 def test_scalar_boundary_serializes_in_sql(self):
  with tempfile.TemporaryDirectory() as td:
   r,calls=self.runner(td);self.assertIs(r.json('select true'),True);self.assertIn('select to_jsonb(__combined_result.value)',calls[0][1]['input'])
 def test_raw_psql_t_rejected(self):
  with tempfile.TemporaryDirectory() as td:
   r,_=self.runner(td,stdout='t\n')
   with self.assertRaises(json.JSONDecodeError):r.json('select true')
 def test_json_false_not_coerced(self):
  with tempfile.TemporaryDirectory() as td:
   r,_=self.runner(td,stdout='false\n');self.assertIs(r.json('select false'),False)
 def test_extra_response_line_refused(self):
  with tempfile.TemporaryDirectory() as td:
   r,_=self.runner(td,stdout='true\nfalse\n')
   with self.assertRaises(RuntimeError):r.json('select true')
 def test_large_subprocess_output_retained(self):
  with tempfile.TemporaryDirectory() as td:
   data={'large':'x'*2500000};raw=json.dumps(data)+'\n';r,_=self.runner(td,stdout=raw);self.assertEqual(r.json("select '{}'::jsonb"),data)
   self.assertEqual((r.report.path.parent/'call-00000.stdout').read_text(),raw)
 def test_installed_runtime_timeouts_not_overridden(self):
  with tempfile.TemporaryDirectory() as td:
   r,calls=self.runner(td);r.run('select true',user='authenticator');self.assertNotIn('set statement_timeout',calls[0][1]['input']);self.assertEqual(calls[0][1]['timeout'],35)
 def test_inspection_timeouts_finite(self):
  with tempfile.TemporaryDirectory() as td:
   r,calls=self.runner(td);r.run('select true');self.assertIn("statement_timeout='20s'",calls[0][1]['input']);self.assertIn("lock_timeout='12s'",calls[0][1]['input'])
 def test_wrong_error_message_refused(self):
  with tempfile.TemporaryDirectory() as td:
   r,_=self.runner(td,code=3,stderr='ERROR: 55000: Wrong source')
   with self.assertRaises(RuntimeError):r.run('select x',error='55000',message='Exact expected')
 def test_expected_error_logged(self):
  with tempfile.TemporaryDirectory() as td:
   r,_=self.runner(td,code=3,stderr='ERROR: 55000: Exact expected');r.run('select x',error='55000',message='Exact expected');self.assertEqual(r.report.value['calls'][0]['returnCode'],3)
 def test_timeout_partial_retained(self):
  with tempfile.TemporaryDirectory() as td:
   r,_=self.runner(td);r.execute=lambda *a,**k:(_ for _ in ()).throw(subprocess.TimeoutExpired('psql',35,output=b'partial',stderr=b'timeout'))
   with self.assertRaises(subprocess.TimeoutExpired):r.run('select x')
   self.assertEqual((r.report.path.parent/'call-00000.stdout').read_bytes(),b'partial');self.assertEqual(r.report.value['calls'][0]['status'],'process_timeout')
 def test_distinct_clone_identity_same_cluster(self):
  a={'systemIdentifier':'a','postmasterStart':'b','serverVersionNum':'170000','timezone':'UTC','database':'x','databaseOid':'10'};b={**a,'database':'y','databaseOid':'11'};e.same_cluster(a,b)
  with self.assertRaises(RuntimeError):e.same_database(a,b)
 def test_cross_instance_rejected(self):
  a={'systemIdentifier':'a','postmasterStart':'b','serverVersionNum':'170000','timezone':'UTC'}
  with self.assertRaises(RuntimeError):e.same_cluster(a,{**a,'systemIdentifier':'different'})
 def test_clone_before_predecessor_before_install(self):
  fn=next(n for n in ast.walk(ast.parse(self.source)) if isinstance(n,ast.ClassDef) and n.name=='Executor');run=next(n for n in fn.body if isinstance(n,ast.FunctionDef) and n.name=='run');calls=[x.func.attr for x in ast.walk(run) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute)]
  self.assertLess(calls.index('clone_branches'),calls.index('predecessors'));self.assertLess(calls.index('predecessors'),calls.index('install'))
 def test_unknown_commit_is_checked_not_ignored(self):
  self.assertIn('if kind not in self.installed:',self.source);self.assertIn('installationRolledBackVerified',self.source);self.assertIn('Ambiguous install left unauthored catalog; refuse repair',self.source)
 def test_no_termination_or_proof_update(self):
  tree=ast.parse(self.source);strings='\n'.join(n.value for n in ast.walk(tree) if isinstance(n,ast.Constant) and isinstance(n.value,str))
  self.assertNotIn('pg_terminate_backend',strings);self.assertNotRegex(strings,r'(?i)update public\.(?:work_cross_job_contract|_work_unit_metadata_contract)');self.assertNotRegex(strings,r'(?i)alter table .*disable trigger')
 def test_same_context_negative_prerequisite(self):self.assertIn("require(context==self.contexts[mode]",self.source)
 def test_paid_full_15_and_digest_source_assertions(self):
  self.assertIn("first['receipt']==expected",self.source);self.assertIn("digest==retained['setup_payload_digest']",self.source);self.assertIn("micro!=fingerprint",self.source);self.assertIn("f.rpc(actor,changed)==unavailable",self.source)
 def test_active_restoration_limit_explicit(self):
  self.assertIn('activeInactiveCatalogRestored=False',self.source);self.assertIn("privateGate':kind=='active'",self.source);self.assertIn('Authority shutdown changed measured paid/source/receipt/history rows',self.source)
 def test_all_approved_float_fixtures_reused(self):
  for name in ['float0-paid-reader-still-refuses.sql','float0-private-coverage.sql','float0-existing-public-readers.sql']:self.assertIn(name,self.source)
 def test_profile_has_no_self_pin(self):self.assertNotIn('combined_executor.py',self.profile['pins']);self.assertIn('Final manifest',self.profile['sourceSelfPin'])
 def test_fresh_auth_inherited_pinned_contract(self):
  source=(e.HERE/'pinned-repository/scripts/verify-work-cross-job-v2-postgres.py').read_text();self.assertIn('SET ROLE authenticated',source);self.assertIn('request.jwt.claim.sub',source);self.assertIn("current_setting('statement_timeout')<>'8s'",source);self.assertIn('Actual fresh LOGIN/SET ROLE/JWT subject mismatch',source)

 def mock_executor(self,report,fail_active=False,fail_cleanup=False):
  x=object.__new__(e.Executor);x.report=report;x.installed=set();x.attempted=set();x.initial_global=None;x.predecessor_state=None;x.events=[]
  x.clone_branches=lambda:x.events.append('clone')
  x.predecessors=lambda:x.events.append('predecessors')
  def install(kind):x.events.append('install_'+kind);x.installed.add(kind);x.attempted.add(kind);return object()
  x.install=install;x.base_cases=lambda f:None;x.capability_pair=lambda f,negative:None
  def active(f):
   if fail_active:raise ValueError('primary fixture failure')
  def cleanup(kind):
   x.events.append('cleanup_'+kind)
   if fail_cleanup:raise RuntimeError('cleanup failure')
  x.active_cases=active;x.finalize_branch=cleanup;return x
 def test_cleanup_failure_is_fatal(self):
  with tempfile.TemporaryDirectory() as td:
   x=self.mock_executor(self.report(td),fail_cleanup=True)
   with self.assertRaisesRegex(RuntimeError,'Cleanup verification failed'):x.run()
   self.assertEqual(len(x.report.value['cleanupFailures']),3)
 def test_primary_failure_preserved_with_cleanup_failure(self):
  with tempfile.TemporaryDirectory() as td:
   x=self.mock_executor(self.report(td),True,True)
   with self.assertRaisesRegex(ValueError,'primary fixture failure'):x.run()
   self.assertEqual(x.report.value['primaryFailure']['message'],'primary fixture failure');self.assertEqual(len(x.report.value['cleanupFailures']),3)
 def test_all_branches_finalized_before_success(self):
  with tempfile.TemporaryDirectory() as td:
   x=self.mock_executor(self.report(td));x.run()
   self.assertEqual(x.events[:2],['clone','predecessors']);self.assertEqual(sum(k.startswith('cleanup_') for k in x.events),3)
   self.assertFalse(x.report.value['activeInactiveCatalogRestored'])
 def test_predecessor_wait_receipt_before_block(self):
  with tempfile.TemporaryDirectory() as td:
   report=self.report(td)
   class Process:
    def wait(self,timeout):
     assert json.loads(report.path.read_text())['stage']=='before_predecessor_wait';assert timeout<=5;return 0
    def poll(self):return 0
   e.predecessor_process(Path('/tmp/pinned.py'),[],{},Path(td)/'pre.log',report,popen=lambda *a,**k:Process())
 def test_unexpected_extra_role_rejected(self):
  expected={'roles':[]};actual=[{'rolname':'unexpected','rolsuper':False}]
  with self.assertRaisesRegex(RuntimeError,'Unexpected extra role'):e.validate_role_rows(actual,expected)

 def test_capability_context_excludes_only_unread_guard_timestamp(self):
  a=v.load_assembler();source=(e.HERE/'pinned-repository/supabase/migrations/20261108410000_work_activity_engine_cutover.sql').read_text()
  guard=next(x for x in a.functions(source) if x[1]=='_work_activity_authority_guard')[5]
  cap=next(x for x in a.functions(self.variants['inactive']['sql']) if x[1]=='work_activity_clock_capability')[5]
  self.assertIn('new.updated_at:=clock_timestamp()',guard);self.assertIn('select capture_enabled,revision into enabled,generation',cap);self.assertNotIn('updated_at',cap)
  self.assertIn("to_jsonb(a)-'updated_at'",self.source);self.assertIn("'rawAuthority':raw_authority",self.source)
 def test_history_characterized_after_authority_off_without_reseeding(self):
  self.assertIn("self.paid_lookup(f,self.legacy.uid(4),fallback_key,False)",self.source)
  self.assertIn("self.authority_set(f.r,False)\n  self.paid_lookup(f,actor,key,True)",self.source)
  self.assertIn("'authorityCaptureEnabled':f.r.json",self.source)

 def test_initial_settings_exact_values_and_no_extras(self):
  expected={'settings':[{'scope':'all_databases','role':'authenticator','safeValues':['statement_timeout=8s','lock_timeout=8s']}]}
  actual={'roles':[{'oid':10,'rolname':'authenticator'}],'settings':[{'setdatabase':0,'setrole':10,'setconfig':['lock_timeout=8s','statement_timeout=8s']}]}
  self.assertTrue(e.validate_initial_settings(actual,expected))
  bad=copy.deepcopy(actual);bad['settings'][0]['setconfig'].append('search_path=unsafe')
  with self.assertRaises(RuntimeError):e.validate_initial_settings(bad,expected)
  bad=copy.deepcopy(actual);bad['settings'][0]['setdatabase']=100
  with self.assertRaises(RuntimeError):e.validate_initial_settings(bad,expected)

 def test_predecessor_timeout_and_failed_kill_keep_both_errors(self):
  with tempfile.TemporaryDirectory() as td:
   report=self.report(td)
   class Process:
    def wait(self,timeout):raise subprocess.TimeoutExpired('predecessor',timeout)
    def poll(self):return None
    def kill(self):raise RuntimeError('kill failed')
   with patch.object(e.time,'monotonic',side_effect=[0,0,0,1300]),self.assertRaisesRegex(RuntimeError,'finite budget expired'):
    e.predecessor_process(Path('/tmp/pinned.py'),[],{},Path(td)/'pre.log',report,popen=lambda *a,**k:Process())
   self.assertEqual(report.value['predecessorCleanupFailures'][0]['message'],'kill failed')
   self.assertEqual(report.value['predecessorFailures'][0]['message'],'Predecessor finite budget expired')

 def test_executor_construction_has_no_contact(self):
  with tempfile.TemporaryDirectory() as td,patch.object(subprocess,'run',side_effect=AssertionError('contact')),patch.object(subprocess,'Popen',side_effect=AssertionError('contact')):
   x=e.Executor(e.validate_target(TARGET),self.report(td),self.profile,self.variants);self.assertEqual(x.r.database,e.BASE)
 def test_catalog_requires_canonical_bytes_not_python_numeric_equality(self):
  with tempfile.TemporaryDirectory() as td:
   x=object.__new__(e.Executor);x.report=self.report(td);x.canonical=v.load_assembler().canonical;x.public_query='select sample';x.combined_query=x.public_query
   x.check=lambda ok,label:e.require(ok,label)
   r=SimpleNamespace(database=e.BASE,run=lambda sql:'{"value": 100.0}')
   # Python structural equality alone would incorrectly accept this distinction.
   self.assertEqual(json.loads(r.run('')),{'value':100})
   with self.assertRaisesRegex(RuntimeError,'canonical catalog bytes'):x.catalog(r,{'value':100})
   self.assertFalse(x.report.value['catalogComparisons'][0]['exactCanonicalBytes'])

 def test_call_tag_unique_sanitized_and_persisted_before_wait(self):
  with tempfile.TemporaryDirectory() as td,patch.dict(e.os.environ,{'PGAPPNAME':'inherited','PGOPTIONS':'unsafe','PGHOST':'elsewhere'}):
   r,calls=self.runner(td);r.run('select 1');r.at(e.BRANCHES['inactive']).run('select 2')
   tags=[call['applicationName'] for call in r.report.value['calls']]
   self.assertEqual(len(set(tags)),2)
   for i,(_,kw) in enumerate(calls):
    self.assertEqual(kw['env']['PGAPPNAME'],tags[i]);self.assertRegex(tags[i],r'^forge-combined-[0-9a-f]{32}$');self.assertNotIn('PGHOST',kw['env']);self.assertNotIn('unsafe',kw['env']['PGOPTIONS'])
 def ambiguous_executor(self,td,mode,implementation=e):
  report=self.report(td);report.value['clusterBaseline']={'systemIdentifier':'system','postmasterStart':'start'};report.value['branches']['inactive']={}
  x=object.__new__(implementation.Executor);x.report=report;x.installed=set();x.attempted=set();x.initial_global=None;x.predecessor_state=None;x.public_query='select sample_catalog';x.canonical=v.load_assembler().canonical
  old=json.loads((e.HERE/'pinned-repository/scripts/work-cross-job-old-catalog.json').read_text())['metadata'];new={'new':'catalog'};x.variants={'inactive':{'catalog':{'publicCatalog':new}}}
  state={'monitorCalls':0,'catalogReads':[],'alive':True,'finalized':False,'clock':0.0,'wireCalls':[]}
  tag='forge-combined-'+'a'*32
  def execute(args,**kw):
   wire=kw['input'];state['wireCalls'].append(kw)
   if 'pg_stat_activity' in wire:
    state['monitorCalls']+=1
    if mode=='monitor_timeout':raise subprocess.TimeoutExpired('monitor',kw['timeout'],output=b'partial-monitor')
    alive=mode in ('alive','wrong_owner') or (mode=='late_commit' and state['monitorCalls']==1)
    state['alive']=alive
    row={'pid':123,'database':e.BRANCHES['inactive'],'login':'postgres','applicationName':tag,'state':'active','transactionStart':'retained transaction','waitEventType':'Lock'}
    if mode=='wrong_owner':row['login']='someone_else'
    sample={'systemIdentifier':'system','postmasterStart':'start','monitorDatabase':e.BRANCHES['inactive'],'monitorLogin':'supabase_admin','monitorCurrentRole':'supabase_admin','canSeeAllBackends':True,'backends':[row] if alive else []}
    if mode=='malformed':sample['backends']=None
    if mode=='hidden_activity':sample['canSeeAllBackends']=False
    if mode=='wrong_cluster':sample['systemIdentifier']='replacement'
    return SimpleNamespace(returncode=0,stdout=json.dumps(sample)+'\n',stderr='')
   state['catalogReads'].append({'alive':state['alive'],'monitorCalls':state['monitorCalls']})
   catalog=new if mode=='late_commit' and not state['alive'] else old
   return SimpleNamespace(returncode=0,stdout=x.canonical(catalog)+'\n',stderr='')
  r=e.Runner(e.validate_target(TARGET),report,e.BRANCHES['inactive'],execute=execute)
  original_wait=r.wait_backend_gone
  def sleep(seconds):state['clock']+=seconds
  r.wait_backend_gone=lambda call:original_wait(call,budget=0.5,clock=lambda:state['clock'],sleep=sleep)
  x.r=SimpleNamespace(at=lambda database:r);x.clone_branches=lambda:None;x.predecessors=lambda:None
  def install(kind):
   x.attempted.add(kind);report.value['calls'].append({'database':r.database,'login':'postgres','applicationName':tag,'purpose':'install:inactive','status':'process_timeout'});raise subprocess.TimeoutExpired('original-install',35)
  x.install=install
  def finalize(kind):state['finalized']=True
  x.finalize_branch=finalize
  return x,state
 def test_surviving_backend_never_classifies_old_catalog_as_rollback(self):
  with tempfile.TemporaryDirectory() as td:
   x,state=self.ambiguous_executor(td,'alive')
   with self.assertRaises(subprocess.TimeoutExpired):x.run()
   self.assertEqual(state['catalogReads'],[]);self.assertNotIn('installationRolledBackVerified',x.report.value['branches']['inactive']);self.assertNotIn('inactive',x.installed);self.assertFalse(state['finalized'])
   self.assertEqual(x.report.value['cleanupFailures'][0]['message'],'ambiguous_backend_alive');self.assertEqual(x.report.value['primaryFailure']['type'],'TimeoutExpired')
 def test_late_commit_waits_for_backend_exit_then_classifies_new(self):
  with tempfile.TemporaryDirectory() as td:
   x,state=self.ambiguous_executor(td,'late_commit')
   with self.assertRaises(subprocess.TimeoutExpired):x.run()
   self.assertEqual(state['catalogReads'],[{'alive':False,'monitorCalls':2}]);self.assertIn('inactive',x.installed);self.assertTrue(state['finalized']);self.assertNotIn('installationRolledBackVerified',x.report.value['branches']['inactive']);self.assertEqual(x.report.value['cleanupFailures'],[])
 def test_normal_gone_allows_old_catalog_rollback_evidence(self):
  with tempfile.TemporaryDirectory() as td:
   x,state=self.ambiguous_executor(td,'gone')
   with self.assertRaises(subprocess.TimeoutExpired):x.run()
   self.assertEqual(state['catalogReads'],[{'alive':False,'monitorCalls':1}]);self.assertTrue(x.report.value['branches']['inactive']['installationRolledBackVerified']);self.assertFalse(state['finalized'])
 def test_monitor_timeout_is_unknown_fatal_without_catalog_claim(self):
  with tempfile.TemporaryDirectory() as td:
   x,state=self.ambiguous_executor(td,'monitor_timeout')
   with self.assertRaises(subprocess.TimeoutExpired):x.run()
   self.assertEqual(state['catalogReads'],[]);self.assertNotIn('installationRolledBackVerified',x.report.value['branches']['inactive']);self.assertEqual(x.report.value['cleanupFailures'][0]['message'],'ambiguous_backend_monitor_unknown')
   evidence=x.report.value['backendSettlement'][0];self.assertEqual(evidence['status'],'unknown');self.assertEqual(evidence['failure']['type'],'TimeoutExpired')
 def test_monitor_ownership_or_malformed_result_refuses(self):
  for mode in ['wrong_owner','malformed','hidden_activity','wrong_cluster']:
   with self.subTest(mode=mode),tempfile.TemporaryDirectory() as td:
    x,state=self.ambiguous_executor(td,mode)
    with self.assertRaises(subprocess.TimeoutExpired):x.run()
    self.assertEqual(state['catalogReads'],[]);self.assertEqual(x.report.value['backendSettlement'][0]['status'],'unknown')
 def test_monitor_uses_unique_identity_and_shorter_budget(self):
  with tempfile.TemporaryDirectory() as td:
   x,state=self.ambiguous_executor(td,'late_commit')
   with self.assertRaises(subprocess.TimeoutExpired):x.run()
   monitor=[c for c in x.report.value['calls'] if str(c.get('purpose','')).startswith('backend_monitor:')]
   self.assertEqual(len(monitor),2);tags=[c['applicationName'] for c in x.report.value['calls']];self.assertEqual(len(set(tags)),len(tags))
   for c in monitor:self.assertEqual(c['login'],'supabase_admin');self.assertLessEqual(c['processTimeoutSeconds'],0.5)
   for call in state['wireCalls'][:2]:self.assertIn("statement_timeout='",call['input']);self.assertIn('ms',call['input']);self.assertNotIn('20s',call['input'])
 def test_old_source_counterexample_falsely_records_rollback(self):
  old_module=e.module(e.HERE/'combined_executor.py','frozen_source1_counterexample')
  with tempfile.TemporaryDirectory() as td:
   x,state=self.ambiguous_executor(td,'alive',implementation=old_module)
   with self.assertRaises(subprocess.TimeoutExpired):x.run()
   self.assertEqual(state['monitorCalls'],0);self.assertTrue(state['catalogReads'][0]['alive'])
   # The same required safety assertion fails on actual frozen source1.
   with self.assertRaises(AssertionError):self.assertNotIn('installationRolledBackVerified',x.report.value['branches']['inactive'])
   self.assertTrue(x.report.value['branches']['inactive']['installationRolledBackVerified'])
 def test_cleanup_preserves_unknown_monitor_and_later_global_failure(self):
  with tempfile.TemporaryDirectory() as td:
   x,state=self.ambiguous_executor(td,'monitor_timeout');x.initial_global={};x.admin=SimpleNamespace(json=lambda *a,**k:(_ for _ in ()).throw(RuntimeError('later global monitor failed')))
   with self.assertRaises(subprocess.TimeoutExpired):x.run()
   self.assertEqual(x.report.value['primaryFailure']['type'],'TimeoutExpired');self.assertEqual(len(x.report.value['cleanupFailures']),2)
   self.assertEqual(x.report.value['cleanupFailures'][0]['message'],'ambiguous_backend_monitor_unknown');self.assertEqual(x.report.value['cleanupFailures'][1]['scope'],'global_backend_settlement')


 def noninstall_executor(self,td,mode,implementation=e):
  x,state=self.ambiguous_executor(td,mode,implementation);original_install=x.install
  def install(kind):
   try:original_install(kind)
   except subprocess.TimeoutExpired:
    x.installed.add(kind);x.report.value['calls'][-1]['purpose']='paid_or_authority_mutator';raise
  x.install=install
  def finalize(kind):state['finalized']=True;state['finalizationWhileBackendAlive']=state['alive']
  x.finalize_branch=finalize;return x,state
 def test_noninstall_live_mutator_blocks_branch_and_global_receipts(self):
  with tempfile.TemporaryDirectory() as td:
   x,state=self.noninstall_executor(td,'alive');x.initial_global={};x.admin=SimpleNamespace(json=lambda *a,**k:(_ for _ in ()).throw(AssertionError('global snapshot must not run')))
   with self.assertRaises(subprocess.TimeoutExpired):x.run()
   self.assertFalse(state['finalized']);self.assertNotIn('finalDatabaseInventory',x.report.value);self.assertNotIn('cleanupVerified',x.report.value['branches']['inactive']);self.assertEqual(x.report.value['cleanupFailures'][1]['scope'],'global_backend_settlement')
 def test_noninstall_late_commit_settles_before_final_snapshot(self):
  with tempfile.TemporaryDirectory() as td:
   x,state=self.noninstall_executor(td,'late_commit')
   with self.assertRaises(subprocess.TimeoutExpired):x.run()
   self.assertTrue(state['finalized']);self.assertFalse(state['finalizationWhileBackendAlive']);self.assertEqual(state['monitorCalls'],2);self.assertEqual(x.report.value['cleanupFailures'],[]);self.assertTrue(x.report.value['calls'][0]['backendGoneVerified'])
 def test_source2_counterexample_finalizes_while_noninstall_backend_alive(self):
  old=e.module(e.SOURCE.parent/'COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-2/combined_executor.py','source2_noninstall_counterexample')
  with tempfile.TemporaryDirectory() as td:
   x,state=self.noninstall_executor(td,'alive',old)
   with self.assertRaises(subprocess.TimeoutExpired):x.run()
   self.assertEqual(state['monitorCalls'],0);self.assertTrue(state['finalized'])
   with self.assertRaises(AssertionError):self.assertFalse(state['finalizationWhileBackendAlive'])
 def test_unexpected_process_exit_is_unresolved_even_with_error_text(self):
  for code in [1,2,-9]:
   with self.subTest(code=code),tempfile.TemporaryDirectory() as td:
    r,_=self.runner(td,code=code,stderr='ERROR: 55000: Exact expected')
    with self.assertRaises(RuntimeError):r.run('select x',error='55000',message='Exact expected')
    self.assertTrue(r.report.value['calls'][0]['requiresBackendSettlement']);self.assertEqual(r.report.value['calls'][0]['status'],'process_unknown')
 def test_expected_sql_refusal_is_known_response_not_unknown_send(self):
  with tempfile.TemporaryDirectory() as td:
   r,_=self.runner(td,code=3,stderr='ERROR: 55000: Exact expected');r.run('select x',error='55000',message='Exact expected')
   self.assertFalse(r.report.value['calls'][0]['requiresBackendSettlement']);self.assertEqual(r.report.value['calls'][0]['outcome'],'expected_sql_refusal')
 def test_unknown_subprocess_exception_requires_settlement(self):
  with tempfile.TemporaryDirectory() as td:
   r,_=self.runner(td);r.execute=lambda *a,**k:(_ for _ in ()).throw(OSError('unknown process boundary'))
   with self.assertRaises(OSError):r.run('begin;select 1;commit;')
   self.assertEqual(r.report.value['calls'][0]['status'],'process_unknown');self.assertTrue(r.report.value['calls'][0]['requiresBackendSettlement'])
 def test_all_unresolved_errors_retained_and_other_database_scoped_out(self):
  with tempfile.TemporaryDirectory() as td:
   x=object.__new__(e.Executor);x.report=self.report(td);seen=[]
   x.report.value['calls']=[{'database':e.BRANCHES['inactive'],'applicationName':'a','status':'process_timeout'},{'database':e.BRANCHES['inactive'],'applicationName':'b','status':'process_unknown'},{'database':e.BRANCHES['active'],'applicationName':'c','status':'process_timeout'}]
   def wait(call):seen.append(call['applicationName']);raise RuntimeError('unknown '+call['applicationName'])
   x.r=SimpleNamespace(at=lambda database:SimpleNamespace(wait_backend_gone=wait))
   with self.assertRaisesRegex(RuntimeError,'unknown a'):x.settle_unresolved({e.BRANCHES['inactive']})
   self.assertEqual(seen,['a','b']);self.assertEqual(len(x.report.value['unresolvedCallFailures']),2)


 def test_failed_untagged_predecessor_suppresses_final_restoration_claims(self):
  with tempfile.TemporaryDirectory() as td:
   x=self.mock_executor(self.report(td));x.initial_global={};x.admin=SimpleNamespace(json=lambda *a,**k:(_ for _ in ()).throw(AssertionError('unproved predecessor must prevent snapshot')))
   def predecessor():x.report.value['predecessorBackendQuiescenceUnproved']=True;raise subprocess.TimeoutExpired('untagged predecessor',1200)
   x.predecessors=predecessor
   with self.assertRaises(subprocess.TimeoutExpired):x.run()
   self.assertEqual(x.report.value['cleanupFailures'][0]['message'],'predecessor_backend_quiescence_unproved');self.assertNotIn('finalDatabaseInventory',x.report.value);self.assertNotIn('predecessorStatePreservedAfterCombined',x.report.value)
 def test_admin_database_unknown_call_blocks_branch_finalization(self):
  with tempfile.TemporaryDirectory() as td:
   x=self.mock_executor(self.report(td));x.report.value['calls'].append({'database':'postgres','applicationName':'admin-tag','status':'process_unknown'});seen=[]
   def wait(call):seen.append(call['database']);raise RuntimeError('admin backend still alive')
   x.r=SimpleNamespace(at=lambda database:SimpleNamespace(wait_backend_gone=wait))
   with self.assertRaisesRegex(RuntimeError,'Cleanup verification failed'):x.run()
   self.assertFalse(any(event.startswith('cleanup_') for event in x.events));self.assertEqual(seen,['postgres']*4);self.assertEqual(len(x.report.value['cleanupFailures']),4)


 def infrastructure_probe(self,td,implementation=e,role_changes=None):
  roles={r['name']:r for r in json.loads((e.HERE/'pinned-repository/scripts/fixtures/work-activity-engine-role-parity.json').read_text())['roles']}
  for name,changes in (role_changes or {}).items():roles[name]={**roles[name],**changes}
  report=self.report(td);calls=[]
  def execute(args,**kwargs):
   login=e.urlparse(args[1]).username;sql=kwargs['input'];calls.append({'login':login,'database':e.urlparse(args[1]).path,'sql':sql})
   if 'system_identifier::text' in sql:raw=(e.SOURCE/'premise/call-00000.stdout').read_text()
   elif 'jsonb_agg(jsonb_build_object' in sql and 'from pg_database' in sql:raw=(e.SOURCE/'premise/call-00001.stdout').read_text()
   elif "session_user='supabase_admin' and" in sql:raw=json.dumps(login=='supabase_admin' and roles[login]['superuser'] and roles[login]['createDatabase'])+'\n'
   elif "session_user='postgres' and not" in sql:raw=json.dumps(login=='postgres' and not roles[login]['superuser'])+'\n'
   elif 'from pg_event_trigger' in sql:raw='true\n'
   elif 'from pg_roles r' in sql:raise RuntimeError('probe_reached_global_without_contact')
   else:raise AssertionError('Unexpected mocked query: '+sql)
   return SimpleNamespace(returncode=0,stdout=raw,stderr='')
  x=object.__new__(implementation.Executor);x.report=report;x.r=e.Runner(e.validate_target(TARGET),report,execute=execute);x.admin=x.r.at('postgres')
  return x,calls
 def test_recorded_first_run_call_used_source_owner_for_admin_predicate(self):
  receipt=json.loads((e.SOURCE/'premise/combined-executor.json').read_text());call=receipt['calls'][2]
  self.assertEqual(call['login'],'postgres');self.assertEqual(call['database'],'postgres');self.assertEqual((e.SOURCE/'premise/call-00002.stdout').read_text(),'false\n');self.assertEqual(e.sha(e.SOURCE/'premise/call-00002.sql'),call['sqlSha256'])
 def test_old_source3_reproduces_first_run_wrong_login(self):
  old=e.module(e.SOURCE.parent/'COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-3/combined_executor.py','ffdf_old_source3')
  with tempfile.TemporaryDirectory() as td:
   x,calls=self.infrastructure_probe(td,old)
   with self.assertRaisesRegex(RuntimeError,'Exact fixture administrator CREATEDB/SUPERUSER prerequisite missing'):x.verify_infrastructure()
   self.assertEqual(calls[-1]['login'],'postgres');self.assertEqual(len(calls),3)
 def test_fixed_admin_probe_keeps_source_owner_separate(self):
  with tempfile.TemporaryDirectory() as td:
   x,calls=self.infrastructure_probe(td)
   with self.assertRaisesRegex(RuntimeError,'probe_reached_global_without_contact'):x.verify_infrastructure()
   self.assertEqual(calls[2]['login'],'supabase_admin');self.assertEqual(calls[2]['database'],'/postgres');self.assertEqual(calls[3]['login'],'postgres');self.assertIn("not (select rolsuper",calls[3]['sql'])
 def test_admin_required_capabilities_not_weakened(self):
  for field in ['superuser','createDatabase']:
   with self.subTest(field=field),tempfile.TemporaryDirectory() as td:
    x,calls=self.infrastructure_probe(td,role_changes={'supabase_admin':{field:False}})
    with self.assertRaisesRegex(RuntimeError,'Exact fixture administrator CREATEDB/SUPERUSER prerequisite missing'):x.verify_infrastructure()
    self.assertEqual(calls[-1]['login'],'supabase_admin')
 def test_source_owner_superuser_still_refused(self):
  with tempfile.TemporaryDirectory() as td:
   x,calls=self.infrastructure_probe(td,role_changes={'postgres':{'superuser':True}})
   with self.assertRaisesRegex(RuntimeError,'Source owner must remain nonsuperuser'):x.verify_infrastructure()


 def captured_global_rows(self):return json.loads((e.SOURCE/'premise/b4b49/call-00005.stdout').read_text())
 def captured_infrastructure(self,td,implementation=e):
  record=json.loads((e.SOURCE/'premise/b4b49/combined-executor.json').read_text());seen=[];report=self.report(td)
  def execute(args,**kwargs):
   call=record['calls'][len(seen)];self.assertEqual(e.sha_bytes(kwargs['input'].encode()),call['sqlSha256']);self.assertEqual(e.urlparse(args[1]).username,call['login']);self.assertEqual(e.urlparse(args[1]).path,'/'+call['database']);seen.append(call['file'])
   return SimpleNamespace(returncode=call['returnCode'],stdout=(e.SOURCE/'premise/b4b49'/(call['file']+'.stdout')).read_text(),stderr=(e.SOURCE/'premise/b4b49'/(call['file']+'.stderr')).read_text())
  x=object.__new__(implementation.Executor);x.report=report;x.r=e.Runner(e.validate_target(TARGET),report,execute=execute);x.admin=x.r.at('postgres');x.initial_global=None
  x.catalog=lambda *a,**k:(_ for _ in ()).throw(RuntimeError('captured_replay_reached_unchanged_catalog_gate'))
  return x,seen
 def test_global_oid_zero_accepts_only_exact_int_or_canonical_text(self):
  for value in [0,'0']:self.assertTrue(e.is_global_database_oid(value))
  for value in [False,True,0.0,1,16384,'16384','00','+0','-0','0.0',' 0','0 ',None,[],{},float('nan')]:
   with self.subTest(value=value):self.assertFalse(e.is_global_database_oid(value))
 def test_actual_global_settings_match_authored_profile_without_rewrite(self):
  rows=self.captured_global_rows();before=copy.deepcopy(rows);profile=json.loads((e.HERE/'pinned-repository/scripts/fixtures/work-activity-engine-role-parity.json').read_text())
  self.assertTrue(all(type(r['setdatabase']) is str and r['setdatabase']=='0' for r in rows['settings']));self.assertTrue(e.validate_initial_settings(rows,profile));self.assertEqual(rows,before)
 def test_old_source4_reproduces_string_oid_false_database_setting(self):
  old=e.module(e.SOURCE.parent/'COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-4/combined_executor.py','b4b49_source4_counterexample')
  with tempfile.TemporaryDirectory() as td:
   x,seen=self.captured_infrastructure(td,old)
   with self.assertRaisesRegex(RuntimeError,'Unexpected database-specific settings'):x.verify_infrastructure()
   self.assertEqual(len(seen),6);self.assertIsNone(x.initial_global)
 def test_actual_six_call_replay_passes_exact_initial_contract_to_catalog_gate(self):
  with tempfile.TemporaryDirectory() as td:
   x,seen=self.captured_infrastructure(td)
   with self.assertRaisesRegex(RuntimeError,'captured_replay_reached_unchanged_catalog_gate'):x.verify_infrastructure()
   self.assertEqual(len(seen),6);self.assertEqual(x.initial_global,self.captured_global_rows());self.assertEqual(x.report.value['globalBefore'],self.captured_global_rows())
 def test_actual_nonzero_or_malformed_database_setting_still_refused(self):
  profile=json.loads((e.HERE/'pinned-repository/scripts/fixtures/work-activity-engine-role-parity.json').read_text())
  for value in ['16384',16384,False,0.0,'00',None]:
   with self.subTest(value=value):
    rows=self.captured_global_rows();rows['settings'][0]['setdatabase']=value
    with self.assertRaisesRegex(RuntimeError,'Unexpected database/all-role setting'):e.validate_initial_settings(rows,profile)
 def test_actual_setting_value_extra_role_and_timeout_drift_still_refused(self):
  profile=json.loads((e.HERE/'pinned-repository/scripts/fixtures/work-activity-engine-role-parity.json').read_text())
  for mode in ['timeout','extra','unknown_role']:
   with self.subTest(mode=mode):
    rows=self.captured_global_rows();auth_oid=next(r['oid'] for r in rows['roles'] if r['rolname']=='authenticator');setting=next(r for r in rows['settings'] if r['setrole']==auth_oid)
    if mode=='timeout':setting['setconfig'][0]='statement_timeout=12s'
    elif mode=='extra':setting['setconfig'].append('extra_float_digits=0')
    else:setting['setrole']='999999'
    with self.assertRaises(RuntimeError):e.validate_initial_settings(rows,profile)

if __name__=='__main__':unittest.main(verbosity=2)
