# Correction 5: the database setting was a JSON type mismatch

**No database-specific setting was present in the failing output.** Run 37327538025, head b4b49d40f2c00e6e00ab81e55aeae0d4dc843781, returned six settings rows with `setdatabase` equal to the JSON string `"0"`. The executor compared that value to integer `0`. In Python those are different, so it falsely reported an unsupported database-specific setting.

PostgreSQL 17 defines setdatabase as an OID and uses zero for settings that are not database-specific; pg_db_role_setting is shared across the cluster. [Primary catalog documentation](https://www.postgresql.org/docs/17/catalog-pg-db-role-setting.html). The string representation is established separately by the actual captured to_jsonb record output.

The six rows are attributable to the unchanged role-parity fixture and its constructor at lines 77–93. Each observed role and complete setting array matches the authored safeValues exactly. They include the original search paths and authenticator 8-second limits. The withheld app.settings.jwt_exp entry has no safeValues, so the constructor emits no database setting for it. SETTING-ATTRIBUTION.json records every exact observed/authored pair and source hash.

## Narrow correction

One strict helper recognizes the zero sentinel only as integer 0 or canonical string `"0"`. Both existing global-setting checks now use it. No other value is accepted: nonzero database OIDs, booleans, floating-point zero, padded/signed strings, null and malformed values still refuse. No generic JSON decoder coercion was added.

The raw global snapshot is unchanged. Settings values, roles, memberships, duplicate/unknown role checks and subsequent whole-snapshot equality remain exact. Other OID consumers were inspected: role/membership/setrole lookups use matching captured string keys; database identity already uses oid::text. No settings, grants, owners, ACLs, proof rows, source/catalog roots or timeouts are changed.

There is consequently no database-specific configuration to copy, delete or normalize when cloning. The observed settings apply to roles across the shared cluster. Clone data fingerprints still cover public/auth rows and sequences; separate complete global-role/configuration equality checks retain the raw string OIDs and detect changes. Per-session setting checks remain required. No fingerprint or setting is rewritten to force agreement.

## Evidence and validation

The artifact ZIP SHA-256 is `18a709a700f45b05bd6e17ab2e3f7b79ae298350fbe6f8bd4476859241619089`. Its extracted files were compared byte-for-byte with archive entries, and all six calls' own SQL/stdout/stderr hashes were verified. The current artifact is under premise/b4b49; the unprefixed premise call files preserve the earlier FFDF regression inputs required by retained tests.

The corrected administrator call00002 returned true in this genuine run. All six prerequisite stages passed. The combined executor made six successful read-only calls, completed zero checks and stopped before seed, clone or candidate writes. It did not assign initial_global or supply a final global/data/catalog/restoration proof. Empty cleanupFailures and service disposal do not establish restoration; earlier prerequisite fixtures already had their own committed synthetic state.

All 80 no-contact tests pass: all 74 previous test methods are unchanged, plus six new controls. The actual old/new infrastructure methods replay the six captured responses with exact SQL hash, database and login matching. The old source reproduces the type refusal. The corrected method validates the complete captured role/settings/membership contract and reaches the next unchanged old-catalog gate, with its raw global snapshot byte-value equivalent to the captured object. This is orchestration replay, not new PostgreSQL execution.

Negative controls retain rejection of real database-specific settings, malformed zero values, changed timeouts, extra settings and unknown roles. Both plan modes remain no-contact and the two changed Python files compile. All earlier checkpoint1–4 files, 283 protected audit entries, profile, candidates and catalog roots remain unchanged. No repository, workflow, package, database, SQL or provider operation was performed by this task; the only external lookup was the public PostgreSQL documentation above.

## Next action and packaging

Actual narrow source review should verify the two boundary replacements, strict zero recognition, exact source attribution, captured-response replay and preserved raw-state comparisons before root repackages. Ownership returns to root at this checkpoint. No premise relaxation or configuration normalization is needed.

Keep checkpoints1–5 as immutable sibling directories. Runtime uses source1 plus correction5 main/profile. Retained counterexamples read prior main files from corrections2–4; the copied evidence is local to correction5. Root must verify prior manifests and externally pin correction5's current manifest/main/test/profile. No mutable links or overlay into old checkpoints are supported.

From the common parent directory, the no-contact entry points are `python3 COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-5/test_combined_executor.py` and `python3 COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-5/combined_executor.py --check-plan`. All runtime, provider, owner, historical portability, full20/42/65 and paid-wait gates remain open. No next-run success or activation is claimed.
