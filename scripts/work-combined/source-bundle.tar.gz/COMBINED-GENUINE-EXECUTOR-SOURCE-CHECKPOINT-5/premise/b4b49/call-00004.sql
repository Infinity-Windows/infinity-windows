\set VERBOSITY verbose
set statement_timeout='20s';set lock_timeout='12s';set search_path=public,pg_temp;
select to_jsonb(__combined_result.value) from (select not exists(select 1 from pg_event_trigger where evtenabled<>'D')) as __combined_result(value);