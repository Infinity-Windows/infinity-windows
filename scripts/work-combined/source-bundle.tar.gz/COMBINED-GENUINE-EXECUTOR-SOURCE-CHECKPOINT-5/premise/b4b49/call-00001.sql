\set VERBOSITY verbose
set statement_timeout='20s';set lock_timeout='12s';set search_path=public,pg_temp;
select to_jsonb(__combined_result.value) from (select jsonb_agg(jsonb_build_object('name',datname,'owner',pg_get_userbyid(datdba),'template',datistemplate,'allow',datallowconn) order by datname) from pg_database) as __combined_result(value);