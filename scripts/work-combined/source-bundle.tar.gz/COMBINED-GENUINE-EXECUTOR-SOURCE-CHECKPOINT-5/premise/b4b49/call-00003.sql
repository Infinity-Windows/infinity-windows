\set VERBOSITY verbose
set statement_timeout='20s';set lock_timeout='12s';set search_path=public,pg_temp;
select to_jsonb(__combined_result.value) from (select session_user='postgres' and not (select rolsuper from pg_roles where rolname=session_user)) as __combined_result(value);