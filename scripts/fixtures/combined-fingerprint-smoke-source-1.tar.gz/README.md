# Isolated fingerprint smoke package

This package runs only the exact approved source6 fingerprint smoke. It does not install the combined candidate, run prerequisite migrations, clone databases or execute the full trial.

`python3 run_fingerprint_smoke.py` and `--check-plan` verify source pins without database contact. `python3 test_fingerprint_smoke.py` runs 26 no-contact controls, including real Python-child output/timeout controls; none executes PostgreSQL.

Execution is a separate reviewed CI job using a new postgres:17 service with POSTGRES_USER=supabase_admin, POSTGRES_DB=forge_work_activity_role_test and fixture-only credentials. Set FINGERPRINT_SMOKE_DATABASE_URL to the exact localhost:5432 fixture URL and invoke `python3 run_fingerprint_smoke.py --execute-smoke --output ABSOLUTE_NEW_DIRECTORY/fingerprint-smoke.json`. Only the future approved workflow is the intended caller.

Every psql call has a unique startup PGAPPNAME, recorded before waiting, sanitized PG environment and complete SQL/stdout/stderr receipts. Business/query calls have a 35-second process deadline and startup statement/lock limits20s/12s. Monitors are fresh administrator reads: maximum5s per process, maximum15s per tagged target, no budget reset. Surviving/unknown backend, unknown startup, error or cancellation fails closed. No backend is terminated. An uncatchable kill or whole-job cancellation can interrupt evidence collection; missing final receipt is failure/unknown, never inferred success.

Success requires exact output including command tags and the final ROLLBACK, same server/system/postmaster/database identity, no non-system persistent relations, and exact tagged-backend absence observations. Temporary namespaces/OIDs can persist after rollback. This is why the job is isolated from the full trial. No namespace/OID restoration, disposal restoration, paid safety, clone equality or provider identity is claimed.

The source6 generator imports its exact combined_executor module only for the pure fingerprint_query helper. It never calls that executor's validate_source, main or database paths. Runtime closure is these three exact source6 files plus the smoke runner and pins; portable tests add one test file. Prior source6's 88 tests and seven authored native controls are distinct from the26 package controls. Native controls remain unexecuted until this new job succeeds.
