import contextlib,io,json,os,subprocess,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
import run_fingerprint_smoke as m
TARGET='postgresql://supabase_admin:fixture-only@localhost:5432/forge_work_activity_role_test'
sys.path.insert(0,str(m.ROOT/'source6'))
import combined_executor as source6
import build_fingerprint_smoke as generator

def identity():return dict(systemIdentifier='123456',postmasterStart='1791213553.458232',databaseOid='16384',database=m.BASE,sessionUser=m.USER,currentUser=m.USER,serverVersion='170011',timezone='UTC',floatDigits='1',isolation='read committed',statementTimeout='20s',lockTimeout='12s',superuser=True,inRecovery=False,userRelations=0,databases=sorted([m.BASE,'postgres','template0','template1']),namespaces=['information_schema','pg_catalog','pg_toast','public'])
def smoke():return '\n'.join(m.TAGS+[json.dumps(m.EXPECTED_RESULT),'ROLLBACK'])+'\n'
def monitor(rows=None):
 i=identity();return dict(systemIdentifier=i['systemIdentifier'],postmasterStart=i['postmasterStart'],databaseOid=i['databaseOid'],database=m.BASE,login=m.USER,role=m.USER,superuser=True,backends=rows or [])
def result(out,err='',code=0):return NS(stdout=out,stderr=err,returncode=code)
class Clock:
 def __init__(self):self.now=0
 def __call__(self):return self.now
 def sleep(self,n):self.now+=n
class Tests(unittest.TestCase):
 def fake(self,args,**kw):
  sql=kw['input'];return result(json.dumps(identity())+'\n' if sql==m.IDENTITY else smoke() if sql.startswith('-- PROPOSED') else json.dumps(monitor())+'\n')
 def run_case(self,hook=None):
  with tempfile.TemporaryDirectory() as d,patch.dict(os.environ,{'FINGERPRINT_SMOKE_DATABASE_URL':TARGET}):
   r=m.Receipt(Path(d)/'new/fingerprint-smoke.json');clock=Clock()
   def fake(args,**kw):return hook(r,args,kw) if hook else self.fake(args,**kw)
   code=m.execute(r,m.Runner(r,fake,clock,clock.sleep));saved={p.name:p.read_bytes() for p in r.path.parent.iterdir() if p.is_file()};return code,r.value,saved
 def test_default_and_check_plan_no_contact(self):
  with patch.object(subprocess,'run',side_effect=AssertionError('No contact')),contextlib.redirect_stdout(io.StringIO()) as out:
   self.assertEqual(m.main([]),0);self.assertEqual(m.main(['--check-plan']),0)
  self.assertIn('"databaseContacted": false',out.getvalue())
 def test_exact_source_pins_and_generator(self):
  self.assertEqual(m.validate_source()['files'],m.PINS);self.assertEqual(generator.build(),(m.ROOT/'source6/fingerprint-smoke.sql').read_text())
 def test_target_refuses_wrong_host_identity_options(self):
  m.validate_target(TARGET)
  for raw in [TARGET+'?x=1',TARGET+'#x',TARGET.replace('localhost','127.0.0.1'),TARGET.replace('5432','5433'),TARGET.replace('fixture-only','other'),TARGET.replace('supabase_admin','postgres'),TARGET.replace(m.BASE,'postgres')]:
   with self.subTest(raw=raw),self.assertRaises(RuntimeError):m.validate_target(raw)
 def test_output_new_and_outside_source(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'new/fingerprint-smoke.json';m.Receipt(p)
   with self.assertRaises(RuntimeError):m.Receipt(p)
  with self.assertRaises(RuntimeError):m.Receipt(m.ROOT/'test-output/fingerprint-smoke.json')
 def test_source_drift_refused_before_contact(self):
  with patch.object(m,'validate_source',side_effect=RuntimeError('drift')):code,r,_=self.run_case()
  self.assertEqual(code,1);self.assertFalse(r['databaseContacted']);self.assertEqual(r['calls'],[])
 def test_missing_target_refused_before_contact(self):
  with tempfile.TemporaryDirectory() as d,patch.dict(os.environ,{},clear=True):
   r=m.Receipt(Path(d)/'new/fingerprint-smoke.json');self.assertEqual(m.execute(r,m.Runner(r,self.fake)),1);self.assertFalse(r.value['databaseContacted'])
 def test_identity_profile_refusals(self):
  for k,v in [('database','postgres'),('sessionUser','postgres'),('currentUser','postgres'),('serverVersion','180001'),('timezone','America/Denver'),('superuser',False),('inRecovery',True),('userRelations',1),('lockTimeout','20s')]:
   i=identity();i[k]=v
   with self.subTest(key=k),self.assertRaises(RuntimeError):m.validate_identity(i,initial=True)
 def test_isolation_rejects_previous_temp_namespace(self):
  i=identity();i['namespaces'].append('pg_temp_3')
  with self.assertRaises(RuntimeError):m.validate_identity(i,initial=True)
  m.validate_identity(i,identity())
 def test_final_identity_change_refuses(self):
  for k,v in [('systemIdentifier','999'),('postmasterStart','123.000'),('databaseOid','999'),('userRelations',1),('namespaces',['public','other'])]:
   i=identity();i[k]=v
   with self.subTest(key=k),self.assertRaises(RuntimeError):m.validate_identity(i,identity())
 def test_exact_json_and_rollback_tags(self):
  m.verify_smoke_output(smoke(),'')
  for out in [smoke().replace('ROLLBACK','COMMIT'),smoke().replace('ROLLBACK\n',''),smoke()+'extra\n',smoke().replace('true','1'),smoke().replace('passed','unknown')]:
   with self.assertRaises(RuntimeError):m.verify_smoke_output(out,'')
  with self.assertRaises(RuntimeError):m.verify_smoke_output(smoke(),'warning')
 def test_raw_boolean_and_multiple_json_refuse(self):
  for out in ['t\n','{}\n{}\n','']:
   with self.assertRaises(RuntimeError):m.parse_json(out)
 def test_success_requires_three_backend_observations(self):
  code,r,_=self.run_case();self.assertEqual(code,0);self.assertTrue(r['rollbackWitnessed']);self.assertTrue(r['backendAbsenceVerified']);self.assertTrue(r['smokePassed']);self.assertEqual(len(r['backendSettlement']),3);self.assertFalse(r['fullTrialPassed'])
 def test_unique_startup_tags_env_and_receipt_precede_wait(self):
  tags=[]
  def hook(r,args,kw):
   saved=json.loads(r.path.read_text());tag=kw['env']['PGAPPNAME'];self.assertEqual(saved['calls'][-1]['applicationName'],tag);tags.append(tag)
   self.assertNotIn('PGSERVICE',kw['env']);self.assertEqual(kw['env']['PGHOST'],'localhost');self.assertNotIn('bogus',kw['env']['PGOPTIONS']);self.assertNotIn('fixture-only',str(args));self.assertNotIn('fixture-only',r.path.read_text());self.assertLessEqual(kw['timeout'],35)
   return self.fake(args,**kw)
  with patch.dict(os.environ,{'PGSERVICE':'bad','PGOPTIONS':'-c bogus=1','PGHOST':'remote'}):self.assertEqual(self.run_case(hook)[0],0)
  self.assertEqual(len(tags),len(set(tags)))
 def test_timeout_retains_partial_output_without_rollback_claim(self):
  def hook(r,args,kw):
   if kw['input'].startswith('-- PROPOSED'):raise subprocess.TimeoutExpired(args,35,output=b'BEGIN\n',stderr=b'partial')
   return self.fake(args,**kw)
  code,r,files=self.run_case(hook);self.assertEqual(code,1);self.assertFalse(r['rollbackWitnessed']);self.assertFalse(r['smokePassed']);c=next(c for c in r['calls'] if c['kind']=='approved_smoke');self.assertTrue(c['backendGoneVerified']);self.assertEqual(files[c['file']+'.stdout'],b'BEGIN\n')
 def test_surviving_backend_prevents_success_even_after_rollback(self):
  def hook(r,args,kw):
   if "'backends'" in kw['input']:
    tag=kw['input'].split('application_name=')[1].split("'")[1];call=next(c for c in r.value['calls'] if c['applicationName']==tag)
    if call['kind']=='approved_smoke':return result(json.dumps(monitor([dict(pid=42,database=m.BASE,login=m.USER,applicationName=tag)]))+'\n')
   return self.fake(args,**kw)
  code,r,_=self.run_case(hook);self.assertEqual(code,1);self.assertTrue(r['rollbackWitnessed']);self.assertFalse(r['backendAbsenceVerified']);self.assertTrue(r['cleanupFailures']);self.assertEqual(len([x for x in r['backendSettlement'] if x['targetApplicationName']==next(c['applicationName'] for c in r['calls'] if c['kind']=='approved_smoke')]),1)
 def test_late_exit_observed_before_final_identity(self):
  seen=[]
  def hook(r,args,kw):
   if "'backends'" in kw['input']:
    tag=kw['input'].split('application_name=')[1].split("'")[1]
    if tag not in seen:
     seen.append(tag);return result(json.dumps(monitor([dict(pid=42,database=m.BASE,login=m.USER,applicationName=tag)]))+'\n')
   return self.fake(args,**kw)
  code,r,_=self.run_case(hook);self.assertEqual(code,0);self.assertTrue(all(len(x['samples'])==2 for x in r['backendSettlement']))
 def test_monitor_timeout_retains_primary_and_cleanup_failures(self):
  def hook(r,args,kw):
   if "'backends'" in kw['input']:raise subprocess.TimeoutExpired(args,kw['timeout'])
   return self.fake(args,**kw)
  code,r,_=self.run_case(hook);self.assertEqual(code,1);self.assertTrue(r['primaryFailure']);self.assertTrue(r['cleanupFailures']);self.assertFalse(r['backendAbsenceVerified'])
 def test_unknown_startup_cannot_invent_identity(self):
  def hook(r,args,kw):
   if kw['input']==m.IDENTITY:raise OSError('do not leak environment')
   return self.fake(args,**kw)
  code,r,_=self.run_case(hook);self.assertEqual(code,1);self.assertNotIn('initialIdentity',r);self.assertFalse(r['backendAbsenceVerified']);self.assertTrue(r['cleanupFailures'])
 def test_sql_error_is_not_success_or_rollback(self):
  def hook(r,args,kw):return result('BEGIN\n','ERROR: 42601 syntax error',3) if kw['input'].startswith('-- PROPOSED') else self.fake(args,**kw)
  code,r,_=self.run_case(hook);self.assertEqual(code,1);self.assertFalse(r['rollbackWitnessed']);self.assertFalse(r['smokePassed'])
 def test_monitor_identity_visibility_and_ownership_refuse(self):
  for k,v in [('database','postgres'),('login','other'),('superuser',False),('systemIdentifier','other'),('backends',None),('backends',[dict(pid=1,database='wrong',login=m.USER,applicationName='forge-fingerprint-'+'a'*32)])]:
   with tempfile.TemporaryDirectory() as d:
    r=m.Receipt(Path(d)/'new/fingerprint-smoke.json');target=dict(applicationName='forge-fingerprint-'+'a'*32,database=m.BASE,login=m.USER);response=monitor();response[k]=v
    fake=lambda *a,**kw:result(json.dumps(response)+'\n')
    with self.subTest(key=k),self.assertRaises(RuntimeError):m.Runner(r,fake).settle(target,identity())
 def test_smoke_bytes_unchanged(self):
  seen=[]
  def hook(r,args,kw):
   if kw['input'].startswith('-- PROPOSED'):seen.append(kw['input'].encode())
   return self.fake(args,**kw)
  self.assertEqual(self.run_case(hook)[0],0);self.assertEqual(seen,[(m.ROOT/'source6/fingerprint-smoke.sql').read_bytes()])
 def test_portable_sequence_projection_and_table_parity(self):
  sql=source6.fingerprint_query('public','x','S');self.assertNotIn('to_jsonb(x)',sql)
  for f in ['last_value','log_cnt','is_called']:self.assertEqual(sql.count("'"+f+"',x."+f),2)
  self.assertIn('to_jsonb(x)',source6.fingerprint_query('public','x','r'));self.assertEqual(source6.fingerprint_query('public','x','r'),source6.fingerprint_query('public','x','p'))
  with self.assertRaises(RuntimeError):source6.fingerprint_query('public','x','v')
 def test_no_backend_termination_or_full_trial(self):
  s=Path(m.__file__).read_text()
  for forbidden in ['pg_terminate_backend','pg_cancel_backend','CREATE DATABASE','execute-fixture']:self.assertNotIn(forbidden,s)
 def test_real_child_stdout_retained_and_parsed(self):
  with tempfile.TemporaryDirectory() as d:
   r=m.Receipt(Path(d)/'new/fingerprint-smoke.json')
   def child(args,**kw):return subprocess.run([sys.executable,'-c','import sys;sys.stdout.write('+repr(smoke())+')'],**kw)
   out,err,call=m.Runner(r,child).call('select 1;','raw_child_control')
   m.verify_smoke_output(out,err);self.assertEqual((r.path.parent/(call['file']+'.stdout')).read_text(),smoke());self.assertFalse(call['backendGoneVerified'])
 def test_real_child_timeout_keeps_partial_stdout(self):
  with tempfile.TemporaryDirectory() as d:
   r=m.Receipt(Path(d)/'new/fingerprint-smoke.json')
   def child(args,**kw):return subprocess.run([sys.executable,'-c','import time;print("partial",flush=True);time.sleep(2)'],**kw)
   with self.assertRaisesRegex(RuntimeError,'backend outcome unknown'):m.Runner(r,child).call('select 1;','raw_timeout_control',.1)
   self.assertEqual((r.path.parent/'call-000.stdout').read_text(),'partial\n');self.assertFalse(r.value['calls'][0]['backendGoneVerified'])
 def test_cancelled_smoke_is_failed_even_if_backend_later_gone(self):
  def hook(r,args,kw):
   if kw['input'].startswith('-- PROPOSED'):raise KeyboardInterrupt()
   return self.fake(args,**kw)
  code,r,_=self.run_case(hook);self.assertEqual(code,1);self.assertEqual(r['primaryFailure']['type'],'KeyboardInterrupt');self.assertFalse(r['rollbackWitnessed']);self.assertFalse(r['smokePassed'])
if __name__=='__main__':unittest.main(verbosity=2)
