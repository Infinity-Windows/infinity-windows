#!/usr/bin/env python3
"""Finite isolated fixture runner. Default/check-plan do not contact PostgreSQL."""
import argparse,hashlib,importlib.util,json,os,re,signal,subprocess,sys,time,uuid
from pathlib import Path
from urllib.parse import urlparse
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
BASE='forge_work_activity_role_test'
USER='supabase_admin'
SQL_SHA='83b59302ba1e59a6bde70be792c697b14d063ea681dbbcf8d5c619d0f0086df8'
PINS={
 'source6/combined_executor.py':'c78537359f30e6ccf92885e763ff11b1f9c38003c1e7bae1f8b46bba8b26532d',
 'source6/build_fingerprint_smoke.py':'b8e921fe7f03234560577964a2b145ca9d85feaade7d5c0335c8e98fc98baf1e',
 'source6/fingerprint-smoke.sql':SQL_SHA,
}
EXPECTED_RESULT={'queryShapeChecks':'passed','oldQuery42809Observed':True,'combinedTrialPassed':False,'rollbackCompleted':False}
TAGS=['BEGIN']+['SET']*5+['DO','CREATE TABLE','INSERT 0 3','CREATE TABLE','CREATE TABLE','CREATE TABLE','INSERT 0 3','CREATE SEQUENCE','DO']
IDENTITY="""select jsonb_build_object(
 'systemIdentifier',(select system_identifier::text from pg_control_system()),
 'postmasterStart',extract(epoch from pg_postmaster_start_time())::text,
 'databaseOid',(select oid::text from pg_database where datname=current_database()),
 'database',current_database(),'sessionUser',session_user,'currentUser',current_user,
 'serverVersion',current_setting('server_version_num'),'timezone',current_setting('TimeZone'),
 'floatDigits',current_setting('extra_float_digits'),'isolation',current_setting('transaction_isolation'),
 'statementTimeout',current_setting('statement_timeout'),'lockTimeout',current_setting('lock_timeout'),
 'superuser',(select rolsuper from pg_roles where rolname=current_user),'inRecovery',pg_is_in_recovery(),
 'databases',(select jsonb_agg(datname order by datname) from pg_database),
 'namespaces',(select jsonb_agg(nspname order by nspname) from pg_namespace),
 'userRelations',(select count(*) from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname not like 'pg_%' and n.nspname<>'information_schema'));
"""
def require(ok,message):
 if not ok:raise RuntimeError(message)
def digest(data):return hashlib.sha256(data).hexdigest()
def sha(path):return digest(Path(path).read_bytes())
def q(value):return "'"+value.replace("'","''")+"'"
def failure(error):return {'type':type(error).__name__,'message':str(error) if isinstance(error,RuntimeError) else type(error).__name__}
def validate_source():
 pins=json.loads((ROOT/'source-pins.json').read_text());require(pins['files']==PINS,'Input pin inventory differs')
 for name,want in PINS.items():require(sha(ROOT/name)==want,'Pinned source drift: '+name)
 return {'files':PINS,'sqlSha256':SQL_SHA,'source6Manifest':pins['source6Manifest']}
def validate_target(raw):
 try:t=urlparse(raw);port=t.port
 except ValueError:raise RuntimeError('Malformed disposable target') from None
 require(t.scheme in ('postgresql','postgres') and t.hostname=='localhost' and port==5432 and t.username==USER and t.password=='fixture-only' and t.path=='/'+BASE and not t.query and not t.fragment and not t.params,'Exact isolated localhost fixture target required')
def validate_identity(value,baseline=None,initial=False):
 require(type(value) is dict,'Identity unavailable')
 expected={'database':BASE,'sessionUser':USER,'currentUser':USER,'timezone':'UTC','floatDigits':'1','isolation':'read committed','statementTimeout':'20s','lockTimeout':'12s','superuser':True,'inRecovery':False,'userRelations':0}
 for key,want in expected.items():require(type(value.get(key)) is type(want) and value[key]==want,'Identity mismatch: '+key)
 require(type(value.get('serverVersion')) is str and re.fullmatch(r'17\d{4}',value['serverVersion']) is not None,'PG17 required')
 for key in ['systemIdentifier','databaseOid']:require(type(value.get(key)) is str and value[key].isdigit() and int(value[key])>0,'Missing identity: '+key)
 require(type(value.get('postmasterStart')) is str and re.fullmatch(r'\d+\.\d+',value['postmasterStart']) is not None,'Missing postmaster identity')
 require(value.get('databases')==sorted([BASE,'postgres','template0','template1']),'Unexpected databases in isolated service')
 ns=value.get('namespaces');require(type(ns) is list and all(type(x) is str for x in ns),'Namespace inventory unavailable')
 expected_ns=['information_schema','pg_catalog','pg_toast','public']
 require(sorted(x for x in ns if not re.fullmatch(r'pg_(?:toast_)?temp_\d+',x))==expected_ns,'Unexpected persistent namespace')
 if initial:require(sorted(ns)==expected_ns,'Smoke must start in an unused isolated service')
 if baseline:
  require(all(value[k]==baseline[k] for k in ['systemIdentifier','postmasterStart','databaseOid','database','serverVersion','databases']),'Server/database identity changed')
 return value

def parse_json(stdout):
 lines=stdout.splitlines();require(len(lines)==1,'Exactly one JSON identity/monitor response required')
 try:return json.loads(lines[0])
 except ValueError:raise RuntimeError('Malformed JSON response') from None

def verify_smoke_output(stdout,stderr):
 require(stderr=='','Unexpected smoke stderr')
 lines=stdout.splitlines();require(len(lines)==len(TAGS)+2 and lines[:len(TAGS)]==TAGS and lines[-1]=='ROLLBACK','Complete expected command tags and terminal ROLLBACK required')
 try:got=json.loads(lines[-2])
 except ValueError:raise RuntimeError('Malformed smoke JSON') from None
 require(type(got) is dict and set(got)==set(EXPECTED_RESULT) and all(type(got[k]) is type(v) and got[k]==v for k,v in EXPECTED_RESULT.items()),'Exact smoke result required')
 return got

class Receipt:
 def __init__(self,path):
  self.path=Path(path);require(self.path.is_absolute() and self.path.name=='fingerprint-smoke.json' and not self.path.parent.exists(),'New absolute output directory required')
  require(ROOT not in self.path.parents,'Runtime output cannot be inside source package')
  self.path.parent.mkdir(parents=True)
  self.value={'status':'running','stage':'before_source_target_contact','databaseContacted':False,'sqlExecuted':False,'calls':[],'backendSettlement':[],'cleanupFailures':[],'primaryFailure':None,'rollbackWitnessed':False,'backendAbsenceVerified':False,'smokePassed':False,'fullTrialPassed':False,'providerVerified':False,'productionActivation':False,'persistentNamespaceRestorationClaimed':False,'runnerSha256':sha(__file__)};self.persist()
 def persist(self,stage=None):
  if stage:self.value['stage']=stage
  tmp=self.path.with_suffix('.tmp');tmp.write_text(json.dumps(self.value,indent=2)+'\n');tmp.replace(self.path)

class Runner:
 def __init__(self,receipt,execute=subprocess.run,clock=time.monotonic,sleep=time.sleep):
  self.r=receipt;self.execute=execute;self.clock=clock;self.sleep=sleep
 def call(self,sql,kind,budget=35,monitor=False):
  require(0<budget<=35 and (not monitor or budget<=5),'Invalid process budget')
  tag='forge-fingerprint-'+uuid.uuid4().hex;stem=self.r.path.parent/f'call-{len(self.r.value["calls"]):03d}'
  stem.with_suffix('.sql').write_bytes(sql.encode())
  call={'kind':kind,'applicationName':tag,'database':BASE,'login':USER,'status':'waiting','file':stem.name,'sqlSha256':digest(sql.encode()),'budgetSeconds':budget,'backendGoneVerified':False,'monitor':monitor};self.r.value['calls'].append(call)
  env={k:v for k,v in os.environ.items() if not k.startswith('PG')}
  env.update(PGHOST='localhost',PGPORT='5432',PGDATABASE=BASE,PGUSER=USER,PGPASSWORD='fixture-only',PGAPPNAME=tag,PGCONNECT_TIMEOUT='3',PGOPTIONS='-c timezone=UTC -c extra_float_digits=1 -c statement_timeout=20s -c lock_timeout=12s')
  if monitor:env['PGOPTIONS']='-c timezone=UTC -c extra_float_digits=1 -c statement_timeout='+str(max(1,min(2000,int(budget*1000))))+'ms -c lock_timeout=2s'
  self.r.value['databaseContacted']=True;self.r.persist('before_psql_wait')
  args=['psql','-X','-A','-t','-v','ON_ERROR_STOP=1','-v','VERBOSITY=verbose']
  start=self.clock()
  try:
   result=self.execute(args,input=sql,text=True,capture_output=True,timeout=budget,env=env)
   stem.with_suffix('.stdout').write_text(result.stdout);stem.with_suffix('.stderr').write_text(result.stderr)
   call.update(status='returned',returnCode=result.returncode,stdoutSha256=digest(result.stdout.encode()),stderrSha256=digest(result.stderr.encode()))
   require(result.returncode==0,'psql did not complete successfully; inspect retained stderr')
   return result.stdout,result.stderr,call
  except subprocess.TimeoutExpired as error:
   call['status']='process_timeout'
   for ext,data in [('stdout',error.stdout),('stderr',error.stderr)]:stem.with_suffix('.'+ext).write_bytes(data.encode() if isinstance(data,str) else data or b'')
   raise RuntimeError('psql process deadline expired; backend outcome unknown') from None
  except BaseException as error:
   call['failure']=failure(error)
   if call['status']=='waiting':call['status']='startup_or_process_unknown'
   raise
  finally:
   call['wallMillisecondsIncludingPsql']=round((self.clock()-start)*1000,3)
   for ext in ['stdout','stderr']:
    f=stem.with_suffix('.'+ext)
    if f.exists():call[ext+'Sha256']=sha(f)
   self.r.persist()
 def settle(self,target,baseline,budget=15):
  require(re.fullmatch(r'forge-fingerprint-[0-9a-f]{32}',target['applicationName']) is not None and target['database']==BASE and target['login']==USER,'Unproven monitoring target')
  require(0<budget<=15,'Invalid settlement budget')
  require(not target.get('settlementAttempted'),'Backend settlement already attempted; no budget reset')
  target['settlementAttempted']=True
  item={'targetApplicationName':target['applicationName'],'status':'waiting','budgetSeconds':budget,'samples':[]};self.r.value['backendSettlement'].append(item);self.r.persist('before_backend_settlement')
  deadline=self.clock()+budget
  try:
   while True:
    remaining=deadline-self.clock();require(remaining>0,'Tagged backend still alive at deadline')
    sql="select jsonb_build_object('systemIdentifier',(select system_identifier::text from pg_control_system()),'postmasterStart',extract(epoch from pg_postmaster_start_time())::text,'databaseOid',(select oid::text from pg_database where datname=current_database()),'database',current_database(),'login',session_user,'role',current_user,'superuser',(select rolsuper from pg_roles where rolname=current_user),'backends',(select coalesce(jsonb_agg(jsonb_build_object('pid',pid,'database',datname,'login',usename,'applicationName',application_name,'state',state,'transactionStart',xact_start::text,'waitEventType',wait_event_type) order by pid),'[]'::jsonb) from pg_stat_activity where application_name="+q(target['applicationName'])+"));\n"
    out,err,monitor=self.call(sql,'monitor:'+target['applicationName'],min(5,remaining),True);require(err=='','Monitor stderr makes outcome unknown');sample=parse_json(out);item['samples'].append(sample);self.r.persist('monitor_sample')
    require(baseline is not None,'Initial server identity unavailable; backend absence unproved')
    require(type(sample) is dict and sample.get('database')==BASE and sample.get('login')==USER and sample.get('role')==USER and sample.get('superuser') is True and all(sample.get(k)==baseline[k] for k in ['systemIdentifier','postmasterStart','databaseOid']),'Monitor identity/visibility unknown')
    rows=sample.get('backends');require(type(rows) is list,'Monitor backend result unknown')
    require(all(type(x) is dict and x.get('database')==BASE and x.get('login')==USER and x.get('applicationName')==target['applicationName'] and type(x.get('pid')) is int for x in rows),'Monitor target ownership unknown')
    require(self.clock()<=deadline,'Monitor exceeded finite settlement budget')
    if not rows:
     item['status']='gone';target['backendGoneVerified']=True;self.r.persist('backend_gone');return
    self.r.persist('before_monitor_pause');self.sleep(min(.25,max(0,deadline-self.clock())))
  except BaseException as error:
   item['status']='unknown_or_alive';item['failure']=failure(error);self.r.persist('backend_settlement_failed');raise

def execute(receipt,runner):
 baseline=None
 try:
  receipt.value['sources']=validate_source();receipt.persist('sources_verified_before_sql')
  validate_target(os.environ.get('FINGERPRINT_SMOKE_DATABASE_URL',''))
  out,err,initial=runner.call(IDENTITY,'initial_identity');require(err=='','Initial identity stderr');baseline=validate_identity(parse_json(out),initial=True);receipt.value['initialIdentity']=baseline;receipt.persist('initial_identity_verified')
  runner.settle(initial,baseline)
  receipt.value['sqlExecuted']=True;receipt.persist('before_approved_smoke')
  out,err,smoke=runner.call((ROOT/'source6/fingerprint-smoke.sql').read_text(),'approved_smoke')
  receipt.value['result']=verify_smoke_output(out,err);receipt.value['rollbackWitnessed']=True;receipt.persist('rollback_command_witnessed')
  runner.settle(smoke,baseline)
  out,err,final=runner.call(IDENTITY,'final_identity');require(err=='','Final identity stderr');receipt.value['finalIdentity']=validate_identity(parse_json(out),baseline);runner.settle(final,baseline)
 except BaseException as error:
  receipt.value['primaryFailure']=failure(error);receipt.persist('primary_failure')
 finally:
  # Never infer backend absence from process status or the fixed statement limits.
  # Read-only monitor failures are retained, never recursively retried/terminated.
  for call in list(receipt.value['calls']):
   if call['monitor'] or call['backendGoneVerified']:continue
   if call.get('settlementAttempted'):
    receipt.value['cleanupFailures'].append({'file':call['file'],'type':'BackendSettlementUnproved','message':'Prior finite settlement failed; no retry or budget reset'});receipt.persist('cleanup_unproved');continue
   try:runner.settle(call,baseline)
   except BaseException as error:receipt.value['cleanupFailures'].append({'file':call['file'],**failure(error)});receipt.persist('cleanup_failed')
  unresolved_monitors=[c['file'] for c in receipt.value['calls'] if c['monitor'] and (c['status']!='returned' or c.get('returnCode')!=0)]
  if unresolved_monitors:receipt.value['cleanupFailures'].append({'type':'MonitorOutcomeUnknown','calls':unresolved_monitors});receipt.persist('monitor_cleanup_unknown')
  receipt.value['backendAbsenceVerified']=bool(baseline) and all(c['backendGoneVerified'] for c in receipt.value['calls'] if not c['monitor']) and not receipt.value['cleanupFailures']
  ok=receipt.value['primaryFailure'] is None and not receipt.value['cleanupFailures'] and receipt.value['rollbackWitnessed'] and receipt.value['backendAbsenceVerified'] and 'finalIdentity' in receipt.value
  receipt.value.update(status='passed' if ok else 'failed',smokePassed=ok);receipt.persist('complete' if ok else 'failed')
 return 0 if ok else 1

def main(argv=None):
 p=argparse.ArgumentParser();g=p.add_mutually_exclusive_group();g.add_argument('--check-plan',action='store_true');g.add_argument('--execute-smoke',action='store_true');p.add_argument('--output');args=p.parse_args(argv)
 if not args.execute_smoke:
  require(args.output is None,'Output is execution-only');sources=validate_source();print(json.dumps({'status':'plan','databaseContacted':False,'sources':sources,'service':'new isolated PG17 only','processSeconds':35,'settlementSeconds':15,'fullTrial':False},indent=2));return 0
 require(args.output is not None,'Execution requires a new output path');receipt=Receipt(args.output)
 return execute(receipt,Runner(receipt))
if __name__=='__main__':
 def interrupted(signum,frame):raise RuntimeError('Runner interrupted; backend outcome requires settlement')
 signal.signal(signal.SIGTERM,interrupted)
 try:raise SystemExit(main())
 except RuntimeError as error:print(str(error),file=sys.stderr);raise SystemExit(1)
