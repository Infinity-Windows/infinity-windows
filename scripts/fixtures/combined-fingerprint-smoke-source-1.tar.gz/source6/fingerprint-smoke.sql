-- PROPOSED genuine PG17 query-shape smoke; not executed by source checks.
-- Run only in the fresh allowlisted disposable service before expensive prerequisites.
-- All writes are to newly created temporary objects, including nextval below.
\set ON_ERROR_STOP on
\set VERBOSITY verbose
begin;
set local statement_timeout='20s';
set local lock_timeout='12s';
set local timezone='UTC';
set local extra_float_digits=1;
set local search_path=pg_temp,pg_catalog;
do $preflight$
begin
 if current_setting('server_version_num')::int not between 170000 and 179999
    or current_database()<>'forge_work_activity_role_test'
    or session_user<>'supabase_admin' or current_user<>'supabase_admin' then
  raise exception 'Exact disposable PG17 fingerprint smoke scope required';
 end if;
end $preflight$;
create temporary table fingerprint_rows(id bigint, value text);
insert into fingerprint_rows values(1,'alpha'),(2,null),(2,null);
create temporary table fingerprint_empty(id bigint, value text);
create temporary table fingerprint_partitioned(id bigint, value text) partition by range(id);
create temporary table fingerprint_leaf partition of fingerprint_partitioned for values from (0) to (10);
insert into fingerprint_partitioned select * from fingerprint_rows;
create temporary sequence fingerprint_sequence as bigint start with 9007199254740993 cache 1;
do $smoke$
declare got jsonb; want jsonb; before_state jsonb; after_state jsonb; initial_hash text; old_refused boolean:=false; state text; message text;
begin
 -- Actual old-query counterexample; no simulated PostgreSQL response.
 begin
  execute 'select jsonb_build_object(''count'',count(*),''sha256'',encode(sha256(convert_to(coalesce(jsonb_agg(to_jsonb(x) order by to_jsonb(x)::text),''[]''::jsonb)::text,''UTF8'')),''hex'')) from "pg_temp"."fingerprint_sequence" x' into got;
 exception when sqlstate '42809' then
  get stacked diagnostics state=returned_sqlstate,message=message_text;
  if message<>'relation "fingerprint_sequence" does not have a composite type' then raise; end if;
  old_refused:=true;
 end;
 if not old_refused then raise exception 'Old sequence whole-row counterexample unexpectedly succeeded'; end if;
 execute 'select jsonb_build_object(''count'',count(*),''sha256'',encode(sha256(convert_to(coalesce(jsonb_agg(to_jsonb(x) order by to_jsonb(x)::text),''[]''::jsonb)::text,''UTF8'')),''hex'')) from "pg_temp"."fingerprint_rows" x' into got;
 want:=jsonb_build_object('count',3,'sha256',encode(sha256(convert_to('[{"id":1,"value":"alpha"},{"id":2,"value":null},{"id":2,"value":null}]'::jsonb::text,'UTF8')),'hex'));
 if got is distinct from want then raise exception 'Table duplicate/null fingerprint mismatch: %',got; end if;
 execute 'select jsonb_build_object(''count'',count(*),''sha256'',encode(sha256(convert_to(coalesce(jsonb_agg(to_jsonb(x) order by to_jsonb(x)::text),''[]''::jsonb)::text,''UTF8'')),''hex'')) from "pg_temp"."fingerprint_partitioned" x' into got;
 if got is distinct from want then raise exception 'Partitioned table fingerprint mismatch'; end if;
 execute 'select jsonb_build_object(''count'',count(*),''sha256'',encode(sha256(convert_to(coalesce(jsonb_agg(to_jsonb(x) order by to_jsonb(x)::text),''[]''::jsonb)::text,''UTF8'')),''hex'')) from "pg_temp"."fingerprint_empty" x' into got;
 want:=jsonb_build_object('count',0,'sha256',encode(sha256(convert_to('[]','UTF8')),'hex'));
 if got is distinct from want then raise exception 'Empty fingerprint mismatch'; end if;
 select jsonb_build_object('last_value',last_value,'log_cnt',log_cnt,'is_called',is_called) into before_state from pg_temp.fingerprint_sequence;
 if before_state is distinct from '{"last_value":9007199254740993,"log_cnt":0,"is_called":false}'::jsonb then raise exception 'Unexpected initial sequence state'; end if;
 execute 'select jsonb_build_object(''count'',count(*),''sha256'',encode(sha256(convert_to(coalesce(jsonb_agg(jsonb_build_object(''last_value'',x.last_value,''log_cnt'',x.log_cnt,''is_called'',x.is_called) order by jsonb_build_object(''last_value'',x.last_value,''log_cnt'',x.log_cnt,''is_called'',x.is_called)::text),''[]''::jsonb)::text,''UTF8'')),''hex'')) from "pg_temp"."fingerprint_sequence" x' into got;
 want:=jsonb_build_object('count',1,'sha256',encode(sha256(convert_to('[{"last_value":9007199254740993,"log_cnt":0,"is_called":false}]'::jsonb::text,'UTF8')),'hex'));
 if got is distinct from want then raise exception 'Initial sequence fingerprint mismatch'; end if;
 initial_hash:=got->>'sha256';
 select jsonb_build_object('last_value',last_value,'log_cnt',log_cnt,'is_called',is_called) into after_state from pg_temp.fingerprint_sequence;
 if before_state is distinct from after_state then raise exception 'Fingerprint changed sequence state'; end if;
 -- Deliberate mutation only of this transaction-created temporary sequence.
 perform nextval('pg_temp.fingerprint_sequence');
 select jsonb_build_object('last_value',last_value,'log_cnt',log_cnt,'is_called',is_called) into before_state from pg_temp.fingerprint_sequence;
 if before_state->>'is_called'<>'true' then raise exception 'Temporary sequence not advanced'; end if;
 execute 'select jsonb_build_object(''count'',count(*),''sha256'',encode(sha256(convert_to(coalesce(jsonb_agg(jsonb_build_object(''last_value'',x.last_value,''log_cnt'',x.log_cnt,''is_called'',x.is_called) order by jsonb_build_object(''last_value'',x.last_value,''log_cnt'',x.log_cnt,''is_called'',x.is_called)::text),''[]''::jsonb)::text,''UTF8'')),''hex'')) from "pg_temp"."fingerprint_sequence" x' into got;
 want:=jsonb_build_object('count',1,'sha256',encode(sha256(convert_to(jsonb_build_array(before_state)::text,'UTF8')),'hex'));
 if got is distinct from want or got->>'sha256'=initial_hash then raise exception 'Called sequence fingerprint mismatch'; end if;
 select jsonb_build_object('last_value',last_value,'log_cnt',log_cnt,'is_called',is_called) into after_state from pg_temp.fingerprint_sequence;
 if before_state is distinct from after_state then raise exception 'Called sequence read changed state'; end if;
end $smoke$;
select jsonb_build_object('queryShapeChecks','passed','oldQuery42809Observed',true,'combinedTrialPassed',false,'rollbackCompleted',false);
-- Successful psql completion must include ROLLBACK. Do not claim this undoes
-- sequence changes generally: the sequence was newly created and temporary.
rollback;
