#!/usr/bin/env python3
"""Generate SQL only. No database imports, process calls or database contact."""
import sys
from pathlib import Path
import combined_executor as e

def build():
 old=e.fingerprint_query('pg_temp','fingerprint_sequence','r')
 queries={name:e.fingerprint_query('pg_temp',name,kind) for name,kind in [('fingerprint_rows','r'),('fingerprint_empty','r'),('fingerprint_partitioned','p'),('fingerprint_sequence','S')]}
 sql="""-- PROPOSED genuine PG17 query-shape smoke; not executed by source checks.
-- Run only in the fresh allowlisted disposable service before expensive prerequisites.
-- All writes are to newly created temporary objects, including nextval below.
\\set ON_ERROR_STOP on
\\set VERBOSITY verbose
begin;
set local statement_timeout='20s';
set local lock_timeout='12s';
set local timezone='UTC';
set local extra_float_digits=1;
set local search_path=pg_temp,pg_catalog;
do $preflight$
begin
 if current_setting('server_version_num')::int not between 170000 and 179999
    or current_database()<>'forge_work_activity_role_test'
    or session_user<>'supabase_admin' or current_user<>'supabase_admin' then
  raise exception 'Exact disposable PG17 fingerprint smoke scope required';
 end if;
end $preflight$;
create temporary table fingerprint_rows(id bigint, value text);
insert into fingerprint_rows values(1,'alpha'),(2,null),(2,null);
create temporary table fingerprint_empty(id bigint, value text);
create temporary table fingerprint_partitioned(id bigint, value text) partition by range(id);
create temporary table fingerprint_leaf partition of fingerprint_partitioned for values from (0) to (10);
insert into fingerprint_partitioned select * from fingerprint_rows;
create temporary sequence fingerprint_sequence as bigint start with 9007199254740993 cache 1;
do $smoke$
declare got jsonb; want jsonb; before_state jsonb; after_state jsonb; initial_hash text; old_refused boolean:=false; state text; message text;
begin
 -- Actual old-query counterexample; no simulated PostgreSQL response.
 begin
  execute __OLD__ into got;
 exception when sqlstate '42809' then
  get stacked diagnostics state=returned_sqlstate,message=message_text;
  if message<>'relation "fingerprint_sequence" does not have a composite type' then raise; end if;
  old_refused:=true;
 end;
 if not old_refused then raise exception 'Old sequence whole-row counterexample unexpectedly succeeded'; end if;
 execute __ROWS__ into got;
 want:=jsonb_build_object('count',3,'sha256',encode(sha256(convert_to('[{"id":1,"value":"alpha"},{"id":2,"value":null},{"id":2,"value":null}]'::jsonb::text,'UTF8')),'hex'));
 if got is distinct from want then raise exception 'Table duplicate/null fingerprint mismatch: %',got; end if;
 execute __PARTITIONED__ into got;
 if got is distinct from want then raise exception 'Partitioned table fingerprint mismatch'; end if;
 execute __EMPTY__ into got;
 want:=jsonb_build_object('count',0,'sha256',encode(sha256(convert_to('[]','UTF8')),'hex'));
 if got is distinct from want then raise exception 'Empty fingerprint mismatch'; end if;
 select jsonb_build_object('last_value',last_value,'log_cnt',log_cnt,'is_called',is_called) into before_state from pg_temp.fingerprint_sequence;
 if before_state is distinct from '{"last_value":9007199254740993,"log_cnt":0,"is_called":false}'::jsonb then raise exception 'Unexpected initial sequence state'; end if;
 execute __SEQUENCE__ into got;
 want:=jsonb_build_object('count',1,'sha256',encode(sha256(convert_to('[{"last_value":9007199254740993,"log_cnt":0,"is_called":false}]'::jsonb::text,'UTF8')),'hex'));
 if got is distinct from want then raise exception 'Initial sequence fingerprint mismatch'; end if;
 initial_hash:=got->>'sha256';
 select jsonb_build_object('last_value',last_value,'log_cnt',log_cnt,'is_called',is_called) into after_state from pg_temp.fingerprint_sequence;
 if before_state is distinct from after_state then raise exception 'Fingerprint changed sequence state'; end if;
 -- Deliberate mutation only of this transaction-created temporary sequence.
 perform nextval('pg_temp.fingerprint_sequence');
 select jsonb_build_object('last_value',last_value,'log_cnt',log_cnt,'is_called',is_called) into before_state from pg_temp.fingerprint_sequence;
 if before_state->>'is_called'<>'true' then raise exception 'Temporary sequence not advanced'; end if;
 execute __SEQUENCE__ into got;
 want:=jsonb_build_object('count',1,'sha256',encode(sha256(convert_to(jsonb_build_array(before_state)::text,'UTF8')),'hex'));
 if got is distinct from want or got->>'sha256'=initial_hash then raise exception 'Called sequence fingerprint mismatch'; end if;
 select jsonb_build_object('last_value',last_value,'log_cnt',log_cnt,'is_called',is_called) into after_state from pg_temp.fingerprint_sequence;
 if before_state is distinct from after_state then raise exception 'Called sequence read changed state'; end if;
end $smoke$;
select jsonb_build_object('queryShapeChecks','passed','oldQuery42809Observed',true,'combinedTrialPassed',false,'rollbackCompleted',false);
-- Successful psql completion must include ROLLBACK. Do not claim this undoes
-- sequence changes generally: the sequence was newly created and temporary.
rollback;
"""
 for marker,query in [('__OLD__',old),('__ROWS__',queries['fingerprint_rows']),('__EMPTY__',queries['fingerprint_empty']),('__PARTITIONED__',queries['fingerprint_partitioned']),('__SEQUENCE__',queries['fingerprint_sequence'])]:sql=sql.replace(marker,e.q(query))
 return sql

if __name__=='__main__':
 if len(sys.argv)!=2:raise SystemExit('Usage: build_fingerprint_smoke.py NEW_OUTPUT.sql (generation only)')
 with Path(sys.argv[1]).open('x') as f:f.write(build())
