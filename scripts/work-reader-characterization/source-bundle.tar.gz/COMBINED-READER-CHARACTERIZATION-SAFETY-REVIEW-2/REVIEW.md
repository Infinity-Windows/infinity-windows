# Independent reader characterization safety review 2

Decision: REQUIRED FIXES, not dispatch approval. Source2 closes the five reproduced Source1 failures and substantially implements R1-R6, but still has evidence-to-conclusion and evidence-accounting gaps. Method approval remains: a bounded fresh paired characterization is defensible; historical reproduction, full trial acceptance and restoration remain unproved. Four pending ROOT_MUST_PIN values are expected root work, not defects.

43/43 Source2 offline controls pass. Independent counterexamples and actual source6 Runner wire controls were run with process/network entry points denied and all filesystem output confined to this review directory. No database, browser, install, build, CI, git, network or external process was invoked by reviewed code. Source2 and all source inputs remain unchanged.

## R1-R6 closure assessment

| Requirement | Result |
|---|---|
| R1 earliest fail-close | Closed for the supplied evidence failures: pre-round mismatch executes0, first malformed sample executes1, post-round mismatches stop at8/16, settings and completed-pair wait mismatches halt promptly. |
| R2 global validity | Original false-valid bugs closed. Missing NOTICE, unclassified B-only failure and final-witness loss now make the whole result inconclusive and suppress aggregate. Paired-scope causal conclusions still need correction F1. |
| R3 NOTICE correctness | Closed at source/offline level: successful copy requires20 exact descriptors, cancellations require a nonempty exact prefix, timestamps/order/functions and both wire hashes checked. Raw error retained, cancellation remains censored. Actual PG17 NOTICE transport remains unexecuted. |
| R4 witness integrity | Raw planner rows now retained; malformed sample/physical fields and identity mismatch controls reject. Zero total sampling attempts remain accepted (F2), distinct from legitimate empty-backend samples. |
| R5 accounting | 9/11/4/3 payload counts corrected and verified through unchanged Runner. Missing auxiliary evidence and lack of ledger reconciliation remain (F3). |
| R6 fresh fixture contract | Historical hashes recorded rather than gated; all original relation counts/inventory conservatively gated; mutual raw equality and authority context preserved. Exact treatment inventory derivable, but current gate permits unexpected extras (F4). |

## Required changes

### F1 — Invalidate causal paired conclusions when final integrity is unknown

Source2 lines553-572 derive paired_ok from16 outcomes, three checkpoint labels and stop phase; final_reasons are not consulted. A run with both-round A1000/B1500 and final `persistent_state_changed_by_reads:B` returns whole=inconclusive but pairedScope totals conclusion=`bounded_candidate_dependent_timing_signal_not_universal_regression`. The same occurs for `global_roles_or_settings_changed`. Both are reproduced in OFFLINE-COUNTEREXAMPLES.json.

A physical/checkpoint sample does not prove row equality remained valid throughout both rounds. An end-of-run changed row/settings receipt cannot establish when the drift began. Merely placing the same causal conclusion under pairedScope does not restore its premises.

Required: centralize evidence validity and claim eligibility. Preserve raw partial timings and numeric observations after failures, but withhold candidate-dependent/inherited/no-demonstrated-regression conclusions wherever relevant final data/global/session/settlement/inventory/accounting evidence is missing or changed. The simplest safe correction suppresses interpreted pairedScope whenever final integrity is unresolved. If retaining interpreted paired scope after a strictly B-only instrumentation failure, explicitly require the independent final data/global/identity/evidence invariants to remain valid and prove the failure could not affect paired evidence. Acceptance: injected persistent/global drift, final inspection failure and missing relevant audit evidence must retain raw measurements with a withheld conclusion, never a bounded candidate signal.

### F2 — Distinguish zero attempted samples from explicit empty samples

Source2 execute489 defaults samples to[], validates the empty loop at505, and wait_profile emits a coverage caveat without refusing. Independent FakeIO with samples=[] for every call runs all20 and returns valid. The real adapter773 also converts a missing sampler into[]; a thread scheduled only after stop is set can exit without an attempt. That is no observation evidence, not a successful observation that found no backend.

Required: an explicit sampler lifecycle/attempt ledger per measured invocation, with at least one completed, schema-valid sample attempt or an inconclusive evidence result. Reconcile returned sample records to captured SQL/stdout/stderr files and count; never substitute[] for missing sampler state. Keep explicit valid samples whose backends=[] legitimate, including short calls and zero active hits. Do not demand active-backend evidence for every sub250ms read. Acceptance: absent sampler, zero attempts, missing sample files and returned/file count disagreement fail closed at that call; one or more valid empty-backend samples remain supported and caveated. Monitoring stays at most4Hz and the existing finite ceilings remain.

### F3 — Reconcile an explicit IO ledger, not only upper bounds

Source2 account645-670 increments unreadable but only treats missing measured wire as an error. A missing witness wire gives unreadable1/reasons[]; a one-statement witness wire gives reasons[] despite the4-statement contract. An entirely empty call ledger gives reasons[]. Tests currently pass these categories through fake accounting independently of the real call records.

Required: derive expected IO identities from executed records/checkpoints and reconcile them with persisted calls and sample receipts. Enforce exact measured IDs/order/branch/kind count and payload digests; exact witnessed checkpoints that succeeded/failed; required settlement/quiescence receipts per actual invocation; and their per-call ceilings. Refuse missing/unreadable/duplicate/unexpected evidence and wrong auxiliary payload counts. For setup/final SQL, enumerate actual finite calls separately, preserving failed calls and unknown payload counts as evidence loss. Setup refusal and exception paths also need this accounting receipt; current main844-845 exits before accounting.

Keep counts of stored payload statements distinct from statements PostgreSQL actually executed. With ON_ERROR_STOP, a timed-out API never reaches its trailing clock SELECT and a failed compound gate does not reach COMMIT, although the stored input still contains9/11 statements. Current docstring says 'statements psql sends'; those are full payload budgets, not proof every statement was dispatched/executed. Label them precisely and retain execution-tail uncertainty after failure without changing the byte-exact gate.

Verified full payload counts:18×9 API +2×11 gates =184 top-level statements, of which20 are designated measured statements and164 auxiliary. Eight witness invocations carry32 payload statements. At most720 wait-sample invocations carry2160; at most160 quiescence invocations640; at most1280 settlement invocations5120. Setup/final inspection remains separately counted by actual stored calls. Real unchanged Runner integration proved API9/gate11/inspection4/monitor4 and the gate SHA remained a6e7cd11479e38b441b5fabe063470ff9a0ef0fc883db1d14e7d5c6c1d79f986. No actual psql process ran.

### F4 — Close the treatment inventory using the authored17-table delta

Current treatment_gate424-425 checks only presence of the nine metadata names. Passing those names plus `auth.rogue` yields no failure. The combined authored catalog checks all PUBLIC relations/sequences, so this is not evidence that arbitrary extra public tables bypass it; however auth additions are outside that catalog, and the explicit fresh fingerprint gate currently accepts B-only extras.

I derived the expected delta by subtracting frozen genuine baseline inventory from pinned inactive public catalog tables/sequences, then independently compared it with every top-level CREATE TABLE in the pinned inactive SQL. They match exactly:17 public regular tables, no new sequence and no auth relation. Both candidate input hashes match source6 profile pins. See EXPECTED-TREATMENT-INVENTORY.json for schema/name/kind and source line receipts.

The17 tables are the nine `_work_unit_metadata_` tables already in the profile plus `work_cross_job_allocations`, `work_cross_job_bindings`, `work_cross_job_clock_requests`, `work_cross_job_contract`, `work_cross_job_heads`, `work_cross_job_resume`, `work_cross_job_shifts`, `work_cross_job_write_frames`.

Required: freeze schema/name/kind tuples as authored expectations, require exact set equality, retain all actual extras/missing entries in the refusal report, and reject non-authored A-side additions as well. Continue exact catalog/root verification. Do not learn the allowed delta from live B. Acceptance: all17 present passes; each removal, wrong kind, extra public or auth table/sequence fails. The catalog overlap is useful defense in depth, not a reason to weaken either gate.

## Questions resolved without new runtime action

Historical all-count gate: KEEP IT CONSERVATIVE. It is stricter than the six dense count requirement but safe, and the reviewed evidence does not identify a legitimate non-dense count exception. The previous guaranteed historical-hash blocker is gone. A future actual count mismatch must be preserved and diagnosed; do not silently narrow the gate to get a run through. This review does not assert every non-dense count is guaranteed deterministic.

Method: current_fixture_paired_raw_ab_v2 remains appropriate if exact source/fixture lineage, fresh mutual raw equality and valid observed-state gates hold. The raw authority exception is still limited by source6 context comparison, with full rows retained. Unknown original physical/hardware/history, omitted pre-seam fixtures and timing limitations remain machine-readable. The unchanged compound gate, all20/42/65, provider and release holds are intact.

Metadata contract evidence: `freshRawContract` at739-740 is actually the full-row fingerprint entry, not row contents. Its hash evidence is sufficient for the previous review's stated raw-contract-hash condition, but rename the field or record the actual row to avoid implying it contains row data. Candidate semantics remain derived from pinned source/catalog, not the fresh value.

PG17/runtime boundary: generated witness keys match the strict schema; raw pg_stats projections and timestamp representations are consistent with the SQL expressions inspected. The NOTICE wire generation remains mechanically constrained. Source6 Runner prelude and process budgets were checked with injected fake execution. No new guaranteed parser/SQL stop was established by this source review. Actual PG17 type/null behavior, local psql text/localization, NOTICE transport and real sampler scheduling remain unverified, and must be reported as such; no live claim is made. Do not relax schema or parse failures after seeing results.

The statistical comparison remains only a two-round supplementary diagnostic. A fresh exact-gate pass cannot refute the original timeout or satisfy the full acceptance suite. Physical and non-IO wait mismatches remain whole-comparison holds; disk IO stays recorded context. psql elapsed, server-clock envelope and caller wall time remain separate, none pure executor time.

## Evidence and handoff

- OFFLINE-TESTS.txt:43/43 controls passed. Read the entire test file before running; tests use FakeIO/injected sampler callbacks, no DB setup path.
- OFFLINE-COUNTEREXAMPLES.json: prior failures now closed, and new F1/F2/F3/F4 controlled counterexamples.
- ACTUAL-RUNNER-WIRE-CONTROLS.json plus runner-wire/: unchanged source6 Runner.run through source2 CharRunner, using a fake execute callback; actual process/socket calls remained denied.
- EXPECTED-TREATMENT-INVENTORY.json: independently matching pinned candidate DDL/catalog delta.
- SOURCE2-BEFORE.json and SOURCE2-AFTER.json: all seven Source2 files identical throughout review.
- READ-LIST.json and MANIFEST.json: bounded source list and artifact digests.

No source was corrected in this review. Root has chosen a central evidence/claim gate and explicit expected IO ledger for the next correction rather than another independent patch of each symptom. Do not start Source3 until root assigns ownership. Root retains pinning, Fable counts/settings review, packaging and dispatch. Actual Source2 Opus model/receipt participation was reported by root; this review does not independently attest that new receipt. No Claude contact or recursive delegation occurred. Live Codex meter at this review start showed3% used/97% remaining; simultaneous consumption and delayed reporting are outside this review's control.
