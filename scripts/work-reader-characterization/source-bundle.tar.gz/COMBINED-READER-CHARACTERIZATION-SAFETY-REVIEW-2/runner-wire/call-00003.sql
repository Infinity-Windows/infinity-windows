\set VERBOSITY verbose
set statement_timeout='2000ms';set lock_timeout='2000ms';set search_path=public,pg_temp;
select 1;