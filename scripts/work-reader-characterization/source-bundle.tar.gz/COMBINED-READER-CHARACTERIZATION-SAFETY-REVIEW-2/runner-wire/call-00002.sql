\set VERBOSITY verbose
set statement_timeout='20s';set lock_timeout='12s';set search_path=public,pg_temp;
select 1;