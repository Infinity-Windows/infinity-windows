#!/usr/bin/env python3
"""Held current-fixture reader characterization (REVISED-CHARACTERIZATION-PLAN.md,
method current_fixture_paired_raw_ab_v3). SOURCE ONLY.

Default/check-plan mode never contacts a database. Execution requires root pins,
offline controls, peer gates, packaging and explicit dispatch. The method
characterizes a FRESH fixture only: historical whole-row data is not reproduced,
the failed instance is not recreated, and nothing here satisfies the unchanged
full20/42/65, provider or release gates, restores databases, or authorizes a fix.
Unchanged source6 constructors are imported by an explicit pinned path.
"""
import argparse,datetime,hashlib,importlib.util,json,os,platform,re,subprocess,sys,threading,time,uuid
from pathlib import Path,PurePosixPath
from urllib.parse import urlunparse
sys.dont_write_bytecode=True

SOURCE=Path(__file__).resolve().parent
ROOT=SOURCE.parent
PROFILE=SOURCE/'characterization-profile.json'
REPORT_NAME='reader-characterization.json'
PENDING='ROOT_MUST_PIN'
METHOD='current_fixture_paired_raw_ab_v3'

CLONE_A='forge_reader_char_a_common0846'
CLONE_B='forge_reader_char_b_inactive'
CLONES={'A':CLONE_A,'B':CLONE_B}
FORBIDDEN_DATABASES=('forge_combined_inactive_test','forge_combined_active_test','forge_combined_negative_test')

ACTOR='00000000-0000-4000-8000-000000720003'
PROJECT='00000000-0000-4000-8000-000000720011'
UNIT='00000000-0000-4000-8000-000000720030'
MISSING='00000000-0000-4000-8000-000000720031'

API_TYPES=('totals','contributors','review_visible','review_missing')
ROUNDS=((1,('A','B')),(2,('B','A')))
MEASURED_TOTAL=20
PLAN_CEILING=24
RESERVE_USED=0
SAMPLE_INTERVAL_SECONDS=0.25
SAMPLES_PER_STATEMENT=36
SAMPLES_PER_PROCESS=140
SAMPLE_PROCESS_TIMEOUT_SECONDS=2
QUIESCENCE_CHECKS=8
SETTLEMENT_CALLS_MAX=64
RATIO_THRESHOLD=1.25
DELTA_THRESHOLD_MS=250.0
PRIMARY_TIMING='psqlElapsedMs'
GATE_PRELUDE='\\set VERBOSITY verbose\n'
GATE_ASSIGNMENTS=10
MONITOR_PREFIX='forge-charmon-'
TAG_PATTERN=re.compile(r'forge-combined-[0-9a-f]{32}')
PAIRED_CHECKPOINTS=('pre_round1','post_round1','post_round2')
OMITTED_SEAM_HISTORY=('approved-source3 v1-capability-active fixture','approved-source3 v1-capability-closing_only fixture','float0-paid-reader-still-refuses fixture','float0-private-coverage fixture','predecessor 47/66 template workloads after cloning')

# R5: exact emitted top-level SQL statements (psql meta lines excluded).
EMITTED={'apiInvocation':9,'apiAuxiliaryPerInvocation':8,'gateInvocation':11,'gateAuxiliaryPerInvocation':10,
 'runnerInspectionInvocation':4,'runnerMonitorInvocation':4,'waitSampleInvocation':3}
CEILINGS={'measuredApiInvocations':18,'measuredGateInvocations':2,'witnessInvocations':8,'waitSampleInvocationsPerMeasured':SAMPLES_PER_STATEMENT,
 'quiescenceInvocationsPerMeasured':QUIESCENCE_CHECKS,'settlementInvocationsPerMeasured':SETTLEMENT_CALLS_MAX}

class SetupInconclusive(RuntimeError):
 """Setup could not establish the declared current-fixture state. Measurements are refused."""

def require(ok,message):
 if not ok:raise RuntimeError(message)
def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def sha(path):return sha_bytes(Path(path).read_bytes())
def q(v):return 'null' if v is None else "'"+str(v).replace("'","''")+"'"
def encoded(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def is_int(v):return type(v) is int
def is_num(v):return type(v) in (int,float)
def opt_str(v):return v is None or isinstance(v,str)

# ---------------------------------------------------------------- profile/pins

def resolve_input(relative,base=ROOT):
 p=PurePosixPath(relative)
 require(not p.is_absolute() and len(p.parts)>=3 and p.parts[0]=='..' and '..' not in p.parts[1:] and '.' not in p.parts,'Input must be an explicit ../<checkpoint>/<file> path')
 base=Path(base).resolve();joined=base/Path(*p.parts[1:])
 require(joined.is_file() and not joined.is_symlink(),'Pinned input missing or symlinked: '+relative)
 resolved=joined.resolve()
 require(resolved==joined and base in resolved.parents,'Pinned input escapes the reviewed tree: '+relative)
 return resolved

def validate_profile(profile):
 require(profile.get('method')==METHOD,'Profile method identifier changed')
 require(set(profile.get('inputs',{}))=={'characterizationPlan3','revisedPlan','safetyReview','safetyReview2','expectedTreatment','exactGate','observations','source6Executor','source6Profile','source6Tests'},'Required input pin inventory changed')
 constants={'measuredTotal':MEASURED_TOTAL,'planCeiling':PLAN_CEILING,'reserveUsed':RESERVE_USED,'optionalFloat0CoverageCalls':0,
  'sampleIntervalSeconds':SAMPLE_INTERVAL_SECONDS,'samplesPerStatement':SAMPLES_PER_STATEMENT,'samplesPerProcess':SAMPLES_PER_PROCESS,
  'quiescenceChecksPerStatement':QUIESCENCE_CHECKS,'settlementMonitorCallsMax':SETTLEMENT_CALLS_MAX,
  'ratioThreshold':RATIO_THRESHOLD,'deltaThresholdMs':DELTA_THRESHOLD_MS,'primaryTiming':PRIMARY_TIMING}
 m=profile.get('measurement',{})
 for key,value in constants.items():require(m.get(key)==value,'Profile measurement invariant changed: '+key)
 a=profile.get('accounting',{})
 require(a.get('emittedStatements')==EMITTED and a.get('ceilings')==CEILINGS,'Profile statement accounting differs from emitted SQL contract')
 require(profile.get('clones')==CLONES,'Profile clone names changed')
 require(not set(CLONES.values())&set(FORBIDDEN_DATABASES),'Clone name reuses a residual database')
 require(profile.get('seam')=={'actor':ACTOR,'project':PROJECT,'unit':UNIT,'missingUnit':MISSING},'Profile seam identities changed')
 t=profile.get('timeoutsSeconds',{})
 require(t=={'installedAuthenticatorStatement':8,'installedAuthenticatorLock':8,'inspectionStatement':20,'inspectionLock':12,'psqlProcess':35},'Timeouts are fixed; no increase or normalization')
 forbidden=profile.get('forbidden',[])
 for item in ('DROP DATABASE','ANALYZE','VACUUM','EXPLAIN','CREATE EXTENSION','ALTER SYSTEM','private helper timing','fake baseline metadata endpoint','retry','historical hash normalization','dense volume reduction'):
  require(item in forbidden,'Profile must declare forbidden action: '+item)
 g=profile.get('genuine',{})
 require(len(g.get('denseTables',[]))==6 and len(g.get('metadataTables',[]))==9,'Genuine dense/metadata witnesses incomplete')
 require(g.get('failedCall',{}).get('floatDigits')==1 and g.get('failedCall',{}).get('statementTimeout')=='8s','Genuine failed-call facts changed')
 c=profile.get('claims',{})
 require(c=={'historicalDataReproducedWhenHashesDiffer':False,'full20Complete':False,'full42Complete':False,'full65Complete':False,'providerAcceptance':False,'primaryAcceptanceSatisfied':False,'restorationClaimed':False},'Acceptance/restoration claims must stay false')
 return True

def validate_inputs(profile,execute,base=ROOT):
 resolved={};pending=[]
 for name,entry in sorted(profile['inputs'].items()):
  digest=entry['sha256']
  if digest==PENDING:
   pending.append(name);require(not execute,'Execution refused: root has not pinned '+name)
   try:resolved[name]=resolve_input(entry['path'],base)
   except RuntimeError:pass
   continue
  require(re.fullmatch('[0-9a-f]{64}',digest) is not None,'Malformed pin: '+name)
  path=resolve_input(entry['path'],base);require(sha(path)==digest,'Raw source pin refused: '+name);resolved[name]=path
 return resolved,pending

def cross_check_observations(profile,observations):
 g=profile['genuine']
 require([{'name':x['name'],'count':x['count'],'sha256':x['sha256']} for x in observations['baselineDenseCounts']]==g['denseTables'],'Profile dense witnesses differ from frozen OBSERVATIONS')
 require([{'name':x['name'],'count':x['count'],'sha256':x['sha256']} for x in observations['inactiveMetadataCounts']]==g['metadataTables'],'Profile metadata witnesses differ from frozen OBSERVATIONS')
 f=observations['failedCall']
 require(f['sqlSha256']==profile['inputs']['exactGate']['sha256'] and f['login']=='authenticator' and f['zone']=='UTC' and f['floatDigits']==1,'Failed-call facts differ from frozen OBSERVATIONS')
 state=observations['baselineState'];keys=[(e['schema'],e['name'],e['kind']) for e in state]
 require(len(keys)==len(set(keys)) and all(is_int(e['count']) and re.fullmatch('[0-9a-f]{64}',e['sha256']) for e in state),'Frozen baselineState malformed or duplicated')
 by={(e['schema'],e['name']):e for e in state}
 for d in g['denseTables']:require(by.get(('public',d['name']),{}).get('count')==d['count'],'Dense witness absent from frozen baselineState')
 return True

def load_module(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

# ------------------------------------------------- R5 emitted statement counter

def count_statements(text):
 """Top-level SQL statements psql sends; meta lines, comments and quoted/dollar bodies skipped."""
 n=0;has=False;i=0;L=len(text);line_start=True
 while i<L:
  c=text[i]
  if line_start and c=='\\':
   j=text.find('\n',i);i=L if j<0 else j+1;continue
  if c=='\n':line_start=True;i+=1;continue
  line_start=False
  if text.startswith('--',i):
   j=text.find('\n',i);i=L if j<0 else j;continue
  if c=="'":
   j=i+1
   while j<L:
    if text[j]=="'":
     if j+1<L and text[j+1]=="'":j+=2;continue
     break
    j+=1
   require(j<L,'Unterminated quoted literal');i=j+1;has=True;continue
  if c=='$':
   m=re.match(r'\$([A-Za-z_][A-Za-z_0-9]*)?\$',text[i:])
   if m:
    tag=m.group(0);j=text.find(tag,i+len(tag));require(j>=0,'Unterminated dollar quote');i=j+len(tag);has=True;continue
  if c==';':
   if has:n+=1
   has=False;i+=1;continue
  if not c.isspace():has=True
  i+=1
 return n+(1 if has else 0)

INSPECTION_PRELUDE="set statement_timeout='20s';set lock_timeout='12s';set search_path=public,pg_temp;\n"
def json_wrapper(select):return 'select to_jsonb(__combined_result.value) from ('+select.strip().removesuffix(';')+') as __combined_result(value);'
def inspection_wire(select):
 # Mirrors the unchanged source6 Runner.run/json wire for a supabase_admin inspection call.
 return GATE_PRELUDE+INSPECTION_PRELUDE+json_wrapper(select)
def monitor_wire(select,milliseconds=2000):
 return GATE_PRELUDE+f"set statement_timeout='{milliseconds}ms';set lock_timeout='{milliseconds}ms';set search_path=public,pg_temp;\n"+json_wrapper(select)

# ------------------------------------------------------------- exact gate/copy

def gate_body(pinned,pin):
 require(sha_bytes(pinned)==pin,'Exact call-01300 bytes differ from pin')
 text=pinned.decode('utf-8');require(text.startswith(GATE_PRELUDE),'Exact gate lacks recorded runner prelude')
 return text[len(GATE_PRELUDE):]

ASSIGNMENT=re.compile(r'^ (r|baseline_review):=public\.(work_activity_totals_read|work_unit_contributors_read|work_unit_metadata_read|work_unit_review_read)\(([^;]*)\);$')
MARKER=re.compile(r"^ raise notice 'forge-char-marker %',jsonb_build_object\('marker','(before|after):([0-9]{2}):([a-z_]+)','at',clock_timestamp\(\)::text\);$")
def marker_line(phase,index,function):return " raise notice 'forge-char-marker %',jsonb_build_object('marker','"+phase+':'+f'{index:02d}'+':'+function+"','at',clock_timestamp()::text);"

def do_bounds(lines):
 starts=[i for i,l in enumerate(lines) if l.startswith('do $float_public$')];ends=[i for i,l in enumerate(lines) if l=='end $float_public$;']
 require(len(starts)==1 and len(ends)==1 and starts[0]<ends[0],'Exact single float_public DO block required');return starts[0],ends[0]

def notice_copy(body):
 lines=body.split('\n');start,end=do_bounds(lines);out=[];seen=0
 for i,line in enumerate(lines):
  m=ASSIGNMENT.match(line) if start<i<end else None
  if m:
   seen+=1;out.extend([marker_line('before',seen,m.group(2)),line,marker_line('after',seen,m.group(2))])
  else:out.append(line)
 require(seen==GATE_ASSIGNMENTS,'Unexpected reader assignment count')
 copy='\n'.join(out);validate_notice_copy(body,copy);return copy

def validate_notice_copy(original,copy):
 lines=copy.split('\n');kept=[l for l in lines if not MARKER.match(l)]
 require('\n'.join(kept)==original,'NOTICE copy changed a call, argument, order, assertion or float transition')
 start,end=do_bounds(lines);markers=[i for i,l in enumerate(lines) if MARKER.match(l)]
 require(len(markers)==2*GATE_ASSIGNMENTS,'NOTICE copy marker count changed')
 expected=1
 for k in range(0,len(markers),2):
  b,a=markers[k],markers[k+1];mb,ma=MARKER.match(lines[b]),MARKER.match(lines[a])
  require(start<b and a<end and a==b+2,'Marker outside DO or not adjacent to one assignment')
  assignment=ASSIGNMENT.match(lines[b+1])
  require(assignment is not None and mb.group(1)=='before' and ma.group(1)=='after' and int(mb.group(2))==int(ma.group(2))==expected and mb.group(3)==ma.group(3)==assignment.group(2),'Marker does not wrap the matching reader assignment')
  expected+=1
 return True

def expected_markers(copy):
 # R3: the exact twenty descriptors, derived from the validated pinned copy itself.
 out=[]
 for line in copy.split('\n'):
  m=MARKER.match(line)
  if m:out.append(m.group(1)+':'+m.group(2)+':'+m.group(3))
 require(len(out)==2*GATE_ASSIGNMENTS,'Expected marker descriptors incomplete');return out

NOTICE_LINE=re.compile(r'^NOTICE:  00000: forge-char-marker (\{.*\})$')
def parse_notice_evidence(stderr,expected,outcome):
 """Returns validated markers. Raises on missing/malformed/garbled/out-of-order evidence."""
 markers=[];previous=None
 for line in stderr.splitlines():
  if not line.startswith('NOTICE:') and 'forge-char-marker' not in line:continue
  m=NOTICE_LINE.match(line);require(m is not None,'Garbled or unexpected NOTICE line')
  try:value=json.loads(m.group(1))
  except ValueError:raise RuntimeError('Malformed marker JSON') from None
  require(isinstance(value,dict) and set(value)=={'at','marker'} and isinstance(value['marker'],str) and isinstance(value['at'],str),'Malformed marker fields')
  require(len(markers)<len(expected) and value['marker']==expected[len(markers)],'Marker sequence/name/phase/index differs from pinned copy')
  at=pg_utc(value['at']);require(previous is None or at>=previous,'Marker timestamps out of order');previous=at;markers.append(value)
 if outcome=='returned':require(len(markers)==len(expected),'Successful instrumented copy lacks all twenty markers')
 elif outcome in ('statement_timeout','gate_assertion_failed'):require(len(markers)>=1,'Cancelled/failed copy has no marker prefix; localization withheld')
 else:raise RuntimeError('Unclassified instrumented outcome')
 return markers

# ------------------------------------------------------- measured API statements
LOGIN="select jsonb_build_object('kind','login','pid',pg_backend_pid(),'backendStart',(select extract(epoch from backend_start)::text from pg_stat_activity where pid=pg_backend_pid()),'sessionUser',session_user,'currentUser',current_user,'zone',current_setting('TimeZone'),'statementTimeout',current_setting('statement_timeout'),'lockTimeout',current_setting('lock_timeout'));"
RUNTIME="SET ROLE authenticated;SET request.jwt.claim.sub="+q(ACTOR)+";select jsonb_build_object('kind','runtime','sessionUser',session_user,'currentUser',current_user,'jwtSubject',auth.uid(),'zone',current_setting('TimeZone'),'floatDigits',current_setting('extra_float_digits'),'statementTimeout',current_setting('statement_timeout'),'lockTimeout',current_setting('lock_timeout'));"
GUARD="DO $$BEGIN IF session_user<>'authenticator' OR current_user<>'authenticated' OR auth.uid() IS DISTINCT FROM "+q(ACTOR)+"::uuid OR current_setting('statement_timeout')<>'8s' OR current_setting('lock_timeout')<>'8s' THEN RAISE EXCEPTION 'Runtime identity or installed timeout changed';END IF;END$$;"
SETTINGS_NAMES=('TimeZone','extra_float_digits','transaction_isolation','statement_timeout','lock_timeout','search_path','work_mem','hash_mem_multiplier','temp_buffers','jit','jit_above_cost','jit_inline_above_cost','jit_optimize_above_cost','max_parallel_workers_per_gather','random_page_cost','seq_page_cost','cpu_tuple_cost','cpu_index_tuple_cost','cpu_operator_cost','effective_cache_size','default_statistics_target','plan_cache_mode','from_collapse_limit','join_collapse_limit','geqo','geqo_threshold','enable_seqscan','enable_indexscan','enable_indexonlyscan','enable_bitmapscan','enable_hashjoin','enable_mergejoin','enable_nestloop','enable_material','enable_memoize','enable_hashagg','enable_sort','enable_incremental_sort')
SETTINGS_SQL="select jsonb_build_object('kind','settings','values',jsonb_build_object("+','.join(q(n)+',current_setting('+q(n)+')' for n in SETTINGS_NAMES)+"));"
REQUIRED_SETTINGS={'TimeZone':'UTC','extra_float_digits':'1','transaction_isolation':'read committed','statement_timeout':'8s','lock_timeout':'8s'}
def clock_sql(phase):return "select jsonb_build_object('kind','clock','phase',"+q(phase)+",'at',clock_timestamp()::text);"
API_EXPRESSIONS={
 'totals':'public.work_activity_totals_read('+q(PROJECT)+'::uuid,'+q(UNIT)+'::uuid)',
 'contributors':'public.work_unit_contributors_read('+q(PROJECT)+'::uuid,'+q(UNIT)+'::uuid,1)',
 'review_visible':'public.work_unit_review_read('+q(UNIT)+'::uuid)',
 'review_missing':'public.work_unit_review_read('+q(MISSING)+'::uuid)',
 'metadata':'public.work_unit_metadata_read('+q(UNIT)+'::uuid,1)'}

def measured_api_sql(api):
 require(api in API_EXPRESSIONS,'Unknown public API')
 return (LOGIN+RUNTIME+GUARD+'\n'+SETTINGS_SQL+clock_sql('before')+'\n\\set QUIET off\n\\timing on\n'
  +"select jsonb_build_object('kind','response','value',"+API_EXPRESSIONS[api]+");\n\\timing off\n\\set QUIET on\n"+clock_sql('after')+'\n')

TIME_LINE=re.compile(r'^Time: ([0-9]+(?:\.[0-9]+)?) ms(?: \([0-9:.]+\))?$')
def parse_api_stdout(stdout,complete):
 values=[];psql_ms=None
 for line in stdout.splitlines():
  if not line.strip() or line in ('Timing is on.','Timing is off.'):continue
  m=TIME_LINE.match(line)
  if m:
   require(psql_ms is None,'Multiple psql timing lines');psql_ms=float(m.group(1));continue
  try:value=json.loads(line)
  except ValueError:raise RuntimeError('Unrecognized measured output line') from None
  require(isinstance(value,dict) and isinstance(value.get('kind'),str),'Unrecognized measured JSON line');values.append(value)
 kinds=[v['kind'] for v in values]
 if complete:
  require(kinds==['login','runtime','settings','clock','response','clock'] and values[3]['phase']=='before' and values[5]['phase']=='after','Measured evidence order incomplete')
  require(psql_ms is not None,'psql elapsed timing missing')
  return {'login':values[0],'runtime':values[1],'settings':values[2]['values'],'clockBefore':values[3]['at'],'response':values[4]['value'],'clockAfter':values[5]['at'],'psqlElapsedMs':psql_ms}
 require(kinds==['login','runtime','settings','clock'] and values[3]['phase']=='before','Censored evidence prefix incomplete')
 return {'login':values[0],'runtime':values[1],'settings':values[2]['values'],'clockBefore':values[3]['at'],'response':None,'clockAfter':None,'psqlElapsedMs':None}

def parse_gate_stdout(stdout):
 rows=[json.loads(l) for l in stdout.splitlines() if l.strip()]
 require(len(rows)==2 and rows[0].get('kind')=='login' and rows[1].get('kind')=='runtime','Gate identity evidence missing')
 return rows[0],rows[1]

def validate_identity(login,runtime,seen):
 try:
  identity=(login['pid'],login['backendStart'])
  ok=(is_int(login['pid']) and isinstance(login['backendStart'],str) and identity not in seen and login['sessionUser']==login['currentUser']=='authenticator' and runtime['sessionUser']=='authenticator'
   and runtime['currentUser']=='authenticated' and runtime['jwtSubject']==ACTOR and login['zone']==runtime['zone']=='UTC' and runtime['floatDigits']=='1'
   and login['statementTimeout']==runtime['statementTimeout']=='8s' and login['lockTimeout']==runtime['lockTimeout']=='8s')
 except (KeyError,TypeError):ok=False
 require(ok,'Fresh authenticator/JWT/UTC/float1/8s identity not proven; no normalization');seen.add(identity);return True

def validate_settings(settings):
 require(isinstance(settings,dict) and set(settings)==set(SETTINGS_NAMES) and all(isinstance(v,str) for v in settings.values()) and all(settings[k]==v for k,v in REQUIRED_SETTINGS.items()),'Measured session settings differ from the failure seam')
 return True

def api_assertion(api,value):
 if not isinstance(value,dict):return False
 if api in ('totals','contributors','metadata'):return value.get('availability')=='available'
 if api=='review_visible':
  review=value.get('review');qc=review.get('qc') if isinstance(review,dict) else None
  return value.get('availability')=='available' and isinstance(qc,dict) and qc.get('lifecycle')=='proven'
 if api=='review_missing':return {k:v for k,v in value.items() if k!='asOf'}=={'protocolVersion':1,'availability':'unavailable','review':None}
 raise RuntimeError('Unknown API assertion')

PG_TS=re.compile(r'^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d(?:\.\d{1,6})?)\+00$')
def pg_utc(text):
 m=PG_TS.match(text if isinstance(text,str) else '');require(m is not None,'Unexpected server clock text')
 fmt='%Y-%m-%d %H:%M:%S.%f' if '.' in m.group(1) else '%Y-%m-%d %H:%M:%S'
 return datetime.datetime.strptime(m.group(1),fmt)
def envelope_ms(before,after):return round((pg_utc(after)-pg_utc(before)).total_seconds()*1000,3)

# ----------------------------------------------------------- outcome classifier
STATEMENT_TIMEOUT=re.compile(r'ERROR:\s+57014:\s+canceling statement due to statement timeout')
LOCK_TIMEOUT=re.compile(r'ERROR:\s+55P03:')
GATE_ASSERTIONS=('Fixture requires initial float1','Distinct fixture IDs required','Totals positive prerequisite failed','Contributors positive prerequisite failed','Metadata positive prerequisite failed','Proven review positive prerequisite failed','Missing-unit prerequisite failed','Totals false-coverage response changed','Contributors false-coverage response changed','Metadata false-coverage response changed','Review false-coverage response changed','Missing-unit review response changed')
def classify(raw,kind):
 if raw.get('processTimeout'):return 'process_timeout'
 rc=raw.get('returnCode');stderr=raw.get('stderr') or ''
 if rc==0:return 'returned'
 if rc==3 and STATEMENT_TIMEOUT.search(stderr):return 'statement_timeout'
 if rc==3 and LOCK_TIMEOUT.search(stderr):return 'lock_timeout'
 if rc==3 and kind in ('exact_gate','notice_copy') and re.search(r'ERROR:\s+P0001:',stderr) and any(('ERROR:  P0001: '+m) in stderr for m in GATE_ASSERTIONS):return 'gate_assertion_failed'
 return 'unclassified'
def original_error(stderr):return [l for l in (stderr or '').splitlines() if l.startswith(('ERROR:','CONTEXT:','LOCATION:'))]

# ------------------------------------------------------------ plan and ledger
def measurement_plan():
 plan=[]
 for rnd,order in ROUNDS:
  for branch in order:
   for api in API_TYPES:plan.append({'id':f'r{rnd}-{branch}-{api}','kind':'api','round':rnd,'branch':branch,'api':api,'label':'matched_round'})
 plan+=[{'id':f'b-metadata-{n}','kind':'api','round':None,'branch':'B','api':'metadata','label':'repeat_state_not_matched_baseline'} for n in (1,2)]
 plan+=[{'id':'b-exact-gate','kind':'exact_gate','round':None,'branch':'B','api':None,'label':'repeat_state_diagnostic_reproduction'},
        {'id':'b-notice-copy','kind':'notice_copy','round':None,'branch':'B','api':None,'label':'repeat_state_instrumented_diagnostic'}]
 require(len(plan)==MEASURED_TOTAL<=PLAN_CEILING and RESERVE_USED==0,'Measured plan count changed');return plan

class Ledger:
 def __init__(self,plan):self.plan=[dict(x) for x in plan];self.next=0
 def admit(self,spec):
  require(self.next<MEASURED_TOTAL and self.next<len(self.plan) and self.plan[self.next]==spec,'Out-of-plan, repeated, reordered or ceiling-exceeding measured statement refused')
  self.next+=1;return self.next

# --------------------------------------------------- R4 schemas and confounders
def validate_sample(s,tag,cluster,database,login):
 """Strict wait-sample schema. An explicit empty backends array is legitimate."""
 require(isinstance(s,dict) and 'error' not in s,'Wait sample failed')
 require(isinstance(s.get('at'),str) and isinstance(s.get('backends'),list) and isinstance(s.get('monitor'),str) and s['monitor'].startswith(MONITOR_PREFIX),'Wait sample shape invalid')
 pg_utc(s['at'])
 require(s.get('systemIdentifier')==cluster['systemIdentifier'] and s.get('postmasterStart')==cluster['postmasterStart'] and s.get('monitorLogin')=='supabase_admin' and s.get('canSeeAllBackends') is True and s.get('targetApplicationName')==tag,'Wait sample cluster/login/target identity unproven')
 for b in s['backends']:
  require(isinstance(b,dict) and is_int(b.get('pid')) and b.get('pid')==login['pid'] and b.get('backendStart')==login['backendStart'] and b.get('applicationName')==tag and b.get('database')==database and b.get('login')=='authenticator','Sampled backend is not the measured login receipt')
  require(opt_str(b.get('state')) and opt_str(b.get('waitEventType')) and opt_str(b.get('waitEvent')) and isinstance(b.get('blockingPids'),list) and all(is_int(x) for x in b['blockingPids']) and isinstance(b.get('ungrantedLocks'),list) and all(isinstance(x,dict) for x in b['ungrantedLocks']),'Sampled backend fields invalid')
 return True

def wait_profile(samples):
 classes=set();confounders=[];active=0
 for s in samples:
  for b in s['backends']:
   if b['ungrantedLocks'] or b['blockingPids']:confounders.append({'at':s['at'],'reason':'ungranted_lock_or_blocker'})
   if b['state']!='active':continue
   active+=1;kind=b['waitEventType']
   if kind is None or kind=='IO':continue  # disk IO recorded, never an automatic mismatch
   if kind=='Lock':confounders.append({'at':s['at'],'reason':'lock_class_wait','event':b['waitEvent']})
   classes.add(kind+':'+str(b['waitEvent']))
 return {'samples':len(samples),'activeSamples':active,'nonIoClasses':sorted(classes),'confounders':confounders,
  'coverage':'zero active samples observed; short calls can evade 4Hz sampling; absence of waits is NOT proved' if active==0 else 'sampled at most 4Hz; short waits can be missed'}

INT_KEYS=('relpages','relationBytes','totalBytes','liveTuples','deadTuples','modsSinceAnalyze','insertsSinceVacuum','analyzeCount','autoanalyzeCount','vacuumCount','autovacuumCount','heapBlocksRead','heapBlocksHit')
OPTIONAL_INT_KEYS=('indexBlocksRead','indexBlocksHit')  # null when the table has no index
TIMESTAMP_KEYS=('lastAnalyze','lastAutoanalyze','lastVacuum','lastAutovacuum')  # null when never run since this clone's statistics began
STAT_ROW_KEYS={'attname','inherited','nullFrac','avgWidth','nDistinct','mostCommonVals','mostCommonFreqs','histogramBounds','correlation','mostCommonElems','mostCommonElemFreqs','elemCountHistogram'}
def validate_witness(w,database,dense,cluster):
 require(isinstance(w,dict) and w.get('database')==database and w.get('login')=='supabase_admin' and w.get('systemIdentifier')==cluster['systemIdentifier'] and w.get('postmasterStart')==cluster['postmasterStart'],'Witness database/login/cluster identity unproven')
 pg_utc(w.get('at'));require(isinstance(w.get('tables'),list) and isinstance(w.get('databaseCounters'),dict),'Witness shape invalid')
 names=[t.get('name') if isinstance(t,dict) else None for t in w['tables']]
 require(len(names)==len(set(names)) and set(names)==set(dense),'Witness dense table rows duplicated or missing')
 for t in w['tables']:
  require(all(is_int(t.get(k)) for k in INT_KEYS) and is_num(t.get('reltuples')) and all(t.get(k) is None or is_int(t.get(k)) for k in OPTIONAL_INT_KEYS),'Witness physical fields missing or mistyped: '+t['name'])
  for k in TIMESTAMP_KEYS:
   require(k in t and opt_str(t[k]),'Witness timestamp field missing: '+t['name']+'.'+k)
  require(isinstance(t.get('indexes'),list) and all(isinstance(x,str) for x in t['indexes']),'Witness index inventory invalid')
  p=t.get('plannerStats');require(isinstance(p,dict) and is_int(p.get('rows')) and isinstance(p.get('sha256'),str) and re.fullmatch('[0-9a-f]{64}',p['sha256']) and isinstance(p.get('rawRows'),list) and len(p['rawRows'])==p['rows'],'Planner statistics raw rows missing')
  require(all(isinstance(r,dict) and set(r)==STAT_ROW_KEYS and isinstance(r['attname'],str) and isinstance(r['inherited'],bool) for r in p['rawRows']),'Planner statistics row schema invalid')
  order=[(r['attname'],r['inherited']) for r in p['rawRows']];require(order==sorted(order),'Planner statistics rows not sorted')
 return True

PARITY_KEYS=('relpages','reltuples','relationBytes','liveTuples','deadTuples','modsSinceAnalyze','insertsSinceVacuum','analyzeCount','autoanalyzeCount','vacuumCount','autovacuumCount','plannerStats')
def physical_parity(a,b,dense):
 ta={t['name']:t for t in a['tables']};tb={t['name']:t for t in b['tables']};reasons=[]
 for name in sorted(dense):
  for k in PARITY_KEYS:
   if ta[name][k]!=tb[name][k]:reasons.append(name+'.'+k)
  for k in TIMESTAMP_KEYS:
   if (ta[name][k] is None)!=(tb[name][k] is None):reasons.append(name+'.'+k+'Presence')
 return reasons

# --------------------------------------------------- R6 current-fixture gates
def relation_map(fingerprint):
 m={(e['schema'],e['name'],e['kind']):e for e in fingerprint};require(len(m)==len(fingerprint),'Duplicate relation in fingerprint');return m
def historical_deltas(fresh,genuine_state):
 f,g=relation_map(fresh),relation_map(genuine_state);out=[]
 for k in sorted(set(f)|set(g)):
  a,b=g.get(k),f.get(k)
  row={'schema':k[0],'name':k[1],'kind':k[2],'presentInGenuine':a is not None,'presentInFresh':b is not None,'genuineCount':a and a['count'],'freshCount':b and b['count'],'genuineSha256':a and a['sha256'],'freshSha256':b and b['sha256']}
  row.update(countEqual=row['genuineCount']==row['freshCount'] and a is not None and b is not None,hashEqual=row['genuineSha256']==row['freshSha256'] and a is not None and b is not None,cause='unknown_not_separately_proved')
  if not(row['countEqual'] and row['hashEqual']):out.append(row)
 return {'comparedRelations':len(set(f)|set(g)),'differences':out,'historicalDataReproduced':not out}
def historical_gate(deltas):
 # Exact constructor lineage: identical relation inventory and genuine counts; hashes are evidence only.
 return [('inventory:' if not(d['presentInGenuine'] and d['presentInFresh']) else 'count:')+d['schema']+'.'+d['name'] for d in deltas['differences'] if not d['countEqual']]

AUTHORITY=('public','work_activity_authority_generation')
def shared_state(fa,fb):
 a={(e['schema'],e['name']):e for e in fa};b={(e['schema'],e['name']):e for e in fb};reasons=[]
 require(len(a)==len(fa) and len(b)==len(fb),'Duplicate relation in fingerprint')
 for k in sorted(a):
  if k not in b:reasons.append('missing_in_B:'+'.'.join(k))
  elif ({field:value for field,value in a[k].items() if field!='sha256'}!={field:value for field,value in b[k].items() if field!='sha256'} if k==AUTHORITY else a[k]!=b[k]):reasons.append('shared_relation_differs:'+'.'.join(k))
 return reasons,['.'.join(k) for k in sorted(set(b)-set(a))]

def treatment_gate(fa,fb,expected):
 a=relation_map(fa);b=relation_map(fb)
 actual=set(b)-set(a);authored={(x['schema'],x['name'],x['kind']) for x in expected}
 require(len(authored)==17 and len(authored)==len(expected) and all(k[0]=='public' and k[2]=='r' for k in authored),'Authored treatment inventory invalid')
 return ['missing:'+'.'.join(k) for k in sorted(authored-actual)]+['unexpected:'+'.'.join(k) for k in sorted(actual-authored)]

def metadata_gate(fingerprint,genuine):
 by={(e['schema'],e['name']):e for e in fingerprint};counts=[];hashes=[]
 for g in genuine:
  e=by.get(('public',g['name']),{})
  if e.get('count')!=g['count']:counts.append(g['name'])
  if e.get('sha256')!=g['sha256']:hashes.append(g['name'])
 return counts,hashes

# --------------------------------------------------------- interpretation
def interpret(records,valid):
 apis={}
 for api in API_TYPES:
  rounds=[]
  for rnd,_ in ROUNDS:
   a,b=records.get((rnd,'A',api)),records.get((rnd,'B',api))
   if a is None or b is None:rounds.append({'round':rnd,'status':'missing'});continue
   row={'round':rnd,'aMs':a.get(PRIMARY_TIMING),'bMs':b.get(PRIMARY_TIMING),'ratio':None,'deltaMs':None}
   if a['outcome']=='timeout' and b['outcome']=='timeout':row['status']='both_timeout_censored'
   elif b['outcome']=='timeout':row['status']='b_only_timeout_censored'
   elif a['outcome']=='timeout':row['status']='a_only_timeout_censored'
   else:
    av,bv=row['aMs'],row['bMs'];row['deltaMs']=round(bv-av,3);row['ratio']=round(bv/av,6) if av>0 else None
    row['status']=('threshold_met' if (av>0 and bv/av>=RATIO_THRESHOLD and bv-av>=DELTA_THRESHOLD_MS) else 'threshold_not_met') if valid else 'threshold_not_evaluated'
   rounds.append(row)
  statuses=[r['status'] for r in rounds]
  if 'missing' in statuses:conclusion='incomplete'
  elif not valid:conclusion='withheld_whole_characterization_inconclusive'
  elif 'both_timeout_censored' in statuses:conclusion='inherited_reader_limit_observed_candidate_cost_unresolved'
  elif 'a_only_timeout_censored' in statuses:conclusion='inconsistent_censoring_inconclusive'
  elif 'b_only_timeout_censored' in statuses:conclusion='candidate_only_timeout_observed_investigate_coverage_preserving_guards'
  elif all(s=='threshold_met' for s in statuses):conclusion='bounded_candidate_dependent_timing_signal_not_universal_regression'
  else:conclusion='no_demonstrated_regression_under_this_characterization'
  apis[api]={'rounds':rounds,'conclusion':conclusion}
 return apis

def gate_label(classification):
 return {'returned':'diagnostic_reproduction_passed','statement_timeout':'diagnostic_reproduction_failed_statement_timeout','gate_assertion_failed':'diagnostic_reproduction_failed_assertion'}.get(classification,'not_classified')

# ------------------------------------------------------------- engine
class Characterization:
 def __init__(self,io,dense,gate_pin,gate_text,copy_text):
  self.io=io;self.dense=list(dense);self.plan=measurement_plan();self.ledger=Ledger(self.plan)
  self.gate_pin=gate_pin;self.gate_text=gate_text;self.copy_text=copy_text;validate_notice_copy(gate_text,copy_text)
  self.copy_pin=sha_bytes((GATE_PRELUDE+copy_text).encode());self.expected=expected_markers(copy_text)
  self.cluster=io.cluster;self.records=[];self.identities=set();self.settings=None;self.witnesses={};self.checkpoints={};self.stop=None;self.phase='paired';self.final_reasons=[];self.accounting=None
 def halt(self,reason,spec=None,detail=None):
  if self.stop is None:self.stop={'reason':reason,'statement':spec['id'] if spec else None,'phase':self.phase,'detail':detail}
 def checkpoint(self,name):
  try:
   w=self.io.witness(name)
   for kind in ('A','B'):validate_witness(w[kind],CLONES[kind],self.dense,self.cluster)
   self.witnesses[name]=w
  except BaseException as e:
   self.checkpoints[name]='evidence_lost';return self.halt('witness_evidence_lost',detail=name+': '+str(e))
  reasons=physical_parity(w['A'],w['B'],self.dense) if name in PAIRED_CHECKPOINTS else []
  self.checkpoints[name]='valid' if not reasons else 'mismatch:'+','.join(reasons)
  if reasons:self.halt('physical_or_statistics_mismatch',detail=name+': '+','.join(reasons))
 def sql_for(self,spec):
  if spec['kind']=='api':return measured_api_sql(spec['api'])
  return self.gate_text if spec['kind']=='exact_gate' else self.copy_text
 def execute(self,spec):
  self.ledger.admit(spec);raw=self.io.run_measured(spec,self.sql_for(spec))
  outcome=classify(raw,spec['kind']);call=raw.get('call',{});samples=raw.get('samples',[])
  record={'id':spec['id'],'spec':spec,'classification':outcome,'callerWallMs':call.get('wallMillisecondsIncludingPsql'),'applicationName':call.get('applicationName'),'settled':raw.get('settled') is True,'quiescent':raw.get('quiescent') is True,'originalError':original_error(raw.get('stderr'))}
  self.records.append(record)
  if len(samples)>SAMPLES_PER_STATEMENT:return self.halt('wait_sample_ceiling_exceeded',spec)
  if raw.get('settled') is not True:return self.halt('uncertain_backend_settlement',spec)
  if raw.get('quiescent') is not True:return self.halt('monitor_not_quiescent',spec)
  if outcome in ('process_timeout','unclassified','lock_timeout'):return self.halt('stop_'+outcome,spec,(raw.get('stderr') or '')[-1200:])
  try:
   if spec['kind']=='api':
    if outcome not in ('returned','statement_timeout'):return self.halt('unexpected_api_outcome',spec,outcome)
    parsed=parse_api_stdout(raw.get('stdout',''),outcome=='returned');login,runtime,settings=parsed['login'],parsed['runtime'],parsed['settings']
    record.update(observedPsqlElapsedMs=parsed['psqlElapsedMs'],clockBefore=parsed['clockBefore'],clockAfter=parsed['clockAfter'])
   else:
    login,runtime=parse_gate_stdout(raw.get('stdout',''));settings=None
   validate_identity(login,runtime,self.identities)
  except (RuntimeError,ValueError,KeyError,TypeError) as e:return self.halt('identity_or_evidence_failure',spec,str(e))
  try:
   audit=raw.get('samplerAudit',{});require(isinstance(audit,dict),'Sampler audit missing');require(audit.get('verified') is True and audit.get('completedSamples')==len(samples) and len(samples)>0,'Sampler lifecycle/file evidence missing or incomplete')
   record['samplerAudit']=audit
   for s in samples:validate_sample(s,record['applicationName'],self.cluster,CLONES[spec['branch']],login)
  except RuntimeError as e:return self.halt('wait_evidence_lost',spec,str(e))
  record['wait']=wait_profile(samples)
  if record['wait']['confounders']:return self.halt('wait_confounder',spec)
  if settings is not None:
   try:validate_settings(settings)
   except RuntimeError as e:return self.halt('identity_or_evidence_failure',spec,str(e))
   if self.settings is None:self.settings=settings
   elif settings!=self.settings:return self.halt('session_settings_mismatch',spec)
  if spec['kind']=='api':
   if outcome=='returned':
    if not api_assertion(spec['api'],parsed['response']):return self.halt('original_assertion_failed',spec)
    try:record.update(outcome='ok',psqlElapsedMs=parsed['psqlElapsedMs'],serverClockEnvelopeMs=envelope_ms(parsed['clockBefore'],parsed['clockAfter']))
    except RuntimeError as e:return self.halt('identity_or_evidence_failure',spec,str(e))
   else:record.update(outcome='timeout',psqlElapsedMs=None,serverClockEnvelopeMs=None,censoredAtStatementTimeout=True)
   if spec['label']=='matched_round':self.pair_check(spec,record)
   return
  pin=self.gate_pin if spec['kind']=='exact_gate' else self.copy_pin
  if call.get('sqlSha256')!=pin:return self.halt(spec['kind']+'_wire_bytes_changed',spec)
  try:
   if spec['kind']=='notice_copy':record['markers']=parse_notice_evidence(raw.get('stderr',''),self.expected,outcome)
   else:require('forge-char-marker' not in (raw.get('stderr') or ''),'Exact gate carried instrumentation')
  except (RuntimeError,ValueError) as e:return self.halt('notice_evidence_lost',spec,str(e))
  record.update(outcome=outcome,diagnostic=gate_label(outcome),primaryAcceptanceSatisfied=False)
  if spec['kind']=='notice_copy' and outcome!='returned':record.update(markerPrefixLength=len(record['markers']),censored=True,localization='not_inferred_beyond_last_observed_marker')
 def pair_check(self,spec,record):
  other='B' if spec['branch']=='A' else 'A'
  partner=next((r for r in self.records if r['spec']['label']=='matched_round' and r['spec']['round']==spec['round'] and r['spec']['api']==spec['api'] and r['spec']['branch']==other and 'outcome' in r),None)
  if partner and partner['wait']['nonIoClasses']!=record['wait']['nonIoClasses']:self.halt('non_io_wait_class_mismatch',spec)
 def run(self):
  try:
   for reason in getattr(self.io,'setup_reasons',[]):self.halt('setup_invalid',detail=reason)
   if not self.stop:self.checkpoint('pre_round1')
   for index,spec in enumerate(self.plan):
    if self.stop:break
    if index==8:self.checkpoint('post_round1')
    if index==16:
     self.phase='post_round2';self.checkpoint('post_round2');self.phase='b_only'
    if self.stop:break
    self.execute(spec)
  finally:
   self.phase='final';self.checkpoint('final')  # bounded final evidence is always attempted, even after a stop
   try:self.final_reasons=list(self.io.final_checks())
   except BaseException as e:self.final_reasons=['final_checks_failed: '+str(e)]
   try:self.accounting,acc_reasons=self.io.accounting()
   except BaseException as e:self.accounting,acc_reasons=None,['accounting_failed: '+str(e)]
   self.final_reasons+=list(acc_reasons)
  return self.summary()
 def summary(self):
  complete=[r for r in self.records if 'outcome' in r];matched={(r['spec']['round'],r['spec']['branch'],r['spec']['api']):r for r in complete if r['spec']['label']=='matched_round'}
  reasons=[]
  if self.stop:reasons.append('stopped:'+self.stop['reason'])
  if self.ledger.next!=MEASURED_TOTAL or len(complete)!=MEASURED_TOTAL:reasons.append('measured_invocations_incomplete:'+str(len(complete)))
  if self.checkpoints.get('final')!='valid':reasons.append('final_witness_not_valid')
  reasons+=['final:'+x for x in self.final_reasons]
  valid=not reasons
  # One gate controls ALL interpreted claims; partial numeric observations remain visible.
  if not isinstance(self.accounting,dict) or self.accounting.get('verified') is not True or self.accounting.get('measuredIds')!=[r['id'] for r in self.records]:reasons.append('io_ledger_not_verified')
  valid=not reasons
  apis=interpret(matched,valid)
  paired=interpret(matched,False) if len(matched)==16 else None
  # Project every public record through the same claim gate, including aliases.
  records=[dict(r) for r in self.records]
  if not valid:
   for r in records:
    if r['spec']['api']=='metadata' or r['spec']['kind'] in ('exact_gate','notice_copy'):r['diagnostic']='withheld_whole_characterization_inconclusive'
  meta=[r for r in records if r['spec']['api']=='metadata']
  gate=next((r for r in records if r['spec']['kind']=='exact_gate'),None);copy=next((r for r in records if r['spec']['kind']=='notice_copy'),None)
  aggregate=None
  if valid and all(apis[a]['conclusion']=='no_demonstrated_regression_under_this_characterization' for a in API_TYPES) and all(m.get('outcome')=='ok' for m in meta) and gate.get('outcome')=='statement_timeout':
   aggregate='aggregate_envelope_effect_consistent_with_additional_scope_pass_not_a_cost_decomposition'
  return {'method':METHOD,'measuredPlanned':MEASURED_TOTAL,'measuredExecuted':self.ledger.next,'planCeiling':PLAN_CEILING,'reserveUsed':RESERVE_USED,'stop':self.stop,
   'characterization':{'status':'valid' if valid else 'inconclusive','reasons':reasons},'checkpoints':self.checkpoints,'apis':apis,
   'pairedScope':None if (valid or paired is None) else {'label':'raw_paired_observations_only_all_interpretations_withheld','apis':paired},
   'metadataRepeatState':meta,'exactGate':gate,'noticeCopy':copy,'aggregate':aggregate,'accounting':self.accounting,
   'historicalDataReproduced':bool(getattr(self.io,'historical_reproduced',False)),'full20Complete':False,'full42Complete':False,'full65Complete':False,'providerAcceptance':False,
   'primaryAcceptanceSatisfied':False,'restorationClaimed':False,'records':records,'witnesses':self.witnesses,
   'limitations':{'freshFixtureOnly':True,'omittedGenuineSeamHistory':list(OMITTED_SEAM_HISTORY),'failedInstancePhysicalStatisticsKnown':False,'hardwareHistoryKnown':False,
    'notes':['A fresh pass cannot refute the original timeout.','Two matched rounds give a bounded current-fixture signal only, never a universal regression or equivalence.','psql elapsed and server clock envelopes include wire/client overhead; neither is pure executor time.','4Hz sampling can miss short waits.','Characterization never satisfies the unchanged full combined trial.']}}

# ---------------------------------------------------------- real database IO
WAIT_PRELUDE="set statement_timeout='200ms';set lock_timeout='200ms';\n"
CLUSTER_FIELDS="'systemIdentifier',(select system_identifier::text from pg_control_system()),'postmasterStart',extract(epoch from pg_postmaster_start_time())::text"
def wait_sample_sql(tag):
 require(TAG_PATTERN.fullmatch(tag) is not None,'Unproven sampled application name')
 return ("select jsonb_build_object('at',clock_timestamp()::text,"+CLUSTER_FIELDS+",'monitorLogin',session_user,'canSeeAllBackends',(select rolsuper from pg_roles where rolname=current_user),'targetApplicationName',"+q(tag)+","
  "'backends',(select coalesce(jsonb_agg(jsonb_build_object('pid',a.pid,'backendStart',extract(epoch from a.backend_start)::text,'applicationName',a.application_name,'database',a.datname,'login',a.usename,'state',a.state,'waitEventType',a.wait_event_type,'waitEvent',a.wait_event,"
  "'blockingPids',to_jsonb(pg_blocking_pids(a.pid)),'ungrantedLocks',(select coalesce(jsonb_agg(jsonb_build_object('locktype',l.locktype,'mode',l.mode,'relation',l.relation::text) order by l.locktype,l.mode),'[]'::jsonb) from pg_locks l where l.pid=a.pid and not l.granted)) order by a.pid),'[]'::jsonb) "
  "from pg_stat_activity a where a.application_name="+q(tag)+")));\n")

class WaitSampler:
 """Finite observer with an explicit attempt ledger and immutable raw-file receipts."""
 def __init__(self,uri,env,out_dir,cap=SAMPLES_PER_STATEMENT,interval=SAMPLE_INTERVAL_SECONDS,spawn=subprocess.run,clock=time.monotonic):
  require(0<cap<=SAMPLES_PER_STATEMENT<=SAMPLES_PER_PROCESS and interval>=SAMPLE_INTERVAL_SECONDS,'Wait sampling exceeds declared ceiling')
  self.uri=uri;self.env=env;self.out_dir=Path(out_dir);self.cap=cap;self.interval=interval;self.spawn=spawn;self.clock=clock
  self.samples=[];self.attempts=[];self.started=False;self.finished=False
 def run(self,tag,stop,wait=None):
  wait=wait or stop.wait;self.started=True
  try:
   while not stop.is_set() and len(self.attempts)<self.cap:
    started=self.clock();self.samples.append(self.sample(tag))
    remaining=self.interval-(self.clock()-started)
    if remaining>0 and wait(remaining):break
  finally:self.finished=True
 def sample(self,tag):
  monitor=MONITOR_PREFIX+uuid.uuid4().hex;stem=self.out_dir/f'{len(self.attempts):03d}'
  attempt={'file':stem.name,'monitor':monitor,'completed':False,'files':{}};self.attempts.append(attempt)
  try:
   sql=WAIT_PRELUDE+wait_sample_sql(tag);attempt['sqlSha256']=sha_bytes(sql.encode());self.out_dir.mkdir(parents=True,exist_ok=True);stem.with_suffix('.sql').write_text(sql)
   try:
    result=self.spawn(['psql',self.uri,'-X','-q','-t','-A','-v','ON_ERROR_STOP=1'],input=sql,text=True,capture_output=True,timeout=SAMPLE_PROCESS_TIMEOUT_SECONDS,env=dict(self.env,PGAPPNAME=monitor,PGOPTIONS='-c timezone=UTC -c extra_float_digits=1'))
    stdout,stderr=result.stdout,result.stderr;attempt['returnCode']=result.returncode
   except subprocess.TimeoutExpired as e:
    stdout=e.stdout or '';stderr=e.stderr or '';attempt['processTimeout']=True
    stem.with_suffix('.stdout').write_bytes(stdout.encode() if isinstance(stdout,str) else stdout);stem.with_suffix('.stderr').write_bytes(stderr.encode() if isinstance(stderr,str) else stderr);raise
   stem.with_suffix('.stdout').write_text(stdout);stem.with_suffix('.stderr').write_text(stderr)
   if result.returncode!=0:return {'error':'returncode_'+str(result.returncode),'monitor':monitor}
   value=json.loads(stdout.strip());require(isinstance(value,dict),'Malformed sample')
   value['monitor']=monitor;attempt['completed']=True;return value
  except BaseException as e:return {'error':('malformed_sample' if isinstance(e,RuntimeError) else type(e).__name__),'monitor':monitor}
  finally:
   for ext in ('sql','stdout','stderr'):
    f=stem.with_suffix('.'+ext)
    if f.is_file():attempt['files'][ext]=sha(f)

def sampler_audit(folder,lifecycle,attempts,samples,tag):
 reasons=[];folder=Path(folder)
 if lifecycle!={'started':True,'finished':True}:reasons.append('sampler_lifecycle_incomplete')
 if not (0<len(attempts)==len(samples)<=SAMPLES_PER_STATEMENT):reasons.append('sampler_attempt_count')
 expected=set()
 for index,a in enumerate(attempts):
  stem=f'{index:03d}'
  if a.get('file')!=stem or a.get('completed') is not True or a.get('returnCode')!=0:reasons.append('sampler_attempt_incomplete:'+stem)
  wire=WAIT_PRELUDE+wait_sample_sql(tag)
  if a.get('sqlSha256')!=sha_bytes(wire.encode()):reasons.append('sampler_expected_sql:'+stem)
  for ext in ('sql','stdout','stderr'):
   name=stem+'.'+ext;expected.add(name);f=folder/name
   if not f.is_file() or f.is_symlink() or a.get('files',{}).get(ext)!=sha(f):reasons.append('sampler_file_missing_or_changed:'+name)
  if index<len(samples) and all((folder/(stem+'.'+e)).is_file() for e in ('sql','stdout','stderr')):
   try:
    value=json.loads((folder/(stem+'.stdout')).read_text().strip());value['monitor']=a['monitor']
    if value!=samples[index] or (folder/(stem+'.sql')).read_text()!=wire:reasons.append('sampler_returned_file_disagreement:'+stem)
   except (ValueError,TypeError,KeyError):reasons.append('sampler_raw_evidence_malformed:'+stem)
 actual={p.name for p in folder.iterdir()} if folder.is_dir() else set()
 if actual!=expected:reasons.append('sampler_file_inventory')
 return {'verified':not reasons,'completedSamples':len(samples),'attempts':attempts,'lifecycle':lifecycle,'reasons':reasons}

def witness_sql(dense):
 names='array['+','.join(q(n) for n in dense)+']::text[]'
 row=("jsonb_build_object('attname',p.attname,'inherited',p.inherited,'nullFrac',p.null_frac,'avgWidth',p.avg_width,'nDistinct',p.n_distinct,"
  "'mostCommonVals',p.most_common_vals::text,'mostCommonFreqs',p.most_common_freqs,'histogramBounds',p.histogram_bounds::text,'correlation',p.correlation,'mostCommonElems',p.most_common_elems::text,'mostCommonElemFreqs',p.most_common_elem_freqs,'elemCountHistogram',p.elem_count_histogram)")
 raw="coalesce(jsonb_agg("+row+" order by p.attname,p.inherited),'[]'::jsonb)"
 stats="(select jsonb_build_object('rows',count(*),'rawRows',"+raw+",'sha256',encode(sha256(convert_to("+raw+"::text,'UTF8')),'hex')) from pg_stats p where p.schemaname='public' and p.tablename=c.relname)"
 return ("select jsonb_build_object('database',current_database(),'login',session_user,"+CLUSTER_FIELDS+",'at',clock_timestamp()::text,'tables',(select coalesce(jsonb_agg(jsonb_build_object('name',c.relname,'relpages',c.relpages,'reltuples',c.reltuples,"
  "'relationBytes',pg_relation_size(c.oid),'totalBytes',pg_total_relation_size(c.oid),'liveTuples',s.n_live_tup,'deadTuples',s.n_dead_tup,'modsSinceAnalyze',s.n_mod_since_analyze,'insertsSinceVacuum',s.n_ins_since_vacuum,"
  "'lastAnalyze',s.last_analyze::text,'lastAutoanalyze',s.last_autoanalyze::text,'lastVacuum',s.last_vacuum::text,'lastAutovacuum',s.last_autovacuum::text,'analyzeCount',s.analyze_count,'autoanalyzeCount',s.autoanalyze_count,"
  "'vacuumCount',s.vacuum_count,'autovacuumCount',s.autovacuum_count,'heapBlocksRead',io.heap_blks_read,'heapBlocksHit',io.heap_blks_hit,'indexBlocksRead',io.idx_blks_read,'indexBlocksHit',io.idx_blks_hit,"
  "'indexes',(select coalesce(jsonb_agg(pg_get_indexdef(i.indexrelid) order by pg_get_indexdef(i.indexrelid)),'[]'::jsonb) from pg_index i where i.indrelid=c.oid),'plannerStats',"+stats+") order by c.relname),'[]'::jsonb) "
  "from pg_class c join pg_namespace n on n.oid=c.relnamespace left join pg_stat_user_tables s on s.relid=c.oid left join pg_statio_user_tables io on io.relid=c.oid where n.nspname='public' and c.relkind in('r','p') and c.relname=any("+names+")),"
  "'databaseCounters',(select jsonb_build_object('blocksRead',d.blks_read,'blocksHit',d.blks_hit,'statsReset',d.stats_reset::text) from pg_stat_database d where d.datname=current_database()),"
  "'lagNote','cumulative statistics flush asynchronously; buffer deltas are context, never per-query EXPLAIN evidence')")

INSTANCE_SETTINGS=SETTINGS_NAMES+('shared_buffers','max_connections','autovacuum','autovacuum_naptime','track_counts','track_io_timing','effective_io_concurrency','max_worker_processes','huge_pages','server_version')
def instance_settings_sql():
 return "select coalesce(jsonb_object_agg(name,jsonb_build_object('setting',setting,'unit',unit,'source',source) order by name),'{}'::jsonb) from pg_settings where name=any(array["+','.join(q(n) for n in INSTANCE_SETTINGS)+"]::text[])"

def clone_acl_sql(s6,name,role_profile):
 require(name in CLONES.values(),'Only new characterization clone ACL construction')
 statements=['REVOKE ALL ON DATABASE '+s6.qi(name)+' FROM PUBLIC;']
 require(role_profile['database']['owner']=='postgres','Authored database owner differs')
 for entry in role_profile['database']['acl']:
  m=re.fullmatch(r'([^=]*)=([CTc]+)/postgres',entry);require(m is not None,'Unauthored database ACL')
  who,rights=m.groups();statements.append('GRANT '+','.join({'C':'CREATE','T':'TEMPORARY','c':'CONNECT'}[x] for x in rights)+' ON DATABASE '+s6.qi(name)+' TO '+(s6.qi(who) if who else 'PUBLIC')+';')
 return ''.join(statements)

def categorize(call):
 p=call.get('purpose') or ''
 for prefix,name in (('measured:','measured'),('witness:','witness'),('backend_monitor:','settlement'),('monitor_quiescence','quiescence')):
  if p.startswith(prefix):return name
 return None

def runner_wire(sql,user,monitor_budget=None):
 prelude=GATE_PRELUDE
 if monitor_budget is not None:
  milliseconds=max(1,min(2000,int(monitor_budget*1000)));prelude+=f"set statement_timeout='{milliseconds}ms';set lock_timeout='{milliseconds}ms';set search_path=public,pg_temp;\n"
 elif user!='authenticator':prelude+=INSPECTION_PRELUDE
 return prelude+sql

def account_io(calls,expected,folder,measured_specs,checkpoint_attempts,sampler_receipts,settlements):
 """Reconcile pre-issued IO intentions, actual call receipts and all persisted payload/output files.
 Counts describe complete stored payloads; ON_ERROR_STOP can leave their execution tail unknown.
 """
 folder=Path(folder);reasons=[];cats={};payload_files=set();seen_tags=set();measured=[];witness=[];per_settlement={};quiescence={}
 if len(calls)!=len(expected):reasons.append('io_call_count_mismatch')
 for i,e in enumerate(expected):
  stem=f'call-{i:05d}'
  if e.get('id')!=f'io-{i:05d}' or e.get('file')!=stem:reasons.append('expected_io_identity:'+str(i))
  if i>=len(calls):continue
  c=calls[i];category=categorize(c) or e.get('phase','unknown');group=cats.setdefault(category,{'invocations':0,'payloadStatements':0,'executionTail':'unknown_on_error_or_process_failure'});group['invocations']+=1
  if any(c.get(k)!=e.get(k) for k in ('file','database','login','purpose','zone','floatDigits')):reasons.append('io_identity_mismatch:'+stem)
  tag=c.get('applicationName')
  if not isinstance(tag,str) or TAG_PATTERN.fullmatch(tag) is None or tag in seen_tags:reasons.append('io_backend_tag_invalid:'+stem)
  seen_tags.add(tag)
  if c.get('status') not in ('returned','process_unknown','process_timeout'):reasons.append('io_completion_unknown:'+stem)
  for ext in ('sql','stdout','stderr'):
   name=stem+'.'+ext;payload_files.add(name);p=folder/name
   if not p.is_file() or p.is_symlink() or e.get('files',{}).get(ext)!=sha(p):reasons.append('io_file_missing_or_changed:'+name)
  p=folder/(stem+'.sql')
  if p.is_file():
   n=count_statements(p.read_text());group['payloadStatements']+=n
   if sha(p)!=e.get('sqlSha256') or c.get('sqlSha256')!=e.get('sqlSha256') or n!=e.get('payloadStatements'):reasons.append('io_payload_mismatch:'+stem)
   limit=EMITTED['runnerMonitorInvocation'] if category in ('settlement','quiescence') else (EMITTED['runnerInspectionInvocation'] if category=='witness' else None)
   if limit is not None and n!=limit:reasons.append('auxiliary_payload_count:'+stem)
  if category=='measured':measured.append(c)
  if category=='witness':witness.append(c['purpose'])
  if category=='settlement':per_settlement.setdefault(c['purpose'],[]).append(c)
  if category=='quiescence':quiescence.setdefault(e.get('measuredId'),[]).append(c)
 actual_files={p.name for p in folder.glob('call-*')}
 if actual_files!=payload_files:reasons.append('io_raw_file_inventory')
 if len(measured)!=len(measured_specs):reasons.append('measured_ledger_count')
 planned=measurement_plan()
 for i,spec in enumerate(measured_specs):
  if i>=len(planned) or spec!=planned[i]:reasons.append('measured_plan_identity_or_order')
  if i>=len(measured):continue
  c=measured[i]
  if c.get('purpose')!='measured:'+spec['id'] or c.get('database')!=CLONES[spec['branch']] or c.get('login')!='authenticator':reasons.append('measured_call_identity:'+spec['id'])
  n=EMITTED['apiInvocation'] if spec['kind']=='api' else EMITTED['gateInvocation']
  e=next((x for x in expected if x.get('file')==c.get('file')),{})
  if e.get('payloadStatements')!=n:reasons.append('measured_payload_count:'+spec['id'])
  monitors=per_settlement.get('backend_monitor:'+str(c.get('applicationName')),[])
  proof=[x for x in settlements if x.get('targetApplicationName')==c.get('applicationName')]
  if not (1<=len(monitors)<=SETTLEMENT_CALLS_MAX) or not proof or not any(x.get('status')=='gone' for x in proof) or c.get('backendGoneVerified') is not True:reasons.append('measured_settlement_missing:'+spec['id'])
  if not 1<=len(quiescence.get(spec['id'],[]))<=QUIESCENCE_CHECKS:reasons.append('measured_quiescence_count:'+spec['id'])
  try:
   observed=[json.loads((folder/(m['file']+'.stdout')).read_text().strip()) for m in monitors]
   recorded=[sample for p in proof for sample in p.get('samples',[])]
   if observed!=recorded:reasons.append('settlement_raw_receipt_disagreement:'+spec['id'])
   quiet=quiescence.get(spec['id'],[])
   if not quiet or json.loads((folder/(quiet[-1]['file']+'.stdout')).read_text().strip())!=[]:reasons.append('quiescence_not_proved:'+spec['id'])
  except (OSError,ValueError,KeyError,TypeError):reasons.append('monitor_raw_receipt_missing:'+spec['id'])
 allowed_witnesses=['witness:'+name+':'+branch for name in (*PAIRED_CHECKPOINTS,'final') for branch in ('A','B')]
 if witness!=checkpoint_attempts or len(witness)>8 or len(set(witness))!=len(witness) or any(p not in allowed_witnesses for p in witness):reasons.append('witness_ledger_mismatch')
 elif witness!=sorted(witness,key=allowed_witnesses.index):reasons.append('witness_ledger_order')
 if set(quiescence)-{x['id'] for x in measured_specs}:reasons.append('unexpected_quiescence_identity')
 if any(len(v)>SETTLEMENT_CALLS_MAX for v in per_settlement.values()):reasons.append('settlement_over_ceiling')
 sampler_ids=[x['id'] for x in sampler_receipts]
 if sampler_ids!=[x['id'] for x in measured_specs]:reasons.append('sampler_ledger_identity')
 wait_root=folder/'wait-samples';dirs={x.name for x in wait_root.iterdir()} if wait_root.is_dir() else set()
 if dirs!=set(sampler_ids):reasons.append('sampler_directory_inventory')
 for receipt in sampler_receipts:
  audit=sampler_audit(wait_root/receipt['id'],receipt['lifecycle'],receipt['attempts'],receipt['samples'],receipt['applicationName'])
  if not audit['verified']:reasons+=['sampler:'+receipt['id']+':'+r for r in audit['reasons']]
 return {'verified':not reasons,'measuredIds':[x['id'] for x in measured_specs],'categories':cats,'calls':expected,'samplerReceipts':sampler_receipts,'payloadStatementMeaning':'complete stored psql input, NOT proof of server dispatch/execution; tail unknown on failure'},reasons

class Report:
 def __init__(self,path):
  self.path=Path(path);require(self.path.is_absolute() and self.path.name==REPORT_NAME and not self.path.parent.exists(),'New absolute output directory required')
  require(ROOT.resolve() not in self.path.resolve().parents,'Runtime output must be outside the reviewed source tree')
  self.path.parent.mkdir(parents=True,exist_ok=False)
  self.value={'status':'running','stage':'initial_before_contact','method':METHOD,'checks':0,'labels':[],'calls':[],'sessions':[],'cases':[],'branches':{},'databaseContacted':False,
   'historicalDataReproduced':False,'full20Complete':False,'full42Complete':False,'full65Complete':False,'providerAcceptance':False,
   'primaryAcceptanceSatisfied':False,'restorationClaimed':False,'dropIssued':False,'clonesRetained':None,'disposalIsNotRestoration':True,
   'failedInstancePhysicalStatisticsKnown':False,'hardwareHistoryKnown':False,'omittedGenuineSeamHistory':list(OMITTED_SEAM_HISTORY),'scriptSha256':sha(__file__)};self.persist()
 def persist(self,stage=None):
  if stage:self.value['stage']=stage
  tmp=self.path.with_suffix('.tmp');tmp.write_text(json.dumps(self.value,indent=2)+'\n');tmp.replace(self.path)
 def check(self,ok,label):require(ok,label);self.value['checks']+=1;self.value['labels'].append(label);self.persist()

def runner_class(s6):
 class CharRunner(s6.Runner):
  def __init__(self,target,report,database,execute=subprocess.run):
   require(database in {*CLONES.values(),s6.BASE,'postgres'},'Unapproved characterization database')
   self.target=target;self.report=report;self.database=database;self.execute=execute
   self.env={k:v for k,v in os.environ.items() if not k.startswith('PG')};self.env['PGCONNECT_TIMEOUT']='3'
  def at(self,database):return CharRunner(self.target,self.report,database,self.execute)
  def run(self,sql,user='postgres',zone='UTC',digits=1,error=None,message=None,purpose=None,monitor_budget=None):
   expectations=self.report.value.setdefault('ioExpected',[]);i=len(expectations);wire=runner_wire(sql,user,monitor_budget)
   entry={'id':f'io-{i:05d}','file':f'call-{i:05d}','database':self.database,'login':user,'zone':zone,'floatDigits':digits,'purpose':purpose,'sqlSha256':sha_bytes(wire.encode()),'payloadStatements':count_statements(wire),'phase':self.report.value.get('ioPhase','setup'),'measuredId':self.report.value.get('ioMeasuredId'),'files':{}}
   expectations.append(entry);self.report.persist('before_expected_io')
   try:return super().run(sql,user=user,zone=zone,digits=digits,error=error,message=message,purpose=purpose,monitor_budget=monitor_budget)
   finally:
    for ext in ('sql','stdout','stderr'):
     p=self.report.path.parent/(entry['file']+'.'+ext)
     if p.is_file():entry['files'][ext]=sha(p)
    self.report.persist()
 return CharRunner

class PgIO:
 def __init__(self,s6,target,report,profile6,variants,genuine,genuine_state,expected_treatment,sleep=time.sleep):
  self.s6=s6;self.target=target;self.report=report;self.genuine=genuine;self.genuine_state=genuine_state;self.dense=[x['name'] for x in genuine['denseTables']];self.sleep=sleep
  self.ex=s6.Executor(target,report,profile6,variants);self.variants=variants;Char=runner_class(s6)
  self.runners={k:Char(target,report,v) for k,v in CLONES.items()};self.setup_reasons=[];self.post_setup={};self.cluster=None;self.historical_reproduced=False
  self.setup_end=None;self.final_start=None;self.expected_treatment=expected_treatment;self.measured_specs=[];self.checkpoint_attempts=[];self.sampler_receipts=[]
  self.ex.r=Char(target,report,s6.BASE);self.ex.admin=self.ex.r.at('postgres')
 def persist(self,key,value,stage=None):self.report.value[key]=value;self.report.persist(stage)
 def setup(self):
  ex=self.ex;identity,old=ex.verify_infrastructure();self.cluster={'systemIdentifier':identity['systemIdentifier'],'postmasterStart':identity['postmasterStart']}
  self.persist('environment',{'cpuCount':os.cpu_count(),'platform':platform.platform(),'runner':{k:os.environ.get(k) for k in ('RUNNER_OS','RUNNER_ARCH','RUNNER_NAME','RUNNER_ENVIRONMENT','ImageOS','ImageVersion')},'memoryBytes':(os.sysconf('SC_PAGE_SIZE')*os.sysconf('SC_PHYS_PAGES')) if hasattr(os,'sysconf') else None})
  self.persist('instanceSettings',ex.admin.json(instance_settings_sql(),user='supabase_admin'))
  ex.fixture=ex.make_fixture(ex.r);ex.fixture.seed();ex.catalog(ex.r,old)
  base=ex.fingerprint(ex.r);self.persist('baseState',base,'seeded_before_clones')
  deltas=historical_deltas(base,self.genuine_state);self.historical_reproduced=deltas['historicalDataReproduced']
  self.persist('historical',dict(deltas,policy='inventory and genuine counts gate exact lineage; whole-row hash differences retained as evidence with unknown cause'));self.report.value['historicalDataReproduced']=self.historical_reproduced
  lineage=historical_gate(deltas)
  if lineage:self.persist('lineageFailures',lineage);raise SetupInconclusive('Fresh fixture relation inventory or genuine counts differ; exact constructor lineage not established')
  role_profile=json.loads((self.s6.HERE/'pinned-repository/scripts/fixtures/work-activity-engine-role-parity.json').read_text())
  for kind,name in CLONES.items():
   require(ex.admin.json('select not exists(select 1 from pg_stat_activity where datname='+q(self.s6.BASE)+')',user='supabase_admin') is True,'Template has another connection; never terminate it')
   self.report.value['branches'][kind]={'name':name,'stage':'before_create'};self.report.persist('before_clone_'+kind)
   ex.admin.run('create database '+self.s6.qi(name)+' with template '+self.s6.qi(self.s6.BASE)+' owner postgres;',user='supabase_admin',purpose='setup:clone:'+kind)
   ex.admin.run(clone_acl_sql(self.s6,name,role_profile),user='postgres',purpose='setup:clone_acl:'+kind)
   r=self.runners[kind];clone=ex.identity(r);self.s6.same_cluster(identity,clone);require(clone['databaseOid']!=identity['databaseOid'],'Clone must have distinct OID')
   acl=r.json("select jsonb_build_object('owner',pg_get_userbyid(datdba),'acl',to_jsonb(datacl::text[])) from pg_database where datname=current_database()")
   require(acl['owner']=='postgres' and sorted(acl['acl'])==sorted(role_profile['database']['acl']),'Clone ACL differs from authored construction')
   ex.catalog(r,old);require(ex.fingerprint(r)==base,'Clone starting state differs')
   self.report.value['branches'][kind].update(identity=clone,stage='cloned',installed=False);self.report.persist()
  self.install_b(old)
  contexts={}
  for kind in ('A','B'):
   r=self.runners[kind];before=ex.context(r)
   ex.authority_set(r,True);ex.authority_set(r,False)
   contexts[kind]={'before':before,'after':ex.context(r),'rawAuthority':r.json('select to_jsonb(a) from work_activity_authority_generation a where singleton')}
  self.persist('authorityContexts',dict(contexts,exception='only the authority raw hash may differ; relation kind and count must match; singleton rows and complete relation fingerprints retained'))
  if contexts['A']['after']!=contexts['B']['after'] or contexts['A']['after']['authority'].get('capture_enabled') is not False:raise SetupInconclusive('Consumed authority context differs between A and B')
  fa,fb=ex.fingerprint(self.runners['A']),ex.fingerprint(self.runners['B']);self.post_setup={'A':fa,'B':fb}
  reasons,treatment=shared_state(fa,fb);self.persist('treatmentOnlyRelations',treatment)
  if reasons:self.persist('sharedStateDifferences',reasons);raise SetupInconclusive('Fresh A/B raw shared state differs outside the declared authority exception')
  missing=treatment_gate(fa,fb,self.expected_treatment)
  if missing:self.persist('missingTreatmentRelations',missing);raise SetupInconclusive('Expected candidate relations missing from B')
  dense=historical_gate(historical_deltas(fa,self.genuine_state))
  if dense:self.persist('postSetupLineageFailures',dense);raise SetupInconclusive('Post-setup A counts drifted from genuine lineage')
  counts,hashes=metadata_gate(fb,self.genuine['metadataTables'])
  contract=next((e for e in fb if (e['schema'],e['name'])==('public','_work_unit_metadata_contract')),None)
  self.persist('metadataWitness',{'countMismatches':counts,'hashDifferencesRecordedOnly':hashes,'freshContractRowFingerprint':contract,'runtimeSemanticsFrom':'pinned inactive installation SQL and exact authored catalog lineage, not learnt from the fresh row'})
  if counts:raise SetupInconclusive('B metadata row counts differ from the genuine inactive install')
  self.setup_end=len(self.report.value['calls']);self.report.value['ioPhase']='measurement';self.report.persist('setup_complete_before_measurement')
 def install_b(self,old):
  ex=self.ex;r=self.runners['B'];expected=self.variants['inactive']
  ex.catalog(r,old);self.report.value['branches']['B']['installationAttempted']=True;self.report.persist('before_inactive_install')
  try:r.run(self.s6.committed_fixture_sql(expected['sql']),purpose='setup:install:inactive')
  except BaseException:
   call=next(c for c in reversed(self.report.value['calls']) if c.get('purpose')=='setup:install:inactive')
   r.wait_backend_gone(call);raise SetupInconclusive('Inactive candidate install failed; no repair attempted') from None
  ex.catalog(r,expected['catalog'],True)
  authored=r.json("select to_jsonb(encode(sha256(convert_to("+q(encoded(expected['catalog']))+"::jsonb::text,'UTF8')),'hex'))")
  require(authored==expected['root'],'Authored canonical root differs on PG17');self.report.value['branches']['B'].update(installed=True,authoredRoot=authored);self.report.persist()
 def witness(self,name):
  out={}
  for kind in ('A','B'):
   purpose='witness:'+name+':'+kind;self.checkpoint_attempts.append(purpose)
   out[kind]=self.runners[kind].json(witness_sql(self.dense),user='supabase_admin',purpose=purpose)
  self.report.value.setdefault('witnesses',{})[name]=out;self.report.persist('witness_'+name);return out
 def run_measured(self,spec,sql):
  self.measured_specs.append(dict(spec));self.report.value['ioMeasuredId']=spec['id']
  r=self.runners[spec['branch']];stop=threading.Event();holder={};t=self.target
  uri=urlunparse((t.scheme,f'supabase_admin:fixture-only@{t.hostname}:5432','/postgres','','',''))
  def execute(args,**kw):
   sampler=WaitSampler(uri,r.env,self.report.path.parent/'wait-samples'/spec['id']);thread=threading.Thread(target=sampler.run,args=(kw['env']['PGAPPNAME'],stop),daemon=True)
   holder.update(sampler=sampler,thread=thread);thread.start()
   try:return subprocess.run(args,**kw)
   finally:stop.set();thread.join(timeout=5)
  raw={'processTimeout':False};r.execute=execute
  try:r.run(sql,user='authenticator',zone='UTC',digits=1,purpose='measured:'+spec['id'])
  except subprocess.TimeoutExpired:raw['processTimeout']=True
  except RuntimeError:pass
  finally:r.execute=subprocess.run
  call=self.report.value['calls'][-1];require(call.get('purpose')=='measured:'+spec['id'],'Measured call record ambiguous')
  stem=self.report.path.parent/call['file']
  raw.update(call=call,returnCode=call.get('returnCode'),stdout=stem.with_suffix('.stdout').read_text() if stem.with_suffix('.stdout').exists() else '',stderr=stem.with_suffix('.stderr').read_text() if stem.with_suffix('.stderr').exists() else '')
  sampler,thread=holder.get('sampler'),holder.get('thread');raw['samples']=list(sampler.samples) if sampler else []
  stopped=thread is not None and not thread.is_alive()
  receipt={'id':spec['id'],'applicationName':call['applicationName'],'samples':raw['samples'],'attempts':sampler.attempts if sampler else [],'lifecycle':{'started':bool(sampler and sampler.started),'finished':bool(sampler and sampler.finished)}}
  self.sampler_receipts.append(receipt)
  raw['samplerAudit']=sampler_audit(self.report.path.parent/'wait-samples'/spec['id'],receipt['lifecycle'],receipt['attempts'],receipt['samples'],receipt['applicationName'])
  try:r.wait_backend_gone(call);settled=True
  except BaseException:settled=False
  monitors=[c for c in self.report.value['calls'] if c.get('purpose')=='backend_monitor:'+call['applicationName']]
  raw['settled']=settled and len(monitors)<=SETTLEMENT_CALLS_MAX;raw['quiescent']=stopped and self.monitor_quiescent()
  self.report.value.setdefault('measured',[]).append(dict(receipt,settled=raw['settled'],quiescent=raw['quiescent'],samplerAudit=raw['samplerAudit']));self.report.value['ioMeasuredId']=None;self.report.persist('measured_'+spec['id'])
  return raw
 def monitor_quiescent(self):
  for _ in range(QUIESCENCE_CHECKS):
   try:rows=self.ex.admin.json("select coalesce(jsonb_agg(application_name order by application_name),'[]'::jsonb) from pg_stat_activity where application_name like "+q(MONITOR_PREFIX+'%'),user='supabase_admin',monitor_budget=2,purpose='monitor_quiescence')
   except BaseException:return False
   if rows==[]:return True
   self.sleep(SAMPLE_INTERVAL_SECONDS)
  return False
 def settle_pending(self):
  errors=[]
  for call in [c for c in self.report.value['calls'] if not c.get('backendGoneVerified',False) and (c.get('requiresBackendSettlement',False) or c.get('status') in ('waiting','process_timeout','process_unknown'))]:
   r=self.runners[next(k for k,v in CLONES.items() if v==call['database'])] if call['database'] in CLONES.values() else self.ex.r.at(call['database'])
   try:r.wait_backend_gone(call)
   except BaseException as e:errors.append({'applicationName':call.get('applicationName'),'message':str(e)})
  return errors
 def final_checks(self):
  self.final_start=len(self.report.value['calls']);self.report.value['ioPhase']='final_inspection';self.report.value['ioMeasuredId']=None;reasons=[];ex=self.ex
  errors=self.settle_pending()
  if errors:self.persist('unresolvedSettlement',errors);return ['uncertain_backend_settlement']
  for kind in ('A','B'):
   if self.post_setup.get(kind) is not None and ex.fingerprint(self.runners[kind])!=self.post_setup[kind]:reasons.append('persistent_state_changed_by_reads:'+kind)
  if ex.initial_global is not None and ex.admin.json(self.s6.GLOBAL,user='supabase_admin')!=ex.initial_global:reasons.append('global_roles_or_settings_changed')
  inventory=ex.admin.json('select jsonb_agg(datname order by datname) from pg_database',user='supabase_admin')
  if not set(inventory)<={'postgres','template0','template1',self.s6.BASE,*CLONES.values()}:reasons.append('unexpected_database_inventory')
  self.report.value.update(finalDatabaseInventory=inventory,clonesRetained=set(CLONES.values())<=set(inventory),dropIssued=False);self.report.persist('final_checks')
  return reasons
 def accounting(self):
  cats,reasons=account_io(self.report.value['calls'],self.report.value.get('ioExpected',[]),self.report.path.parent,self.measured_specs,self.checkpoint_attempts,self.sampler_receipts,self.report.value.get('backendSettlement',[]))
  self.persist('statementAccounting',dict(cats,reasons=reasons));return cats,reasons

# ---------------------------------------------------------------------- main
def prepare(profile_path=PROFILE,execute=False,base=ROOT):
 profile=json.loads(Path(profile_path).read_text());validate_profile(profile)
 inputs,pending=validate_inputs(profile,execute,base)
 summary={'pendingPins':pending,'plan':[x['id'] for x in measurement_plan()]}
 if 'observations' in inputs and 'observations' not in pending:
  observations=json.loads(inputs['observations'].read_text());cross_check_observations(profile,observations);summary['genuineState']=observations['baselineState']
 if 'expectedTreatment' in inputs:
  inventory=json.loads(inputs['expectedTreatment'].read_text());summary['expectedTreatment']=inventory['catalogMinusGenuineBaseline']
  require(inventory['createMatchesDelta'] is True and all(inventory['candidatePinsVerified'].values()) and inventory['newSequenceCount']==0 and inventory['authRelationsAllowedToBeAdded']==[],'Authored inventory proof incomplete')
 if 'exactGate' in inputs:
  body=gate_body(inputs['exactGate'].read_bytes(),profile['inputs']['exactGate']['sha256']);copy=notice_copy(body)
  summary.update(gateBody=body,noticeCopy=copy,noticeCopySha256=sha_bytes((GATE_PRELUDE+copy).encode()))
 return profile,inputs,summary

def main(argv=None):
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--check-plan',action='store_true');parser.add_argument('--execute-characterization',action='store_true');parser.add_argument('--output');args=parser.parse_args(argv)
 require(not(args.check_plan and args.execute_characterization),'Mutually exclusive modes')
 if not args.execute_characterization:
  require(args.output is None,'Plan mode creates no runtime receipt');profile,_,summary=prepare()
  print(encoded({'status':'CHARACTERIZATION_PLAN_VALIDATED_SOURCE_ONLY','method':METHOD,'databaseContacted':False,'measuredPlan':summary['plan'],'pendingPins':summary['pendingPins'],'noticeCopySha256':summary.get('noticeCopySha256'),'accounting':profile['accounting'],'claims':profile['claims']}));return 0
 require(args.output,'Explicit fresh output path required');report=Report(args.output);io=None
 try:
  profile,inputs,summary=prepare(execute=True);report.value.update(profileSha256=sha(PROFILE),noticeCopySha256=summary['noticeCopySha256']);report.persist('source_validated_before_target')
  s6=load_module(inputs['source6Executor'],'reviewed_source6_executor');require(Path(s6.PROFILE).resolve()==inputs['source6Profile'],'Source6 profile path is not the pinned profile')
  profile6,variants=s6.validate_source();target=s6.validate_target(os.environ.get('WORK_ACTIVITY_ROLE_TEST_DB_URL',''))
  io=PgIO(s6,target,report,profile6,variants,profile['genuine'],summary['genuineState'],summary['expectedTreatment'])
  try:io.setup()
  except SetupInconclusive as e:
   report.value.update(status='inconclusive_setup_not_established',inconclusive=str(e),settlementErrors=io.settle_pending());io.accounting();report.persist('stopped_before_measurement');return 2
  result=Characterization(io,io.dense,profile['inputs']['exactGate']['sha256'],summary['gateBody'],summary['noticeCopy']).run()
  valid=result['characterization']['status']=='valid'
  report.value.update(status='characterization_valid_diagnostic_only' if valid else 'characterization_inconclusive',characterization=result);report.persist('complete_diagnostic_only');return 0 if valid else 3
 except BaseException as e:
  report.value.update(status='failed',failure={'type':type(e).__name__,'message':str(e)})
  if io is not None:
   try:report.value['settlementErrors']=io.settle_pending()
   except BaseException as inner:report.value['settlementErrors']=[{'message':str(inner)}]
  if io is not None:
   try:io.accounting()
   except BaseException as audit_error:report.value['accountingFailure']={'message':str(audit_error)}
  report.persist('failed');raise
if __name__=='__main__':raise SystemExit(main())
