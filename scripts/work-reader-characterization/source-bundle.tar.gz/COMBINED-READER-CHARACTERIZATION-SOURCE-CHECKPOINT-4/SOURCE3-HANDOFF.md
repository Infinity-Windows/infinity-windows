# Source3 handoff

Outcome: F1-F4 implemented in a new checkpoint using a central claim gate and explicit IO/sampler receipts. Source1, Source2, both reviews and prerequisites are unchanged. Source3 is HELD for root independent verification and actual Opus/Fable review; no PostgreSQL run or dispatch occurred.

## Changes

- F1: every interpreted claim uses the same complete whole-characterization gate. Unknown final data/global/identity/evidence/settlement/accounting premises suppress all interpretation, including pairedScope. Partial numeric timings are retained.
- F2: sampler lifecycle, ordered attempts, nonzero completed sample count, exact SQL/stdout/stderr membership/hashes and returned-data agreement are validated at the measured call and rechecked during final accounting. Explicit valid empty-backend samples remain allowed. Timeout partial output is preserved.
- F3: an audited CharRunner wraps the unchanged source6 Runner for every setup, inspection, measured and final call. It records the expected identity/digest before execution, captures raw-file receipts afterward, then reconciles the expected and actual ledgers. Auxiliary4-statement payloads and sample3-statement payloads are enforced. Setup refusals and exceptions still emit accounting. Payload counts describe stored input; ON_ERROR_STOP leaves later dispatch/execution unknown.
- F4: exact schema/name/kind treatment delta is pinned to review2's17-table derivation. No extra public/auth relation or new sequence is accepted. A's entire historical relation inventory/count gate is preserved. `freshRawContract` was renamed `freshContractRowFingerprint`.

## Validation

55/55 offline controls pass. No denied-contact attempts occurred. Check-plan exits0, all10 inputs pinned, no pending pins. Controls include prior review counterexamples, all17 treatment removals, wrong kind, extra public/auth/sequence, genuine positive and censored cases, raw-file loss/change/extra files, missing or duplicate IO, wrong auxiliary counts, zero samples, sampler timeout partial output, setup-refusal/exception accounting, and real source6 Runner plus real PgIO-adapter fake-execution receipts. Original byte-exact gate SHA remains a6e7cd11479e38b441b5fabe063470ff9a0ef0fc883db1d14e7d5c6c1d79f986.

42 retained/adapted Source2 tests plus13 new central-gate/ledger tests give55. One old high-level account test was replaced by stronger ordered-ledger/raw-file controls; no safety acceptance was removed. The old post_round2 check now requires withheld conclusions while retaining raw pairs.

Implementation test adjustments: the first guarded harness import needed unittest.mock's standard-library SSL classes imported before replacing socket.socket. The first complete suite then exposed two stale fixture assumptions (relative fake profile path and old assertion that partial raw pairs disappear); both were corrected. No actual process/network attempt occurred in either iteration.

Source3 implementer is Codex Astra, not Claude. Prior actual Opus Source2 contribution remains separate. No new peer receipt is claimed; root will obtain actual Opus/Fable checks of this sealed revision.

## Holds and next action

Real PG17 SQL/NULL and psql/NOTICE behavior are unverified. Source6 builders were not run. Two-round timing is current-fixture evidence only and cannot recreate or refute the historical timeout. All full-trial/provider/release/restoration holds remain. Root verifies manifest/pins, obtains independent peer reconciliation, then packages or dispatches within the existing authorized disposable scope. No repeated policy approval is inferred.
