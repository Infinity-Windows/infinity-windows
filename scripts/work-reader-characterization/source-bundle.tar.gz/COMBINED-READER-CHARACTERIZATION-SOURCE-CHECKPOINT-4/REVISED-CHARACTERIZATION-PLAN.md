# Revised characterization plan: the current-fixture paired raw A/B method

**Method identifier:** `current_fixture_paired_raw_ab_v3`.

This revises the setup gate of frozen plan3. Plan3 itself is unchanged and stays pinned as historical input. The method was conditionally approved in `COMBINED-READER-CHARACTERIZATION-SAFETY-REVIEW-1/REVIEW.md`. This document authorizes no execution; root owns pins, offline controls, the Fable count/settings gate, packaging and dispatch.

## Question answered

The experiment asks one thing: on this fresh shared fixture, under the observed conditions, what difference does the authored inactive candidate (B) make compared with authentic common0846 (A)?

It does **not**:
- recreate the failed instance;
- replay historical row data;
- refute the original timeout;
- establish a universal regression or an equivalence.

## Why the historical hash gate was replaced

The unchanged contributors builder stamps `opening_phases` rows with `now()`, and the legacy seed uses `clock_timestamp()`. Source6 hashes whole rows. Exact historical whole-row hashes therefore cannot reliably be reproduced on a fresh run.

The method does not normalize, drop timestamp columns, alter clocks or reduce volume. Instead it keeps every historical difference as evidence and gates on exact lineage plus mutual A/B equality.

## Setup gates (any failure: exit 2, zero measured calls)

1. **Inputs.** All pinned inputs validate, and every `ROOT_MUST_PIN` fails closed. The source6 `validate_source()` and `validate_target()` checks are unchanged (source1, approved-source3, prerequisite, variant, catalog and security pins; localhost:5432 fixture target). The profile's genuine witnesses are cross-checked against frozen OBSERVATIONS, including the full `baselineState`.
2. **Fresh infrastructure and seed.** Source6 checks a fresh four-database PG17 cluster with the authored roles and settings. The unchanged source6/legacy seed runs, followed by the old-catalog exact check.
3. **Lineage.** The fresh relation inventory must equal the frozen `baselineState` inventory, and every relation count must equal its genuine count. All count and whole-row hash differences are retained, each with cause `unknown_not_separately_proved`. `historicalDataReproduced` is true only if no difference exists; otherwise it is false.
4. **Clones.** A and B are new, uniquely named clones of the seeded template, with the authored ACL and old catalog. Each clone's full raw fingerprint must equal the template's.
5. **Treatment.** B alone receives the pinned authored inactive SQL. The exact authored combined catalog bytes and canonical root are verified on PG17.
6. **Authority.** A and B each receive the same two owner authority transitions (true, then false). The consumed authority context must be equal, with capture disabled. Both singleton authority rows and complete relation fingerprints are retained. Only the authority raw hash may differ; relation kind and count must match.
7. **Mutual raw equality.**
   - Every shared relation's full raw fingerprint must be equal in A and B, except the authority raw hash; its count and kind must still match.
   - Every B-only relation is recorded, and the exact authored17 schema/name/kind tuples from the pinned review2 inventory must be the B-only delta; no other public/auth relation or sequence is allowed.
   - A's counts must still equal the genuine counts.
   - B's metadata row counts must equal the genuine counts. The fresh raw contract row is recorded; runtime semantics come from the pinned install, not from that row.

## Measurement (unchanged from plan3)

Exactly 20 measured invocations, in this order:

1. Round 1: A then B. Round 2: B then A. Each branch runs totals, contributors, review (visible unit) and review (missing unit).
2. Only after both rounds **and** a valid post_round2 checkpoint, B runs:
   - metadata twice;
   - the byte-exact original `call-01300` (wire SHA equals the pin);
   - the NOTICE-only copy (wire SHA equals the derived copy pin; only twenty markers are added around the ten reader assignments).

Rules: hard ceiling 24, reserve unused, no float0 extras, no retries, no repeat trial. Every API invocation runs in a fresh authenticator/authenticated session with the original JWT, UTC, float1, read committed and 8s/8s, all proven in-band.

## Immediate fail-close (R1)

| Trigger | When it stops |
|---|---|
| Schema or physical/planner mismatch at pre_round1 | 0 measured calls |
| Mismatch at post_round1 | After 8 calls |
| Mismatch at post_round2 | After 16 calls, before any B-only work |
| A lost, failed or malformed wait sample | At that call (first call means 1 executed) |
| Ungranted lock, blocker or Lock-class wait | At that call |
| Session settings differ from the first API connection | At the earliest differing call |
| Non-IO wait class differs within an A/B pair | Once the pair completes |
| Uncertain settlement, non-quiescent monitor, unclassified/lock/process outcome, identity/evidence failure, original assertion failure, wire-hash change, NOTICE evidence loss | At that call |

After any stop, bounded settlement and final evidence are still collected.

## Validity (R2)

The characterization is valid only when all of these hold:
- there is no stop;
- all 20 invocations completed with classified outcomes and validated evidence;
- the final witness is schema-valid;
- no final or accounting reasons were raised.

Otherwise it is **inconclusive**. After any unknown or failed premise, `pairedScope` contains raw numeric observations only; every interpreted conclusion is withheld. A single central whole-characterization gate requires a verified ordered IO ledger, complete validated samples and all final integrity checks before any causal, inherited-limit, or no-demonstrated-regression claim. Aggregate interpretation is emitted only for a valid whole characterization. A classified original gate assertion failure is a diagnostic result, not a passing assertion.

## NOTICE evidence (R3)

The twenty expected descriptors (phase, index and function) are derived from the validated copy, and every marker needs a valid ordered UTC timestamp.

| Case | Treatment |
|---|---|
| Copy returns successfully | All twenty markers required |
| Cancellation or classified assertion failure | A non-empty exact prefix is required. It is recorded as censored, the original error is preserved, and localization is withheld beyond the last observed marker |
| Zero markers, wrong function/order/phase, malformed timestamp, or garbled/unexpected NOTICE line | Evidence lost; stop |

## Schemas (R4)

- **Wait samples** must carry timestamp, cluster identity, monitor login `supabase_admin` with visibility of all backends, the target tag, and backend rows whose pid and backendStart match the measured login receipt. An explicit empty backends array is valid. Zero active samples is disclosed as coverage, not as proof of no waits.
- **Witnesses** must carry database/login/cluster identity and exactly one row per dense table with typed physical fields. Null is accepted only for:
  - analyze/vacuum timestamps (never run since this clone's statistics began);
  - index block counters (no index).
- **Planner statistics** are kept as raw sorted rows together with their SQL hash.

## Statement accounting (R5)

| Invocation type | Top-level statements |
|---|---|
| Measured API | 9 (8 auxiliary + 1 measured) |
| Gate or copy | 11 (5 identity + BEGIN + 3 fixture SET + measured DO + COMMIT) |
| Inspection or monitor call | 4 (3 runner SET + 1 SELECT) |
| Wait sample | 3 |

- **Ceilings:** 20 measured, 8 witness calls, 36 samples and 8 quiescence checks per measured invocation, 64 settlement monitors per measured invocation.
- **Runtime:** actual emitted counts are recomputed from the stored wire files. Setup and final inspection are enumerated by phase and never labelled measured.

## Interpretation (unchanged thresholds)

- **Bounded current-fixture signal:** B/A ≥ 1.25 **and** B − A ≥ 250 ms on psql elapsed, in both rounds.
- **Inherited limit:** the same API times out in both A and B in a round.
- **Censored timeouts:** never produce a ratio.
- **Exact gate:** diagnostic reproduction only.

## Retained limitations (machine-readable in the output)

- Fresh fixture only.
- Omitted from the genuine seam: the capability active/closing_only fixtures, the float0 paid-reader and private-coverage fixtures, and the predecessor 47/66 template workloads.
- Failed-instance physical statistics and hardware history are unknown.
- `full20/42/65Complete`, `providerAcceptance`, `primaryAcceptanceSatisfied` and `restorationClaimed` are always false.
- Clones are retained and no DROP is issued. Disposal is not restoration.

## Source3 evidence closure

Every measured invocation requires a started-and-finished sampler with at least one completed schema-valid attempt. Raw SQL/stdout/stderr membership, hashes and returned sample agreement are exact. A valid empty backend array is permitted; no sampler or zero attempts is evidence loss. Cadence remains at most4Hz and at most36 attempts. Source6 builders, security contracts, budgets, fixed20 order and both gate payloads are unchanged. All original baseline counts remain hard gates. No production, full-trial acceptance, provider or restoration claim is added.

## Source4 claim projection corrections

An inconclusive whole characterization replaces exact-gate, NOTICE-copy and metadata diagnostic labels with `withheld_whole_characterization_inconclusive` in every public record and alias. Numeric paired comparisons retain timings, ratios and deltas but use `threshold_not_evaluated`; timeout censoring facts remain visible. No change to the fixed plan, wire, NOTICE, authentication, budgets, inventory or acceptance gates.
