"""Run source-only controls with every actual process/network entry point denied."""
from pathlib import Path
import contextlib,hashlib,importlib.util,io,json,os,socket,subprocess,sys,tempfile,unittest
import unittest.mock  # import standard-library SSL classes before replacing socket constructor
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
DENIED=[]
def deny(*args,**kwargs):
 DENIED.append('process_or_network_call_denied');raise AssertionError('Offline controls deny actual process/network contact')
subprocess.run=deny;subprocess.Popen=deny;socket.socket=deny;socket.create_connection=deny;os.system=deny
for name in ('fork','forkpty','posix_spawn','posix_spawnp','execv','execve','execl','execlp','execvp','execvpe','spawnv','spawnve','spawnvp','spawnvpe','popen'):
 if hasattr(os,name):setattr(os,name,deny)
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
with tempfile.TemporaryDirectory(prefix='.offline-',dir=HERE) as scratch:
 tempfile.tempdir=scratch
 suite=unittest.TestSuite()
 for name in ('test_characterization_executor','test_evidence_ledger','test_source4_corrections'):
  module=load(HERE/(name+'.py'),name);suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
 stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
 (HERE/'OFFLINE-TESTS.txt').write_text(stream.getvalue())
 x=load(HERE/'characterization_executor.py','source4_plan_check');plan=io.StringIO()
 with contextlib.redirect_stdout(plan):code=x.main(['--check-plan'])
 (HERE/'CHECK-PLAN.json').write_text(plan.getvalue())
 value={'testsRun':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'passed':result.wasSuccessful(),'checkPlanExit':code,'blockedActualContactAttempts':DENIED,'databaseContacted':False,'realProcessSpawned':False,'sourceSha256':hashlib.sha256((HERE/'characterization_executor.py').read_bytes()).hexdigest(),'profileSha256':hashlib.sha256((HERE/'characterization-profile.json').read_bytes()).hexdigest()}
 (HERE/'VALIDATION.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))
 sys.exit(0 if result.wasSuccessful() and not DENIED and code==0 else 1)
