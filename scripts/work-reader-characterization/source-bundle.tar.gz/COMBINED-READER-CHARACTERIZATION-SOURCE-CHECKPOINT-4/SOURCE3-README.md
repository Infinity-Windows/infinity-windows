# Reader characterization Source3 — held source

Source3 uses a single whole-characterization evidence gate. Any missing final integrity or IO evidence withholds every candidate-dependent, inherited-limit and no-demonstrated-regression interpretation. Raw timings remain available, labelled as observations.

The pre-issued IO ledger reconciles actual measured/checkpoint/setup/final calls, exact SQL/stdout/stderr files and hashes, sampler attempts, backend settlement and quiescence. Each measured invocation requires at least one completed valid sample. An explicit empty backend array is supported; missing attempts are not.

The candidate delta is exactly17 authored public regular tables from pinned review2 evidence, with zero extra auth relations or sequences. Genuine relation inventory and all baseline counts remain conservative hard gates. The unchanged source6 validation/security/fixture contracts, fixed20 order, byte-exact compound gate,8s/8s and35s budgets remain intact.

Run `python3 run_offline_controls.py` from this directory for offline controls. It denies actual process/network entry points, uses temporary files inside this checkpoint and cleans them, and writes OFFLINE-TESTS.txt, CHECK-PLAN.json and VALIDATION.json. No fixture constructor, database, psql process or CI action is executed. Re-running changes validation artifacts and therefore requires resealing the manifest.

Current result:55/55 tests; check-plan exits0 with no pending pins. The four original pending pins plus review2/inventory are closed against actual files. Actual PG17 execution, psql/NOTICE formatting, statistics null behavior, scheduling under load and CI packaging remain unverified. Root owns actual Opus/Fable review, packaging and any disposable dispatch. This checkpoint does not authorize or prove full20/42/65, provider acceptance, release, or restoration.
