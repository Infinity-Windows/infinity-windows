#!/usr/bin/env python3
"""Offline controls for the held current-fixture reader characterization executor.
No database, psql, network or CI contact. Fakes stand in only for the runner/IO
boundary; every assertion exercises the real executor functions. Each Rn class
encodes the safety-review negative controls as failure-boundary proofs."""
import copy,datetime,importlib.util,json,re,sys,tempfile,threading,types,unittest
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
_spec=importlib.util.spec_from_file_location('characterization_executor_under_test',HERE/'characterization_executor.py')
X=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(X)
PROFILE=json.loads((HERE/'characterization-profile.json').read_text())
GATE_PIN=PROFILE['inputs']['exactGate']['sha256']
GATE_BYTES=X.resolve_input(PROFILE['inputs']['exactGate']['path']).read_bytes()
GATE_BODY=X.gate_body(GATE_BYTES,GATE_PIN)
COPY=X.notice_copy(GATE_BODY)
EXPECTED=X.expected_markers(COPY)
DENSE=[x['name'] for x in PROFILE['genuine']['denseTables']]
SETTINGS={n:'fixed' for n in X.SETTINGS_NAMES};SETTINGS.update(X.REQUIRED_SETTINGS)
CLUSTER={'systemIdentifier':'7412345678901234567','postmasterStart':'1791000000.123456'}
BASE_TS=datetime.datetime(2026,10,5,10,0,0)
TAG='forge-combined-'+'a'*32
def dumps(v):return json.dumps(v)
def ts(ms):return (BASE_TS+datetime.timedelta(milliseconds=ms)).strftime('%Y-%m-%d %H:%M:%S.%f')+'+00'
def login(pid):return {'kind':'login','pid':pid,'backendStart':str(5000+pid),'sessionUser':'authenticator','currentUser':'authenticator','zone':'UTC','statementTimeout':'8s','lockTimeout':'8s'}
def runtime(**over):
 value={'kind':'runtime','sessionUser':'authenticator','currentUser':'authenticated','jwtSubject':X.ACTOR,'zone':'UTC','floatDigits':'1','statementTimeout':'8s','lockTimeout':'8s'};value.update(over);return value
RESPONSES={'totals':{'protocolVersion':1,'availability':'available','totals':{}},'contributors':{'protocolVersion':1,'availability':'available','contributors':[]},
 'metadata':{'protocolVersion':1,'availability':'available','metadata':{}},'review_visible':{'protocolVersion':1,'availability':'available','asOf':'t','review':{'qc':{'lifecycle':'proven','qcAccepted':True}}},
 'review_missing':{'protocolVersion':1,'availability':'unavailable','review':None,'asOf':'t'}}
def api_stdout(pid,api,ms,complete=True,settings=None,response=None,runtime_row=None):
 lines=[dumps(login(pid)),dumps(runtime_row or runtime()),dumps({'kind':'settings','values':settings or SETTINGS}),dumps({'kind':'clock','phase':'before','at':ts(0)})]
 if complete:lines+=['Timing is on.',dumps({'kind':'response','value':RESPONSES[api] if response is None else response}),f'Time: {ms:.3f} ms','Timing is off.',dumps({'kind':'clock','phase':'after','at':ts(ms+3)})]
 return '\n'.join(lines)+'\n'
def marker(i,descriptor=None,at=None):return 'NOTICE:  00000: forge-char-marker '+dumps({'at':at or ts(i),'marker':descriptor or EXPECTED[i]})
def notice_stderr(count):return '\n'.join(x for i in range(count) for x in (marker(i),'LOCATION:  exec_stmt_raise, pl_exec.c:3911'))+('\n' if count else '')
TIMEOUT_ERR='ERROR:  57014: canceling statement due to statement timeout\nCONTEXT:  PL/pgSQL function inline_code_block line 12 at assignment\n'
def statrow(att):return {'attname':att,'inherited':False,'nullFrac':0.0,'avgWidth':16,'nDistinct':-1.0,'mostCommonVals':None,'mostCommonFreqs':None,'histogramBounds':None,'correlation':1.0,'mostCommonElems':None,'mostCommonElemFreqs':None,'elemCountHistogram':None}
def table(name):
 return {'name':name,'relpages':10,'reltuples':100.0,'relationBytes':81920,'totalBytes':163840,'liveTuples':0,'deadTuples':0,'modsSinceAnalyze':0,'insertsSinceVacuum':0,'analyzeCount':0,'autoanalyzeCount':0,'vacuumCount':0,'autovacuumCount':0,
  'lastAnalyze':None,'lastAutoanalyze':None,'lastVacuum':None,'lastAutovacuum':None,'heapBlocksRead':1,'heapBlocksHit':2,'indexBlocksRead':None,'indexBlocksHit':None,'indexes':[],
  'plannerStats':{'rows':2,'sha256':'e'*64,'rawRows':[statrow('created_at'),statrow('id')]}}
def witness_doc(db):return {'database':db,'login':'supabase_admin',**CLUSTER,'at':ts(0),'tables':[table(n) for n in DENSE],'databaseCounters':{'blocksRead':1,'blocksHit':2,'statsReset':None},'lagNote':'x'}
def backend(pid,db,state='active',kind=None,event=None,locks=None,blockers=None):
 return {'pid':pid,'backendStart':str(5000+pid),'applicationName':TAG,'database':db,'login':'authenticator','state':state,'waitEventType':kind,'waitEvent':event,'blockingPids':blockers or [],'ungrantedLocks':locks or []}
def sample(backends):return {'at':ts(1),'monitor':X.MONITOR_PREFIX+'b'*32,**CLUSTER,'monitorLogin':'supabase_admin','canSeeAllBackends':True,'targetApplicationName':TAG,'backends':backends}

class FakeIO:
 def __init__(self,timings=None,timeouts=(),overrides=None,samples=None,witness_mutator=None,witness_error=None,final=(),setup_reasons=(),reuse_pid_for=None,accounting=None):
  self.timings=timings or {};self.timeouts=set(timeouts);self.overrides=overrides or {};self.samples=samples or {};self.witness_mutator=witness_mutator;self.witness_error=witness_error
  self.final=list(final);self.setup_reasons=list(setup_reasons);self.reuse_pid_for=reuse_pid_for;self.acc=accounting
  self.calls=[];self.sqls={};self.witness_names=[];self.pid=100;self.cluster=dict(CLUSTER);self.historical_reproduced=False
 def witness(self,name):
  self.witness_names.append(name)
  if name==self.witness_error:raise RuntimeError('lost '+name)
  w={'A':witness_doc(X.CLONE_A),'B':witness_doc(X.CLONE_B)}
  if self.witness_mutator:self.witness_mutator(name,w)
  return w
 def run_measured(self,spec,sql):
  self.calls.append(spec['id']);self.sqls[spec['id']]=sql
  self.pid=self.pid if spec['id']==self.reuse_pid_for else self.pid+1
  if spec['kind']=='api':
   if spec['id'] in self.timeouts:stdout,rc,stderr=api_stdout(self.pid,spec['api'],0,complete=False),3,TIMEOUT_ERR
   else:stdout,rc,stderr=api_stdout(self.pid,spec['api'],self.timings.get(spec['id'],1000.0)),0,''
  else:
   stdout,rc=dumps(login(self.pid))+'\n'+dumps(runtime())+'\n',0
   stderr=notice_stderr(20) if spec['kind']=='notice_copy' else ''
  db=X.CLONES[spec['branch']];maker=self.samples.get(spec['id'])
  raw={'returnCode':rc,'stdout':stdout,'stderr':stderr,'processTimeout':False,'samples':maker(self.pid,db) if maker else [sample([backend(self.pid,db,kind='IO',event='DataFileRead')])],'settled':True,'quiescent':True,
   'call':{'wallMillisecondsIncludingPsql':1234.5,'applicationName':TAG,'sqlSha256':X.sha_bytes((X.GATE_PRELUDE+sql).encode())}}
  over=self.overrides.get(spec['id'],{})
  if callable(over):over=over(self.pid)
  raw['samplerAudit']={'verified':True,'completedSamples':len(raw['samples'])}
  raw.update(over);return raw
 def final_checks(self):return list(self.final)
 def accounting(self):return self.acc if self.acc is not None else ({'verified':True,'measuredIds':list(self.calls)},[])

def run(io):return X.Characterization(io,DENSE,GATE_PIN,GATE_BODY,COPY).run()
PLAN_IDS=[x['id'] for x in X.measurement_plan()]
def both_rounds(api,a_ms,b_ms):return {f'r{r}-A-{api}':a_ms for r in (1,2)}|{f'r{r}-B-{api}':b_ms for r in (1,2)}
def mutate_b(checkpoint,fn):
 def m(name,w):
  if name==checkpoint:fn(w['B'])
 return m

class PlanAndLedger(unittest.TestCase):
 def test_exact_twenty_fixed_order_b_only_last_no_reserve(self):
  self.assertEqual(len(PLAN_IDS),20)
  self.assertEqual(PLAN_IDS[:8],[f'r1-{b}-{a}' for b in 'AB' for a in X.API_TYPES])
  self.assertEqual(PLAN_IDS[8:16],[f'r2-{b}-{a}' for b in 'BA' for a in X.API_TYPES])
  self.assertEqual(PLAN_IDS[16:],['b-metadata-1','b-metadata-2','b-exact-gate','b-notice-copy'])
  self.assertNotIn('float0',json.dumps(X.measurement_plan()))
 def test_ledger_refuses_reorder_repeat_and_twenty_first(self):
  plan=X.measurement_plan();ledger=X.Ledger(plan)
  with self.assertRaises(RuntimeError):ledger.admit(plan[1])
  for spec in plan:ledger.admit(spec)
  with self.assertRaises(RuntimeError):ledger.admit(plan[0])

class ExactGateAndCopy(unittest.TestCase):
 def test_raw_pin_and_wire(self):
  with self.assertRaises(RuntimeError):X.gate_body(GATE_BYTES+b'\n',GATE_PIN)
  self.assertEqual(X.sha_bytes((X.GATE_PRELUDE+GATE_BODY).encode()),GATE_PIN)
 def test_copy_adds_only_twenty_wrapping_markers(self):
  self.assertEqual('\n'.join(l for l in COPY.split('\n') if not X.MARKER.match(l)),GATE_BODY)
  self.assertEqual(len(EXPECTED),20);self.assertEqual(EXPECTED[0],'before:01:work_activity_totals_read');self.assertEqual(EXPECTED[5],'after:03:work_unit_metadata_read')
 def test_copy_tampering_refused(self):
  tampered=[COPY.replace('work_unit_contributors_read(project_id,unit_id,1)','work_unit_contributors_read(project_id,unit_id,2)',1),
   COPY.replace(" perform set_config('extra_float_digits','0',true);\n",'',1),
   COPY.replace('commit;',X.marker_line('before',11,'work_unit_review_read')+'\ncommit;'),
   COPY.replace("'before:01:work_activity_totals_read'","'before:01:work_unit_metadata_read'",1),
   '\n'.join(l for l in COPY.split('\n') if 'before:03:' not in l and 'after:03:' not in l)]
  for text in tampered:
   with self.subTest(text=text[-60:]),self.assertRaises(RuntimeError):X.validate_notice_copy(GATE_BODY,text)

class MeasuredStatements(unittest.TestCase):
 def test_protocol_arguments(self):
  self.assertIn("work_unit_contributors_read('"+X.PROJECT+"'::uuid,'"+X.UNIT+"'::uuid,1)",X.measured_api_sql('contributors'))
  self.assertIn("work_unit_metadata_read('"+X.UNIT+"'::uuid,1)",X.measured_api_sql('metadata'))
  self.assertIn("work_unit_review_read('"+X.MISSING+"'::uuid)",X.measured_api_sql('review_missing'))
  for api in X.API_EXPRESSIONS:self.assertIsNone(re.search(r"(?i)set_config|\bset\s+(statement_timeout|lock_timeout|extra_float_digits|timezone|work_mem|jit)",X.measured_api_sql(api)))
 def test_emitted_sql_has_no_maintenance_ddl_or_drop(self):
  fake=types.SimpleNamespace(qi=lambda v:'"'+v+'"');roles={'database':{'owner':'postgres','acl':['=Tc/postgres']}}
  for text in [X.measured_api_sql(a) for a in X.API_EXPRESSIONS]+[X.witness_sql(DENSE),X.wait_sample_sql(TAG),X.instance_settings_sql(),X.clone_acl_sql(fake,X.CLONE_A,roles),GATE_BODY,COPY]:
   self.assertIsNone(re.search(r'(?im)(^|;)\s*(drop|analyze|vacuum|explain|alter\s+system|create\s+extension|truncate|delete|update|insert)\b',text))
  with self.assertRaises(RuntimeError):X.clone_acl_sql(fake,'forge_combined_inactive_test',roles)
 def test_parser_and_assertions(self):
  with self.assertRaises(RuntimeError):X.parse_api_stdout(api_stdout(1,'totals',10)+'surprise\n',True)
  with self.assertRaises(RuntimeError):X.parse_api_stdout(api_stdout(1,'totals',10).replace('Time: 10.000 ms\n',''),True)
  self.assertTrue(all(X.api_assertion(a,RESPONSES[a]) for a in X.API_EXPRESSIONS))
  self.assertFalse(X.api_assertion('review_visible',{'availability':'available','review':{'qc':{'lifecycle':'unproven'}}}))
 def test_classification_never_passes_timeouts(self):
  self.assertEqual(X.classify({'returnCode':3,'stderr':TIMEOUT_ERR},'api'),'statement_timeout')
  self.assertEqual(X.classify({'returnCode':3,'stderr':'ERROR:  55P03: lock timeout'},'api'),'lock_timeout')
  self.assertEqual(X.classify({'returnCode':3,'stderr':'ERROR:  P0001: Totals positive prerequisite failed'},'api'),'unclassified')
  self.assertEqual(X.classify({'returnCode':3,'stderr':'ERROR:  P0001: Totals positive prerequisite failed'},'notice_copy'),'gate_assertion_failed')

class Interpretation(unittest.TestCase):
 def rec(self,a,b):
  out={(r,br,api):{'outcome':'ok','psqlElapsedMs':100.0} for r in (1,2) for br in 'AB' for api in X.API_TYPES}
  for rnd in (1,2):
   for br,v in (('A',a[rnd-1]),('B',b[rnd-1])):out[(rnd,br,'totals')]={'outcome':'timeout','psqlElapsedMs':None} if v is None else {'outcome':'ok','psqlElapsedMs':v}
  return X.interpret(out,True)['totals']
 def test_thresholds_and_censoring(self):
  self.assertEqual(self.rec((1000,1000),(1260,1300))['conclusion'],'bounded_candidate_dependent_timing_signal_not_universal_regression')
  self.assertEqual(self.rec((1000,1000),(1300,1000))['conclusion'],'no_demonstrated_regression_under_this_characterization')
  self.assertEqual(self.rec((100,100),(300,300))['conclusion'],'no_demonstrated_regression_under_this_characterization')
  both=self.rec((None,1000),(None,1000));self.assertTrue(both['conclusion'].startswith('inherited'));self.assertIsNone(both['rounds'][0]['ratio'])
  self.assertTrue(self.rec((1000,1000),(None,None))['conclusion'].startswith('candidate_only_timeout'))

class R1ImmediateFailClose(unittest.TestCase):
 def stop_after(self,io,count,reason):
  s=run(io);self.assertEqual(len(io.calls),count);self.assertEqual(s['stop']['reason'],reason);self.assertEqual(s['characterization']['status'],'inconclusive')
  self.assertNotIn('b-metadata-1',io.calls) if count<17 else None;self.assertEqual(io.witness_names[-1],'final');return s
 def test_pre_round_mismatch_executes_zero(self):
  s=self.stop_after(FakeIO(witness_mutator=mutate_b('pre_round1',lambda w:w['tables'][0].update(deadTuples=4))),0,'physical_or_statistics_mismatch')
  self.assertIsNone(s['pairedScope'])
 def test_setup_reason_executes_zero(self):self.stop_after(FakeIO(setup_reasons=['declared']),0,'setup_invalid')
 def test_first_lost_sampler_executes_one(self):
  self.stop_after(FakeIO(samples={'r1-A-totals':lambda pid,db:[{'error':'TimeoutExpired','monitor':X.MONITOR_PREFIX+'x'}]}),1,'wait_evidence_lost')
  self.stop_after(FakeIO(samples={'r1-A-totals':lambda pid,db:[{}]}),1,'wait_evidence_lost')
 def test_post_round1_mismatch_executes_eight(self):
  self.stop_after(FakeIO(witness_mutator=mutate_b('post_round1',lambda w:w['tables'][1]['plannerStats']['rawRows'][0].update(nullFrac=0.5))),8,'physical_or_statistics_mismatch')
 def test_post_round2_mismatch_stops_before_b_only(self):
  s=self.stop_after(FakeIO(witness_mutator=mutate_b('post_round2',lambda w:w['tables'][2].update(lastAutoanalyze=ts(5)))),16,'physical_or_statistics_mismatch')
  self.assertTrue(all(v['conclusion']=='withheld_whole_characterization_inconclusive' for v in s['pairedScope']['apis'].values()))
 def test_settings_mismatch_stops_at_earliest_call(self):
  io=FakeIO(overrides={'r1-A-contributors':lambda pid:{'stdout':api_stdout(pid,'contributors',1000.0,settings=dict(SETTINGS,work_mem='64MB'))}})
  self.stop_after(io,2,'session_settings_mismatch')
 def test_confounders_stop_immediately(self):
  self.stop_after(FakeIO(samples={'r1-A-review_visible':lambda pid,db:[sample([backend(pid,db,locks=[{'locktype':'relation'}])])]}),3,'wait_confounder')
  self.stop_after(FakeIO(samples={'r1-A-totals':lambda pid,db:[sample([backend(pid,db,kind='Lock',event='relation')])]}),1,'wait_confounder')
 def test_pair_wait_class_mismatch_stops_when_pair_completes(self):
  self.stop_after(FakeIO(samples={'r1-B-totals':lambda pid,db:[sample([backend(pid,db,kind='LWLock',event='BufferMapping')])]}),5,'non_io_wait_class_mismatch')
  self.stop_after(FakeIO(samples={'r2-B-contributors':lambda pid,db:[sample([backend(pid,db,kind='LWLock',event='BufferMapping')])]}),14,'non_io_wait_class_mismatch')
 def test_other_stops(self):
  cases={'stop_process_timeout':{'processTimeout':True},'uncertain_backend_settlement':{'settled':False},'monitor_not_quiescent':{'quiescent':False},'stop_unclassified':{'returnCode':3,'stderr':'ERROR:  42501: denied'}}
  for reason,over in cases.items():
   with self.subTest(reason=reason):self.stop_after(FakeIO(overrides={'r1-B-contributors':over}),6,reason)

class R2NoValidAfterStop(unittest.TestCase):
 def test_complete_valid_run(self):
  io=FakeIO();s=run(io)
  self.assertEqual(io.calls,PLAN_IDS);self.assertEqual(io.witness_names,['pre_round1','post_round1','post_round2','final'])
  self.assertEqual(s['characterization'],{'status':'valid','reasons':[]});self.assertIsNone(s['pairedScope']);self.assertEqual(s['method'],X.METHOD)
  self.assertTrue(all(v['conclusion']=='no_demonstrated_regression_under_this_characterization' for v in s['apis'].values()))
  self.assertEqual(s['exactGate']['diagnostic'],'diagnostic_reproduction_passed');self.assertEqual(len(s['noticeCopy']['markers']),20)
  for k in ('full20Complete','full42Complete','full65Complete','providerAcceptance','primaryAcceptanceSatisfied','restorationClaimed','historicalDataReproduced'):self.assertIs(s[k],False)
  self.assertEqual(s['limitations']['omittedGenuineSeamHistory'],list(X.OMITTED_SEAM_HISTORY));self.assertFalse(s['limitations']['failedInstancePhysicalStatisticsKnown'])
 def test_b_only_and_final_failures_never_valid(self):
  cases={'metadata':dict(overrides={'b-metadata-1':{'returnCode':3,'stderr':'ERROR:  XX000: boom'}}),'gate':dict(overrides={'b-exact-gate':{'returnCode':3,'stderr':'ERROR:  42501: denied'}}),
   'copy':dict(overrides={'b-notice-copy':{'returnCode':3,'stderr':'ERROR:  42501: denied'}}),'finalWitness':dict(witness_error='final'),
   'finalChecks':dict(final=['persistent_state_changed_by_reads:B']),'accounting':dict(accounting=({},['settlement_over_ceiling'])),
   'finalSchema':dict(witness_mutator=mutate_b('final',lambda w:w['tables'].pop()))}
  for name,kwargs in cases.items():
   with self.subTest(name=name):
    s=run(FakeIO(overrides=kwargs.get('overrides'),witness_error=kwargs.get('witness_error'),final=kwargs.get('final',()),accounting=kwargs.get('accounting'),witness_mutator=kwargs.get('witness_mutator')))
    self.assertEqual(s['characterization']['status'],'inconclusive');self.assertIsNone(s['aggregate'])
    self.assertTrue(all(v['conclusion']=='withheld_whole_characterization_inconclusive' for v in s['apis'].values()))
    self.assertEqual(s['pairedScope']['label'],'raw_paired_observations_only_all_interpretations_withheld')
 def test_paired_stop_yields_no_paired_scope(self):
  s=run(FakeIO(overrides={'r2-A-totals':{'returnCode':3,'stderr':'ERROR:  42501: denied'}}));self.assertIsNone(s['pairedScope'])
  self.assertTrue(all(v['conclusion'] in ('incomplete','withheld_whole_characterization_inconclusive') for v in s['apis'].values()))
 def test_valid_gate_timeout_and_gate_assertion_are_diagnostics(self):
  s=run(FakeIO(overrides={'b-exact-gate':{'returnCode':3,'stderr':TIMEOUT_ERR},'b-notice-copy':{'returnCode':3,'stderr':notice_stderr(5)+TIMEOUT_ERR}}))
  self.assertEqual(s['characterization']['status'],'valid');self.assertEqual(s['exactGate']['diagnostic'],'diagnostic_reproduction_failed_statement_timeout')
  self.assertEqual(s['aggregate'],'aggregate_envelope_effect_consistent_with_additional_scope_pass_not_a_cost_decomposition')
  self.assertEqual(s['noticeCopy']['markerPrefixLength'],5);self.assertTrue(s['noticeCopy']['censored']);self.assertTrue(any('57014' in l for l in s['noticeCopy']['originalError']))
  s=run(FakeIO(overrides={'b-exact-gate':{'returnCode':3,'stderr':'ERROR:  P0001: Metadata positive prerequisite failed'}}))
  self.assertEqual(s['exactGate']['diagnostic'],'diagnostic_reproduction_failed_assertion');self.assertFalse(s['exactGate']['primaryAcceptanceSatisfied']);self.assertIsNone(s['aggregate'])

class R3NoticeEvidence(unittest.TestCase):
 def lost(self,stderr,rc=0):
  s=run(FakeIO(overrides={'b-notice-copy':{'returnCode':rc,'stderr':stderr}}));self.assertEqual(s['stop']['reason'],'notice_evidence_lost');self.assertEqual(s['characterization']['status'],'inconclusive');return s
 def test_missing_truncated_wrong_or_garbled_evidence_is_lost(self):
  self.lost('')
  self.lost(notice_stderr(19))
  self.lost('\n'.join(marker(i,descriptor=EXPECTED[i].rsplit(':',1)[0]+':work_activity_totals_read') for i in range(20)))
  self.lost('\n'.join(marker(i) for i in [1,0]+list(range(2,20))))
  self.lost('\n'.join(marker(i,at='2026-10-05T10:00:00Z' if i==3 else None) for i in range(20)))
  self.lost('\n'.join(marker(i,at=ts(100-i)) for i in range(20)))
  self.lost(notice_stderr(20)+'NOTICE:  00000: forge-char-marker {broken\n')
  self.lost(notice_stderr(20)+'NOTICE:  00000: unexpected notice\n')
  self.lost(TIMEOUT_ERR,rc=3)
 def test_wire_hashes_and_exact_gate_instrumentation(self):
  s=run(FakeIO(overrides={'b-notice-copy':{'call':{'sqlSha256':'f'*64,'applicationName':TAG}}}));self.assertEqual(s['stop']['reason'],'notice_copy_wire_bytes_changed')
  s=run(FakeIO(overrides={'b-exact-gate':{'call':{'sqlSha256':'f'*64,'applicationName':TAG}}}));self.assertEqual(s['stop']['reason'],'exact_gate_wire_bytes_changed')
  s=run(FakeIO(overrides={'b-exact-gate':{'stderr':notice_stderr(2)}}));self.assertEqual(s['stop']['reason'],'notice_evidence_lost')
 def test_parser_direct(self):
  self.assertEqual(len(X.parse_notice_evidence(notice_stderr(20),EXPECTED,'returned')),20)
  self.assertEqual(len(X.parse_notice_evidence(notice_stderr(3),EXPECTED,'statement_timeout')),3)
  for args in ((notice_stderr(3),'returned'),('','statement_timeout'),(notice_stderr(20),'unclassified')):
   with self.subTest(args=args[1]),self.assertRaises(RuntimeError):X.parse_notice_evidence(args[0],EXPECTED,args[1])

class R4Schemas(unittest.TestCase):
 def test_sample_schema(self):
  login_row=login(101);db=X.CLONE_A;good=sample([backend(101,db)])
  self.assertTrue(X.validate_sample(good,TAG,CLUSTER,db,login_row));self.assertTrue(X.validate_sample(sample([]),TAG,CLUSTER,db,login_row))
  bad=[{},{'error':'x'},dict(good,backends=None),dict(good,systemIdentifier='1'),dict(good,monitorLogin='postgres'),dict(good,canSeeAllBackends=False),dict(good,targetApplicationName='forge-combined-'+'c'*32),
   dict(good,at='yesterday'),sample([backend(102,db)]),sample([backend(101,X.CLONE_B)]),sample([dict(backend(101,db),login='postgres')]),sample([dict(backend(101,db),blockingPids=['x'])]),
   sample([dict(backend(101,db),ungrantedLocks='none')]),sample([dict(backend(101,db),backendStart='1')])]
  for s in bad:
   with self.subTest(s=str(s)[:60]),self.assertRaises(RuntimeError):X.validate_sample(s,TAG,CLUSTER,db,login_row)
 def test_zero_active_coverage_disclosed(self):
  p=X.wait_profile([sample([])]);self.assertEqual(p['activeSamples'],0);self.assertIn('NOT proved',p['coverage'])
 def test_witness_schema(self):
  good=witness_doc(X.CLONE_A);self.assertTrue(X.validate_witness(good,X.CLONE_A,DENSE,CLUSTER))
  def variant(fn):w=copy.deepcopy(good);fn(w);return w
  bad=[variant(lambda w:w['tables'][0].pop('deadTuples')),variant(lambda w:w['tables'][0].update(relpages='10')),variant(lambda w:w['tables'][0].update(heapBlocksRead=None)),
   variant(lambda w:w['tables'].append(copy.deepcopy(w['tables'][0]))),variant(lambda w:w['tables'].pop()),variant(lambda w:w.update(database=X.CLONE_B)),
   variant(lambda w:w.update(postmasterStart='0')),variant(lambda w:w.update(login='postgres')),variant(lambda w:w['tables'][0].pop('lastAnalyze')),
   variant(lambda w:w['tables'][0]['plannerStats'].update(rows=3)),variant(lambda w:w['tables'][0]['plannerStats']['rawRows'].reverse()),
   variant(lambda w:w['tables'][0]['plannerStats'].pop('rawRows')),variant(lambda w:w['tables'][0]['plannerStats']['rawRows'][0].pop('nullFrac')),
   {'tables':[{} for _ in DENSE]}]
  for w in bad:
   with self.subTest(w=str(w)[:60]),self.assertRaises(RuntimeError):X.validate_witness(w,X.CLONE_A,DENSE,CLUSTER)
  ok=variant(lambda w:w['tables'][0].update(lastAnalyze=ts(9),indexBlocksRead=3,indexBlocksHit=4));self.assertTrue(X.validate_witness(ok,X.CLONE_A,DENSE,CLUSTER))
 def test_raw_planner_rows_drive_parity(self):
  a,b=witness_doc(X.CLONE_A),witness_doc(X.CLONE_B);self.assertEqual(X.physical_parity(a,b,DENSE),[])
  b['tables'][0]['totalBytes']=1;b['tables'][0]['indexes']=['x'];self.assertEqual(X.physical_parity(a,b,DENSE),[])
  b['tables'][0]['plannerStats']['rawRows'][0]['correlation']=0.5;self.assertEqual(X.physical_parity(a,b,DENSE),[DENSE[0]+'.plannerStats'])

class R5Accounting(unittest.TestCase):
 def test_emitted_statement_counts(self):
  for api in X.API_EXPRESSIONS:self.assertEqual(X.count_statements(X.measured_api_sql(api)),X.EMITTED['apiInvocation'])
  self.assertEqual(X.count_statements(X.GATE_PRELUDE+GATE_BODY),X.EMITTED['gateInvocation']);self.assertEqual(X.count_statements(X.GATE_PRELUDE+COPY),X.EMITTED['gateInvocation'])
  self.assertEqual(X.count_statements(X.inspection_wire(X.witness_sql(DENSE))),X.EMITTED['runnerInspectionInvocation'])
  self.assertEqual(X.count_statements(X.monitor_wire("select 1")),X.EMITTED['runnerMonitorInvocation'])
  self.assertEqual(X.count_statements(X.WAIT_PRELUDE+X.wait_sample_sql(TAG)),X.EMITTED['waitSampleInvocation'])
  self.assertEqual(X.count_statements("select ';' -- x;y\n;DO $t$ a; b; $t$;\n\\set Q on\nselect 'it''s;'"),3)
  self.assertEqual(X.EMITTED['apiInvocation']-1,X.EMITTED['apiAuxiliaryPerInvocation']);self.assertEqual(X.EMITTED['gateInvocation']-1,X.EMITTED['gateAuxiliaryPerInvocation'])
 def test_profile_maxima_match_contract(self):
  m=PROFILE['accounting']['boundedMaxima'];c=X.CEILINGS;e=X.EMITTED
  self.assertEqual(m['measuredEmittedStatements'],c['measuredApiInvocations']*e['apiInvocation']+c['measuredGateInvocations']*e['gateInvocation'])
  self.assertEqual(m['witnessEmittedStatements'],c['witnessInvocations']*e['runnerInspectionInvocation'])
  self.assertEqual(m['waitSampleInvocations'],20*c['waitSampleInvocationsPerMeasured']);self.assertEqual(m['waitSampleEmittedStatements'],m['waitSampleInvocations']*e['waitSampleInvocation'])
  self.assertEqual(m['quiescenceEmittedStatements'],20*c['quiescenceInvocationsPerMeasured']*e['runnerMonitorInvocation'])
  self.assertEqual(m['settlementEmittedStatements'],20*c['settlementInvocationsPerMeasured']*e['runnerMonitorInvocation'])

class R6CurrentFixtureGates(unittest.TestCase):
 def state(self):return [{'schema':'public','name':g['name'],'kind':'r','count':g['count'],'sha256':g['sha256']} for g in PROFILE['genuine']['denseTables']]+[{'schema':'public','name':'seq','kind':'S','count':1,'sha256':'1'*64}]
 def test_hash_only_differences_enter_but_are_retained(self):
  genuine=self.state();fresh=copy.deepcopy(genuine);fresh[0]['sha256']='0'*64;fresh[-1]['sha256']='2'*64
  d=X.historical_deltas(fresh,genuine);self.assertFalse(d['historicalDataReproduced']);self.assertEqual(len(d['differences']),2)
  self.assertTrue(all(x['cause']=='unknown_not_separately_proved' and x['countEqual'] and not x['hashEqual'] for x in d['differences']));self.assertEqual(X.historical_gate(d),[])
  self.assertTrue(X.historical_deltas(genuine,genuine)['historicalDataReproduced'])
 def test_count_or_inventory_change_refused(self):
  genuine=self.state();fresh=copy.deepcopy(genuine);fresh[1]['count']+=1
  self.assertEqual(X.historical_gate(X.historical_deltas(fresh,genuine)),['count:public.'+fresh[1]['name']])
  self.assertTrue(X.historical_gate(X.historical_deltas(genuine[:-1],genuine))[0].startswith('inventory:'))
  self.assertTrue(X.historical_gate(X.historical_deltas(genuine+[{'schema':'public','name':'extra','kind':'r','count':0,'sha256':'3'*64}],genuine))[0].startswith('inventory:'))
  with self.assertRaises(RuntimeError):X.historical_deltas(genuine+[genuine[0]],genuine)
 def test_mutual_raw_authority_exception_and_treatment(self):
  fp=self.state();auth={'schema':'public','name':'work_activity_authority_generation','kind':'r','count':1,'sha256':'1'}
  expected=json.loads(X.resolve_input(PROFILE['inputs']['expectedTreatment']['path']).read_text())['catalogMinusGenuineBaseline']
  additions=[dict(e,count=0,sha256='0'*64) for e in expected]
  a=fp+[auth];b=fp+[dict(auth,sha256='other')]+additions
  reasons,treatment=X.shared_state(a,b);self.assertEqual(reasons,[]);self.assertEqual(X.treatment_gate(a,b,expected),[])
  changed=copy.deepcopy(fp);changed[0]['sha256']='9'*64;self.assertEqual(len(X.shared_state(fp,changed)[0]),1)
  for i in range(17):self.assertTrue(X.treatment_gate(a,b[:len(a)]+additions[:i]+additions[i+1:],expected))
  for extra in ({'schema':'auth','name':'rogue','kind':'r'},{'schema':'public','name':'rogue','kind':'r'},{'schema':'public','name':'rogue','kind':'S'}):
   self.assertTrue(X.treatment_gate(a,b+[dict(extra,count=0,sha256='f'*64)],expected))
  wrong=copy.deepcopy(b);wrong[-1]['kind']='S';self.assertTrue(X.treatment_gate(a,wrong,expected))
 def test_observations_cross_check_includes_baseline_state(self):
  obs={'baselineDenseCounts':[dict(x,kind='r',schema='public') for x in PROFILE['genuine']['denseTables']],'inactiveMetadataCounts':[dict(x,kind='r',schema='public') for x in PROFILE['genuine']['metadataTables']],
   'failedCall':{'sqlSha256':GATE_PIN,'login':'authenticator','zone':'UTC','floatDigits':1},'baselineState':self.state()}
  self.assertTrue(X.cross_check_observations(PROFILE,obs))
  for mutate in (lambda o:o['baselineState'].pop(0),lambda o:o['baselineState'].append(o['baselineState'][1]),lambda o:o['baselineDenseCounts'][0].update(count=1)):
   o=copy.deepcopy(obs);mutate(o)
   with self.subTest(),self.assertRaises(RuntimeError):X.cross_check_observations(PROFILE,o)
 def test_profile_invariants(self):
  self.assertTrue(X.validate_profile(PROFILE))
  mutations=[lambda p:p['measurement'].update(measuredTotal=21),lambda p:p['measurement'].update(reserveUsed=4),lambda p:p.update(method='historical_hash_v1'),
   lambda p:p['claims'].update(full20Complete=True),lambda p:p['claims'].update(historicalDataReproducedWhenHashesDiffer=True),lambda p:p['accounting']['emittedStatements'].update(apiInvocation=8),
   lambda p:p['forbidden'].remove('historical hash normalization'),lambda p:p['timeoutsSeconds'].update(installedAuthenticatorStatement=10),lambda p:p['clones'].update(A='forge_combined_inactive_test')]
  for mutate in mutations:
   p=copy.deepcopy(PROFILE);mutate(p)
   with self.subTest(),self.assertRaises(RuntimeError):X.validate_profile(p)
 def test_pins_fail_closed(self):
  with tempfile.TemporaryDirectory() as d:
   base=Path(d);(base/'ck').mkdir();f=base/'ck'/'file.txt';f.write_text('frozen')
   self.assertEqual(X.validate_inputs({'inputs':{'x':{'path':'../ck/file.txt','sha256':X.sha(f)}}},True,base)[0]['x'],f.resolve())
   with self.assertRaises(RuntimeError):X.validate_inputs({'inputs':{'x':{'path':'../ck/file.txt','sha256':'0'*64}}},False,base)
   pending={'inputs':{'x':{'path':'../ck/file.txt','sha256':X.PENDING}}};self.assertEqual(X.validate_inputs(pending,False,base)[1],['x'])
   with self.assertRaises(RuntimeError):X.validate_inputs(pending,True,base)
   for path in ('/etc/passwd','../ck/../ck/file.txt','ck/file.txt'):
    with self.subTest(path=path),self.assertRaises(RuntimeError):X.validate_inputs({'inputs':{'x':{'path':path,'sha256':X.sha(f)}}},False,base)
 def test_check_plan_reports_pending_and_execute_refuses(self):
  profile,_,summary=X.prepare()
  self.assertEqual(sorted(summary['pendingPins']),sorted(k for k,v in profile['inputs'].items() if v['sha256']==X.PENDING))
  self.assertEqual(summary['plan'],PLAN_IDS);self.assertEqual(summary['noticeCopy'],COPY)
  if summary['pendingPins']:
   with self.assertRaises(RuntimeError):X.prepare(execute=True)
 def test_historical_flag_passes_through(self):
  io=FakeIO();io.historical_reproduced=True;self.assertTrue(run(io)['historicalDataReproduced'])

class Sampler(unittest.TestCase):
 def test_hard_ceiling_and_cadence(self):
  clock=[0.0];waits=[]
  def spawn(args,**kw):
   clock[0]+=0.05;self.assertEqual(kw['timeout'],X.SAMPLE_PROCESS_TIMEOUT_SECONDS);return types.SimpleNamespace(returncode=0,stdout=dumps(sample([])),stderr='')
  def wait(s):waits.append(s);clock[0]+=s;return False
  with tempfile.TemporaryDirectory() as d:
   s=X.WaitSampler('uri',{},Path(d),spawn=spawn,clock=lambda:clock[0]);s.run(TAG,threading.Event(),wait=wait)
  self.assertEqual(len(s.samples),36);self.assertTrue(all(abs(w-0.2)<1e-9 for w in waits))
  for kwargs in ({'cap':37},{'interval':0.2}):
   with self.subTest(kwargs=kwargs),self.assertRaises(RuntimeError):X.WaitSampler('uri',{},Path('/nonexistent'),**kwargs)
 def test_failed_and_malformed_samples_are_marked(self):
  with tempfile.TemporaryDirectory() as d:
   s=X.WaitSampler('uri',{},Path(d),spawn=lambda *a,**k:1/0);self.assertIn('error',s.sample(TAG))
   s=X.WaitSampler('uri',{},Path(d),spawn=lambda *a,**k:types.SimpleNamespace(returncode=0,stdout='[]',stderr=''));self.assertEqual(s.sample(TAG)['error'],'malformed_sample')
  with self.assertRaises(RuntimeError):X.wait_sample_sql("x' or true --")

if __name__=='__main__':unittest.main(verbosity=2)
