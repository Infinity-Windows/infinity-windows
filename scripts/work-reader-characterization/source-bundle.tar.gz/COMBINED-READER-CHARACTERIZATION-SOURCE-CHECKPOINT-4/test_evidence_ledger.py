"""Independent regression controls for the central gate and real runner/receipt adapters.
Only local temp files and injected fake process replies. No fixture constructor runs.
"""
import copy,importlib.util,json,subprocess,sys,tempfile,threading,types,unittest
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('source3_baseline_tests',HERE/'test_characterization_executor.py');T=importlib.util.module_from_spec(spec);spec.loader.exec_module(T)
X=T.X
S6=X.load_module(X.resolve_input(T.PROFILE['inputs']['source6Executor']['path']),'source6_wire_only')

class MemoryReport:
 def __init__(self,path):self.path=path;self.value={'calls':[],'clusterBaseline':T.CLUSTER,'ioPhase':'measurement'}
 def persist(self,*args):pass

def fixture(folder):
 report=MemoryReport(folder/'report.json');target=S6.validate_target('postgresql://supabase_admin:fixture-only@localhost:5432/'+S6.BASE)
 def fake(args,**kwargs):
  wire=kwargs['input'];value={}
  if 'monitorCurrentRole' in wire:value={**T.CLUSTER,'monitorDatabase':X.CLONE_A,'monitorLogin':'supabase_admin','monitorCurrentRole':'supabase_admin','canSeeAllBackends':True,'backends':[]}
  elif 'application_name like' in wire:value=[]
  return types.SimpleNamespace(returncode=0,stdout=json.dumps(value)+'\n',stderr='')
 runner=X.runner_class(S6)(target,report,X.CLONE_A,execute=fake);spec=X.measurement_plan()[0];report.value['ioMeasuredId']=spec['id']
 runner.run(X.measured_api_sql('totals'),user='authenticator',purpose='measured:'+spec['id']);call=report.value['calls'][-1]
 runner.wait_backend_gone(call)
 runner.json("select coalesce(jsonb_agg(application_name),'[]'::jsonb) from pg_stat_activity where application_name like 'forge-charmon-%'",user='supabase_admin',monitor_budget=2,purpose='monitor_quiescence')
 report.value['ioMeasuredId']=None
 purpose='witness:pre_round1:A';runner.json(X.witness_sql(T.DENSE),user='supabase_admin',purpose=purpose)
 folder_sample=folder/'wait-samples'/spec['id'];tag=call['applicationName']
 value=T.sample([]);value['targetApplicationName']=tag
 sampler=X.WaitSampler('fake',{},folder_sample,cap=1,spawn=lambda *a,**kw:types.SimpleNamespace(returncode=0,stdout=json.dumps(value)+'\n',stderr=''))
 sampler.run(tag,threading.Event(),wait=lambda seconds:False)
 receipt={'id':spec['id'],'applicationName':tag,'samples':sampler.samples,'attempts':sampler.attempts,'lifecycle':{'started':sampler.started,'finished':sampler.finished}}
 def audit():return X.account_io(report.value['calls'],report.value['ioExpected'],folder,[spec],[purpose],[receipt],report.value['backendSettlement'])
 return report,runner,receipt,audit

class CentralClaimGate(unittest.TestCase):
 def test_every_relevant_final_failure_withholds_all_interpreted_claims(self):
  for reason in ('persistent_state_changed_by_reads:B','global_roles_or_settings_changed','uncertain_backend_settlement','unexpected_database_inventory','io_file_missing_or_changed:x'):
   with self.subTest(reason=reason):
    s=T.run(T.FakeIO(timings=T.both_rounds('totals',1000,1500),final=[reason]))
    self.assertEqual(s['characterization']['status'],'inconclusive');self.assertIsNone(s['aggregate'])
    for section in (s['apis'],s['pairedScope']['apis']):self.assertEqual(section['totals']['conclusion'],'withheld_whole_characterization_inconclusive')
    self.assertEqual(s['pairedScope']['apis']['totals']['rounds'][0]['ratio'],1.5)
 def test_no_sample_attempt_or_missing_receipt_stops_at_one(self):
  for override in ({'samples':[],'samplerAudit':{'verified':True,'completedSamples':0}},{'samplerAudit':None},{'samplerAudit':{'verified':False,'completedSamples':1}},{'samplerAudit':{'verified':True,'completedSamples':2}}):
   with self.subTest(override=override):
    s=T.run(T.FakeIO(overrides={'r1-A-totals':override}));self.assertEqual(s['measuredExecuted'],1);self.assertEqual(s['characterization']['status'],'inconclusive');self.assertIsNone(s['pairedScope'])
    self.assertEqual(s['records'][0]['observedPsqlElapsedMs'],1000.0)
 def test_explicit_valid_empty_backend_samples_are_valid(self):
  s=T.run(T.FakeIO(samples={i:lambda pid,db:[T.sample([])] for i in T.PLAN_IDS}));self.assertEqual(s['characterization']['status'],'valid');self.assertTrue(all(r['wait']['activeSamples']==0 for r in s['records']))
 def test_unverified_or_wrong_measured_accounting_cannot_pass(self):
  for accounting in ({},{'verified':True,'measuredIds':[]},{'verified':False,'measuredIds':T.PLAN_IDS}):
   s=T.run(T.FakeIO(accounting=(accounting,[])));self.assertEqual(s['characterization']['status'],'inconclusive');self.assertIn('io_ledger_not_verified',s['characterization']['reasons'])

class RawSampleLedger(unittest.TestCase):
 def test_attempt_raw_membership_hashes_and_returned_data_must_match(self):
  mutators=[lambda d,r:r['lifecycle'].update(started=False),lambda d,r:r.update(attempts=[]),lambda d,r:r.update(samples=[]),
   lambda d,r:(d/'wait-samples'/r['id']/'000.stderr').unlink(),lambda d,r:(d/'wait-samples'/r['id']/'000.stdout').write_text('{}'),
   lambda d,r:(d/'wait-samples'/r['id']/'extra.sql').write_text('select 1;'),lambda d,r:r['samples'][0].update(at=T.ts(42)),lambda d,r:r['attempts'][0].update(file='001')]
  for mutate in mutators:
   with self.subTest(mutate=mutate),tempfile.TemporaryDirectory() as d:
    folder=Path(d);_,_,receipt,audit=fixture(folder);self.assertTrue(audit()[0]['verified']);mutate(folder,receipt);self.assertFalse(audit()[0]['verified'])
 def test_failed_attempt_preserves_sql_and_partial_timeout_output(self):
  def timeout(*a,**kw):raise subprocess.TimeoutExpired('fake',2,output=b'{partial',stderr=b'timeout')
  with tempfile.TemporaryDirectory() as d:
   sampler=X.WaitSampler('fake',{},Path(d),cap=1,spawn=timeout);sampler.run(T.TAG,threading.Event(),wait=lambda _:False)
   self.assertFalse(sampler.attempts[0]['completed']);self.assertEqual((Path(d)/'000.stdout').read_bytes(),b'{partial')
   audit=X.sampler_audit(d,{'started':True,'finished':True},sampler.attempts,sampler.samples,T.TAG);self.assertFalse(audit['verified'])

class ExpectedIOLedger(unittest.TestCase):
 def test_actual_unchanged_runner_and_sampler_create_verified_ledger(self):
  with tempfile.TemporaryDirectory() as d:
   report,runner,receipt,audit=fixture(Path(d));result,reasons=audit();self.assertEqual(reasons,[]);self.assertTrue(result['verified'])
   self.assertEqual([e['payloadStatements'] for e in report.value['ioExpected']],[9,4,4,4]);self.assertEqual(len(receipt['attempts']),1)
   runner.run(T.GATE_BODY,user='authenticator',purpose='wire_only');self.assertEqual(report.value['calls'][-1]['sqlSha256'],T.GATE_PIN);self.assertEqual(report.value['ioExpected'][-1]['payloadStatements'],11)
   runner.run(T.COPY,user='authenticator',purpose='wire_only_copy');self.assertEqual(report.value['ioExpected'][-1]['payloadStatements'],11)
 def test_missing_changed_duplicate_unexpected_evidence_refused(self):
  mutations=[lambda d,r:(d/'call-00003.sql').unlink(),lambda d,r:(d/'call-00003.stdout').write_text('changed'),lambda d,r:(d/'call-99999.sql').write_text('select 1;'),
   lambda d,r:r.value['calls'].pop(),lambda d,r:r.value['ioExpected'].pop(),lambda d,r:r.value['calls'].reverse(),
   lambda d,r:r.value['calls'][1].update(applicationName=r.value['calls'][0]['applicationName']),lambda d,r:r.value['ioExpected'][2].update(measuredId='unknown'),
   lambda d,r:r.value['backendSettlement'].clear(),lambda d,r:r.value['backendSettlement'][0]['samples'].clear()]
  for mutate in mutations:
   with self.subTest(mutate=mutate),tempfile.TemporaryDirectory() as d:
    folder=Path(d);report,_,_,audit=fixture(folder);mutate(folder,report);self.assertFalse(audit()[0]['verified'])
 def test_wrong_auxiliary_count_rejected_even_with_consistent_updated_hashes(self):
  with tempfile.TemporaryDirectory() as d:
   folder=Path(d);report,_,_,audit=fixture(folder);p=folder/'call-00003.sql';p.write_text('select 1;');digest=X.sha(p)
   e=report.value['ioExpected'][3];e.update(sqlSha256=digest,payloadStatements=1);e['files']['sql']=digest;report.value['calls'][3]['sqlSha256']=digest
   self.assertIn('auxiliary_payload_count:call-00003',audit()[1])
 def test_measured_order_and_witness_membership_required(self):
  with tempfile.TemporaryDirectory() as d:
   folder=Path(d);report,_,receipt,_=fixture(folder)
   for specs,checkpoints in (([X.measurement_plan()[1]],['witness:pre_round1:A']),([X.measurement_plan()[0]],[])):
    result,reasons=X.account_io(report.value['calls'],report.value['ioExpected'],folder,specs,checkpoints,[receipt],report.value['backendSettlement']);self.assertFalse(result['verified']);self.assertTrue(reasons)
 def test_quiescence_and_settlement_ceilings_remain_finite(self):
  with tempfile.TemporaryDirectory() as d:
   report,runner,_,audit=fixture(Path(d));report.value['ioMeasuredId']=T.PLAN_IDS[0]
   for _ in range(8):runner.json('select 1',user='supabase_admin',monitor_budget=2,purpose='monitor_quiescence')
   self.assertIn('measured_quiescence_count:'+T.PLAN_IDS[0],audit()[1])

class PgIOAdapter(unittest.TestCase):
 def test_real_adapter_captures_and_reconciles_sampler_and_backend_receipts(self):
  with tempfile.TemporaryDirectory() as d:
   folder=Path(d);report=MemoryReport(folder/'report.json');report.value['measured']=[]
   target=S6.validate_target('postgresql://supabase_admin:fixture-only@localhost:5432/'+S6.BASE);sampled=threading.Event()
   def fake(args,**kwargs):
    wire=kwargs['input']
    if 'targetApplicationName' in wire:
     import re
     tag=re.search(r"'targetApplicationName','(forge-combined-[a-f0-9]+)'",wire).group(1)
     value=T.sample([]);value.pop('monitor');value['targetApplicationName']=tag;sampled.set()
    elif 'monitorCurrentRole' in wire:value={**T.CLUSTER,'monitorDatabase':X.CLONE_A,'monitorLogin':'supabase_admin','monitorCurrentRole':'supabase_admin','canSeeAllBackends':True,'backends':[]}
    elif 'application_name like' in wire:value=[]
    else:
     self.assertTrue(sampled.wait(1));return types.SimpleNamespace(returncode=0,stdout=T.api_stdout(123,'totals',1000),stderr='')
    return types.SimpleNamespace(returncode=0,stdout=json.dumps(value)+'\n',stderr='')
   Char=X.runner_class(S6);io=X.PgIO.__new__(X.PgIO);io.target=target;io.report=report;io.s6=S6;io.measured_specs=[];io.checkpoint_attempts=[];io.sampler_receipts=[];io.sleep=lambda _:None
   io.runners={k:Char(target,report,v,execute=fake) for k,v in X.CLONES.items()};io.ex=types.SimpleNamespace(admin=Char(target,report,'postgres',execute=fake))
   Original=X.WaitSampler
   def sampler(*args,**kwargs):return Original(*args,**kwargs,spawn=fake)
   with patch.object(X,'WaitSampler',sampler),patch.object(X.subprocess,'run',fake):
    raw=io.run_measured(X.measurement_plan()[0],X.measured_api_sql('totals'))
   self.assertTrue(raw['settled']);self.assertTrue(raw['quiescent']);self.assertTrue(raw['samplerAudit']['verified']);self.assertGreaterEqual(len(raw['samples']),1)
   for sample in raw['samples']:self.assertTrue(X.validate_sample(sample,raw['call']['applicationName'],T.CLUSTER,X.CLONE_A,T.login(123)))
   accounting,reasons=io.accounting();self.assertEqual(reasons,[]);self.assertTrue(accounting['verified']);self.assertEqual(accounting['measuredIds'],[T.PLAN_IDS[0]])


class FailurePathAccounting(unittest.TestCase):
 def test_setup_refusal_and_exception_still_audit(self):
  for error in (X.SetupInconclusive('fixture mismatch'),RuntimeError('setup failed')):
   with self.subTest(error=type(error).__name__),tempfile.TemporaryDirectory() as d:
    destination=Path(d)/'receipt'/X.REPORT_NAME;seen=[]
    inputs={'source6Executor':Path('fake.py'),'source6Profile':Path('fake-profile.json').resolve()}
    module=types.SimpleNamespace(PROFILE=inputs['source6Profile'],validate_source=lambda:({},{}),validate_target=lambda x:None)
    class NoDatabaseIO:
     def __init__(self,*args):self.report=args[2]
     def setup(self):raise error
     def settle_pending(self):return []
     def accounting(self):seen.append('audited');self.report.value['statementAccounting']={'verified':False,'reasons':['setup not established']};return {},[]
    with patch.object(X,'ROOT',Path(d)/'not-output'),patch.object(X,'prepare',return_value=(T.PROFILE,inputs,{'noticeCopySha256':'x','genuineState':[],'expectedTreatment':[]})),patch.object(X,'load_module',return_value=module),patch.object(X,'PgIO',NoDatabaseIO):
     if isinstance(error,X.SetupInconclusive):self.assertEqual(X.main(['--execute-characterization','--output',str(destination)]),2)
     else:
      with self.assertRaises(RuntimeError):X.main(['--execute-characterization','--output',str(destination)])
    self.assertEqual(seen,['audited']);self.assertIn('statementAccounting',json.loads(destination.read_text()))

if __name__=='__main__':unittest.main(verbosity=2)
