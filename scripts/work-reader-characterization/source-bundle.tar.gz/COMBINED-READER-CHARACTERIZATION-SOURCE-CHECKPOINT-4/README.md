# Held reader characterization Source4

Bounded correction of actual Opus's three Source3 findings. See HANDOFF.md for evidence, limits, required sibling extraction layout and root-owned next steps.

62 offline controls pass with process/network contact denied; source-only check-plan passes with all ten pins closed. Raw timing and NOTICE evidence survives invalidity, but interpreted labels are withheld. Authority relation count and kind remain strict; only its raw hash has the declared exception.

The fixed current-fixture method, 20-call plan, exact SQL gate, NOTICE-only copy, real authenticated context, finite budgets and original acceptance holds are unchanged. Source3 and transitive frozen sources are byte-preserved. SOURCE3-* documents are historical evidence. This is not a PG17 runtime pass, package, dispatch, full-trial approval or restoration.
