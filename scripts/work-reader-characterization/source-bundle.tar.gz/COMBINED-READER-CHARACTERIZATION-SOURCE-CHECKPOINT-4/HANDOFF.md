# Source4 handoff — source-only, held for actual peer review

Opus's three Source3 findings are corrected. Invalid evidence now suppresses every gate/copy/metadata diagnostic label and every numeric threshold label, while keeping raw timings, ratios, differences, classifications and NOTICE markers. The authority exception permits only a hash difference: its relation kind and row count must match A/B.

62/62 offline tests pass: 55 inherited controls plus 7 new tests. The new tests cover every public record alias, five late-invalidity reasons, success labels, all three timeout-censoring combinations, a retained five-marker NOTICE prefix, authority count/kind differences, and the real PgIO.setup/main path using fake IO. Count 2 and wrong kind both produce setup exit 2 with zero measured calls; hash-only variation reaches setup completion. Fake setup constructors never call a source6 builder. Existing tests separately exercise the real source6 Runner and real measured PgIO adapter with fake process responses.

Check-plan exits 0 with all 10 pins closed. No real process or network contact was attempted by reviewed code. AST verification finds changes only in shared_state, interpret, Characterization.summary, and the authority-exception description in PgIO.setup. All other function ASTs and module constants are identical to Source3, including the fixed 20-call order, authentication, SQL/NOTICE protocol, timing budgets and central IO/sampler ledger.

Five direct regression controls against frozen Source3 demonstrate the old defects (8 expected failing subtest instances, zero errors); the valid-success control still passes. An initial broader prior-source run had 2 errors after old setup incorrectly passed the expected refusal boundary and reached fake runtime state that was not supplied. That broader attempt is recorded but is not accepted as proof. The primary Source4 suite passed on its first run with no failures or errors.

Source3's manifest and all 16 listed files, Source2's seven original files, all 10 reader inputs, all 35 source6 profile pins, frozen Source1's 188 manifest entries, and approved-source3's 103 entries were hash-verified unchanged. The Source4 profile differs only in revisedPlan's Source4 self-path and digest. PIN-PRESERVATION.json carries the exact reader and transitive inventories. SOURCE3-* files are preserved prior evidence, not current approval or validation. The method identifier stays current_fixture_paired_raw_ab_v3 because the experiment itself did not change.

## Root packaging handoff

No package or workflow was authored. Keep the old bundle's Source1–Source6 sibling layout unchanged. Add this Source4 reader directory under the same extracted parent, together with these reader input paths:

- COMBINED-F6C04-READER-TIMEOUT-DIAGNOSIS-3/CHARACTERIZATION-PLAN.md
- COMBINED-F6C04-READER-TIMEOUT-DIAGNOSIS-1/evidence/call-01300.sql and OBSERVATIONS.json
- COMBINED-READER-CHARACTERIZATION-SAFETY-REVIEW-1/REVIEW.md
- COMBINED-READER-CHARACTERIZATION-SAFETY-REVIEW-2/REVIEW.md and EXPECTED-TREATMENT-INVENTORY.json
- COMBINED-READER-CHARACTERIZATION-SOURCE-CHECKPOINT-4/REVISED-CHARACTERIZATION-PLAN.md
- COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-6/combined_executor.py, executor-profile.json and test_combined_executor.py

Each profile path is exactly ../<checkpoint>/<file>, resolved by the reader under its directory's parent; do not flatten or rename checkpoint directories. Source6 additionally resolves the entire COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-1 sibling, including its MANIFEST, author_variants.py, pinned-repository, variants, approved-source3 and all manifest-listed files. Preserve these transitive files, rather than reconstructing a reduced bundle from just the three direct source6 pins. Source6's unchanged validate_source() does its existing authoring/byte comparisons at execution; no builder was run in this correction task.

Use COMBINED-GENUINE-CI-PROPOSAL-5/work-combined-postgres.yml only as the existing prerequisite template, with prerequisite-pins.json and verify_prerequisites.py. Preserve the exact six root scripts in their existing order and the existing volume-output environment variables:

1. scripts/verify-work-activity-engine-role-parity.py
2. scripts/verify-work-activity-catalog-concurrency.py
3. scripts/verify-work-unit-review-concurrency.py
4. scripts/verify-work-unit-review-volume.py
5. scripts/verify-work-activity-totals-postgres.py
6. scripts/verify-work-unit-contributors-postgres.py

These run before the reader on a fresh disposable PG17 service, leaving exact common0846 with the authored roles, ACLs, settings and four-database inventory. The reader constructs its fresh fixture and A/B clones itself. Do not execute the old full-trial combined_executor --execute-fixture as a reader prerequisite, and do not reuse residual databases. Prerequisite script bodies/pins remain root-owned and unchanged.

With EXTRACTED set to the common absolute extraction parent, the source-only entry is:

```sh
python3 "$EXTRACTED/COMBINED-READER-CHARACTERIZATION-SOURCE-CHECKPOINT-4/characterization_executor.py" --check-plan
```

The future diagnostic entry, after root review/package/prerequisite checks, is:

```sh
python3 "$EXTRACTED/COMBINED-READER-CHARACTERIZATION-SOURCE-CHECKPOINT-4/characterization_executor.py" --execute-characterization --output "$RUNNER_TEMP/work-reader-characterization-new/reader-characterization.json"
```

The output directory must not already exist and must be outside the extracted common source parent. Keep WORK_ACTIVITY_ROLE_TEST_DB_URL equal to postgresql://supabase_admin:fixture-only@localhost:5432/forge_work_activity_role_test. No execution was authorized or performed by this handoff. run_offline_controls.py is the denied-process/network test entry; it writes its local validation receipts, so run it in a disposable copy with the complete sibling input layout, preserving the sealed original.

## Remaining holds

Actual Opus/Fable review of this Source4 seal is root-owned and pending; the actual Opus Source3 receipt is pinned in CORRECTION-AUDIT.json. PostgreSQL17 SQL/NULL behavior, psql/NOTICE runtime formatting, sampler scheduling and overhead, packaging and dispatch remain unverified. A fast call may still correctly fail closed if no sample completes. Setup/final IO is recorded and hashed but is not a predeclared exhaustive semantic query list, as Opus noted. Full original 20/42/65, provider, release and restoration acceptances remain false. The 20 diagnostic measurements cannot recreate or refute the original historical timeout.
