"""Opus Source3 regressions: real summary/interpret/setup control flow, fake IO only.
Setup uses a deliberately minimal fake constructor/seed, never source6 builders.
Existing ledger tests separately exercise the unchanged real runner with fake replies.
"""
import copy,importlib.util,json,sys,tempfile,types,unittest
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('source4_baseline',HERE/'test_characterization_executor.py');T=importlib.util.module_from_spec(spec);spec.loader.exec_module(T)
X=T.X
WITHHELD='withheld_whole_characterization_inconclusive'

def values(value):
 if isinstance(value,dict):
  for child in value.values():yield from values(child)
 elif isinstance(value,list):
  for child in value:yield from values(child)
 else:yield value

class WholeClaimProjection(unittest.TestCase):
 def test_final_failure_withholds_every_gate_metadata_alias_and_preserves_raw(self):
  valid=T.run(T.FakeIO());invalid=T.run(T.FakeIO(final=['io_file_missing_or_changed:x']))
  self.assertEqual(invalid['characterization']['status'],'inconclusive')
  for key in ('exactGate','noticeCopy'):
   self.assertEqual(invalid[key]['diagnostic'],WITHHELD)
   self.assertEqual({k:v for k,v in invalid[key].items() if k!='diagnostic'},{k:v for k,v in valid[key].items() if k!='diagnostic'})
  self.assertEqual(invalid['exactGate']['classification'],'returned');self.assertEqual(len(invalid['noticeCopy']['markers']),20)
  for raw,projected in zip(valid['metadataRepeatState'],invalid['metadataRepeatState']):
   self.assertEqual(projected['diagnostic'],WITHHELD);self.assertEqual({k:v for k,v in projected.items() if k!='diagnostic'},raw)
  for record in invalid['records'][16:]:self.assertEqual(record['diagnostic'],WITHHELD)
  self.assertFalse(any(isinstance(v,str) and v.startswith('diagnostic_reproduction_') for v in values(invalid)))
 def test_all_late_invalidity_reasons_hide_thresholds_but_retain_numbers(self):
  for reason in ('persistent_state_changed_by_reads:B','global_roles_or_settings_changed','uncertain_backend_settlement','unexpected_database_inventory','io_file_missing_or_changed:x'):
   with self.subTest(reason=reason):
    s=T.run(T.FakeIO(timings=T.both_rounds('totals',1000,1500),final=[reason]))
    for apis in (s['apis'],s['pairedScope']['apis']):
     for api in X.API_TYPES:
      self.assertEqual(apis[api]['conclusion'],WITHHELD)
      for row in apis[api]['rounds']:self.assertEqual(row['status'],'threshold_not_evaluated')
     for row in apis['totals']['rounds']:self.assertEqual((row['aMs'],row['bMs'],row['ratio'],row['deltaMs']),(1000.0,1500.0,1.5,500.0))
    self.assertFalse({'threshold_met','threshold_not_met'} & {v for v in values(s) if isinstance(v,str)})
 def test_invalidity_preserves_censor_facts_and_notice_prefix(self):
  for branches,status in (('AB','both_timeout_censored'),('A','a_only_timeout_censored'),('B','b_only_timeout_censored')):
   ids=[f'r{r}-{b}-totals' for r in (1,2) for b in branches]
   s=T.run(T.FakeIO(timeouts=ids,final=['final_state_unknown'],overrides={'b-notice-copy':{'returnCode':3,'stderr':T.notice_stderr(5)+T.TIMEOUT_ERR}}))
   for apis in (s['apis'],s['pairedScope']['apis']):
    self.assertEqual(apis['totals']['conclusion'],WITHHELD)
    self.assertTrue(all(row['status']==status for row in apis['totals']['rounds']))
   self.assertEqual(s['noticeCopy']['diagnostic'],WITHHELD);self.assertEqual(s['noticeCopy']['classification'],'statement_timeout')
   self.assertEqual(s['noticeCopy']['markerPrefixLength'],5);self.assertEqual(len(s['noticeCopy']['markers']),5);self.assertTrue(s['noticeCopy']['censored'])
 def test_valid_results_keep_diagnostic_and_threshold_labels(self):
  s=T.run(T.FakeIO(timings=T.both_rounds('totals',1000,1500)))
  self.assertEqual(s['characterization']['status'],'valid');self.assertIsNone(s['pairedScope'])
  self.assertEqual(s['exactGate']['diagnostic'],'diagnostic_reproduction_passed');self.assertEqual(s['noticeCopy']['diagnostic'],'diagnostic_reproduction_passed')
  self.assertTrue(all(r['status']=='threshold_met' for r in s['apis']['totals']['rounds']))
  self.assertTrue(all(r['status']=='threshold_not_met' for r in s['apis']['contributors']['rounds']))

AUTH={'schema':'public','name':'work_activity_authority_generation','kind':'r','count':1,'sha256':'1'*64}
class AuthorityHashOnlyException(unittest.TestCase):
 def test_only_hash_difference_is_exempt(self):
  a=[dict(AUTH)];b=copy.deepcopy(a);b[0]['sha256']='2'*64;self.assertEqual(X.shared_state(a,b)[0],[])
  for change in ({'count':2},{'kind':'S'}):
   modified=copy.deepcopy(b);modified[0].update(change)
   self.assertEqual(X.shared_state(a,modified)[0],['shared_relation_differs:public.work_activity_authority_generation'])

# The real PgIO.setup is called. Only environmental IO/fixture methods are fake;
# control-flow tests neither instantiate source6.Executor nor execute seed/install SQL.
RealPgIO=X.PgIO
class SetupFixture:
 def __init__(self,folder,change):
  self.folder=folder;self.change=change;self.installed=False;self.trace=[]
  profile=folder/'pinned-repository/scripts/fixtures/work-activity-engine-role-parity.json';profile.parent.mkdir(parents=True)
  profile.write_text(json.dumps({'database':{'owner':'postgres','acl':['=Tc/postgres']}}))
  self.expected=json.loads(X.resolve_input(T.PROFILE['inputs']['expectedTreatment']['path']).read_text())['catalogMinusGenuineBaseline']
  self.module=types.SimpleNamespace(HERE=folder,BASE='fake_template',PROFILE=(folder/'fake-profile.json').resolve(),qi=lambda s:'"'+s+'"',same_cluster=lambda a,b:None,validate_source=lambda:({},{}),validate_target=lambda x:None)
 def make(self,s6,target,report,*args):
  outer=self
  class Runner:
   def __init__(self,kind):self.kind=kind
   def run(self,sql,**kw):outer.trace.append('fake_sql:'+str(kw.get('purpose')))
   def json(self,sql,**kw):
    if 'not exists' in sql:return True
    if 'datacl' in sql:return {'owner':'postgres','acl':['=Tc/postgres']}
    if 'work_activity_authority_generation' in sql:return {'singleton':True,'capture_enabled':False}
    return {}
  runners={k:Runner(k) for k in ('A','B')};base=Runner('base');admin=Runner('admin')
  identity={**T.CLUSTER,'databaseOid':1}
  def fingerprint(r):
   state=[dict(AUTH)]
   if self.installed and r.kind=='B':
    state[0].update(sha256='2'*64,**self.change);state += [dict(x,count=0,sha256='3'*64) for x in self.expected]
   self.trace.append('fingerprint:'+r.kind);return state
  ex=types.SimpleNamespace(r=base,admin=admin,verify_infrastructure=lambda:(identity,{}),make_fixture=lambda r:types.SimpleNamespace(seed=lambda:self.trace.append('fake_seed')),catalog=lambda *a:None,fingerprint=fingerprint,identity=lambda r:{**identity,'databaseOid':2 if r.kind=='A' else 3},context=lambda r:{'authority':{'capture_enabled':False}},authority_set=lambda *a:None)
  io=RealPgIO.__new__(RealPgIO);io.s6=self.module;io.ex=ex;io.report=report;io.runners=runners;io.genuine_state=[dict(AUTH)];io.genuine={'metadataTables':[]};io.expected_treatment=self.expected;io.dense=[]
  io.setup_reasons=[];io.post_setup={};io.cluster=None;io.historical_reproduced=False;io.setup_end=None;io.final_start=None;io.measured_specs=[];io.checkpoint_attempts=[];io.sampler_receipts=[]
  def install(old):self.installed=True;self.trace.append('fake_install')
  io.install_b=install;self.io=io;return io

class ActualSetupAuthorityBoundary(unittest.TestCase):
 def test_extra_authority_row_and_wrong_kind_refuse_real_setup_with_exit_two(self):
  for change in ({'count':2},{'kind':'S'}):
   with self.subTest(change=change),tempfile.TemporaryDirectory() as d:
    folder=Path(d);fixture=SetupFixture(folder,change);destination=folder/'receipt'/X.REPORT_NAME
    inputs={'source6Executor':folder/'fake.py','source6Profile':fixture.module.PROFILE}
    with patch.object(X,'ROOT',folder/'not-output'),patch.object(X,'prepare',return_value=(T.PROFILE,inputs,{'noticeCopySha256':'x','genuineState':[],'expectedTreatment':fixture.expected})),patch.object(X,'load_module',return_value=fixture.module),patch.object(X,'PgIO',fixture.make),patch.object(X.platform,'platform',return_value='offline fake platform'):
     self.assertEqual(X.main(['--execute-characterization','--output',str(destination)]),2)
    report=json.loads(destination.read_text());self.assertEqual(report['status'],'inconclusive_setup_not_established')
    self.assertEqual(report['sharedStateDifferences'],['shared_relation_differs:public.work_activity_authority_generation'])
    self.assertEqual(report['calls'],[]);self.assertEqual(report['statementAccounting']['measuredIds'],[])
    self.assertEqual(report['authorityContexts']['A']['after'],report['authorityContexts']['B']['after'])
    self.assertEqual(fixture.trace[-2:],['fingerprint:A','fingerprint:B']);self.assertIsNone(fixture.io.setup_end)
 def test_hash_only_exception_reaches_setup_complete_in_real_control_flow(self):
  with tempfile.TemporaryDirectory() as d:
   folder=Path(d);fixture=SetupFixture(folder,{});report=types.SimpleNamespace(value={'calls':[],'branches':{}},persist=lambda *a:None)
   io=fixture.make(None,None,report)
   with patch.object(X.platform,'platform',return_value='offline fake platform'):io.setup()
   self.assertEqual(io.setup_end,0);self.assertEqual(report.value['ioPhase'],'measurement');self.assertNotIn('sharedStateDifferences',report.value)
   self.assertEqual(len(report.value['treatmentOnlyRelations']),17)

if __name__=='__main__':unittest.main(verbosity=2)
