## outputs/Forge-Redesign-Implementation-2026-10-03/Cross-Job-Capture/COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-1/pinned-repository/supabase/migrations/20261108440000_work_unit_review.sql:119
SHA-256: e32122a581bf995857983cc433323bc490381b6eb217c583bf95fd7376b3e53f

```text
119: create function public._work_activity_source_material(p_kind text,p_row jsonb) returns jsonb
120: language plpgsql immutable set search_path=public,pg_temp as $$
121: declare fields text[];
122: begin
123:  if p_row is null then return '{}'::jsonb; end if;
124:  fields:=case p_kind
125:  when 'opening_phases' then array['id','opening_id','kind','status','started_by','started_at','paused_at','paused_seconds','submitted_at','submitted_by','minutes']
126:  when 'custom_work_sessions' then array['id','profile_id','shift_id','project_id','unit_id','kind','participation','stage','outcome','started_at','ended_at','end_reason','revision','review_required','shift_status']
127:  when 'custom_work_units' then array['id','project_id','opening_id','created_by']
128:  when 'project_openings' then array['id','project_id','removed_at','assigned_window_id','status','confirmed','work_started_at','work_ended_at','needs_flashing']
129:  when 'service_visit_units' then array['id','visit_id','project_id','work_unit_id','opening_id','window_id','created_by','outcome','facts','issue','fail_point','cause','repair','verification','prevention','next_steps']
130:  when 'service_visits' then array['id','project_id','created_by']
131:  when 'summons' then array['id','project_id','opening_id','requested_by','status']
132:  when 'unit_redos' then array['id','opening_id','pressed_by','pressed_at','resolved_at']
133:  when 'qc_checks' then array['id','project_opening_id','status','checked_by','checked_at']
134:  when 'install_events' then array['id','project_opening_id','started_at','minutes','installer_id','voided_at','voided_by','credited_to','quality_grade','ai_confirmed']
135:  when 'crew_work_records' then array['id','project_id','unit_id','filed_by','work_date','stage','outcome','whole_complete']
136:  when 'crew_work_record_people' then array['record_id','profile_id','voided_at','voided_by']
137:  when 'work_session_capture_metadata' then array['session_id','profile_id','project_id','scope','unit_id','fact_revision','unit_facts','recorded_at']
138:  when 'custom_work_history' then array['id','project_id','actor_id','entity_id','action','before_value','after_value','created_at']
139:  else null end;
140:  if fields is null then return public._work_activity_evidence(p_kind,p_row); end if;
141:  return (select jsonb_object_agg(key,value) from jsonb_each(p_row) where key=any(fields));
142: end; $$;
143: revoke all on function public._work_activity_source_material(text,jsonb) from public,anon,authenticated,service_role;
```

## outputs/Forge-Redesign-Implementation-2026-10-03/Cross-Job-Capture/COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-1/pinned-repository/supabase/migrations/20261108440000_work_unit_review.sql:354
SHA-256: e32122a581bf995857983cc433323bc490381b6eb217c583bf95fd7376b3e53f

```text
354: create view public._work_unit_review_live_sources as
355: select 'custom_work_units'::text kind,r.id::text source_id,public._work_activity_source_material('custom_work_units',to_jsonb(r)) value from public.custom_work_units r
356: union all
357: select 'project_openings'::text kind,r.id::text source_id,public._work_activity_source_material('project_openings',to_jsonb(r)) value from public.project_openings r
358: union all
359: select 'service_visit_units'::text kind,r.id::text source_id,public._work_activity_source_material('service_visit_units',to_jsonb(r)) value from public.service_visit_units r
360: union all
361: select 'service_visits'::text kind,r.id::text source_id,public._work_activity_source_material('service_visits',to_jsonb(r)) value from public.service_visits r
362: union all
363: select 'summons'::text kind,r.id::text source_id,public._work_activity_source_material('summons',to_jsonb(r)) value from public.summons r
364: union all
365: select 'unit_redos'::text kind,r.id::text source_id,public._work_activity_source_material('unit_redos',to_jsonb(r)) value from public.unit_redos r
366: union all
367: select 'qc_checks'::text kind,r.id::text source_id,public._work_activity_source_material('qc_checks',to_jsonb(r)) value from public.qc_checks r
368: union all
369: select 'install_events'::text kind,r.id::text source_id,public._work_activity_source_material('install_events',to_jsonb(r)) value from public.install_events r
370: union all
371: select 'crew_work_records'::text kind,r.id::text source_id,public._work_activity_source_material('crew_work_records',to_jsonb(r)) value from public.crew_work_records r
372: union all
373: select 'crew_work_record_people'::text kind,r.record_id::text||':'||r.profile_id::text source_id,public._work_activity_source_material('crew_work_record_people',to_jsonb(r)) value from public.crew_work_record_people r
374: union all
375: select 'work_session_capture_metadata'::text kind,r.session_id::text source_id,public._work_activity_source_material('work_session_capture_metadata',to_jsonb(r)) value from public.work_session_capture_metadata r
376: union all
377: select 'custom_work_history'::text kind,r.id::text source_id,public._work_activity_source_material('custom_work_history',to_jsonb(r)) value from public.custom_work_history r
378: union all
379: select 'custom_work_sessions'::text kind,r.id::text source_id,public._work_activity_source_material('custom_work_sessions',to_jsonb(r)) value from public.custom_work_sessions r
380: union all
381: select 'unit_sessions'::text kind,r.id::text source_id,public._work_activity_source_material('unit_sessions',to_jsonb(r)) value from public.unit_sessions r
382: union all
383: select 'task_sessions'::text kind,r.id::text source_id,public._work_activity_source_material('task_sessions',to_jsonb(r)) value from public.task_sessions r
384: union all
385: select 'service_time_sessions'::text kind,r.id::text source_id,public._work_activity_source_material('service_time_sessions',to_jsonb(r)) value from public.service_time_sessions r
386: union all
387: select 'opening_phases'::text kind,r.id::text source_id,public._work_activity_source_material('opening_phases',to_jsonb(r)) value from public.opening_phases r
388: union all
389: select 'summon_helpers'::text kind,r.id::text source_id,public._work_activity_source_material('summon_helpers',to_jsonb(r)) value from public.summon_helpers r
390: ;
391: revoke all on public._work_unit_review_live_sources from public,anon,authenticated,service_role;
392: 
393: -- Private complete source closure. Authorization precedes every returned identity
394: -- or digest. Legacy baseline plus every OLD/NEW version prevents current-row ABA.
395: create function public._work_unit_review_scope(actor uuid,unit_id uuid) returns jsonb
396: language plpgsql volatile security definer set search_path=public,pg_temp as $$
397: declare ub jsonb;u public.custom_work_units;f public.work_unit_fact_revisions;
398:  history jsonb;live jsonb;jobs jsonb;openings jsonb;fact_origins jsonb;people uuid[];sourceids jsonb;v jsonb;w jsonb;j uuid;o uuid;
399:  active integer:=0;pending integer:=0;proven boolean:=true;dimension_proven boolean:=true;normal_sources jsonb;shift_history jsonb;dimension jsonb;manifest jsonb;integrity jsonb;inc bigint;
400: begin
401:  ub:=public._work_activity_unit_basis(unit_id,actor);if ub is null then return null;end if;
402:  select * into u from public.custom_work_units where id=unit_id;
403:  select r.* into f from public.work_unit_fact_revisions r join public.work_unit_fact_current c on c.current_revision_id=r.id where c.unit_id=u.id;
404:  inc:=(ub->>'incarnationEpoch')::bigint;
405:  if f.id is not null and (f.unit_id is distinct from u.id or not exists(select 1 from public.work_unit_fact_current c where c.unit_id=u.id and c.current_revision_id=f.id and c.current_revision=f.revision)) then return null;end if;
406:  -- A reused physical UUID cannot inherit a pre-existing history partition.
407:  -- Canonical writers already refuse it; administrative reconciliation is explicit.
408:  if inc<>0 then proven:=false;end if;
409:  with versions as materialized (
410:  select source_kind kind,source_id,b.value from public.work_activity_source_history h
411:  cross join lateral (values(h.before_value),(h.after_value)) b(value) where b.value<>'{}'
412:  union all
413:  select case e.source_kind when 'custom' then 'custom_work_sessions' when 'unit' then 'unit_sessions' when 'task' then 'task_sessions' when 'service' then 'service_time_sessions' when 'phase' then 'opening_phases' when 'helper' then 'summon_helpers' end,e.source_id::text,b.value
414:  from public.personal_activity_transition_sources e cross join lateral(values(e.before_evidence),(e.after_evidence)) b(value)
415:  where e.source_kind in ('custom','unit','task','service','phase','helper') and b.value<>'{}'
416:  union all select kind,source_id,value from public._work_unit_review_live_sources
417:  ), roots as (
418:  select value from versions where kind='custom_work_units' and source_id=u.id::text
419:  ), mapped as (
420:  select value->>'opening_id' id from roots where value->>'opening_id' is not null
421:  union select u.opening_id::text where u.opening_id is not null
422:  ), service_units as (
423:  select distinct source_id id from versions where kind='service_visit_units' and (value->>'work_unit_id'=u.id::text or value->>'opening_id' in(select id from mapped) or value->>'window_id' in(select value->>'assigned_window_id' from versions where kind='project_openings' and source_id in(select id from mapped)))
424:  ), summons_for_unit as (
425:  select distinct source_id id from versions where kind='summons' and value->>'opening_id' in(select id from mapped)
426:  ), crew as (
427:  select distinct source_id id from versions where kind='crew_work_records' and value->>'unit_id'=u.id::text
428:  ), custom_sessions as (
429:  select distinct source_id id from versions where kind='custom_work_sessions' and value->>'unit_id'=u.id::text
430:  union select value->>'session_id' from versions where kind='work_session_capture_metadata' and value->>'unit_id'=u.id::text
431:  ), visits as (
432:  select distinct value->>'visit_id' id from versions where kind='service_visit_units' and source_id in(select id from service_units)
433:  ), selected as (
434:  select distinct kind,source_id from versions where
435:  (kind='custom_work_units' and source_id=u.id::text)
436:  or (kind='project_openings' and source_id in(select id from mapped))
437:  or (kind in ('unit_sessions','task_sessions','opening_phases','unit_redos') and value->>'opening_id' in(select id from mapped))
438:  or (kind in ('qc_checks','install_events') and value->>'project_opening_id' in(select id from mapped))
439:  or (kind='custom_work_sessions' and source_id in(select id from custom_sessions))
440:  or (kind='service_visit_units' and source_id in(select id from service_units))
441:  or (kind='service_time_sessions' and value->>'unit_id' in(select id from service_units))
442:  or (kind='service_visits' and source_id in(select id from visits))
443:  or (kind='summons' and source_id in(select id from summons_for_unit))
444:  or (kind='summon_helpers' and value->>'summon_id' in(select id from summons_for_unit))
445:  or (kind='crew_work_records' and source_id in(select id from crew))
446:  or (kind='crew_work_record_people' and value->>'record_id' in(select id from crew))
447:  or (kind='work_session_capture_metadata' and (value->>'unit_id'=u.id::text or source_id in(select id from custom_sessions)))
448:  or (kind='custom_work_history' and (value->>'entity_id' in(select id from custom_sessions)
449:  or (value->>'entity_id'=u.id::text and (value->>'action' not in ('unit','link')
450:  or value#>'{before_value,facts,installation_complete}' is distinct from value#>'{after_value,facts,installation_complete}'))))
451:  ) select coalesce(jsonb_agg(jsonb_build_object('kind',kind,'id',source_id) order by kind,source_id),'[]') into sourceids from selected;
452:  if jsonb_array_length(sourceids)>4000 then return null;end if;
453:  select coalesce(jsonb_agg(to_jsonb(h) order by h.id),'[]') into history from public.work_activity_source_history h
454:  where exists(select 1 from jsonb_array_elements(sourceids) x where x->>'kind'=h.source_kind and x->>'id'=h.source_id);
455:  -- Baseline captures current rows only; missing pre-install intermediate work is unknown.
456:  if exists(select 1 from jsonb_array_elements(history) h where h->>'legacy_baseline'='true') then proven:=false;end if;
457:  if jsonb_array_length(history)>10000 or octet_length(history::text)>2000000 then return null;end if;
458:  select coalesce(jsonb_agg(jsonb_build_object('kind',s.kind,'id',s.source_id,'value',s.value) order by s.kind,s.source_id),'[]') into live
459:  from public._work_unit_review_live_sources s where exists(select 1 from jsonb_array_elements(sourceids) x where x->>'kind'=s.kind and x->>'id'=s.source_id);
```

## outputs/Forge-Redesign-Implementation-2026-10-03/Cross-Job-Capture/COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-1/pinned-repository/supabase/migrations/20261108450000_work_activity_totals.sql:304
SHA-256: e0e74c2d1985d332af81f95d20d2a6625c40cb5fcf995b4aa6e267d75e092140

```text
304: create function public.work_activity_totals_read(p_project_id uuid,p_unit_id uuid default null) returns jsonb
305: language plpgsql volatile security definer set search_path=public,pg_temp as $$
306: declare actor uuid;stamp timestamptz;ids uuid[];sid uuid;ledger jsonb;ledgers jsonb:='[]';rows jsonb;unit_scope jsonb;review jsonb;unitrow public.custom_work_units;
307:  available constant jsonb:='{"protocolVersion":1,"availability":"unavailable","totals":null}';complete boolean:=true;personal_complete boolean:=true;trusted boolean:=false;
308:  orphan record;orphan_proof jsonb;scope_unproven boolean:=false;own_scope_unproven boolean:=false;reconciliation_authorized boolean:=false;reconciliation_ledgers jsonb;orphan_count integer:=0;cohort jsonb;reason text[]:='{}';area numeric;factor_num numeric;factor_den numeric;labor numeric;own_labor numeric;actual numeric;cohort_scope boolean;
309: begin
310:  perform public._work_activity_read_committed();perform public._work_activity_gate();actor:=public._work_activity_actor();
311:  perform pg_advisory_xact_lock(7710,0);actor:=public._work_activity_actor();stamp:=clock_timestamp();
312:  if p_project_id is null or not public._ai_job_visible(p_project_id,actor) or not public._work_unit_review_coverage() or not public._work_totals_coverage() then return available;end if;
313:  reconciliation_authorized:=public._work_unit_review_authority(actor,jsonb_build_array(p_project_id),'final_qc');
314:  if p_unit_id is not null then
315:  select * into unitrow from public.custom_work_units where id=p_unit_id;
316:  if unitrow.id is null or unitrow.project_id<>p_project_id then return available;end if;
317:  unit_scope:=public._work_unit_review_scope(actor,p_unit_id);if unit_scope is null then return available;end if;
318:  review:=public._work_unit_review_view(actor,unit_scope);if review is null then return available;end if;
319:  reconciliation_authorized:=reconciliation_authorized and public._work_unit_review_authority(actor,unit_scope->'jobs','final_qc');
320:  own_scope_unproven:=exists(select 1 from jsonb_array_elements(unit_scope#>'{manifest,history}') h where h->>'source_kind' in ('custom_work_sessions','unit_sessions','task_sessions','service_time_sessions') and (h#>>'{before_value,profile_id}'=actor::text or h#>>'{after_value,profile_id}'=actor::text) and not exists(select 1 from jsonb_array_elements(unit_scope#>'{manifest,transitions}') t where t#>>'{source,source_id}'=h->>'source_id' and t#>>'{source,source_shift_id}' is not null));
```

## outputs/Forge-Redesign-Implementation-2026-10-03/Cross-Job-Capture/COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-1/pinned-repository/supabase/migrations/20261108460000_work_unit_contributors.sql:203
SHA-256: ae6185e4b390b7cff8f3d7aca837688fda2756792bdf055ef8c3a1f290d438c5

```text
203: create function public.work_unit_contributors_read(p_project_id uuid,p_unit_id uuid,p_protocol_version integer default 1) returns jsonb
204: language plpgsql volatile security definer set search_path=public,pg_temp as $$
205: declare actor uuid;stamp timestamptz;u public.custom_work_units;s jsonb;review jsonb;ids uuid[];sid uuid;ledger jsonb;proof_cache jsonb:='{}';ledgers jsonb:='[]';claims jsonb;v jsonb;w jsonb;r jsonb;n jsonb;
206:  reasons text[]:='{}';row_reasons text[];subject uuid;subjects uuid[];person jsonb;people jsonb:='[]';zero_only jsonb:='[]';named jsonb:='[]';untimed jsonb:='[]';entries jsonb;
207:  micros numeric;positive boolean;uncertain boolean;named_person boolean;live boolean;proof_bytes bigint:=0;
208:  unavailable constant jsonb:='{"protocolVersion":1,"availability":"unavailable","contributors":null}';
209: begin
210:  perform public._work_activity_read_committed();perform public._work_activity_gate();actor:=public._work_activity_actor();
211:  if not public._work_config_is_supervisor(actor) then raise exception using errcode='42501',message='A current supervisor or owner is required.';end if;
212:  perform pg_advisory_xact_lock(7710,0);actor:=public._work_activity_actor();
213:  if not public._work_config_is_supervisor(actor) then raise exception using errcode='42501',message='A current supervisor or owner is required.';end if;
214:  stamp:=clock_timestamp();
215:  if p_protocol_version is distinct from 1 or p_project_id is null or p_unit_id is null then raise exception using errcode='23514',message='A valid unit contributors request is required.';end if;
216:  if not public._ai_job_visible(p_project_id,actor) or not public._work_unit_review_coverage() or not public._work_totals_coverage() or not public._work_unit_contributors_coverage() then return unavailable;end if;
217:  select * into u from public.custom_work_units where id=p_unit_id;
218:  if u.id is null or u.project_id is distinct from p_project_id then return unavailable;end if;
219:  s:=public._work_unit_review_scope(actor,p_unit_id);if s is null then return unavailable;end if;
220:  review:=public._work_unit_review_view(actor,s);if review is null then return unavailable;end if;
221:  if not coalesce((s->>'proven')::boolean,false) then reasons:=array_append(reasons,'source_unproven');end if;
```

## outputs/Forge-Redesign-Implementation-2026-10-03/Cross-Job-Capture/COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-1/variants/inactive.sql:1520
SHA-256: 2a323f3d59e622b80cf235c68d7d39533ae1b98717b1a9769a5e5923046f69cd

```text
1520: create or replace function public._work_unit_review_coverage() returns boolean language sql stable security definer set search_path=public,pg_temp as $$
1521:  select (coalesce((select p.prosrc is not null and encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='b678eca76a31edbf88408302379013b762eea5b2f50d4bdd3a8ebebc55e2f3ea' and pg_get_userbyid(p.proowner)='postgres' and p.proacl::text='{postgres=X/postgres}' and p.prosecdef and p.proconfig=array['search_path=public, pg_temp']::text[] and p.provolatile='s' and not p.proisstrict and not p.proleakproof and p.proparallel='u' and p.prokind='f' and not p.proretset and p.prorettype='boolean'::regtype and p.pronargs=0 and p.pronargdefaults=0 and p.procost=100 and p.prorows=0 and p.prosupport=0 and p.prolang=(select oid from pg_language where lanname='plpgsql') from pg_proc p where p.oid=to_regprocedure('public._work_cross_job_coverage()')),false) and public._work_cross_job_coverage()) and not exists(select 1 from public.work_cross_job_shifts)
1522: $$;
1523: revoke all on function public._work_unit_review_coverage() from public,anon,authenticated,service_role;
1524: create or replace function public._work_totals_coverage() returns boolean language sql stable security definer set search_path=public,pg_temp as $$
1525:  select (coalesce((select p.prosrc is not null and encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='b678eca76a31edbf88408302379013b762eea5b2f50d4bdd3a8ebebc55e2f3ea' and pg_get_userbyid(p.proowner)='postgres' and p.proacl::text='{postgres=X/postgres}' and p.prosecdef and p.proconfig=array['search_path=public, pg_temp']::text[] and p.provolatile='s' and not p.proisstrict and not p.proleakproof and p.proparallel='u' and p.prokind='f' and not p.proretset and p.prorettype='boolean'::regtype and p.pronargs=0 and p.pronargdefaults=0 and p.procost=100 and p.prorows=0 and p.prosupport=0 and p.prolang=(select oid from pg_language where lanname='plpgsql') from pg_proc p where p.oid=to_regprocedure('public._work_cross_job_coverage()')),false) and public._work_cross_job_coverage()) and not exists(select 1 from public.work_cross_job_shifts)
1526: $$;
1527: revoke all on function public._work_totals_coverage() from public,anon,authenticated,service_role;
1528: create or replace function public._work_unit_contributors_coverage() returns boolean language sql stable security definer set search_path=public,pg_temp as $$
1529:  select (coalesce((select p.prosrc is not null and encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='b678eca76a31edbf88408302379013b762eea5b2f50d4bdd3a8ebebc55e2f3ea' and pg_get_userbyid(p.proowner)='postgres' and p.proacl::text='{postgres=X/postgres}' and p.prosecdef and p.proconfig=array['search_path=public, pg_temp']::text[] and p.provolatile='s' and not p.proisstrict and not p.proleakproof and p.proparallel='u' and p.prokind='f' and not p.proretset and p.prorettype='boolean'::regtype and p.pronargs=0 and p.pronargdefaults=0 and p.procost=100 and p.prorows=0 and p.prosupport=0 and p.prolang=(select oid from pg_language where lanname='plpgsql') from pg_proc p where p.oid=to_regprocedure('public._work_cross_job_coverage()')),false) and public._work_cross_job_coverage()) and not exists(select 1 from public.work_cross_job_shifts)
1530: $$;
1531: revoke all on function public._work_unit_contributors_coverage() from public,anon,authenticated,service_role;
```

## outputs/Forge-Redesign-Implementation-2026-10-03/Cross-Job-Capture/COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-1/variants/inactive.sql:1907
SHA-256: 2a323f3d59e622b80cf235c68d7d39533ae1b98717b1a9769a5e5923046f69cd

```text
1907: create function public.work_unit_metadata_read(p_unit_id uuid,p_protocol_version integer default 1) returns jsonb
1908: language plpgsql volatile security definer set search_path=public,pg_temp as $$
1909: declare a uuid;s jsonb;r jsonb;m jsonb;catalog jsonb;begin
1910:  if p_protocol_version is distinct from 1 or p_unit_id is null then raise exception using errcode='23514',message='Invalid metadata request.';end if;
1911:  -- METADATA_BOUNDARY_a_BEGIN
1912:  perform public._work_activity_read_committed();perform public._work_activity_gate();a:=public._work_activity_actor();perform pg_advisory_xact_lock(7710,0);a:=public._work_activity_actor();
1913:  if not coalesce((select encode(sha256(convert_to(pin.value::text,'UTF8')),'hex')='43ffd737b1582224f5b360cd90f2c6651e3cc45486899ee5e15a93bb64541744' from (select jsonb_build_object('body',p.prosrc,'owner',pg_get_userbyid(p.proowner),'acl',p.proacl::text,'definer',p.prosecdef,'config',p.proconfig,'volatility',p.provolatile,'strict',p.proisstrict,'leakproof',p.proleakproof,'parallel',p.proparallel,'kind',p.prokind,'set',p.proretset,'result',pg_get_function_result(p.oid),'args',pg_get_function_identity_arguments(p.oid),'defaults',pg_get_expr(p.proargdefaults,0),'cost',p.procost,'rows',p.prorows,'support',p.prosupport::regprocedure::text,'language',(select lanname from pg_language where oid=p.prolang)) value from pg_proc p where p.oid=to_regprocedure('public._work_unit_metadata_coverage()'))pin),false) then a:=null;
1914:  elsif not public._work_unit_metadata_coverage() or not public._work_unit_review_coverage() or not public._work_totals_coverage() or not public._work_unit_contributors_coverage() then a:=null;end if;
1915:  -- METADATA_BOUNDARY_a_END
1916: if a is not null then s:=public._work_unit_review_scope(a,p_unit_id);r:=public._work_unit_review_view(a,s);m:=public._work_unit_metadata_state(a,s,r);end if;
1917:  if m is null then return jsonb_build_object('protocolVersion',1,'availability','unavailable','metadata',null);end if;
1918:  select coalesce(jsonb_agg(jsonb_build_object('definitionId',d.id,'versionId',v.id,'version',v.version,'kind',d.kind,'projectId',d.project_id,'code',d.code,'state',v.state,'definition',v.value) order by d.kind,d.id,v.version),'[]') into catalog
1919:  from public._work_unit_metadata_definitions d join public._work_unit_metadata_versions v on v.definition_id=d.id
1920:  where d.project_id is null or d.project_id=(s#>>'{unit,projectId}')::uuid;
1921:  if jsonb_array_length(catalog)>500 or octet_length(catalog::text)>1000000 then return jsonb_build_object('protocolVersion',1,'availability','unavailable','metadata',null);end if;
1922:  return jsonb_build_object('protocolVersion',1,'availability','available','metadata',m||jsonb_build_object('asOf',public._work_activity_iso(clock_timestamp()),'catalog',catalog,
1923:  'capabilities',jsonb_build_object('assign',public._is_lead(a) or exists(select 1 from public.custom_work_units where id=p_unit_id and created_by=a),'allocate',public._work_unit_review_authority(a,s->'jobs','dimensions_edit'),'publish',public._work_config_is_owner(a),'propose',public._work_config_is_supervisor(a))));
1924: end$$;
```

## outputs/Forge-Redesign-Implementation-2026-10-03/Cross-Job-Capture/COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-1/variants/inactive.sql:2739
SHA-256: 2a323f3d59e622b80cf235c68d7d39533ae1b98717b1a9769a5e5923046f69cd

```text
2739: create or replace function public._work_unit_metadata_coverage() returns boolean
2740: language plpgsql stable security definer set search_path=public,pg_temp as $combined_coverage$
2741: declare actual text;
2742: begin
2743:  if current_setting('extra_float_digits') is distinct from '1' then
2744:   return false;
2745:  end if;
2746:  select encode(sha256(convert_to(c.value::text,'UTF8')),'hex') into actual from (
2747: select jsonb_build_object('publicCatalog',(select value from (-- Deliberately closed source-derived public catalog. Unknown live drift refuses;
2748: -- this is not a request to normalize a provider to the disposable fixture.
```

## outputs/Forge-Redesign-Implementation-2026-10-03/Cross-Job-Capture/COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-6/combined_executor.py:133
SHA-256: c78537359f30e6ccf92885e763ff11b1f9c38003c1e7bae1f8b46bba8b26532d

```text
133:   require(monitor_budget is None or (user=='supabase_admin' and 0<monitor_budget<=5),'Invalid monitor budget')
134:   timeout=35 if monitor_budget is None else monitor_budget
135:   tag='forge-combined-'+uuid.uuid4().hex
136:   env=dict(self.env,PGAPPNAME=tag,PGOPTIONS='-c timezone='+zone+' -c extra_float_digits='+str(digits))
137:   prelude='\\set VERBOSITY verbose\n'
138:   if monitor_budget is not None:
139:    milliseconds=max(1,min(2000,int(monitor_budget*1000)))
140:    prelude+=f"set statement_timeout='{milliseconds}ms';set lock_timeout='{milliseconds}ms';set search_path=public,pg_temp;\n"
141:   elif user!='authenticator':prelude+="set statement_timeout='20s';set lock_timeout='12s';set search_path=public,pg_temp;\n"
142:   n=len(self.report.value['calls']);stem=self.report.path.parent/f'call-{n:05d}';wire=prelude+sql
143:   stem.with_suffix('.sql').write_text(wire)
144:   call={'database':self.database,'login':user,'zone':zone,'floatDigits':digits,'sqlSha256':sha_bytes(wire.encode()),'file':stem.name,'status':'waiting','processTimeoutSeconds':timeout,'expectedError':error,'applicationName':tag,'purpose':purpose,'requiresBackendSettlement':True};self.report.value['calls'].append(call);self.report.value['databaseContacted']=True;self.report.persist('before_psql_wait')
145:   start=time.monotonic()
146:   try:
147:    result=self.execute(['psql',uri,'-X','-q','-t','-A','-v','ON_ERROR_STOP=1'],input=wire,text=True,capture_output=True,timeout=timeout,env=env)
148:    stem.with_suffix('.stdout').write_text(result.stdout);stem.with_suffix('.stderr').write_text(result.stderr);call.update(status='returned',returnCode=result.returncode,stdoutSha256=sha_bytes(result.stdout.encode()),stderrSha256=sha_bytes(result.stderr.encode()))
149:    if error:require(result.returncode==3 and re.search(r'\b'+re.escape(error)+r'\b',result.stderr) and (message is None or message in result.stderr),'Expected exact refusal missing: '+result.stderr[-1200:])
150:    else:require(result.returncode==0,'SQL failed: '+result.stderr[-1200:])
151:    call['requiresBackendSettlement']=False;call['outcome']='expected_sql_refusal' if error else 'successful_response'
152:    return result.stdout.strip()
153:   except subprocess.TimeoutExpired as e:
154:    call['status']='process_timeout';stem.with_suffix('.stdout').write_bytes(e.stdout.encode() if isinstance(e.stdout,str) else e.stdout or b'');stem.with_suffix('.stderr').write_bytes(e.stderr.encode() if isinstance(e.stderr,str) else e.stderr or b'');raise
155:   except BaseException as error:
156:    if call['requiresBackendSettlement']:call['status']='process_unknown'
157:    call['failure']={'type':type(error).__name__,'message':str(error)};raise
158:   finally:call['wallMillisecondsIncludingPsql']=round((time.monotonic()-start)*1000,3);self.report.persist()
```

## outputs/Forge-Redesign-Implementation-2026-10-03/Cross-Job-Capture/COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-6/combined_executor.py:271
SHA-256: c78537359f30e6ccf92885e763ff11b1f9c38003c1e7bae1f8b46bba8b26532d

```text
271:   old=json.loads((HERE/'pinned-repository/scripts/work-cross-job-old-catalog.json').read_text())['metadata'];self.catalog(self.r,old)
272:   require(self.r.json("select to_regclass('public.work_cross_job_contract') is null and to_regclass('public._work_unit_metadata_contract') is null") is True,'Fresh common0846 required')
273:   return identity,old
274:  def clone_branches(self):
275:   identity,old=self.verify_infrastructure()
276:   # Supported publication/unit constructors and explicit synthetic fixture rows,
277:   # all before cloning. No retained paid receipt or clock-request row is inserted.
278:   self.fixture=self.make_fixture(self.r);self.fixture.seed();self.catalog(self.r,old)
279:   baseline=self.fingerprint(self.r);self.report.value['baselineState']=baseline;self.report.value['syntheticSeedTimes']=self.fixture.times;self.report.persist('before_database_clones')
280:   role_profile=json.loads((HERE/'pinned-repository/scripts/fixtures/work-activity-engine-role-parity.json').read_text())
281:   for kind,name in BRANCHES.items():
282:    # Every query used for the baseline has completed and closed its connection.
283:    require(self.admin.json('select not exists(select 1 from pg_stat_activity where datname='+q(BASE)+')',user='supabase_admin') is True,'Template has another connection; never terminate it')
284:    self.report.value.setdefault('cloneAttempts',[]).append({'name':name,'stage':'before_create'});self.report.persist('before_database_create')
285:    self.admin.run('create database '+qi(name)+' with template '+qi(BASE)+' owner postgres;',user='supabase_admin')
286:    self.admin.run(db_acl_sql(name,role_profile),user='postgres')
287:    r=self.r.at(name);clone=self.identity(r);same_cluster(identity,clone);require(clone['databaseOid']!=identity['databaseOid'],'Clone must have distinct OID')
288:    actual=r.json("select jsonb_build_object('owner',pg_get_userbyid(datdba),'acl',to_jsonb(datacl::text[])) from pg_database where datname=current_database()")
289:    require(actual['owner']=='postgres' and sorted(actual['acl'])==sorted(role_profile['database']['acl']),'New database ACL differs from authored construction')
290:    self.catalog(r,old);state=self.fingerprint(r);require(state==baseline,'Clone starting state differs')
291:    self.report.value['branches'][kind]={'identity':clone,'startingStateSha256':sha_bytes(encoded(state).encode()),'startingCatalogSha256':self.profile['oldCatalogDigest'],'installed':False,'inactiveCatalogRestored':kind!='active'};self.report.persist()
292:   self.check(self.admin.json(GLOBAL,user='supabase_admin')==self.initial_global,'New branch construction leaves all global roles/settings exact')
293:  def predecessors(self):
294:   root=HERE/'pinned-repository';out=self.report.path.parent/'predecessors';out.mkdir()
295:   env=dict(self.r.env,WORK_ACTIVITY_ROLE_TEST_DB_URL=urlunparse(self.target),WORK_CROSS_JOB_POSTGRES_OUT=str(out/'work-cross-job-postgres.json'),WORK_CROSS_JOB_FRESH_SESSIONS_OUT=str(out/'work-cross-job-fresh-sessions.json'))
296:   vprofile=json.loads((root/'scripts/work-cross-job-v2-profile.json').read_text());baseline=self.identity(self.r)
297:   for kind,name,args in [('inert','verify-work-cross-job-postgres.py',[]),('fresh','verify-work-cross-job-fresh-sessions.py',['--execute-fixture'])]:
298:    before=self.identity(self.r);self.report.value['predecessorBackendQuiescenceUnproved']=True;self.report.persist('before_untagged_predecessor_execution');predecessor_process(root/'scripts'/name,args,env,out/(kind+'.log'),self.report);after=self.identity(self.r);same_database(before,after);same_database(baseline,after)
299:    path=out/('work-cross-job-postgres.json' if kind=='inert' else 'work-cross-job-fresh-sessions.json');receipt=json.loads(path.read_text());self.legacy.validate_predecessor(kind,receipt,vprofile)
300:    self.check(self.admin.json(GLOBAL,user='supabase_admin')==self.initial_global,'Pinned '+kind+' restores exact global roles, memberships and settings; no extras allowed')
301:    self.catalog(self.r,json.loads((root/'scripts/work-cross-job-new-catalog.json').read_text())['metadata'])
```

## outputs/Forge-Redesign-Implementation-2026-10-03/Cross-Job-Capture/COMBINED-GENUINE-EXECUTOR-SOURCE-CHECKPOINT-6/combined_executor.py:319
SHA-256: c78537359f30e6ccf92885e763ff11b1f9c38003c1e7bae1f8b46bba8b26532d

```text
319:  def capability_pair(self,f,negative=False):
320:   for mode,enabled in [('active',True),('closing_only',False)]:
321:    self.authority_set(f.r,enabled);context=self.context(f.r)
322:    # Guard-written updated_at differs across sequential databases and is not
323:    # read by capability. Preserve it separately; compare all consumed authority
324:    # fields, actor/state/safety values exactly, without editing either row.
325:    raw_authority=f.r.json('select to_jsonb(a) from work_activity_authority_generation a where singleton')
326:    self.report.value['cases'].append({'case':'capability_context','database':f.r.database,'mode':mode,'negative':negative,'consumedContext':context,'rawAuthority':raw_authority});self.report.persist()
327:    if negative:
328:     require(context==self.contexts[mode],'Negative lacks same-identity/state base positive')
329:     f.auth(ACTOR,(HERE/'approved-source3/fixtures/v1-capability-omitted-negative.sql').read_text())
330:    else:
331:     f.auth(ACTOR,(HERE/f'approved-source3/fixtures/v1-capability-{mode}.sql').read_text());self.contexts[mode]=context
332:    self.check(True,('Negative refusal after exact same-context positive: ' if negative else 'Base V1 positive: ')+mode)
333:  def base_cases(self,f):
334:   self.capability_pair(f)
335:   f.auth(ACTOR,(HERE/'approved-source3/fixtures/float0-paid-reader-still-refuses.sql').read_text())
336:   f.r.run((HERE/'approved-source3/fixtures/float0-private-coverage.sql').read_text())
337:   settings="set fixture.visible_project_id="+q(f.job_b)+";set fixture.visible_unit_id="+q(self.legacy.uid(30))+";set fixture.missing_unit_id="+q(self.legacy.uid(31))+';'
338:   f.auth(ACTOR,'begin;'+settings+(HERE/'approved-source3/fixtures/float0-existing-public-readers.sql').read_text()+'commit;')
339:   self.check(True,'Actual approved float contracts under fresh authenticated contexts')
```
