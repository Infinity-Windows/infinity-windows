\set VERBOSITY verbose
select jsonb_build_object('kind','login','pid',pg_backend_pid(),'backendStart',(select extract(epoch from backend_start)::text from pg_stat_activity where pid=pg_backend_pid()),'sessionUser',session_user,'currentUser',current_user,'zone',current_setting('TimeZone'),'statementTimeout',current_setting('statement_timeout'),'lockTimeout',current_setting('lock_timeout'));SET ROLE authenticated;SET request.jwt.claim.sub='00000000-0000-4000-8000-000000720003';select jsonb_build_object('kind','runtime','sessionUser',session_user,'currentUser',current_user,'jwtSubject',auth.uid(),'zone',current_setting('TimeZone'),'floatDigits',current_setting('extra_float_digits'),'statementTimeout',current_setting('statement_timeout'),'lockTimeout',current_setting('lock_timeout'));DO $$BEGIN IF session_user<>'authenticator' OR current_user<>'authenticated' OR auth.uid() IS DISTINCT FROM '00000000-0000-4000-8000-000000720003'::uuid OR current_setting('statement_timeout')<>'8s' OR current_setting('lock_timeout')<>'8s' THEN RAISE EXCEPTION 'Runtime identity or installed timeout changed';END IF;END$$;begin;set fixture.visible_project_id='00000000-0000-4000-8000-000000720011';set fixture.visible_unit_id='00000000-0000-4000-8000-000000720030';set fixture.missing_unit_id='00000000-0000-4000-8000-000000720031';-- UNEXECUTED: run at the candidate fixture seam as a genuine eligible
-- authenticated supervisor/owner, before any registered2 shift. The later
-- executor must provide an actually visible project and coherent unit whose
-- baseline review is proven. No identities, rows or grants are manufactured here.
-- The positive float1 calls below prevent invalid context from vacuously passing
-- the float0 unavailable assertions. Any unexpected SQL error fails the fixture.
-- Custom settings hold fixture IDs only; they are not provider attestation.
do $float_public$ declare project_id uuid;unit_id uuid;missing_unit_id uuid;r jsonb;baseline_review jsonb;
begin
 if current_setting('extra_float_digits') is distinct from '1' then raise exception 'Fixture requires initial float1';end if;
 project_id:=current_setting('fixture.visible_project_id')::uuid;
 unit_id:=current_setting('fixture.visible_unit_id')::uuid;
 missing_unit_id:=current_setting('fixture.missing_unit_id')::uuid;
 if project_id is null or unit_id is null or missing_unit_id is null or missing_unit_id=unit_id then raise exception 'Distinct fixture IDs required';end if;
 r:=public.work_activity_totals_read(project_id,unit_id);
 if r->>'availability' is distinct from 'available' then raise exception 'Totals positive prerequisite failed';end if;
 r:=public.work_unit_contributors_read(project_id,unit_id,1);
 if r->>'availability' is distinct from 'available' then raise exception 'Contributors positive prerequisite failed';end if;
 r:=public.work_unit_metadata_read(unit_id,1);
 if r->>'availability' is distinct from 'available' then raise exception 'Metadata positive prerequisite failed';end if;
 baseline_review:=public.work_unit_review_read(unit_id);
 if baseline_review->>'availability' is distinct from 'available' or baseline_review#>>'{review,qc,lifecycle}' is distinct from 'proven' then raise exception 'Proven review positive prerequisite failed';end if;
 r:=public.work_unit_review_read(missing_unit_id);
 if r-'asOf' is distinct from '{"protocolVersion":1,"availability":"unavailable","review":null}'::jsonb then raise exception 'Missing-unit prerequisite failed';end if;
 perform set_config('extra_float_digits','0',true);
 r:=public.work_activity_totals_read(project_id,unit_id);
 if r is distinct from '{"protocolVersion":1,"availability":"unavailable","totals":null}'::jsonb then raise exception 'Totals false-coverage response changed';end if;
 r:=public.work_unit_contributors_read(project_id,unit_id,1);
 if r is distinct from '{"protocolVersion":1,"availability":"unavailable","contributors":null}'::jsonb then raise exception 'Contributors false-coverage response changed';end if;
 r:=public.work_unit_metadata_read(unit_id,1);
 if r is distinct from '{"protocolVersion":1,"availability":"unavailable","metadata":null}'::jsonb then raise exception 'Metadata false-coverage response changed';end if;
 -- Review has a different existing contract: a valid view stays available,
 -- but its proof is unproven and its accepted-proof bit cannot remain true.
 r:=public.work_unit_review_read(unit_id);
 if (select array_agg(k order by k) from jsonb_object_keys(r) k) is distinct from array['asOf','availability','protocolVersion','review']::text[]
 or r->'protocolVersion' is distinct from '1'::jsonb or r->>'availability' is distinct from 'available'
 or jsonb_typeof(r->'asOf') is distinct from 'string'
 or (select array_agg(k order by k) from jsonb_object_keys(r->'review') k) is distinct from array['basis','basisStatus','capabilities','defects','dimensionVerification','observation','qc','work']::text[]
 or r#>>'{review,qc,lifecycle}' is distinct from 'unproven'
 or r#>'{review,qc,qcAccepted}' is distinct from 'false'::jsonb
 or r#>>'{review,qc,acceptance}'='accepted'
 then raise exception 'Review false-coverage response changed';end if;
 r:=public.work_unit_review_read(missing_unit_id);
 if r-'asOf' is distinct from '{"protocolVersion":1,"availability":"unavailable","review":null}'::jsonb
 or jsonb_typeof(r->'asOf') is distinct from 'string' then raise exception 'Missing-unit review response changed';end if;
 perform set_config('extra_float_digits','1',true);
 -- Restoration is an explicit fixture input reset, not production normalization.
end $float_public$;
commit;