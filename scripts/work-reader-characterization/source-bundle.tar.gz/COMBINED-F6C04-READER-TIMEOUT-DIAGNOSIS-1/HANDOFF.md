# Root/Claude handoff

Objective: diagnose the F6C04 genuine reader cancellation without changing frozen sources or running a database experiment.

Outcome: actual SQLSTATE57014 occurs in the first positive float1 metadata assignment, after totals/contributors passed inside one DO. Eight seconds applies to the whole DO, not to metadata alone. The old scope/helper/view/readers are exact authored-catalog matches; coverage dependencies change and metadata is new. The dense fixture predates candidate install. Baseline causality remains unmeasured.

Files: `DIAGNOSIS.md`, `CHARACTERIZATION-PLAN.md`, `INPUT-PINS.json`, `evidence/` and immutable `MANIFEST.json`. Only this new directory is owned/changed. Root's receipt remains the authority for all 1,828 artifact triples; the failed triple and selected source pins are independently verified here.

Checks: selected hashes, exact catalog entries, failed line/order, runtime script/profile match and source6 manifest pin verified with no database contact. No build, database test, fix, CI trigger, provider/installation/activation, commit, merge or deployment occurred. No root-owned restoration claim is expanded.

Decision: first perform one independently reviewed, bounded same-instance A/B characterization under unchanged eight-/twenty-second limits and full dense fixture. Retain the exact full gate and all assertions. Metadata is absent in common0846; do not fabricate a baseline or silently skip its call. Options depend on measured inherited-reader cost versus candidate overhead versus aggregate-DO cost.

Holds: full20/42/65 and all earlier functional, paid-wait, source-family, concurrency, volume, transport, provider, upgrade, compatibility and release requirements stay open. Source1–6, combined-catalog3 and prior metadata evidence remain unchanged. The producer preserved its predecessor state and retained clones; full pre-trial restoration is not proved here.

Peer review: actual Opus5.5 and Fable contacts belong to root after this freeze. Suggested split: Opus independently assess causal inference/guard-preserving options; Fable independently verify call ordering, timeout/settings evidence and that the plan retains the original gate. Require actual-model receipts; no peer participation is claimed yet.

Usage: live meter was 93% used at start and 94% used at the source/diagnosis phase boundary (6% remaining). Preserve the owner's 3% reserve and recheck before substantial follow-through. This package returns routine coordination to root.
